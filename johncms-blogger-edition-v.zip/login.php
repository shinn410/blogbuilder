<?php

define('_IN_JOHNCMS', 1);

$headmod = 'login';
$out = '';
$r = isset($_GET['redirect']) ? htmlentities(trim($_GET['redirect'])) : '';
if ($r != '') {
    if (!filter_var(urldecode($r), FILTER_VALIDATE_URL,
        FILTER_FLAG_SCHEME_REQUIRED))
        $r = '';
}
if (isset($_GET['token']) && isset($_GET['key']) && $r != "") {
    session_name("SESID");
    session_start();
    if (isset($_SESSION['uid']) && isset($_SESSION['ups'])) {
        unset($_SESSION['uid']);
        unset($_SESSION['ups']);
    }
    $uid = base64_decode($_GET['key']);
    $ups = urldecode($_GET['token']);
    $_SESSION['uid'] = $uid;
    $_SESSION['ups'] = $ups;
    header("Location: " . urldecode($r));
    exit();
}
require ('incfiles/core.php');
if (core::$user_id) {
    if ($r == "") {
        header("Location: " . $home . "/index.php");
        exit;
    }
    else {
        $url = strtolower(parse_url(urldecode($r), PHP_URL_HOST));
        $sqlreq = mysql_query("SELECT * FROM `blog_sites` WHERE `url` = '" .
            mysql_real_escape_string($url) . "' OR `url2` = '" .
            mysql_real_escape_string($url) . "'");
        if (mysql_num_rows($sqlreq)) {
            $pass = substr($datauser['password'], 2, 2);
            //$salt = openssl_random_pseudo_bytes(22);
            //$salt = '$2a$%13$' . strtr($salt, array('_' => '.', '~' => '/'));
            //$password_hash = crypt($pass, $salt);
            $password_hash = md5($pass);
            $token = $password_hash;
            $cuid = base64_encode($user_id);
            header("Location: http://" . $url . "/login.php?__site=true&token=" .
                urlencode($token) . "&key=" . $cuid . "&redirect=" . urlencode($r));
            exit();
        }
        else {
            header("Location: " . $home . "/index.php");
            exit();
        }
    }
    header('Location: ' . $home . '/index.php');
    exit();
}

$error = array();
$captcha = false;
$display_form = 1;
$user_login = isset($_POST['n']) ? functions::check($_POST['n']) : null;
$user_pass = isset($_POST['p']) ? functions::check($_POST['p']) : null;
$user_mem = isset($_POST['mem']) ? 1 : 0;
$user_code = isset($_POST['code']) ? strtolower(trim($_POST['code'])) : null;
if ($user_pass && !$user_login)
    $error[] = $lng['error_login_empty'];
if ($user_login && !$user_pass)
    $error[] = $lng['error_empty_password'];
if ($user_login && (mb_strlen($user_login) < 2 || mb_strlen($user_login) > 20))
    $error[] = $lng['nick'] . ': ' . $lng['error_wrong_lenght'];
if ($user_pass && (mb_strlen($user_pass) < 3 || mb_strlen($user_pass) > 15))
    $error[] = $lng['password'] . ': ' . $lng['error_wrong_lenght'];
if (!$error && $user_pass && $user_login) {

    $req = mysql_query("SELECT * FROM `users` WHERE `name_lat`='" . functions::rus_lat
        (mb_strtolower($user_login)) . "' LIMIT 1");
    if (mysql_num_rows($req)) {
        $user = mysql_fetch_assoc($req);
        if ($user['failed_login'] > 2) {
            if ($user_code) {
                if (mb_strlen($user_code) > 3 && $user_code == strtolower($_SESSION['code'])) {

                    unset($_SESSION['code']);
                    $captcha = true;
                }
                else {

                    unset($_SESSION['code']);
                    $error[] = $lng['error_wrong_captcha'];
                }
            }
            else {

                $display_form = 0;
                $out .= '<form class="login-form" role="form" action="' . $home .
                    '/login.php' . ($id ? '/id/' . $id : '') . '?redirect=' .
                    urlencode($r) . '" method="post">' .
                    '<div class="body bg-gray"><div class="form-group">' .
                    '<label>' . $lng['enter_code'] .
                    '</label><p><img class="img-responsive" src="' . $set['homeurl'] .
                    '/captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng['verifying_code'] .
                    '"/></p><input class="form-control" type="text" maxlength="5"  name="code"/>' .
                    '</div></div><div class="footer">' .
                    '<button class="btn bg-light-blue btn-block" type="submit" name="submit">' .
                    $lng['continue'] . '</button></div>' .
                    '<input type="hidden" name="n" value="' . $user_login .
                    '"/><input type="hidden" name="p" value="' . $user_pass .
                    '"/><input type="hidden" name="mem" value="' . $user_mem .
                    '"/></form>';
            }
        }
        if ($user['failed_login'] < 3 || $captcha) {
            if (md5(md5($user_pass)) == $user['password']) {

                $display_form = 0;
                mysql_query("UPDATE `users` SET `failed_login` = '0' WHERE `id` = '" .
                    $user['id'] . "'");
                if (!$user['preg']) {

                    $error[] = $lng['registration_not_approved'];
                }
                else {

                    if (isset($_POST['mem'])) {

                        $cuid = base64_encode($user['id']);
                        $cups = md5($user_pass);
                        setcookie("cuid", $cuid, time() + 3600 * 24 * 365);
                        setcookie("cups", $cups, time() + 3600 * 24 * 365);
                    }

                    $_SESSION['uid'] = $user['id'];
                    $_SESSION['ups'] = md5(md5($user_pass));
                    mysql_query("UPDATE `users` SET `sestime` = '" . time() .
                        "' WHERE `id` = '" . $user['id'] . "'");
                    if ($r != '') {
                        $url = strtolower(parse_url(urldecode($r), PHP_URL_HOST));
                        $sqlreq = mysql_query("SELECT * FROM `blog_sites` WHERE `url` = '" .
                            mysql_real_escape_string($url) . "' OR `url2` = '" .
                            mysql_real_escape_string($url) . "'");
                        if (mysql_num_rows($sqlreq)) {
                            $pass = substr($user['password'], 2, 2);
                            //$salt = openssl_random_pseudo_bytes(22);
                            //$salt = '$2a$%13$' . strtr($salt, array('_' => '.',
                            //'~' => '/'));
                            //$password_hash = crypt($pass, $salt);
                            $password_hash = md5($pass);
                            $token = $password_hash;
                            $cuid = base64_encode($user['id']);
                            header("Location: http://" . $url .
                                "/login.php?__site=true&token=" . urlencode($token) .
                                "&key=" . $cuid . "&redirect=" . urlencode($r));
                        }
                        else {
                            header("Location: " . $home . "/index.php");
                        }
                        exit();
                    }
                    $set_user = unserialize($user['set_user']);
                    if ($user['lastdate'] < (time() - 3600) && $set_user['digest'])
                        header('Location: ' . $set['homeurl'] .
                            '/index.php/act/digest/last/' . $user['lastdate']);
                    else
                        header('Location: ' . $set['homeurl'] . '/index.php');
                    exit();
                    $out .= '<div class="gmenu"><p><b><a href="' . $home .
                        '/index.php/act/digest">' . $lng['enter_on_site'] .
                        '</a></b></p></div>';
                }
            }
            else {

                if ($user['failed_login'] < 3) {

                    mysql_query("UPDATE `users` SET `failed_login` = '" . ($user['failed_login'] +
                        1) . "' WHERE `id` = '" . $user['id'] . "'");
                }
                $error[] = $lng['authorisation_not_passed'];
            }
        }
    }
    else {
        $error[] = $lng['authorisation_not_passed'];
    }
}
if ($display_form) {
    if ($error) {
        $err = '<div class="alert alert-danger flat">' . implode('br />', $error) .
            '</div>';

    }

    $info = '';
    if (core::$system_set['site_access'] == 0 || core::$system_set['site_access'] ==
        1) {
        if (core::$system_set['site_access'] == 0) {
            $info = '<div class="callout callout-danger">' . $lng['info_only_sv'] .
                '</div>';
        }
        elseif (core::$system_set['site_access'] == 1) {
            $info = '<div class="callout callout-danger">' . $lng['info_only_adm'] .
                '</div>';
        }
    }

    $out .= '<form class="login-form" role="form" action="' . $home .
        '/login.php?redirect=' . urlencode($r) .
        '" method="post"><div class="body bg-gray">' . $info . (isset($err) ? $err :
        '') . '<div class="form-group">' .
        '<input class="form-control" type="text" name="n" value="' .
        htmlentities($user_login, ENT_QUOTES, 'UTF-8') .
        '" maxlength="20" placeholder="' . $lng['login_name'] .
        '"/></div><div class="form-group">' .
        '<input class="form-control" type="password" name="p" maxlength="20" placeholder="' .
        $lng['password'] . '"/>' .
        '</div><div class="form-group"><input type="checkbox" name="mem" value="1" checked="checked"/>&nbsp;' .
        $lng['remember'] .
        '</div></div><div class="footer"><button class="btn bg-light-blue btn-block" type="submit">' .
        $lng['login'] . '</button><p><a href="' . $home .
        '/users/skl.php/continue">' . $lng['forgotten_password'] .
        '?</a></p><a class="text-center" href="' . $set['homeurl'] .
        '/registration.php">' . $lng['registration'] . '</a></div></form>';
}

$breadcrumb = functions::breadcrumb(array(array('label' => $lng['login'])));
$textl = $lng['login'];

echo '<!DOCTYPE html><html class="bg-black"><head><meta charset="UTF-8"/>' .
    '<title>' . $textl . '</title>' .
    '<meta content="width=device-width, initial-scale=1, ' .
    'maximum-scale=1, user-scalable=no" name="viewport"><!-- bootstrap 3.2.0 -->' .
    '<link href="' . $home .
    '/theme/web/default/css/bootstrap.min.css" rel="stylesheet" type="text/css" />' .
    '<!-- font Awesome --><link href="' . $home .
    '/theme/web/default/css/font-awesome.min.css" rel="stylesheet" type="text/css" />' .
    '<!-- Theme style --><link href="' . $home .
    '/theme/web/default/css/style.css" rel="stylesheet" type="text/css" />' .
    '<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->' .
    '<!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->' .
    '<!--[if lt IE 9]><script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>' .
    '<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script><![endif]-->' .
    '</head><body class="bg-black"><div class="form-box" id="login-box"><div class="header bg-light-blue">' .
    $textl . '</div>';
echo $out;
echo '<div class="margin text-center"><span>&copy; ' . htmlspecialchars($set['copyright'],
    ENT_QUOTES, 'UTF-8') . '</span><br/>' .
    '<a class="btn bg-light-blue btn-circle" href="' . $home .
    '/"><i class="fa fa-home"></i></a></div>';
echo '</div><script src="' . $home .
    '/theme/web/default/js/jquery-2.1.1.min.js"></script>' .
    '<!-- Bootstrap --><script src="' . $home .
    '/theme/web/default/js/bootstrap.min.js" type="text/javascript"></script>' .
    '</body></html>';
