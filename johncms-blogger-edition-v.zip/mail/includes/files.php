<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = 'mail';
$textl = $lng['files'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['personal'], 'url' => 'users/profile.php/act/office'),
    array('label' => $lng['mail'], 'url' => 'mail/index.php/act/input'),
    array('label' => $lng['files']),
    ));
require_once ('../incfiles/head.php');
//Отображаем список файлов
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE (`user_id`='$user_id' OR `from_id`='$user_id') AND `delete`!='$user_id' AND `file_name`!=''"),
    0);
if ($total)
{
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/mail/index.php/act/files/', $start, $total, $kmess) . '</div>';
    $req = mysql_query("SELECT `cms_mail`.*, `users`.`name`
        FROM `cms_mail`
        LEFT JOIN `users` ON `cms_mail`.`user_id`=`users`.`id`
	    WHERE (`cms_mail`.`user_id`='$user_id' OR `cms_mail`.`from_id`='$user_id')
	    AND `cms_mail`.`delete`!='$user_id'
	    AND `cms_mail`.`file_name`!=''
	    ORDER BY `cms_mail`.`time` DESC
	    LIMIT " . $start . "," . $kmess);
    for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++$i)
    {
        echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
        echo '<a href="' . $set['homeurl'] . '/users/profile.php/user/' . $row['user_id'] .
            '"><b>' . $row['name'] . '</b></a>:: <a href="' . $set['homeurl'] .
            '/mail/index.php/act/load/id/' . $row['id'] . '">' . $row['file_name'] .
            '</a> (' . formatsize($row['size']) . ') (' . $row['count'] . ')';
        echo '</div>';
    }
}
else
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}

echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/mail/index.php/act/files/', $start, $total, $kmess) . '</div>';
}

echo '<p>' . functions::link_back($lng['personal'],
    'users/profile.php/act/office', false) . '</p>';
