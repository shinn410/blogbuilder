<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = 'mail';
$textl = $lng_mail['contacts'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['personal'], 'url' => 'users/profile.php/act/office'),
    array('label' => $lng_mail['contacts']),
    ));
require_once ('../incfiles/head.php');
if (isset($_GET['del']))
{
    if ($id)
    {

        $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
        if (mysql_num_rows($req) == 0)
        {
            echo functions::display_error($lng['error_user_not_exist']);
            require_once ("../incfiles/end.php");
            exit;
        }

        if (isset($_POST['submit']))
        {
            if (isset($_SESSION['ref']))
            {
                $ref = $_SESSION['ref'];
                unset($_SESSION['ref']);
            }
            else
            {
                $ref = 'mail/index.php';
            }
            $q = mysql_query("SELECT * FROM `cms_contact` WHERE `user_id`='" . $user_id .
                "' AND `from_id`='" . $id . "' AND `ban`='1'");
            if (mysql_num_rows($q) == 0)
            {
                echo '<div class="alert alert-danger"><p>' . $lng_mail['user_not_block'] .
                    '</p><p><a class="alert-link" href="' . $ref . '">' . $lng['continue'] .
                    ' &rarr;</a></p></div>';
            }
            else
            {
                mysql_query("UPDATE `cms_contact` SET `ban`='0' WHERE `user_id`='$user_id' AND `from_id`='$id' AND `ban`='1';");
                echo '<div class="alert alert-danger"><p>' . $lng_mail['user_enabled'] .
                    '</p><p><a class="alert-link" href="' . $ref . '">' . $lng['continue'] .
                    ' &rarr;</a></p></div>';
            }
        }
        else
        {
            echo '<form role="form" action="' . $set['homeurl'] .
                '/mail/index.php/act/ignor/id/' . $id . '/del" method="post">' .
                '<div class="alert alert-warning">' . $lng_mail['really_enabled_contact'] .
                '</div>' .
                '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng_mail['enabled'] . '"/></p>' . '</form>';
            $_SESSION['ref'] = isset($_SERVER['HTTP_REFERER']) ?
                htmlspecialchars($_SERVER['HTTP_REFERER']) : 'mail/index.php';
            echo '<p>' . functions::link_back($lng['back'], (isset($_SERVER['HTTP_REFERER']) ?
                htmlspecialchars($_SERVER['HTTP_REFERER']) :
                'mail/index.php/act/ignor')) . '</p>';
        }
    }
    else
    {
        echo functions::display_error($lng_mail['no_contact_is_chose']);
    }
}
elseif (isset($_GET['add']))
{
    if ($id)
    {
        $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1;");
        if (mysql_num_rows($req) == 0)
        {
            echo functions::display_error($lng['error_user_not_exist']);
            require_once ("../incfiles/end.php");
            exit;
        }
        $res = mysql_fetch_assoc($req);

        if (isset($_POST['submit']))
        {
            if (isset($_SESSION['ref']))
            {
                $ref = $_SESSION['ref'];
                unset($_SESSION['ref']);
            }
            else
            {
                $ref = 'mail/index.php';
            }
            if ($res['rights'] > $rights)
            {
                echo '<div class="alert alert-danger"><p>' . $lng_mail['user_impossible_block'] .
                    '</p><p><a class="alert-link" href="' . $ref . '">' . $lng['continue'] .
                    ' &rarr;</a></p></div>';
            }
            else
            {
                $q = mysql_query("SELECT * FROM `cms_contact`
				WHERE `user_id`='" . $user_id . "' AND `from_id`='" . $id . "';");
                if (mysql_num_rows($q) == 0)
                {
                    mysql_query("INSERT INTO `cms_contact` SET
					`user_id` = '" . $user_id . "',
					`from_id` = '" . $id . "',
					`time` = '" . time() . "',
					`ban`='1';");
                }
                else
                {
                    mysql_query("UPDATE `cms_contact` SET `ban`='1', `friends`='0', `type`='1' WHERE `user_id`='$user_id' AND `from_id`='$id';");
                    mysql_query("UPDATE `cms_contact` SET `friends`='0', `type`='1' WHERE `user_id`='$id' AND `from_id`='$user_id';");
                }
                echo '<div class="alert alert-success"><p>' . $lng_mail['user_block'] .
                    '</p><p><a class="alert-link" href="' . $ref . '">' . $lng['continue'] .
                    '  &rarr;</a></p></div>';
            }
        }
        else
        {
            echo '<form role="form" action="' . $set['homeurl'] .
                '/mail/index.php/act/ignor/id/' . $id . '/add" method="post">' .
                '<div class="alert alert-warning">' . $lng_mail['really_block_contact'] .
                '</div>' .
                '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng_mail['block'] . '"/></p>' . '</form>';
            $_SESSION['ref'] = isset($_SERVER['HTTP_REFERER']) ?
                htmlspecialchars($_SERVER['HTTP_REFERER']) : 'mail/index.php';
            echo '<p>' . functions::link_back($lng['back'], (isset($_SERVER['HTTP_REFERER']) ?
                htmlspecialchars($_SERVER['HTTP_REFERER']) : 'mail/index.php')) .
                '</p>';
        }
    }
    else
    {
        echo functions::display_error($lng_mail['no_contact_is_chose']);
    }
}
else
{
    echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li><a href="' .
        $set['homeurl'] . '/mail/index.php"><i class="fa fa-users"></i> ' . $lng_mail['my_contacts'] .
        '</a></li><li class="active"><a href="#"><i class="fa fa-ban"></i> ' . $lng_mail['blocklist'] .
        '</a></li></ul><div class="tab-content">';

    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id` = '" .
        $user_id . "' AND `ban`='1'"), 0);
    if ($total)
    {
        $req = mysql_query("SELECT `users`.* FROM `cms_contact`
		    LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
		    WHERE `cms_contact`.`user_id`='" . $user_id . "'
		    AND `ban`='1'
		    ORDER BY `cms_contact`.`time` DESC
		    LIMIT $start, $kmess");

        for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++$i)
        {
            echo $i % 2 ? '<div class="list1">' : '<div class="list2">';

            $subtext = '<a href="' . $set['homeurl'] .
                '/mail/index.php/act/write/id/' . $row['id'] .
                '"><span class="glyphicon glyphicon-comment"></span> ' . $lng_mail['correspondence'] .
                '</a> | <a href="' . $set['homeurl'] .
                '/mail/index.php/act/deluser/id/' . $row['id'] .
                '" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal"><span class="glyphicon glyphicon-remove"></span> ' .
                $lng['delete'] . '</a> | <a href="' . $set['homeurl'] .
                '/mail/index.php/act/ignor/id/' . $row['id'] .
                '/del" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal"><span class="glyphicon glyphicon-ban-circle"></span> ' .
                $lng_mail['enabled'] . '</a>';
            $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='{$row['id']}' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='{$row['id']}')) AND `delete`!='$user_id' AND `sys`!='1' AND `spam`!='1';"),
                0);
            $new_count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `cms_mail`.`user_id`='$user_id' AND `cms_mail`.`from_id`='{$row['id']}' AND `read`='0' AND `delete`!='$user_id' AND `sys`!='1' AND `spam`!='1';"),
                0);
            $arg = array('header' => '(' . $count_message . ($new_count_message ?
                    '/<span class="red">+' . $new_count_message . '</span>' : '') .
                    ')', 'sub' => $subtext);
            echo functions::display_user($row, $arg);
            echo '</div>';
        }
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }
    echo '</div></div>';
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/mail/index.php/act/ignor/', $start, $total, $kmess) . '</div>';
    }
}
