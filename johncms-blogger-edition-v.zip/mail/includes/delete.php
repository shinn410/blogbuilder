<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = 'mail';
$textl = $lng_mail['deleted_messages'];
if ($id)
{

    $req = mysql_query("SELECT * FROM `cms_mail` WHERE (`user_id`='$user_id' OR `from_id`='$user_id') AND `id` = '$id' AND `delete`!='$user_id' LIMIT 1;");
    if (mysql_num_rows($req) == 0)
    {
        require_once ('../incfiles/head.php');
        echo functions::display_error($lng_mail['messages_does_not_exist']);
        require_once ("../incfiles/end.php");
        exit;
    }
    $res = mysql_fetch_assoc($req);
    if ($res['sys'])
    {
        $breadcrumb = functions::breadcrumb(array(
            array('label' => $lng['personal'], 'url' =>
                    'users/profile.php/act/office'),
            array('label' => $lng['mail'], 'url' => 'mail/index.php/act/input'),
            array('label' => $lng_mail['systems_messages'], 'url' =>
                    'mail/index.php/act/systems'),
            array('label' => $lng_mail['deleted_messages']),
            ));
    }
    else
    {
        $breadcrumb = functions::breadcrumb(array(
            array('label' => $lng['personal'], 'url' =>
                    'users/profile.php/act/office'),
            array('label' => $lng['mail'], 'url' => 'mail/index.php/act/input'),
            array('label' => $lng_mail['correspondence'], 'url' =>
                    'mail/index.php/act/write/id/' . ($res['user_id'] == $user_id ?
                    $res['from_id'] : $res['user_id'])),
            array('label' => $lng_mail['deleted_messages']),
            ));
    }
    require_once ('../incfiles/head.php');
    if (isset($_POST['submit']))
    {


        if ($res['sys'])
        {
            mysql_query("DELETE FROM `cms_mail` WHERE `from_id`='$user_id' AND `id` = '$id' AND `sys`='1' LIMIT 1");
            echo '<div class="alert alert-success"><p>' . $lng_mail['messages_delete_ok'] .
                '</p>' . '<p><a href="' . $set['homeurl'] .
                '/mail/index.php/act/systems">&larr; ' . $lng['back'] .
                '</a></p></div>';
        }
        else
        {

            if ($res['read'] == 0 && $res['user_id'] == $user_id)
            {

                if ($res['file_name'])
                    @unlink('../files/mail/' . $res['file_name']);
                mysql_query("DELETE FROM `cms_mail` WHERE `user_id`='$user_id' AND `id` = '$id' LIMIT 1");
            }
            else
            {

                if ($res['delete'])
                {

                    if ($res['file_name'])
                        @unlink('../files/mail/' . $res['file_name']);
                    mysql_query("DELETE FROM `cms_mail` WHERE (`user_id`='$user_id' OR `from_id`='$user_id') AND `id` = '$id' LIMIT 1");
                }
                else
                {
                    mysql_query("UPDATE `cms_mail` SET `delete` = '$user_id' WHERE `id` = '$id' LIMIT 1");
                }
            }
            echo '<div class="alert alert-success"><p>' . $lng_mail['messages_delete_ok'] .
                '</p>' . '<p><a href="' . $set['homeurl'] .
                '/mail/index.php/act/write/id/' . ($res['user_id'] == $user_id ?
                $res['from_id'] : $res['user_id']) . '">&larr; ' . $lng['back'] .
                '</a></p></div>';
        }
    }
    else
    {
        echo '<form role="form" action="' . $set['homeurl'] .
            '/mail/index.php/act/delete/id/' . $id . '" method="post">' .
            '<div class="alert alert-warning">' . $lng_mail['really_delete_message'] .
            '</div>' .
            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['delete'] .
            '"/>&nbsp;<a data-dismiss="modal" class="btn btn-default" href="' . ($res['sys'] ?
            $home . '/mail/index.php/act/systems' : $home .
            '/mail/index.php/act/write/id/' . ($res['user_id'] == $user_id ? $res['from_id'] :
            $res['user_id'])) . '">' . $lng['cancel'] . '<a></p></form>';
    }
}
else
{
    require_once ('../incfiles/head.php');
    echo '<div class="alert alert-danger">' . $lng_mail['not_message_is_chose'] .
        '</div>';
}
