<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$out = '';
$total = 0;

if ($mod == 'clear')
{
    if (isset($_POST['clear']))
    {
        $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `sys`='1';"),
            0);
        if ($count_message)
        {
            $req = mysql_query("SELECT `id` FROM `cms_mail` WHERE `from_id`='$user_id' AND `sys`='1' LIMIT " .
                $count_message);
            $mass_del = array();
            while (($row = mysql_fetch_assoc($req)) !== false)
            {
                $mass_del[] = $row['id'];
            }
            if ($mass_del)
            {
                $result = implode(',', $mass_del);
                mysql_query("DELETE FROM `cms_mail` WHERE `id` IN (" . $result .
                    ")");
            }
        }
        $out .= '<div class="alert alert-success">' . $lng_mail['messages_are_removed'] .
            '</div>';
    }
    else
    {
        $out .= '<form role="form" action="' . $set['homeurl'] .
            '/mail/index.php/act/systems/mod/clear" method="post">' .
            '<div class="alert alert-danger">' . $lng_mail['really_messages_removed'] .
            '</div>' .
            '<p><input class="btn btn-primary" type="submit" name="clear" value="' .
            $lng['delete'] . '"/> <a class="btn btn-default" href="' . $set['homeurl'] .
            '/mail/index.php/act/systems/" data-dismiss="modal">' . $lng['cancel'] .
            '</a></p>' . '</form>';
    }
    $textl = $lng_mail['clear_messages'];
    $breadcrumb = functions::breadcrumb(array(
        array('label' => $lng['personal'], 'url' =>
                'users/profile.php/act/office'),
        array('label' => $lng['mail'], 'url' => 'mail/index.php/act/input'),
        array('label' => $lng_mail['systems_messages'], 'url' =>
                'mail/index.php/act/systems'),
        array('label' => $lng_mail['clear_messages']),
        ));
    require_once ('../incfiles/head.php');

    echo $out;
    require_once ('../incfiles/end.php');
    exit();
}
else
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `sys`='1' AND `delete`!='$user_id';"),
        0);
    if ($total)
    {
        function time_parce($var)
        {
            return functions::display_date($var[1]);
        }

        $req = mysql_query("SELECT * FROM `cms_mail` WHERE `from_id`='$user_id' AND `sys`='1' AND `delete`!='$user_id' ORDER BY `time` DESC LIMIT " .
            $start . "," . $kmess);
        $mass_read = array();
        for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++$i)
        {
            $out .= $i % 2 ? '<div class="list1">' : '<div class="list2">';
            if ($row['read'] == 0 && $row['from_id'] == $user_id)
                $mass_read[] = $row['id'];
            $post = $row['text'];
            $post = functions::checkout($post, 1, 1);
            if ($set_user['smileys'])
                $post = functions::smileys($post);
            $out .= '<strong>' . functions::checkout($row['them']) .
                '</strong> (' . functions::display_date($row['time']) .
                ')<br />';
            $post = preg_replace_callback("/{TIME=(.+?)}/usi", 'time_parce', $post);

            $out .= $post;
            $out .= '<div class="sub"><a href="' . $set['homeurl'] .
                '/mail/index.php/act/delete/id/' . $row['id'] .
                '" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal"><i class="fa fa-times"></i> ' . $lng['delete'] .
                '</a></div>';
            $out .= '</div>';
        }

        if ($mass_read)
        {
            $result = implode(',', $mass_read);
            mysql_query("UPDATE `cms_mail` SET `read`='1' WHERE `from_id`='$user_id' AND `sys`='1' AND `id` IN (" .
                $result . ")");
        }
    }
    else
    {
        $out .= '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }

    if ($total > $kmess)
    {
        $out .= '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/mail/index.php/act/systems/', $start, $total, $kmess) . '</div>';
    }
}

$textl = $lng['mail'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['personal'], 'url' => 'users/profile.php/act/office'),
    array('label' => $lng['mail']),
    ));
require_once ('../incfiles/head.php');
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs">' . '<li><a href="' .
    $set['homeurl'] .
    '/mail/index.php/act/input"><i class="fa fa-mail-forward"></i> ' . $lng_mail['input_messages'] .
    '</a></li>' . '<li><a href="' . $set['homeurl'] .
    '/mail/index.php/act/output"><i class="fa fa-mail-reply"></i> ' . $lng_mail['sent_messages'] .
    '</a></li><li class="active"><a hre="#"><i class="fa fa-info-circle"></i> ' .
    $lng_mail['systems_messages'] . '</a></li>' .
    '</ul><div class="tab-content">';
if ($total)
{
    echo '<p class="margin"><a class="btn btn-danger btn-sm btn-flat" data-target="#global-modal"  data-toggle="' .
        functions::set_modal() . '" href="' . $home .
        '/mail/index.php/act/systems/mod/clear"><i class="fa fa-times"></i> ' .
        $lng_mail['clear_messages'] . '</a></p>';
}
echo $out;
echo '</div></div>';
