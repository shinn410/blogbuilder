<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

require ('../incfiles/core.php');
$headmod = 'gallery';
$lng_gal = core::load_lng('gallery');
$textl = $lng['gallery'];
$main_header = 1;
require ('../incfiles/head.php');

function get_gal($id)
{
    $req = mysql_query("select * from `gallery` where id='" . abs(intval($id)) .
        "';");
    if (mysql_num_rows($req) == 0)
        return false;
    return mysql_fetch_array($req);
}

$error = '';
if (!$set['mod_gal'] && $rights < 7)
    $error = $lng_gal['gallery_closed'];
elseif ($set['mod_gal'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error)
{
    echo '<div class="alert alert-danger"><p>' . $error . '</p></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$array = array(
    'new',
    'edf',
    'delf',
    'edit',
    'del',
    'load',
    'upl',
    'cral',
    'razd',
    );
if (in_array($act, $array) && file_exists($act . '.php'))
{
    require_once ($act . '.php');
}
else
{
    $i = isset($i) ? $i : 0;
    if (!$set['mod_gal'])
        echo '<div class="alert alert-warning">' . $lng_gal['gallery_closed'] .
            '</div>';
    $ms = get_gal($id);
    if ($ms != false)
    {
        switch ($ms['type'])
        {
            case 'rz':
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                            $lng['gallery'], 'url' => 'gallery/'), array('label' =>
                            $ms['text'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `type` = 'al' AND `refid` = '$id'"),
                    0);
                if ($total)
                {
                    echo '<div class="list-group">';
                    $req = mysql_query("SELECT * FROM `gallery` WHERE `type` = 'al' AND `refid` = '$id' ORDER BY `time` DESC LIMIT $start, $kmess");
                    while ($res = mysql_fetch_assoc($req))
                    {
                        $total_f = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `type` = 'ft' AND `refid` = '" .
                            $res['id'] . "'"), 0);
                        echo '<a class="list-group-item" href="' . $set['homeurl'] .
                            '/gallery/index.php/id/' . $res['id'] .
                            '"><i class="fa fa-picture-o"></i> ' . $res['text'] .
                            ' <span class="badge">' . $total_f . '</span></a>';
                        ++$i;
                    }
                    echo '</div>';
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                        '</p></div>';
                }

                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/gallery/index.php/id/' . $id . '/', $start, $total, $kmess) .
                        '</p>';
                }
                if ($rights >= 6)
                {
                    echo "<hr class='hidden-xs'/><ul class='nav nav-pills'>" .
                        "<li><a href='" . $home .
                        "/gallery/index.php/act/cral/id/" . $id .
                        "' data-toggle='modal' data-target='#global-modal'><i class=\"fa fa-plus\"></i> " .
                        $lng_gal['create_album'] . "</a></li>" . "<li><a href='" .
                        $home . "/gallery/index.php/act/del/id/" . $id .
                        "' data-toggle='modal' data-target='#global-modal'>" .
                        "<i class=\"fa fa-times\"></i> " . $lng_gal['delete_section'] .
                        "</a></li>" . "<li><a href='" . $home .
                        "/gallery/index.php/act/edit/id/" . $id .
                        "' data-toggle='modal' data-target='#global-modal'><i class=\"fa fa-edit\"></i> " .
                        $lng_gal['edit_section'] . "</a></li>" . "</ul>";
                }
                echo '<p>' . functions::link_back($lng_gal['to_gallery'],
                    'gallery/index.php') . '</p>';
                break;

            case 'al':
                $delimag = opendir("temp");
                while ($imd = readdir($delimag))
                {
                    if ($imd != "." && $imd != ".." && $imd !=
                        "gallery/index.php")
                    {
                        $im[] = $imd;
                    }
                }
                closedir($delimag);
                $totalim = count($im);
                for ($imi = 0; $imi < $totalim; $imi++)
                {
                    $filtime[$imi] = filemtime("temp/$im[$imi]");
                    $tim = time();
                    $ftime1 = $tim - 10;
                    if ($filtime[$imi] < $ftime1)
                    {
                    }
                }
                $rz = mysql_query("select * from `gallery` where type='rz' and  id='" .
                    $ms['refid'] . "';");
                $rz1 = mysql_fetch_array($rz);
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['gallery'], 'url' => 'gallery/'),
                    array('label' => $rz1['text'], 'url' =>
                            'gallery/index.php/id/' . $ms['refid']),
                    array('label' => $ms['text'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `type` = 'ft' AND `refid` = '$id'"),
                    0);
                $req = mysql_query("SELECT * FROM `gallery` WHERE `type` = 'ft' AND `refid` = '$id' ORDER BY `time` DESC LIMIT $start, $kmess");
                if ($total)
                {
                    echo '<div class="row">';
                    while ($fot1 = mysql_fetch_array($req))
                    {
                        echo
                            '<div class="col-xs-6 col-sm-3 col-md-2"><a class="thumbnail" href="' .
                            $set['homeurl'] . '/gallery/index.php/id/' . $fot1['id'] .
                            '"><img class="img-responsive" src="' . $set['homeurl'] .
                            '/gallery/temp/' . $fot1['name'] . '.sm.png"/></a>' . ($rights >=
                            6 ? "<div class='text-center' style=\"margin-bottom:10px;margin-top:-8px;\"><a href='" .
                            $home . "/gallery/index.php/act/edf/id/" . $fot1['id'] .
                            "' data-toggle=\"" . functions::set_modal() . "\" data-target=\"#global-modal\"><i class=\"fa fa-edit\"></i> " .
                            $lng['edit'] . "</a>&nbsp;<a data-toggle=\"" .
                            functions::set_modal() . "\" data-target=\"#global-modal\" href='" .
                            $home . "/gallery/index.php/act/delf/id/" . $fot1['id'] .
                            "'><i class=\"fa fa-times\"></i> " . $lng['delete'] .
                            "</a></div>" : "") . '<!--';
                        echo $i % 2 ? '<div class="list2">' :
                            '<div class="list1">';
                        echo '<div class="media">';
                        echo
                            '<div class="pull-left"><a class="thumbnail" href="' .
                            $set['homeurl'] . '/gallery/index.php/id/' . $fot1['id'] .
                            '"><img alt="" src="' . $set['homeurl'] .
                            '/gallery/temp/' . $fot1['name'] .
                            '.sm.png"/></a></div>';
                        echo '<div class="media-body">';
                        if (!empty($fot1['text']))
                            echo '<div>' . $fot1['text'] . '</div>';
                        else
                            echo '<div> </div>';
                        echo '</div></div>' . ($rights >= 6 ?
                            "<div class='sub' style='padding:0px;'><a href='" .
                            $home . "/gallery/index.php/act/edf/id/" . $fot1['id'] .
                            "'><span class=\"glyphicon glyphicon-edit\"></span> " .
                            $lng['edit'] . "</a> | <a href='" . $home .
                            "/gallery/index.php/act/delf/id/" . $fot1['id'] .
                            "'><span class=\"glyphicon glyphicon-remove\"></span> " .
                            $lng['delete'] . "</a></div>" : "") . '</div>-->';
                        ++$i;
                        echo '</div>';
                    }
                    echo '</div>';
                }
                else
                {
                    echo '<div class="alert alert-warning">' . $lng['list_empty'] .
                        '</div>';
                }
                echo '<p>';
                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/gallery/index.php/id/' . $id . '/', $start, $total, $kmess) .
                        '</p>';
                }
                $link = '';
                if (($user_id && $rz1['user'] == 1 && $ms['text'] == $login && !
                    $ban['1'] && !$ban['14']) || $rights >= 6)
                {
                    $link .= '<li><a href="' . $set['homeurl'] .
                        '/gallery/index.php/act/upl/id/' . $id .
                        '"><i class="fa fa-upload"></i> ' . $lng_gal['upload_photo'] .
                        '</a></li>';
                }
                if ($rights >= 6)
                {
                    $link .=
                        "<li><a data-toggle='modal' data-target='#global-modal' href='" .
                        $home . "/gallery/index.php/act/del/id/" . $id .
                        "'><i class=\"fa fa-times\"></i> " . $lng_gal['delete_album'] .
                        "</a></li>";
                    $link .=
                        "<li><a data-toggle='modal' data-target='#global-modal' href='" .
                        $home . "/gallery/index.php/act/edit/id/" . $id .
                        "'><i class=\"fa fa-edit\"></i> " . $lng_gal['edit_album'] .
                        "</a></li>";
                }
                if ($link != '')
                    echo '<hr class="hidden-xs"/><ul class="nav nav-pills">' . $link .
                        '</ul>';
                echo '<p>' . functions::link_back($lng_gal['to_gallery'],
                    'gallery/index.php') . '</p>';
                break;

            case 'ft':
                $rz = mysql_query("select `id`,`refid`,`text` from `gallery` where id='" .
                    $ms['refid'] . "';");
                $rz = mysql_fetch_array($rz);
                $ka = mysql_query("select `id`,`refid`,`text` from `gallery` where id='" .
                    $rz['refid'] . "';");
                $ka = mysql_fetch_array($ka);
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['gallery'], 'url' => 'gallery/'),
                    array('label' => $ka['text'], 'url' =>
                            'gallery/index.php/id/' . $ka['id']),
                    array('label' => $rz['text'], 'url' =>
                            'gallery/index.php/id/' . $rz['id']),
                    array('label' => 'Foto #' . $ms['id'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                $infile = "foto/{$ms['name']}";
                $fotsz = filesize("foto/{$ms['name']}");
                $fotsz = round($fotsz / 1024, 2);
                $sizs = GetImageSize("foto/{$ms['name']}");
                $fwidth = $sizs[0];
                $fheight = $sizs[1];
                echo
                    '<div class="box box-solid"><div class="box-body"><div class="row">' .
                    '<div class="col-sm-4 col-lg-3">' .
                    '<img class="thumbnail img-responsive" style="margin:0 auto !important;" src="' .
                    $set['homeurl'] . '/gallery/temp/' . $ms['name'] .
                    '.sm.png" alt=""/>' .
                    '<div class="text-center margin"><a class="btn btn-default" href="' .
                    $home . '/gallery/foto/' . $ms['name'] .
                    '"><i class="fa fa-download"></i> ' . $lng['download'] .
                    '</a></div></div>' .
                    '<div class="col-sm-8 col-lg-9"><ul class="list-unstyled">';
                echo '<h3 class="hidden-xs">Foto #' . $ms['id'] . '</h3>';
                echo "<li>" . $lng_gal['dimensions'] . ": $fwidth*$fheight px.</li>";
                echo "<li>" . $lng_gal['weight'] . ": $fotsz kb.</li>";
                echo '<li>' . $lng['date'] . ': ' . functions::display_date($ms['time']) .
                    '</li>';
                echo "<li>" . $lng_gal['posted_by'] . ": $ms[avtor]</li>";

                echo '</ul><p class="text-mutted">' . $ms['text'] . '</p>' . ($rights >=
                    6 ? "<div class='sub'><a class='func' href='" . $home .
                    "/gallery/index.php/act/edf/id/" . $ms['id'] .
                    "' data-toggle=\"" . functions::set_modal() . "\" data-target=\"#global-modal\">" .
                    "<span class=\"glyphicon glyphicon-edit\"></span> " . $lng['edit'] .
                    "</a>&nbsp;<a class='func' href='" . $home .
                    "/gallery/index.php/act/delf/id/" . $ms['id'] .
                    "' data-toggle=\"" . functions::set_modal() . "\" data-target=\"#global-modal\">" .
                    "<span class=\"glyphicon glyphicon-remove\"></span> " . $lng['delete'] .
                    "</a></div>" : "") . '</div></div></div></div>';
                echo '<p>' . functions::link_back($lng['back'],
                    'gallery/index.php/id/' . $ms['refid']) . '</p>';

                break;
            default:
                header("Location: " . core::$system_set['homeurl'] .
                    "/gallery/index.php");
                break;
        }
    }
    else
    {
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                    $lng['gallery'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<p>';
        if ($rights >= 6)
            echo '<a class="func" href="' . $set['homeurl'] .
                '/gallery/index.php/act/razd"><i class="fa fa-plus"></i> ' . $lng_gal['create_section'] .
                '</a>&nbsp;';
        echo '<a class="func" href="' . $set['homeurl'] .
            '/gallery/index.php/act/new"><i class="fa fa-picture-o"></i> ' . $lng_gal['new_photo'] .
            ' <span class="badge">' . counters::gallery(1) . '</span></a>';
        echo '</p>';
        $req = mysql_query("SELECT * FROM `gallery` WHERE `type` = 'rz'");
        $total = mysql_num_rows($req);
        echo '<div class="list-group">';
        while ($res = mysql_fetch_assoc($req))
        {
            $al = mysql_query("select * from `gallery` where type='al' and  refid='" .
                $res['id'] . "'");
            $countal = mysql_num_rows($al);
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/gallery/index.php/id/' . $res['id'] .
                '"><i class="fa fa-camera"></i> ' . $res['text'] .
                ' <span class="badge">' . $countal . '</span></a>';
            ++$i;
        }
        echo '</div>';
    }
}

require ('../incfiles/end.php');

?>