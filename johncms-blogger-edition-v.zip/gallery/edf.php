<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights >= 6)
{
    if ($_GET['id'] == "")
    {
        echo "ERROR<br/><a href='" . $home . "/gallery/index.php'>Back</a><br/>";
        require_once ('../incfiles/end.php');
        exit;
    }
    $typ = mysql_query("select * from `gallery` where id='" . $id . "';");
    $ms = mysql_fetch_array($typ);
    if ($ms['type'] != "ft")
    {
        echo "ERROR<br/><a href='" . $home . "/gallery/index.php'>Back</a><br/>";
        require_once ('../incfiles/end.php');
        exit;
    }
    if (isset($_POST['submit']))
    {
        $text = functions::check($_POST['text']);
        mysql_query("update `gallery` set text='" . $text . "' where id='" . $id .
            "';");
        header("location: " . $home . "/gallery/index.php/id/$id");
    }
    else
    {
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['gallery'], 'url' => 'gallery/index.php/id/' .
                    $id),
            array('label' => $lng_gal['edit_description']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo "<form action='" . $home . "/gallery/index.php/act/edf/id/" . $id .
            "' method='post'>" . "<div class=\"form-group\">" . "<label class=\"control-label\">" .
            $lng['description'] . "</label>" .
            "<textarea name='text' class='form-control' rows='6'>" . $ms['text'] .
            "</textarea>" . "</div>";
        echo "<p><input class='btn btn-primary' type='submit' name='submit' value='" .
            $lng['save'] . "'/> <a class='btn btn-default' data-dismiss=\"modal\" href='" .
            $home . "/gallery/index.php/id/" . $id . "'>" . $lng['cancel'] .
            "</a></p>" . "</form>";
    }
}
else
{
    header("location: " . $home . "/gallery/index.php");
}

?>