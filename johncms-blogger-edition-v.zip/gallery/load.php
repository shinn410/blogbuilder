<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$user_id || isset($ban['1']) || isset($ban['14']))
{
    header("location: " . $home . "/gallery/index.php");
    exit;
}
$flood = functions::antiflood();
if ($flood)
{
    echo functions::main_header($textl);
    echo functions::display_error('You cannot add pictures so often<br />Please wait ' .
        $flood . ' sec.', '<a class=\'alert-link\' href="' . $set['homeurl'] .
        '/gallery/index.php/id/' . $id . '">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}

$ms = get_gal($id);
if ($ms == false)
{
    echo functions::main_header($textl);
    echo functions::display_error('Not Found!', '<a class="alert-link" href="' .
        $set['homeurl'] . '/gallery/">' . $lnhg['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}
$rz = mysql_query("select * from `gallery` where type='rz' and id='" . $ms['refid'] .
    "';");
$rz1 = mysql_fetch_array($rz);
if ((!empty($_SESSION['uid']) && $rz1['user'] == 1 && $ms['text'] == $login) ||
    $rights >= 6)
{
    $text = functions::check($_POST['text']);
    $dopras = array(
        "gif",
        "jpg",
        "png");
    $tff = implode(" ,", $dopras);
    $ftsz = $set['flsz'] / 5;
    $fname = $_FILES['fail']['name'];
    if (empty($fname))
    {
        header("location: " . $home . "/gallery/index.php");
        exit();
    }
    $ext = functions::get_file_ext($fname);
    $fname = functions::permalink(substr($fname, 0, "-" . (strlen($ext) + 1))) .
        '.' . $ext;
    $fsize = $_FILES['fail']['size'];
    if ($fname != "")
    {
        $ffail = strtolower($fname);
        $formfail = functions::format($ffail);
        if ((preg_match("/php/i", $ffail)) or (preg_match("/.pl/i", $fname)) or
            ($fname == ".htaccess"))
        {
            echo functions::main_header('ERROR');
            echo functions::display_error("Trying to send a file type of prohibited.<br/><a class='alert-link' href='" .
                $home . "/gallery/index.php/act/upl/id/" . $id . "'>" . $lng['repeat'] .
                "</a>");
            require_once ('../incfiles/end.php');
            exit;
        }
        if ($fsize >= 1024 * $ftsz)
        {
            echo functions::main_header('ERROR');
            echo functions::display_error("Weight file exceeds $ftsz kB<br/><a class='alert-link' href='" .
                $home . "/gallery/index.php/act/upl/id/" . $id . "'>" . $lng['repeat'] .
                "</a>");
            require_once ('../incfiles/end.php');
            exit;
        }
        if (!in_array($formfail, $dopras))
        {
            echo functions::main_header('ERROR');
            echo functions::display_error("Allowed only the following file types: $tff !.<br/><a class='alert-link' href='" .
                $home . "/gallery/index.php/act/upl/id/" . $id . "'>" . $lng['repeat'] .
                "</a>");
            require_once ('../incfiles/end.php');
            exit;
        }
        if (preg_match("/[^\da-z_\-.]+/", $fname))
        {
            echo functions::main_header($textl);
            echo functions::display_error("The image name contains invalid characters<br/><a class='alert-link' href='" .
                $home . "/gallery/index.php/act/upl/id/" . $id . "'>" . $lng['repeat'] .
                "</a>");
            require_once ('../incfiles/end.php');
            exit;
        }
        if ($rz1['user'] == 1 && $ms['text'] == $login)
        {
            $fname = "$_SESSION[pid].$fname";
        }
        if (file_exists("foto/$fname"))
        {
            $fname = time() . $fname;
        }
        require ('../incfiles/lib/class.upload.php');
        if ((move_uploaded_file($_FILES["fail"]["tmp_name"], "foto/$fname")) == true)
        {
            $handle = new upload('foto/' . $fname);
            $handle->file_new_name_body = $fname . ".sm";
            $handle->allowed = array(
                'image/jpeg',
                'image/gif',
                'image/png',
                'image/jpg');
            $handle->image_resize = true;
            $handle->image_x = 180;
            $handle->image_y = 180;
            $handle->image_ratio_crop = true;
            $handle->image_ratio_no_zoom_in = true;
            $handle->image_convert = 'png';
            $handle->process('temp/');

            if ($handle->processed)
            {
                $ch = $fname;
                @chmod("$ch", 0777);
                @chmod("foto/$ch", 0777);
                echo functions::main_header($textl);
                echo
                    "<div class='alert alert-success'>Foto uploaded!<br/><a class='alert-link' href='" .
                    $home . "/gallery/index.php/id/" . $id . "'>" . $lng_gal['to_album'] .
                    "</a></div>";
                mysql_query("insert into `gallery` values(0,'" . $id . "','" .
                    time() . "','ft','" . $login . "','" . $text . "','" . $ch .
                    "','','','');");
                mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
                    "' WHERE `id` = '" . $user_id . "'");
            }
            else
            {
                echo functions::main_header($textl);
                if (file_exists('foto/' . $fname))
                    unlink('foto/' . $fname);
                echo functions::display_error($lng_gal['error_uploading_photo'] .
                    "<br/><a class='alert-link' href='" . $home .
                    "/gallery/index.php/id/" . $id . "'>" . $lng_gal['to_album'] .
                    "</a>");
            }
        }
        else
        {
            echo functions::main_header($textl);
            echo functions::display_error($lng_gal['error_uploading_photo'] .
                "<br/><a class='alert-link' href='" . $home .
                "/gallery/index.php/id/" . $id . "'>" . $lng_gal['to_album'] .
                "</a>");
        }
    }
}
else
{
    header("location: " . $home . "/gallery/index.php");
}

?>