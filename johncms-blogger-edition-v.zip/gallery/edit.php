<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights >= 6)
{
    $ms = get_gal($id);
    if ($ms == false)
    {
        echo functions::main_header($textl);
        echo "<div class='alert alert-danger'>ERROR<br/><a clas='alert-link' href='" .
            $home . "/gallery/index.php'>Back</a></div>";
        require_once ('../incfiles/end.php');
        exit;
    }
    switch ($ms['type'])
    {
        case "al":
            if (isset($_POST['submit']))
            {
                $text = functions::check($_POST['text']);
                mysql_query("update `gallery` set text='" . $text .
                    "' where id='" . $id . "';");
                header("location: " . $home . "/gallery/index.php/id/$id");
            }
            else
            {
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                            $lng['gallery'], 'url' => 'gallery/index.php/id/' .
                            $id), array('label' => $lng_gal['edit_album'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo "<form action='" . $home .
                    "/gallery/index.php/act/edit/id/" . $id . "' method='post'>" .
                    "<div class=\"form-group\">" . "<label class=\"control-label\">" .
                    $lng['name'] . "</label>" .
                    "<input class='form-control' type='text' name='text' value='" .
                    $ms['text'] . "'/>" . "</div>";
                echo
                    "<p><input class='btn btn-primary' type='submit' name='submit' value='" .
                    $lng['save'] .
                    "'/> <a class='btn btn-default' data-dismiss='modal' href='" .
                    $home . "/gallery/index.php/id/" . $id . "'>" . $lng['cancel'] .
                    "</a></p>" . "</form>";
            }
            break;

        case "rz":
            if (isset($_POST['submit']))
            {
                $text = functions::check($_POST['text']);
                if (!empty($_POST['user']))
                {
                    $user = intval($_POST['user']);
                }
                else
                {
                    $user = 0;
                }
                mysql_query("update `gallery` set text='" . $text . "', user='" .
                    $user . "' where id='" . $id . "';");
                header("location: " . $home . "/gallery/index.php/id/$id");
            }
            else
            {
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['gallery'], 'url' =>
                            'gallery/index.php/id/' . $id),
                    array('label' => $lng_gal['edit_section']),
                    ));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo "<form action='" . $home .
                    "/gallery/index.php/act/edit/id/" . $id . "' method='post'>" .
                    "<div class=\"form-group\">" . "<label class=\"control-label\">" .
                    $lng['name'] . "</label>" .
                    "<input class='form-control' type='text' name='text' value='" .
                    $ms['text'] . "'/>" . "</div>";
                echo
                    "<p><input class='btn btn-primary' type='submit' name='submit' value='" .
                    $lng['save'] .
                    "'/> <a class='btn btn-default' data-dismiss='modal' href='" .
                    $home . "/gallery/index.php/id/" . $id . "'>" . $lng['cancel'] .
                    "</a></p></form>";
            }
            break;

        default:
            echo functions::main_header($textl);
            echo "<div class='alert alert-danger'>ERROR<br/><a clas='alert-link' href='" .
                $home . "/gallery/index.php'>Back</a></div>";
            require_once ('../incfiles/end.php');
            exit;
            break;
    }
}
else
{
    header("location: " . $home . "/gallery/index.php");
}

?>