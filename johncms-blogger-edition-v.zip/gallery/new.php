<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['gallery'], 'url' => 'gallery/'),
    array('label' => $lng_gal['new_photo']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);

$newfile = mysql_query("select * from `gallery` where time > '" . (time() -
    259200) . "' and type='ft' order by time DESC LIMIT $start, $kmess");
$total = mysql_num_rows($newfile);
if ($total != 0)
{
    echo '<div class="row">';
    while ($fot1 = mysql_fetch_array($newfile))
    {
        echo '<div class="col-xs-6 col-sm-3 col-md-2">';
        echo '<a class="thumbnail" href="' . $set['homeurl'] .
            '/gallery/index.php/id/' . $fot1['id'] . '"><img alt="" src="' . $set['homeurl'] .
            '/gallery/temp/' . $fot1['name'] .
            '.sm.png" class="img-responsive"/></a>' . ($rights >= 6 ?
            "<div class='text-center' style=\"margin-bottom:10px;margin-top:-8px;\"><a href='" .
            $home . "/gallery/index.php/act/edf/id/" . $fot1['id'] .
            "' data-toggle=\"" . functions::set_modal() . "\" data-target=\"#global-modal\"><i class=\"fa fa-edit\"></i> " .
            $lng['edit'] . "</a>&nbsp;<a data-toggle=\"" . functions::set_modal
            () . "\" data-target=\"#global-modal\" href='" . $home .
            "/gallery/index.php/act/delf/id/" . $fot1['id'] . "'><i class=\"fa fa-times\"></i> " .
            $lng['delete'] . "</a></div>" : "") . '</div>';
    }
    echo '</div>';
    if ($total > $kmess)
    {
        echo '<p>' . functions::display_pagination($set['homeurl'] .
            '/gallery/index.php/act/new/', $start, $total, $kmess) . '</p>';
    }


}
else
{
    echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
}

?>