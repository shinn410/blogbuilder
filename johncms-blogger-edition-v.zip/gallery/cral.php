<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights >= 6)
{
    $ms = get_gal($id);
    if ($ms == false)
    {
        echo functions::display_error("ERROR<br/><a class='alert-link' href='" .
            $home . "/gallery/index.php'>" . $lng['back'] . "</a>");
        require_once ('../incfiles/end.php');
        exit;
    }
    elseif ($ms['type'] != "rz")
    {
        echo functions::display_error("ERROR<br/><a class='alert-link' href='" .
            $home . "/gallery/index.php'>" . $lng['back'] . "</a>");
        require_once ('../incfiles/end.php');
        exit;
    }
    if (isset($_POST['submit']))
    {
        $text = functions::check($_POST['text']);
        mysql_query("insert into `gallery` values(0,'" . $id . "','" . time() .
            "','al','','" . $text . "','','','','');");
        header("location: " . $home . "/gallery/index.php/id/$id");
    }
    else
    {
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['gallery'], 'url' => 'gallery/index.php/id/' .
                    $id),
            array('label' => $lng_gal['create_album']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo "<form action='" . $home . "/gallery/index.php/act/cral/id/" . $id .
            "' method='post'>" . "<div class='form-group'>" .
            "<label class='control-label'>" . $lng['title'] . "</label>" .
            "<input class='form-control' type='text' name='text'/>" . "</div>" .
            "<p><input class='btn btn-primary' type='submit' name='submit' value='" .
            $lng['save'] . "'/>" . "</form>";
        echo '<p>' . functions::link_back($lng_gal['to_section'],
            'gallery/index.php/id/' . $id) . '</p>';
    }
}
else
{
    header("location: " . $home . "/gallery/index.php");
}

?>