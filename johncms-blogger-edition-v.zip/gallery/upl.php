<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$user_id || $rights < 6)
{
    header("location: " . $home . "/gallery/index.php");
    exit;
}
$ms = get_gal($id);
if ($ms == false)
{
    echo functions::display_error("ERROR<br/><a class='alert-link' href='" . $home .
        "/gallery/index.php'>" . $lng['back'] . "</a>");
    require_once ('../incfiles/end.php');
    exit;
}
elseif ($ms['type'] != "al")
{
    echo functions::display_error("ERROR<br/><a class='alert-link' href='" . $home .
        "/gallery/index.php'>" . $lng['back'] . "</a>");
    require_once ('../incfiles/end.php');
    exit;
}
$rz = mysql_query("select * from `gallery` where type='rz' and id='" . $ms['refid'] .
    "'");
$rz1 = mysql_fetch_array($rz);
if ((!empty($_SESSION['uid']) && $rz1['user'] == 1 && $ms['text'] == $login) ||
    $rights >= 6)
{
    $dopras = array(
        "gif",
        "jpg",
        "png",
        );
    $tff = implode(" ,", $dopras);
    $fotsize = $set['flsz'] / 5;
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['gallery'], 'url' => 'gallery/index.php/id/' . $id),
        array('label' => $lng_gal['upload_photo']),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo '<form role="form" action="' . $set['homeurl'] .
        '/gallery/index.php/act/load/id/' . $id .
        '" method="post" enctype="multipart/form-data">' .
        '<div class="form-group">' . '<label class="control-label dis-block">' .
        $lng_gal['select_photo'] . '</label>' .
        '<input type="file" name="fail"/>';
    echo "<p class='help-block'>" . $lng_gal['allowed_types'] . ": " . $tff .
        "<br/>" . $lng_gal['maximum_weight'] . ": " . $fotsize . " kb</p>";
    echo '</div>' . '<div class="form-group">' .
        '<label class="control-label dis-block">' . $lng['description'] .
        '</label>' .
        '<textarea class="form-control" name="text" rows="6"></textarea>' .
        '</div>' . '<p><input class="btn btn-primary" type="submit" value="' . $lng['sent'] .
        '"/></p>' . '</form>';
    echo '<p>' . functions::link_back($lng['back'], 'gallery/index.php/id/' . $id) .
        '</p>';
}
else
{
    header("location: " . $home . "/gallery/index.php");
}

?>
