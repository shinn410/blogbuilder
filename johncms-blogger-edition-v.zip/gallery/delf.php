<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights >= 6)
{
    $ms = get_gal($id);
    if ($ms == false)
    {
        echo functions::display_error("ERROR<br/><a class='alert-link' href='" .
            $home . "/gallery/index.php'>" . $lng['back'] . "</a>");
        require_once ('../incfiles/end.php');
        exit;
    }
    elseif ($ms['type'] != "ft")
    {
        echo functions::display_error("ERROR<br/><a class='alert-link' href='" .
            $home . "/gallery/index.php'>" . $lng['back'] . "</a>");
        require_once ('../incfiles/end.php');
        exit;
    }
    if (isset($_GET['yes']))
    {
        $km = mysql_query("select * from `gallery` where type='km' and refid='" .
            $id . "';");
        while ($km1 = mysql_fetch_array($km))
        {
            mysql_query("delete from `gallery` where `id`='" . $km1['id'] . "';");
        }
        unlink("foto/$ms[name]");
        unlink("temp/" . $ms[name] . ".sm.png");
        mysql_query("delete from `gallery` where `id`='" . $id . "';");
        header("location: " . $home . "/gallery/index.php/id/$ms[refid]");
    }
    else
    {
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['gallery'], 'url' => 'gallery/index.php/id/' .
                    $id),
            array('label' => $lng['delete']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo "<div class='alert alert-warning'>" . $lng['delete_confirmation'] .
            "</div>";
        echo "<p><a class='btn btn-primary' href='" . $home .
            "/gallery/index.php/act/delf/id/" . $id . "/yes'>" . $lng['delete'] .
            "</a> <a class='btn btn-default' data-dismiss='modal' href='" . $home .
            "/gallery/index.php/id/" . $ms['refid'] . "'>" . $lng['cancel'] .
            "</a></p>";
    }
}

?>