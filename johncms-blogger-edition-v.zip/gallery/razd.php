<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['gallery'], 'url' => 'gallery/'),
    array('label' => $lng_gal['create_section']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if ($rights >= 6)
{
    if (isset($_POST['submit']))
    {
        $user = 0;
        $text = functions::check($_POST['text']);
        mysql_query("insert into `gallery` values(0,'0','" . time() .
            "','rz','','" . $text . "','','" . $user . "','','');");
        header("location: " . $home . "/gallery/index.php");
    }
    else
    {
        echo '<form role="form" action="' . $set['homeurl'] .
            '/gallery/index.php/act/razd" method="post">' .
            '<div class="form-group">' . '<label class="control-label">' . $lng['name'] .
            '</label>' . '<input class="form-control" type="text" name="text"/>' .
            '</div>' .
            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['save'] . '"/></p>' . '</form>' . '<p>' . functions::link_back($lng['back'],
            'gallery/index.php') . '</p>';
    }
}
