<?php

define('_IN_JOHNCMS', 1);

require ('incfiles/core.php');
$textl = $lng['registration'];
$headmod = 'registration';
$lng_reg = core::load_lng('registration');
$breadcrumb = functions::breadcrumb(array(array('label' => $lng['registration'])));
require ('incfiles/head.php');

if (core::$user_id)
{
    header("Location: " . $home . "/");
    exit;
}
elseif (core::$deny_registration || !$set['mod_reg'])
{
    echo '<div class="alert alert-danger">' . $lng_reg['registration_closed'] .
        '</div>';
    require ('incfiles/end.php');
    exit;
}

$captcha = isset($_POST['captcha']) ? strtolower(trim($_POST['captcha'])) : null;
$reg_nick = isset($_POST['nick']) ? trim($_POST['nick']) : '';
$reg_mail = isset($_POST['mail']) ? strtolower(trim($_POST['mail'])) : '';
$lat_nick = functions::rus_lat(mb_strtolower($reg_nick));
$reg_pass = isset($_POST['password']) ? trim($_POST['password']) : '';
$reg_name = isset($_POST['imname']) ? trim($_POST['imname']) : '';
$reg_about = isset($_POST['about']) ? trim($_POST['about']) : '';
$reg_sex = isset($_POST['sex']) ? functions::check(mb_substr(trim($_POST['sex']),
    0, 2)) : '';

if (isset($_POST['submit']))
{

    $error = array();

    if (empty($reg_nick))
    {
        $error['login'][] = $lng_reg['error_nick_empty'];
    }
    elseif (mb_strlen($reg_nick) < 2 || mb_strlen($reg_nick) > 15)
    {
        $error['login'][] = $lng_reg['error_nick_lenght'];
    }

    if (preg_match('/[^\da-z\-\@\*\(\)\?\!\~\_\=\[\]]+/', $lat_nick))
    {
        $error['login'][] = $lng['error_wrong_symbols'];
    }
    if (empty($reg_mail))
    {
        $error['mail'][] = 'Kamu belum memasukan E-Mail';
    }
    elseif (mb_strlen($reg_mail) < 8 || mb_strlen($reg_mail) > 40)
    {
        $error['mail'][] = 'Panjang E-Mail 8 s/d 40 Karakter';
    }
    elseif (!filter_var($reg_mail, FILTER_VALIDATE_EMAIL))
    {
        $error['mail'][] = 'E-Mail tidak valid';
    }
    if (empty($reg_pass))
    {
        $error['password'][] = $lng['error_empty_password'];
    }
    elseif (mb_strlen($reg_pass) < 3 || mb_strlen($reg_pass) > 10)
    {
        $error['password'][] = $lng['error_wrong_lenght'];
    }

    if (preg_match('/[^\dA-Za-z]+/', $reg_pass))
    {
        $error['password'][] = $lng['error_wrong_symbols'];
    }

    if ($reg_sex != 'm' && $reg_sex != 'zh')
    {
        $error['sex'] = $lng_reg['error_sex'];
    }

    if (!$captcha || !isset($_SESSION['code']) || mb_strlen($captcha) < 4 || $captcha !=
        strtolower($_SESSION['code']))
    {
        $error['captcha'] = $lng['error_wrong_captcha'];
    }
    unset($_SESSION['code']);

    if (empty($error))
    {
        $pass = md5(md5($reg_pass));
        $reg_name = functions::check(mb_substr($reg_name, 0, 20));
        $reg_about = functions::check(mb_substr($reg_about, 0, 500));

        $req = mysql_query("SELECT * FROM `users` WHERE `name_lat`='" .
            mysql_real_escape_string($lat_nick) . "'");
        if (mysql_num_rows($req) != 0)
        {
            $error['login'][] = $lng_reg['error_nick_occupied'];
        }
    }
    if (empty($error))
    {
        $req_mail = mysql_query("SELECT * FROM `users` WHERE `mail`='" .
            mysql_real_escape_string($reg_mail) . "'");
        if (mysql_num_rows($req_mail) != 0)
        {
            $error['mail'][] = 'E-Mail sudah digunakan';
        }
    }
    if ($set['mod_reg'] == 3)
    {
        $last_reg = time() - (2 * 3600);
        $req_reg = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_preg` WHERE `mail`='" .
            mysql_real_escape_string($reg_mail) . "' AND `datereg` > $last_reg"),
            0);
        if ($req_reg != 0)
        {
            $error['mail'][] =
                'Anda baru saja mengirimkan formulir pendaftaran.<br/>' .
                'Silakan periksa Kotak Masuk atau Kotak Spam email Anda yang telah Kami kirimkan sebelumnya, ' .
                'jika belum menerima email tersebut silakan ulangi pendaftaran minimal' .
                ' 2 jam dari pendaftaran sebelumya atau hubungi Administrator situs.';
        }
    }
    if (empty($error))
    {
        if ($set['mod_reg'] == 3)
        {
            $ver_code = functions::generate_password(12);

            mysql_query("DELETE FROM `users_preg` WHERE `mail` = '" .
                mysql_real_escape_string($reg_mail) . "' OR `code` = '" .
                mysql_real_escape_string($ver_code) . "'");

            mysql_query("INSERT INTO `users_preg` SET
            `name` = '" . mysql_real_escape_string($reg_nick) . "',
            `name_lat` = '" . mysql_real_escape_string($lat_nick) . "',
            `password` = '" . mysql_real_escape_string($reg_pass) . "',
            `imname` = '$reg_name',
            `mail` = '" . mysql_real_escape_string($reg_mail) . "',
            `about` = '$reg_about',
            `sex` = '$reg_sex',
            `datereg` = '" . time() . "',
            `code` = '" . mysql_real_escape_string($ver_code) . "'
            ") or exit(__line__ . ': ' . mysql_error());

            $subject = 'Verifikasi Pendaftaran';
            $mail = "Hai, $reg_nick\r\n" .
                "Baru-baru ini Anda telah mengirimkan formulir pendaftaran pada situs {$set['url']},\r\n" .
                "untuk melengkapi pendaftarn tersebut silakan klik link berikut ini\r\n" .
                "{$set['url']}/users/preg.php/code/$ver_code\r\n" . "\r\nJika bukan Anda yang mengirimkan formulir pendaftaran tersebut acuhkan pesan ini";
            $adds = "From: <" . $set['email'] . ">\r\n";
            $adds .= "Content-Type: text/plain; charset=\"utf-8\"\r\n";
            if (mail($reg_mail, $subject, $mail, $adds))
            {
                echo
                    '<div class="alert alert-info">Kode verifikasi telah dikirim ke email Anda.<br/>' .
                    'Silakan buka Kotak Masuk email Anda dan ikuti petunjuk selanjunya, ' .
                    'jika email tidak terdapat pada Kotak Masuk cobalah buka Kotak Spam.' .
                    '<br/>Kode verifikasi berlaku 1x24 jam dari sekarang.</div>';
            }
            else
            {
                echo
                    '<div class="alert alert-danger">Email gagal dikirim!</div>';
            }
        }
        else
        {
            $preg = $set['mod_reg'] > 1 ? 1 : 0;
            mysql_query("INSERT INTO `users` SET
            `name` = '" . mysql_real_escape_string($reg_nick) . "',
            `name_lat` = '" . mysql_real_escape_string($lat_nick) . "',
            `password` = '" . mysql_real_escape_string($pass) . "',
            `imname` = '$reg_name',
            `about` = '$reg_about',
            `sex` = '$reg_sex',
            `rights` = '0',
            `ip` = '" . core::$ip . "',
            `ip_via_proxy` = '" . core::$ip_via_proxy . "',
            `browser` = '" . mysql_real_escape_string($agn) . "',
            `datereg` = '" . time() . "',
            `lastdate` = '" . time() . "',
            `sestime` = '" . time() . "',
            `preg` = '$preg',
            `set_user` = '',
            `set_forum` = '',
            `set_mail` = '',
            `smileys` = ''
        ") or exit(__line__ . ': ' . mysql_error());
            $usid = mysql_insert_id();

            $set_mail = unserialize($set['setting_mail']);

            if (!isset($set_mail['message_include']))
            {
                $set_mail['message_include'] = 0;
            }

            if ($set_mail['message_include'])
            {
                $array = array('{LOGIN}', '{TIME}');
                $array_replace = array($reg_nick, '{TIME=' . time() . '}');

                if (empty($set['them_message']))
                {
                    $set['them_message'] = $lng_mail['them_message'];
                }

                if (empty($set['reg_message']))
                {
                    $set['reg_message'] = $lng['hi'] . ", {LOGIN}\r\n" . $lng_mail['pleased_see_you'] .
                        "\r\n" . $lng_mail['come_my_site'] . "\r\n" . $lng_mail['respectfully_yours'];
                }

                $theme = str_replace($array, $array_replace, $set['them_message']);
                $system = str_replace($array, $array_replace, $set['reg_message']);
                mysql_query("INSERT INTO `cms_mail` SET
			    `user_id` = '0',
			    `from_id` = '" . $usid . "',
			    `text` = '" . mysql_real_escape_string($system) . "',
			    `time` = '" . time() . "',
			    `sys` = '1',
			    `them` = '" . mysql_real_escape_string($theme) . "'
			");
            }

            echo '<div class="alert alert-success"><p><h3>' . $lng_reg['you_registered'] .
                '</h3>' . $lng_reg['your_id'] . ': <b>' . $usid . '</b><br/>' .
                $lng_reg['your_login'] . ': <b>' . $reg_nick . '</b><br/>' . $lng_reg['your_password'] .
                ': <b>' . $reg_pass . '</b></p></div>';

            if ($set['mod_reg'] == 1)
            {
                echo '<div class="alert alert-warning">' . $lng_reg['moderation_note'] .
                    '</div>';
            }
            else
            {
                $_SESSION['uid'] = $usid;
                $_SESSION['ups'] = md5(md5($reg_pass));
                echo '<p>' . functions::link_back($lng_reg['enter'] . ' &rarr;',
                    $home, false) . '</p>';
            }
        }

        require ('incfiles/end.php');
        exit;
    }
}

if ($set['mod_reg'] == 1)
    echo '<div class="alert alert-warning"><p>' . $lng_reg['moderation_warning'] .
        '</p></div>';
echo '<form role="form" action="' . $set['homeurl'] .
    '/registration.php" method="post">' . '<div class="form-group' . (isset($error['login']) ?
    ' has-error' : '') . '">' . '<label class="control-label">' . $lng_reg['login'] .
    '</label>' . (isset($error['login']) ?
    '<p class="help-block"><i class="text-red">' . implode('<br />', $error['login']) .
    '</i></p>' : '') .
    '<input class="form-control" type="text" name="nick" maxlength="15" value="' .
    htmlspecialchars($reg_nick) . '" required/>' . '<p class="help-block">' . $lng_reg['login_help'] .
    '</p>' . '</div>' . '<div class="form-group' . (isset($error['mail']) ?
    ' has-error' : '') . '">' . '<label>E-Mail</label>' . (isset($error['mail']) ?
    '<p class="help-block"><i class="text-red">' . implode('<br />', $error['mail']) .
    '</i></p>' : '') . '<input class="form-control" type="text" value="' .
    htmlspecialchars($reg_mail) . '" name="mail" required/></div>' .
    '<div class="form-group' . (isset($error['password']) ? ' has-error' : '') .
    '">' . '<label class="control-label">' . $lng_reg['password'] . '</label>' . (isset
    ($error['password']) ? '<p class="help-block"><i class="text-red">' .
    implode('<br />', $error['password']) . '</i></p>' : '') .
    '<input class="form-control" type="text" name="password" maxlength="20" value="' .
    htmlspecialchars($reg_pass) . '" required/>' . '<p class="help-block">' . $lng_reg['password_help'] .
    '</p>' . '</div>' . '<div class="form-group' . (isset($error['sex']) ?
    ' has-error' : '') . '">' . '<label class="control-label">' . $lng_reg['sex'] .
    '</label>' . (isset($error['sex']) ?
    '<p class="help-block"><i class="text-red">' . $error['sex'] . '</i></p>' :
    '') . '<select class="form-control" name="sex">' .
    '<option value="?">-?-</option>' . '<option value="m"' . ($reg_sex == 'm' ?
    ' selected="selected"' : '') . '>' . $lng_reg['sex_m'] . '</option>' .
    '<option value="zh"' . ($reg_sex == 'zh' ? ' selected="selected"' : '') .
    '>' . $lng_reg['sex_w'] . '</option>' . '</select>' . '</div>' .
    '<div class="alert alert-info max-width">' . '<div class="form-group">' .
    '<label class="control-label">' . $lng_reg['name'] . '</label>' .
    '<input class="form-control" type="text" name="imname" maxlength="30" value="' .
    htmlspecialchars($reg_name) . '" />' . '<p class="help-block">' . $lng_reg['name_help'] .
    '</p>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng_reg['about'] . '</label>' .
    '<textarea class="form-control" rows="3" name="about">' . htmlspecialchars($reg_about) .
    '</textarea>' . '<p class="help-block">' . $lng_reg['about_help'] . '</p>' .
    '</div>' . '</div>' . '<div class="form-group' . (isset($error['captcha']) ?
    ' has-error' : '') . '">' .
    '<label class="control-label" style="display:block;">' . $lng_reg['captcha'] .
    '</label>' . '<img class="img-responsive" src="' . $set['homeurl'] .
    '/captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng_reg['captcha'] .
    '" border="1"/><br/>' . (isset($error['captcha']) ?
    '<p class="help-block"><i class="text-red">' . $error['captcha'] .
    '</i></p>' : '') .
    '<input class="form-control" type="text" size="5" maxlength="5"  name="captcha" required/>' .
    '<p class="help-block">' . $lng_reg['captcha_help'] . '</p>' . '</div>' .
    '<p><button class="btn btn-primary" type="submit" name="submit">' . $lng_reg['registration'] .
    '</button></p></form>';

require ('incfiles/end.php');
