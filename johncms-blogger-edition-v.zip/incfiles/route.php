<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('HANDLE_REQUEST', true);

if (!empty($_SERVER['PATH_INFO']))
{
    parse_str($_SERVER['QUERY_STRING'], $query_string);
    $handle_requests = array();
    $r = explode('/', strtr(trim($_SERVER['PATH_INFO']), array('//' => '/', '\\' =>
            '/')));
    for ($i = 0; $i < count($r); $i++)
    {
        if ($i % 2)
        {
            if (!isset($handle_requests[$r[$i]]))
                $handle_requests[$r[$i]] = isset($r[$i + 1]) ? $r[$i + 1] : '';
        }
    }
    $_REQUEST = $_GET = array_merge($query_string, $handle_requests);
}

?>