<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($is_mobile) {
    include (ROOTPATH . 'incfiles/wap_end.php');
}
else {
    include (ROOTPATH . 'incfiles/web_end.php');
}

?>