<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
$is_friend = functions::is_friend($site['user_id']);
$item = '';
if ($mod == "comments")
{
    $title = "Komentar: " . $site['title'];
    $link = $site['url'];
    $description = $site['set']['description'];
    $pubDate = date("r", $timeshift);
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `site_id` = '" .
        $site['id'] . "' AND `post_id`!='0' AND `status`='accepted'"), 0);
    if ($total > 0)
    {
        $query = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id` = '" .
            $site['id'] .
            "' AND `post_id`!='0' AND `status`='accepted' ORDER BY `time` DESC LIMIT 15;");
        while ($res = mysql_fetch_assoc($query))
        {
            $post = mysql_fetch_assoc(mysql_query("SELECT `title`,`permalink`,`privacy` FROM `blog_posts` WHERE `id`='" .
                $res['post_id'] . "'"));
            if ($post['privacy'] != "publics")
            {
                if (!$user_id)
                    $co = 0;
                elseif ($is_friend == true || $user_id == $site['user_id'] || $rights >=
                    7)
                    $co = 1;
                else
                    $co = 0;
            }
            else
                $co = 1;

            if ($co = 1)
            {
                $item .= '<item><title>' . htmlspecialchars($res['author_name'] .
                    ": " . $post['title'], ENT_QUOTES, 'UTF-8') .
                    '</title><link>' . $site['url'] . '/' . $post['permalink'] .
                    '.html</link><pubDate>' . date('r', ($res['time'] + (($set['timeshift'] +
                    $set_user['timeshift']) * 3600))) .
                    '</pubDate><description><![CDATA[' . functions::smileys(nl2br
                    ($res['text'])) . ']]></description></item>';
            }
        }
    }
}
elseif ($mod == "post_comments")
{
    $q = mysql_query("SELECT `id`,`title`,`description`,`permalink`,`privacy`,`time` FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `permalink`='" . mysql_real_escape_string($_GET['permalink']) .
        "' AND `time`<'" . time() . "'");
    if (mysql_num_rows($q) != 1)
    {
        $title = "Komentar: " . $site['title'];
        $link = $site['url'];
        $description = $site['set']['description'];
        $item = "";
    }
    else
    {

        $post = mysql_fetch_array($q);
        $title = "Komentar: " . $post['title'];
        $link = $site['url'] . "/" . $post['permalink'] . ".html";
        if ($post['privacy'] != "publics")
        {
            if (!$user_id)
                $co = 0;
            elseif ($is_friend == true || $user_id == $site['user_id'] || $rights >=
                7)
                $co = 1;
            else
                $co = 0;
        }
        else
            $co = 1;

        if ($co == 1)
            $description = $post['description'];
        else
            $description = 'Postingan ini hanya untuk Teman';
        $pubDate = date("r", ($post['time'] + (($set['timeshift'] + $set_user['timeshift']) *
            3600)));
        if ($co = 0)
        {
            $item = "";
        }
        else
        {
            $query = mysql_query("SELECT * FROM `blog_comments` WHERE `post_id` = '" .
                $post['id'] .
                "' AND `status`='accepted' ORDER BY `time` DESC LIMIT 15;");
            if (mysql_num_rows($query) == 0)
            {
                $item = "";
            }
            else
            {
                while ($res = mysql_fetch_assoc($query))
                {
                    $item .= '<item><title>' . htmlspecialchars($res['author_name'] .
                        ": " . $post['title'], ENT_QUOTES, 'UTF-8') .
                        '</title><link>' . $site['url'] . '/' . $post['permalink'] .
                        '.html</link><pubDate>' . date('r', ($res['time'] + ($set['timeshift'] +
                        $set_user['timeshift']) * 3600)) .
                        '</pubDate><description><![CDATA[' . functions::smileys(nl2br
                        ($res['text'])) . ']]></description></item>';
                }
            }
        }
    }
}
else
{
    $title = $site['title'];
    $link = $site['url'];
    $description = $site['set']['description'];
    $pubDate = date("r", ($timeshift));
    $total = mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `time`<'" . time() . "'");
    if ($total > 0)
    {
        $query = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '" .
            $site['id'] . "' AND `time`<'" . time() .
            "' ORDER BY `time` DESC LIMIT 15;");

        while ($res = mysql_fetch_assoc($query))
        {
            $item .= '<item><title>' . htmlspecialchars($res['title'],
                ENT_QUOTES, 'UTF-8') . '</title><link>' . $site['url'] . '/' . $res['permalink'] .
                '.html</link><pubDate>' . date('r', ($res['time'] + ($set['timeshift'] +
                $set_user['timeshift']) * 3600)) . '</pubDate>';
            if ($res['privacy'] != "publics")
            {
                if (!$user_id)
                {
                    $des = "Postingan ini hanya untuk Teman.";
                }
                else
                {
                    if ($is_friend == true || $user_id == $site['user_id'] || $rights >=
                        7)
                        $des = $res['description'];
                    else
                        $des = "Postingan ini hanya untuk Teman.";
                }
            }
            else
            {
                $des = $res['description'];
            }
            $item .= '<description><![CDATA[' . functions::smileys($des) .
                ']]></description></item>';
        }
    }
}

header("Content-Type: application/xml");
echo '<?xml version="1.0" encoding="iso-8859-1"?><rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/"
><channel><title>' . htmlentities($title, ENT_QUOTES, 'UTF-8') . '</title>
<link>' . $link . '</link><description><![CDATA[' . htmlentities(strip_tags($description),
    ENT_QUOTES, 'UTF-8') . ']]></description><pubDate>' . $pubDate .
    '</pubDate>';
echo $item;
echo '</channel></rss>';

?>
