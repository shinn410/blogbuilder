<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

function safe_str($str)
{
    setlocale(LC_ALL, 'en_US.UTF8');
    $plink = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
    $plink = preg_replace("/[^a-zA-Z0-9\/_| -]/", '', $plink);
    $plink = strtolower(trim($plink, '-'));
    $plink = preg_replace("/[\/_| -]+/", '-', $plink);

    return $plink;
}

$filename = safe_str($_GET['filename']);
$fileext = safe_str($_GET['fileext']);
$file = $filename . '.' . $fileext;
$mime_types = include_once (dirname(__file__) . '/../mime_types.php');

if (is_file(dirname(__file__) . '/../../sites/' . $site_host . '/contents/' . $file))
{
    $file_location = dirname(__file__) . '/../../sites/' . $site_host .
        '/contents/' . $file;
    $name = $file;
    $ex = $fileext;
    if (in_array($ex, array_keys($mime_types)))
        $type = $mime_types[$ex[1]];
    else
        $type = "application/octet-stream";
    header('Content-Description: File Transfer');
    header('Content-Type: ' . $type);
    header('Content-Disposition: attachment; filename=' . $name);
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_location));
    readfile($file_location);
    exit();
}
else
{
    header("HTTP/1.0 404 Not Found");
    exit();
}
