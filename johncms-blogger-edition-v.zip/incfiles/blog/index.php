<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

$in_category = false;
$in_search = false;
$in_tag = false;
$total_pages = 0;
if (isset($_GET['category'])) {
    $in_category = htmlentities(trim($_GET['category']));
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `category`='" . mysql_real_escape_string($in_category) .
        "' AND `time` < '" . time() . "'"), 0);
}
elseif (isset($_GET['search'])) {
    $in_search = htmlentities(trim($_GET['search']));
    $search_db = strtr($in_search, array('_' => '\\_', '%' => '\\%'));
    $search_db = '%' . $search_db . '%';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `title` LIKE '" . mysql_real_escape_string($search_db) .
        "' AND `time` < '" . time() . "'"), 0);
}
elseif (isset($_GET['tag'])) {
    $in_tag = htmlentities(trim($_GET['tag']));
    $tag_db = strtr($in_tag, array('_' => '\\_', '%' => '\\%'));
    $tag_db = '%' . $tag_db . '%';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `tags` LIKE '" . mysql_real_escape_string($tag_db) .
        "' AND `time` < '" . time() . "'"), 0);
}
else {
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id` = '" .
        $site['id'] . "' AND `time` < '" . time() . "'"), 0);
}
$posts = array();
if ($total) {
    $total_pages = ceil($total / $kmess);
    include_once (dirname(__file__) . '/../lib/simple_html_dom.php');
    $dom = new simple_html_dom();

    if ($in_category) {
        $req = mysql_query("
                SELECT `blog_posts`.*, `blog_categories`.`name` AS `category_name`
                FROM `blog_posts`
                LEFT JOIN `blog_categories` ON (`blog_posts`.`site_id` = `blog_categories`.`site_id` AND `blog_posts`.`category` = `blog_categories`.`permalink`)
                WHERE `blog_posts`.`site_id` = '" . $site['id'] . "'
                AND `blog_posts`.`category`='" . mysql_real_escape_string($in_category) .
            "'
                AND `blog_posts`.`time` < '" . time() . "'
                ORDER BY `blog_posts`.`time` DESC LIMIT $start,$kmess");
    }
    elseif ($in_search) {
        $req = mysql_query("
                SELECT `blog_posts`.*, `blog_categories`.`name` AS `category_name`
                FROM `blog_posts`
                LEFT JOIN `blog_categories` ON (`blog_posts`.`site_id` = `blog_categories`.`site_id` AND `blog_posts`.`category` = `blog_categories`.`permalink`)
                WHERE `blog_posts`.`site_id` = '" . $site['id'] . "'
                AND `blog_posts`.`tags` LIKE '" . mysql_real_escape_string($search_db) .
            "'
                AND `blog_posts`.`time` < '" . time() . "'
                ORDER BY `blog_posts`.`time` DESC LIMIT $start,$kmess");
    }
    elseif ($in_tag) {
        $req = mysql_query("
                SELECT `blog_posts`.*, `blog_categories`.`name` AS `category_name`
                FROM `blog_posts`
                LEFT JOIN `blog_categories` ON (`blog_posts`.`site_id` = `blog_categories`.`site_id` AND `blog_posts`.`category` = `blog_categories`.`permalink`)
                WHERE `blog_posts`.`site_id` = '" . $site['id'] . "' 
                AND `blog_posts`.`tags` LIKE '" . mysql_real_escape_string($tag_db) .
            "'
                AND `blog_posts`.`time` < '" . time() . "'
                ORDER BY `blog_posts`.`time` DESC LIMIT $start,$kmess");
    }
    else {
        $req = mysql_query("
                SELECT `blog_posts`.*, `blog_categories`.`name` AS `category_name`
                FROM `blog_posts`
                LEFT JOIN `blog_categories` ON (`blog_posts`.`site_id` = `blog_categories`.`site_id` AND `blog_posts`.`category` = `blog_categories`.`permalink`)
                WHERE `blog_posts`.`site_id` = '" . $site['id'] . "'
                AND `blog_posts`.`time` < '" . time() . "'
                ORDER BY `blog_posts`.`time` DESC LIMIT $start, $kmess
                ");
    }

    $is_friend = functions::is_friend($site['user_id']);

    $nomor = 1;
    while ($post = mysql_fetch_assoc($req)) {
        if ($post['privacy'] == 'publics' || ($site['user_id'] == $user_id) || ($post['privacy'] ==
            'friends' && $is_friend == true)) {
            $dom->load($post['description']);
            $image = $dom->find('img', 0);
            $thumbnail = @$image->src;
            $dom->clear();
            $text = str_ireplace("\n", " ", mb_substr(strip_tags(str_ireplace('<br />',
                "\n", $post['description'])), 0, 100));
        }
        else {
            $text = 'Postingan ini hanya bisa dilihat oleh teman!';
            $thumbnail = '';
        }
        $posts[] = array(
            'id' => $post['id'],
            'title' => htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8'),
            'text' => ($nomor == 1 ? '[//JCMSBE_ADSX_HOMEPAGE//]' . $text .
                '[//JCMSBE_ADSX_HOMEPAGE//]' : $text),
            'category' => array('link' => $site['url'] . '/category/' . $post['category'] .
                    '/1.html', 'name' => $post['category_name']),
            'link' => $site['url'] . '/' . $post['permalink'] . '.html',
            'tags' => functions::get_tags($post['tags'], '<a href="' . $site['url'] .
                '/tag/{TAG_LINK}/1.html" rel="tag">{TAG_NAME}</a>'),
            'privacy' => $post['privacy'] == 'publics' ? 'public' : 'friend',
            'total_comments' => $post['comments'],
            'hits_today' => $post['hits_today'],
            'hits_total' => $post['hits_total'],
            'time' => $post['time'],
            'date' => functions::display_date($post['time']),
            'thumbnail' => $thumbnail,
            );
        $nomor++;
    }
}
return array_merge($args, array(
    'posts' => $posts,
    'total_pages' => $total_pages,
    'homepage' => true,
    'in_category' => $in_category,
    'in_search' => $in_search,
    'in_tag' => $in_tag,
    ));
