<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

$permalink = trim($_GET['post']);

if ($site['user_id'] == $user_id) {
    $req = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '" . $site['id'] .
        "' AND `permalink` = '" . mysql_real_escape_string($permalink) .
        "' LIMIT 1");
}
else {
    $req = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '" . $site['id'] .
        "' AND `permalink` = '" . mysql_real_escape_string($permalink) .
        "' AND `time`<'" . time() . "' LIMIT 1");
}

$post = false;
$display_comments = false;
$comments = array();
$comment_form = false;
$is_friend = functions::is_friend($site['user_id']);
if (mysql_num_rows($req) == 1) {
    $form_result = false;

    $post1 = mysql_fetch_array($req);
    $module->set_post($post1);

    if ($post1['draft'] == "no") {
        if ($post1['hits_today_date'] == date("d-m-Y", $timeshift)) {
            mysql_query("UPDATE `blog_posts` SET
            `hits_today` = `hits_today` + 1,
            `hits_total` = `hits_total` + 1,
            `lastview`='" . time() . "'
            WHERE `id`='" . $post1['id'] . "'");
        }
        else {
            mysql_query("UPDATE `blog_posts` SET
            `hits_today` = 1,
            `hits_today_date` = '" . date("d-m-Y", $timeshift) . "',
            `hits_total` = `hits_total` + 1,
            `lastview`='" . time() . "'
            WHERE `id`='" . $post1['id'] . "'");
        }
        if ($user_id) {
            mysql_query("UPDATE `users` SET `place` = '" .
                mysql_real_escape_string("bspost_" . $post1['id']) .
                "', `lastdate` = '" . time() . "' WHERE `id` = '" . $user_id .
                "'");
        }
        else {
            $session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
            $req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '" .
                $session . "' LIMIT 1");
            if (mysql_num_rows($req)) {
                mysql_query("UPDATE `cms_sessions` SET `place` = 'bspost_" . $post1['id'] .
                    "', `lastdate` = '" . time() . "' WHERE `session_id` = '" .
                    $session . "'");
            }
            else {
                mysql_query("INSERT INTO `cms_sessions` SET `session_id` = '" .
                    $session . "', `ip` = '" . core::$ip .
                    "', `ip_via_proxy` = '" . core::$ip_via_proxy .
                    "', `browser` = '" . mysql_real_escape_string($agn) .
                    "', `lastdate` = '" . time() . "', `sestime` = '" . time() .
                    "', `place` = 'bspost1_" . $post['id'] . "'");
            }
        }
    }

    $cat = mysql_fetch_array(mysql_query("SELECT `name` FROM `blog_categories` WHERE `site_id`='" .
        $site['id'] . "' AND `permalink`='" . mysql_real_escape_string($post1['category']) .
        "'"));
    $opt_post = array();
    if ($post1['privacy'] == 'publics' || ($site['user_id'] == $user_id) || ($post1['privacy'] ==
        'friends' && $is_friend == true)) {
        if ($post1['time'] < time()) {
            $form_errors = array();
            $form_success = array();
            $quote = isset($_GET['comment_reply']) ? abs(intval($_GET['comment_reply'])) : (isset
                ($_POST['comment_reply']) ? abs(intval($_POST['comment_reply'])) :
                0);

            $form_name = isset($_POST['name']) ? strip_tags(trim($_POST['name'])) : ($user_id ?
                $datauser['name'] : '');
            $form_email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $form_site = isset($_POST['site']) ? strip_tags(trim($_POST['site'])) : ($user_id ?
                $datauser['www'] : '');
            $form_captcha = isset($_POST['captcha']) ? trim($_POST['captcha']) :
                '';
            $form_message = isset($_POST['comment']) ? trim($_POST['comment']) :
                '';

            if (isset($_POST['submit']) || isset($_POST['addComment'])) {
                if (strlen($form_name) < 2 or strlen($form_name) > 30)
                    $form_errors['name'] =
                        "Nama minimal 2 dan maksimal 30 karakter.";
                if ($site['set']['emailcomment'] == 'yes' || $form_email != '') {
                    if (!filter_var($form_email, FILTER_VALIDATE_EMAIL))
                        $form_errors['email'] = 'E-Mail tidak benar';
                }
                if (!filter_var($form_site, FILTER_VALIDATE_URL,
                    FILTER_FLAG_SCHEME_REQUIRED))
                    $form_errors['site'] = 'Alamat situs tidak benar';
                if ((!$user_id || $site['set']['captchacomment'] == 'yes')) {
                    if (!isset($_POST['captcha']))
                        $captcha_form = 1;
                    if (!isset($_SESSION['code']) || strtolower($form_captcha) !=
                        strtolower($_SESSION['code']))
                        $form_errors['captcha'] = 'Kode keamanan tidak benar.';
                }
                if ($user_id) {
                    $flood = functions::antiflood();
                    if ($flood)
                        $form_errors['comment'] = $lng['error_flood'] . " " . $flood .
                            " " . $lng['seconds'];
                    $author_id = $user_id;
                    $form_name = $datauser['name'];
                    if (strlen($form_message) < 2 or strlen($form_message) >
                        5000)
                        $form_errors['comment'] =
                            "Komentar minimal 2 dan maksimal 5000 karakter.";
                }
                else {
                    $author_id = 0;
                    if (strlen($form_message) < 2 or strlen($form_message) >
                        1024)
                        $form_errors['comment'] =
                            "Komentar minimal 2 dan maksimal 1024 karakter.";
                }
                if ($post1['privacy'] == "publics" || $site['user_id'] == $user_id ||
                    functions::is_friend($site['user_id']) || $rights == 9 || $rights ==
                    7) {
                }
                else {
                    $form_errors['comment'] =
                        "Anda tidak diijinkan berkomentar. Postingan ini hanya untuk teman.";
                }
                if (isset($_SESSION['code']))
                    unset($_SESSION['code']);
                if (empty($form_errors)) {
                    if ($site['set']['moderatecomment'] == "yes" || !$user_id) {
                        $sts = "moderated";
                    }
                    else {
                        if (stripos($form_message, "http://") !== false) {
                            if (count(explode("http://", $form_message)) > 5)
                                $sts = "spam";
                            else
                                $sts = "accepted";
                        }
                        else {
                            $sts = "accepted";
                        }
                    }
                    if ($site['user_id'] == $user_id || $rights == 9 || $rights ==
                        7)
                        $sts = "accepted";
                    if ($sts == "accepted") {
                        mysql_query("UPDATE `blog_posts` SET `comments` = `comments` + 1, `lastcomment`='" .
                            time() . "' WHERE `id`='" . $post1['id'] . "'");
                        $form_success['published'] =
                            "Komentar Anda berhasil ditambahkan.";
                    }
                    elseif ($sts == "moderated" or $sts == "spam") {
                        $form_success['moderated'] =
                            "Komentar Anda berhasil ditambahkan dan akan " .
                            "ditampilkan setelah disetujui Administrator.";
                    }
                    if ($site['user_id'] == $user_id)
                        $read = 1;
                    else
                        $read = 0;
                    mysql_query("INSERT INTO `blog_comments` SET `site_id`='" .
                        $site['id'] . "',`user_id`='" . $site['user_id'] .
                        "',`post_id`='" . $post1['id'] . "',`author_id`='" . $author_id .
                        "',`author_name`='" . mysql_real_escape_string($form_name) .
                        "',`author_email`='" . mysql_real_escape_string($form_email) .
                        "',`author_homepage`='" . mysql_real_escape_string($form_site) .
                        "',`quote`='" . mysql_real_escape_string($quote) .
                        "',`text`='" . mysql_real_escape_string(functions::smileys
                        ($form_message)) . "',`status`='" . $sts .
                        "',`adminread`='" . $read . "',`time`='" . time() . "'") or
                        die(mysql_error());
                    $psid = mysql_insert_id();
                    if ($user_id) {
                        mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
                            "' WHERE `id` = '" . $user_id . "'");
                    }
                    else {
                        $_SESSION['a_name'] = $form_name;
                        $_SESSION['a_site'] = $form_site;
                    }
                    $_SESSION['a_email'] = $form_email;
                    if ($site['user_id'] != $user_id) {
                        $n_link = $set['url'] .
                            '/blogpanel/index.php/act/switch/id/' . $post1['site_id'] .
                            '/redir/' . base64_encode($set['homeurl'] .
                            '/blogpanel/index.php/act/manage_comments/mod/' . $sts);
                        $n_text = htmlspecialchars($form_name) .
                            ' mengomentari postingan ' . htmlspecialchars($post1['title']) .
                            ' pada blog ' . htmlspecialchars($site['title']) .
                            '. [url=' . $n_link . ']Lihat komentar[/url]';
                        mysql_query("INSERT INTO `cms_mail` SET
					       `user_id` = '$author_id', 
					       `from_id` = '{$site['user_id']}',
					       `text` = '" . mysql_real_escape_string($n_text) . "',
					       `time` = '" . time() . "',
					       `sys` = '1',
					       `them` = 'Blog: Komentar baru'
                    ");
                    }
                }
                elseif (isset($captcha_form)) {
                    echo
                        '<!DOCTYPE html><html class="bg-black"><head><meta charset="UTF-8"/>' .
                        '<title>Captcha Form</title>' .
                        '<meta content="width=device-width, initial-scale=1, ' .
                        'maximum-scale=1, user-scalable=no" name="viewport"><!-- bootstrap 3.2.0 -->' .
                        '<link href="' . $home .
                        '/theme/default/css/bootstrap.min.css" rel="stylesheet" type="text/css" />' .
                        '<!-- font Awesome --><link href="' . $home .
                        '/theme/default/css/font-awesome.min.css" rel="stylesheet" type="text/css" />' .
                        '<!-- Theme style --><link href="' . $home .
                        '/theme/default/css/style.css" rel="stylesheet" type="text/css" />' .
                        '<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->' .
                        '<!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->' .
                        '<!--[if lt IE 9]><script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js">' .
                        '</script><script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js">' .
                        '</script><![endif]-->' .
                        '</head><body class="bg-black"><div class="form-box" id="login-box">' .
                        '<div class="header bg-light-blue">Captcha Form</div>';
                    echo '<form class="login-form" role="form" action="' . $site['url'] .
                        '/' . $post1['permalink'] . '.html?comment_reply=' . $quote .
                        '#respond" method="post"><div class="body bg-gray"><div class="form-group">' .
                        '<label>' . $lng['enter_code'] .
                        '</label><p><img class="img-responsive" src="' . $set['homeurl'] .
                        '/captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng['verifying_code'] .
                        '"/></p><input class="form-control" type="text" maxlength="5"  name="captcha"/>' .
                        '</div></div><div class="footer">' .
                        '<button class="btn bg-light-blue btn-block" type="submit" name="submit">' .
                        $lng['continue'] . '</button><p><a href="' . $site['url'] .
                        '/' . $post1['permalink'] . '.html">' . $lng['cancel'] .
                        '</a></p></div>' .
                        '<input type="hidden" name="name" value="' .
                        htmlentities($form_name) .
                        '"/><input type="hidden" name="email" value="' .
                        htmlentities($form_email) .
                        '"/><input type="hidden" name="site" value="' .
                        htmlentities($form_site) .
                        '"/><input type="hidden" name="comment" value="' .
                        htmlentities($form_message) . '"/></form>';
                    echo '<div class="margin text-center"><span>&copy; ' .
                        htmlspecialchars($site['title'], ENT_QUOTES, 'UTF-8') .
                        '</span><br/>' .
                        '<a class="btn bg-light-blue btn-circle" href="' . $site['url'] .
                        '/"><i class="fa fa-home"></i></a></div>';
                    echo '</div><script src="' . $home .
                        '/theme/default/js/jquery-2.1.1.min.js"></script>' .
                        '<!-- Bootstrap --><script src="' . $home .
                        '/theme/default/js/bootstrap.min.js" type="text/javascript"></script>' .
                        '</body></html>';
                    exit();
                }
            }

            $total_comments = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
                $site['id'] . "' AND `post_id`='" . $post1['id'] .
                "' AND `status`='accepted'"), 0);
            $display_comments = true;
            $comments = array();

            if ($total_comments) {
                $req = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id`='" .
                    $site['id'] . "' AND `post_id`='" . $post1['id'] .
                    "' AND `status`='accepted' ORDER BY `time` ASC");
                $mass_read = array();
                while ($comment = mysql_fetch_assoc($req)) {
                    if (empty($comment['quote'])) {
                        $comments[$comment['id']] = array(
                            'id' => $comment['id'],
                            'author_id' => $comment['author_id'],
                            'author_homepage' => htmlspecialchars($comment['author_homepage'],
                                ENT_QUOTES, 'UTF-8'),
                            'author_name' => htmlspecialchars($comment['author_name'],
                                ENT_QUOTES, 'UTF-8'),
                            'text' => functions::smileys(functions::checkout($comment['text'],
                                1, 1)),
                            'reply' => array(),
                            'time' => $comment['time'],
                            'date' => functions::display_date($comment['time']),
                            );
                    }
                    else {
                        if (isset($comments[$comment['quote']])) {
                            $comments[$comment['quote']]['reply'][] = array(
                                'id' => $comment['id'],
                                'author_id' => $comment['author_id'],
                                'author_homepage' => htmlspecialchars($comment['author_homepage'],
                                    ENT_QUOTES, 'UTF-8'),
                                'author_name' => htmlspecialchars($comment['author_name'],
                                    ENT_QUOTES, 'UTF-8'),
                                'text' => $comment['text'],
                                'time' => $comment['time'],
                                'date' => functions::display_date($comment['time']),
                                );
                        }
                    }
                    if ($comment['adminread'] == '0')
                        $mass_read[] = $comment['id'];
                }
                if ($mass_read) {
                    mysql_query("UPDATE `blog_comments` SET `adminread` = '1' WHERE `id` IN (" .
                        implode(',', $mass_read) . ") AND `site_id` = '" . $site['id'] .
                        "'");
                }
            }

            $comment_form = array();
            $comment_form['auth'] = $user_id ? array(
                'link' => $site['url'] . '/usersignout',
                'title' => 'Keluar',
                ) : array(
                'link' => $set['url'] . '/login.php?redirect=' . urlencode($site['url'] .
                    '/' . $post1['permalink'] . '.html'),
                'title' => 'Masuk',
                );
            $comment_form['errors'] = $form_errors;
            $comment_form['success'] = $form_success;
            $comment_form['action'] = $site['url'] . '/' . $post1['permalink'] .
                '.html';
            $comment_form['name'] = $form_name != '' ? htmlentities($form_name) : (isset
                ($_SESSION['a_name']) ? htmlentities($_SESSION['a_name']) : '');
            $comment_form['email'] = $form_email != '' ? htmlentities($form_email) : (isset
                ($_SESSION['a_email']) ? htmlentities($_SESSION['a_email']) : '');
            $comment_form['site'] = $form_site != '' ? htmlentities($form_site) : (isset
                ($_SESSION['a_site']) ? htmlentities($_SESSION['a_site']) : '');
            $comment_form['comment_reply'] = $quote;
        }
    }
    else {
        $opt_post['text'] =
            'Postingan hanya bisa dilihat oleh teman!<br />Silakan <a href="' .
            $set['url'] . '/login.php?redirect=' . urlencode($site['url'] . '/' .
            $post1['permalink'] . '.html') . '">Masuk</a> atau <a href="' . $set['url'] .
            '/registration.php">Register</a> terlebih dahulu.';
    }
    $post = array_merge(array(
        'id' => $post1['id'],
        'title' => htmlspecialchars($post1['title'], ENT_QUOTES, 'UTF-8'),
        'text' => '[//JCMSBE_ADSX_SINGLEPOST//]' . ($post1['mode'] == 'html' ? $post1['description'] :
            functions::smileys(bbcode::special_bb(functions::checkout($post1['description'],
            1, 1)))) . '[//JCMSBE_ADSX_SINGLEPOST//]',
        'category' => array('link' => $site['url'] . '/category/' . $post1['category'] .
                '/1.html', 'name' => htmlspecialchars($cat['name'], ENT_QUOTES,
                'UTF-8')),
        'link' => $site['url'] . '/' . $post1['permalink'] . '.html',
        'tags' => functions::get_tags($post1['tags'], '<a href="' . $site['url'] .
            '/tag/{TAG_LINK}/1.html" rel="tag">{TAG_NAME}</a>'),
        'privacy' => $post1['privacy'] == 'publics' ? 'public ' : 'friend',
        'total_comments' => $post1['comments'],
        'hits_today' => $post1['hits_today'],
        'hits_total' => $post1['hits_total'],
        'time' => $post1['time'],
        'date' => functions::display_date($post1['time']),
        'display_comments' => $display_comments,
        'total_comments' => isset($total_comments) ? $total_comments : 0,
        'comments' => array_values($comments),
        'comment_form' => $comment_form,
        ), $opt_post);
}
return array_merge($args, array(
    'post' => $post,
    'singlepostpage' => true,
    'page_title' => htmlspecialchars($post ? $post['title'] : $site['title'],
        ENT_QUOTES, 'UTF-8'),
    ));

?>
