<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($is_mobile) {
    include (ROOTPATH . 'incfiles/wap_head.php');
}
else {
    include (ROOTPATH . 'incfiles/web_head.php');
}

?>