<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Restricted access');

class mainpage
{
    public $news;

    public $newscount;

    public $lastnewsdate;

    private $settings = array();
    function __construct()
    {
        global $set;
        $this->settings = unserialize($set['news']);
        $this->newscount = $this->newscount() . $this->lastnewscount();
        $this->news = $this->news();
    }

    private function news()
    {
        global $lng, $set;
        if ($this->settings['view'] > 0)
        {
            $reqtime = $this->settings['days'] ? time() - ($this->settings['days'] *
                86400) : 0;
            $req = mysql_query("SELECT * FROM `news` WHERE `time` > '$reqtime' ORDER BY `time` DESC LIMIT " .
                $this->settings['quantity']);
            if (mysql_num_rows($req) > 0)
            {
                $i = 0;
                $news = '<ul class="list-group">';
                while (($res = mysql_fetch_array($req)) !== false)
                {
                    $text = $res['text'];

                    if (mb_strlen($text) > $this->settings['size'])
                    {
                        $text = mb_substr($text, 0, $this->settings['size']);
                        $text = htmlentities($text, ENT_QUOTES, 'UTF-8');
                        $text .= ' <a href="' . $set['homeurl'] .
                            '/news/index.php#news-' . $res['id'] . '">' . $lng['next'] .
                            ' <i class="fa fa-angle-double-right"></i></a>';
                    }
                    else
                    {
                        $text = htmlentities($text, ENT_QUOTES, 'UTF-8');
                    }

                    if ($this->settings['breaks'])
                        $text = str_replace("\r\n", "<br/>", $text);

                    if ($this->settings['tags'])
                    {
                        $text = bbcode::tags($text);
                    }
                    else
                    {
                        $text = bbcode::notags($text);
                    }

                    if ($this->settings['smileys'])
                    {
                        $text = functions::smileys($text);
                    }

                    $news .= '<li class="list-group-item bg-transparent">';
                    switch ($this->settings['view'])
                    {
                        case 2:
                            $news .=
                                '<h4 class="list-group-item-heading"><a href="' .
                                $set['homeurl'] . '/news/index.php#news-' . $res['id'] .
                                '">' . $res['name'] . '</a></h4>';
                            break;

                        case 3:
                            $news .= $text;
                            break;
                        default:
                            $news .= '<h4 class="list-group-item-heading">' . $res['name'] .
                                '</h4><p class="list-group-item-text">' . $text .
                                '</p>';
                    }

                    if (!empty($res['kom']) && $this->settings['view'] != 2 && $this->settings['kom'] ==
                        1)
                    {
                        $mes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `refid` = '" .
                            $res['kom'] . "'");
                        $komm = mysql_result($mes, 0) - 1;
                        if ($komm >= 0)
                            $news .= '<div><a class="func" href="' . $set['homeurl'] .
                                '/forum/index.php/id/' . $res['kom'] .
                                '"><i class="fa fa-comments"></i> ' . $lng['discuss'] .
                                ' <span class="badge">' . $komm .
                                '</span></a></div>';
                    }
                    $news .= '</li>';
                    ++$i;
                }
                $news .= '</ul>';
                return $news;
            }
            else
            {
                return false;
            }
        }
    }

    private function newscount()
    {
        $req = mysql_query("SELECT COUNT(*) FROM `news`");
        $res = mysql_result($req, 0);
        return ($res > 0 ? $res : '0');
    }

    private function lastnewscount()
    {
        $req = mysql_query("SELECT COUNT(*) FROM `news` WHERE `time` > '" . (time
            () - 259200) . "'");
        $res = mysql_result($req, 0);
        return ($res > 0 ? '/<span class="red">+' . $res . '</span>' : false);
    }
}
