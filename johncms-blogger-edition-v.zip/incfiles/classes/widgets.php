<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

class widgets extends core
{
    private $site;
    private $modules = array();
    private $module = array();
    private $option = array();
    private $current_post = null;

    public function __construct($site, $modules = null)
    {
        $this->site = $site;
        $this->modules = is_null($modules) ? $this->set_modules() : $modules;
    }

    public function set_post($post)
    {
        $this->current_post = $post;
    }

    public function set_modules()
    {
        return array(
            'categories' => 'module_categories',
            'related_posts' => 'module_related_posts',
            'recent_posts' => 'module_recent_posts',
            'recent_comments' => 'module_recent_comments',
            'prev_post' => 'module_prev_post',
            'next_post' => 'module_next_post',
            'navigations' => 'module_navigations',
            );
    }

    public function module($module, $option = null)
    {
        if (!in_array($module, array_keys($this->modules)))
            return;
        if (isset($this->module[$module]))
            return $this->module[$module];
        if (!is_null($option))
            $this->option[$module] = $option;

        return call_user_func_array(array($this, $this->modules[$module]), array
            ($module));
    }

    function module_categories($module)
    {
        $categories = array();
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='" .
            $this->site['id'] . "'"), 0);
        if ($total > 0)
        {
            $req = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
                $this->site['id'] . "' ORDER BY `name` ASC");
            while ($category = mysql_fetch_array($req))
            {
                $categories[] = array(
                    'id' => $category['id'],
                    'name' => $category['name'],
                    'total_posts' => $category['counts'],
                    'link' => $this->site['url'] . '/category/' . $category['permalink'] .
                        '/1.html');
            }
        }
        $this->module[$module] = $categories;
        return $categories;
    }

    function module_recent_posts($module)
    {
        $posts = array();
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
            $this->site['id'] . "' AND `time`<'" . time() . "'"), 0);
        if ($total > 0)
        {
            $req = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '" .
                $this->site['id'] . "' AND `time`<'" . time() .
                "' ORDER BY `time` DESC LIMIT 10");
            while ($post = mysql_fetch_array($req))
            {
                $posts[] = array(
                    'id' => $post['id'],
                    'title' => htmlspecialchars($post['title']),
                    'text' => mb_substr(strip_tags($post['description']), 0, 200),
                    'link' => $this->site['url'] . '/' . $post['permalink'] .
                        '.html');
            }
        }
        $this->module[$module] = $posts;
        return $posts;
    }

    function module_related_posts($module)
    {
        $total_related = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `id` != '" .
            $this->current_post['id'] . "' AND `site_id`='" . $this->site['id'] .
            "' AND `category`='" . mysql_real_escape_string($this->current_post['category']) .
            "' AND `time`<'" . time() . "'"), 0);
        $related = array();

        if ($total_related)
        {
            $req = mysql_query("SELECT `title`,`permalink`,`time` FROM `blog_posts` WHERE `id` != '" .
                $this->current_post['id'] . "' AND `site_id`='" . $this->site['id'] .
                "' AND `category`='" . mysql_real_escape_string($this->current_post['category']) .
                "' AND `time`<'" . time() . "' ORDER BY `time` DESC LIMIT 5");
            while ($rel = mysql_fetch_array($req))
            {
                $related[] = array(
                    'title' => htmlspecialchars($rel['title']),
                    'link' => $this->site['url'] . '/' . $rel['permalink'] .
                        '.html',
                    'time' => $rel['time'],
                    'date' => functions::display_date($rel['time']),
                    );
            }
        }
        return $this->module[$module] = $related;
    }
    function module_prev_post($module)
    {
        if (is_null($this->current_post))
            return false;

        $time = time();
        $req = mysql_query("SELECT * FROM `blog_posts` WHERE `id` != '" . $this->current_post['id'] .
            "' AND `site_id` = '" . $this->site['id'] . "' AND `time`<'" . $this->current_post['time'] .
            "' AND `time`<'" . $time . "' ORDER BY `time` DESC LIMIT 1");
        if (mysql_num_rows($req) == 1)
        {
            $prev_post = mysql_fetch_array($req);
            $post = array(
                'id' => $prev_post['id'],
                'title' => htmlspecialchars($prev_post['title']),
                'text' => mb_substr(strip_tags($prev_post['description']), 0,
                    200),
                'link' => $this->site['url'] . '/' . $prev_post['permalink'] .
                    '.html');
        }
        return $this->module[$module] = isset($post) ? $post : false;
    }

    function module_next_post($module)
    {
        if (is_null($this->current_post))
            return false;

        $time = time();
        $req = mysql_query("SELECT * FROM `blog_posts` WHERE `id` != '" . $this->current_post['id'] .
            "' AND `site_id` = '" . $this->site['id'] . "' AND `time`>'" . $this->current_post['time'] .
            "' AND `time` < '" . $time . "' ORDER BY `time` ASC LIMIT 1");
        if (mysql_num_rows($req) == 1)
        {
            $next_post = mysql_fetch_array($req);
            $post = array(
                'id' => $next_post['id'],
                'title' => htmlspecialchars($next_post['title']),
                'text' => mb_substr(strip_tags($next_post['description']), 0,
                    200),
                'link' => $this->site['url'] . '/' . $next_post['permalink'] .
                    '.html');
        }
        return $this->module[$module] = isset($post) ? $post : false;
    }

    public function module_recent_comments($module)
    {
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
            $this->site['id'] . "' AND `post_id`!='0' AND `status`='accepted'"),
            0);
        if ($total == 0)
        {
            return $this->module[$module] = false;
        }

        $req = mysql_query("
                SELECT `blog_comments`.*,
                `blog_posts`.`title` AS `post_title`,
                `blog_posts`.`permalink` AS `post_permalink`,
                `blog_posts`.`privacy` AS `post_privacy`
                FROM `blog_comments`
                LEFT JOIN `blog_posts` ON `blog_comments`.`post_id` = `blog_posts`.`id` 
                AND `blog_posts`.`time` < '" . time() . "'
                WHERE `blog_comments`.`site_id`='" . $this->site['id'] . "'
                AND `blog_comments`.`post_id`!='0'
                AND `blog_comments`.`status`='accepted'
                ORDER BY `blog_comments`.`time` DESC LIMIT 10
                ");
        $comments = array();
        while ($comment = mysql_fetch_array($req))
        {
            $comments[] = array(
                'id' => $comment['id'],
                'author_id' => $comment['author_id'],
                'author_name' => htmlspecialchars($comment['author_name']),
                'author_homepage' => $comment['author_homepage'],
                'time' => $comment['time'],
                'date' => functions::display_date($comment['time']),
                'text' => $comment['post_privacy'] == 'publics' ?
                    htmlspecialchars($comment['text']) : '...',
                'post' => array(
                    'link' => $this->site['url'] . '/' . $comment['post_permalink'] .
                        '.html',
                    'title' => htmlspecialchars($comment['post_title']),
                    ),
                );
        }
        return $this->module[$module] = $comments;
    }

    function module_navigations($module)
    {
        $url = parse_url($this->site['url'], PHP_URL_HOST);
        if (file_exists(ROOTPATH . 'sites/' . $url . '/navigations.dat'))
            $navigations = file_get_contents(ROOTPATH . 'sites/' . $url .
                '/navigations.dat');
        else
            $navigations = '';

        if (empty($navigations))
            return $this->module[$module] = array();

        $navs = array();
        if (strpos($navigations, "^") === false)
        {
            $navs[] = $navigations;
            return $this->module[$module] = $navs;
        }
        $navigs = explode("^", $navigations);
        foreach ($navigs as $nav)
            $navs[] = $nav;
        return $this->module[$module] = $navs;
    }
}

?>