<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

/**
 * @About Update template johnCMS Blogger Edition v1 to template johnCMS Blogger Edition v2
 * @author Achunk JealousMan
 * @link http://fb.com/achunks
 * @usage:
 * include_once 'TemplateGenerator.php';
 * $tpl = new TemplateGenerator(file_get_contents('FILE LOCATION HERE'));
 * Send output
 * echo htmlentities($tpl);
 * Or save file
 * file_put_contents('NEW FILE LOCATION', $tpl);
 */

class TemplateGenerator
{
    private $newContent;

    public function __construct($content)
    {
        $this->newContent = $this->updateContent($content);
    }

    public function __toString()
    {
        return $this->newContent;
    }

    private function updateContent($content)
    {
        $replaces = array(

            '{global}' => '{# ##########',
            '{/global}' => '########## #}',

            '{header}' => '{# header #}',
            '{/header}' => '{# end header #}',
            '{header:title}' => '{{ page_title }}',
            '{header:description}' => '{{ page_description }}',
            '{header:keywords}' => '{{ page_keywords }}',
            '{site:metagoogle}' => '{{ site.set.metagoogle|e }}',
            '{site:icon}' => '{# site.icon #}',
            '{site:name}' => '{{ site.title }}',

            '{if:post}' => '{% if homepage %}' . "\n" . '{% if in_search %}' . "\n" .
                '<div><h5>Search results</h5><h3> "{{ in_search }}"</h3></div>' .
                "\n" . '{% elseif in_category %}' . "\n" .
                '<div><h5>Category</h5><h3> "{{ in_category }}"</h3></div>' . "\n" .
                '{% elseif in_tag %}' . "\n" .
                '<div><h5>Tag</h5><h3> "{{ in_tag }}"</h3></div>' . "\n" .
                '{% endif %}',
            '{post:entry}' => '{% if posts|length > 0 %}' . "\n" .
                '{% for post in posts %}',
            '{post:entry:title}' => '{{ post.title }}',
            '{post:entry:link}' => '{{ post.link }}',
            '{post:entry:description}' => '{{ post.text }}',
            '{post:entry:date}' => '{{ post.date }}',
            '{post:entry:thumb}' => '{{ post.thumbnail }}',
            '{post:entry:comments}' => '{{ post.total_comments }}',
            '{post:entry:views}' => '{{ post.hits_total }}',
            '{/post:entry}' => '{% endfor %}' . "\n" . '{% else %}' . "\n" .
                '<div>Post tidak ada!</div>' . "\n" . '{% endif %}',
            '{post:pagination}' => '{# post.pagination #}',
            '{pagination:link}' => '{# pagination.link #}',
            '{/if:post}' => '{% endif %}',

            '{if:singlepost}' => '{% if singlepostpage %}' . "\n" .
                '{% if post %}',
            '{singlepost:title}' => '{{ post.title }}',
            '{singlepost:description}' => '{{ post.text }}',
            '{singlepost:views}' => '{{ post.hits_total }}',
            '{singlepost:comments}' => '{{ post.total_comments }}',
            '{singlepost:tag}' => '{{ post.tags }}',
            '{singlepost:date}' => '{{ post.date }}',
            '{singlepost:author}' => '{{ site.author.name }}',
            '{singlepost:category}' => '{{ post.category.name }}',
            '{singlepost:category:name}' => '{{ post.category.name }}',
            '{singlepost:category:link}' => '{{ post.category.link }}',

            '{singlepost:comment}' => '{% if post.display_comments %}',
            '{singlepost:comments}' => '{{ post.total_comments }}',
            '{singlepost:comment:entry}' => '{% if post.comments|length > 0 %}' .
                "\n" . '{% for comment in post.comments %}',
            '{singlepost:comment:entry:id}' => '{{ comment.id }}',
            '{singlepost:comment:entry:name}' => '{{ comment.author_name }}',
            '{singlepost:comment:entry:date}' => '{{ comment.date }}',
            '{singlepost:comment:entry:message}' => '{{ comment.text }}',
            '{singlepost:comment:entry:homepage}' =>
                '{{ comment.author_homepage }}',
            '{singlepost:comment:entry:userid}' => '{{ comment.author_id }}',
            '{/singlepost:comment:entry}' => '{% endfor %}' . "\n" .
                '{% else %}' . "\n" . '<div>Belum ada komentar</div>' . "\n" .
                '{% endif %}',
            '{/singlepost:comment}' => '{% endif %}',

            '{singlepost:comment:form}' => '{% if post.comment_form %}' . "\n" .
                '{% if post.comment_form.errors %}' . "\n" . '<div>' . "\n" .
                '<h4>KESALAHAN:</h4>' . "\n" . '<ul>' . "\n" .
                '{% for error in post.comment_form.errors %}' . "\n" .
                '<li>{{ error }}</li>' . "\n" . '{% endfor %}' . "\n" . '</ul>' .
                "\n" . '</div>' . "\n" .
                '{% elseif post.comment_form.success.moderated %}' . "\n" .
                '<div>' . "\n" .
                'Komentar berhasil ditambahkan dan akan dipublikasikan setelah disetujui Administrator' .
                "\n" . '</div>' . "\n" .
                '{% elseif post.comment_form.success.published %}' . "\n" .
                '<div>' . "\n" .
                'Komentar berhasil ditambahkan dan telah dipublikasikan' . "\n" .
                '</div>' . "\n" . '{% endif %}',
            '{singlepost:comment:form:action}' =>
                '{{ post.comment_form.action }}',
            '{singlepost:comment:form:auth}' =>
                '<a rel="nofollow" href="{{ post.comment_form.auth.link }}">' .
                "\n" . '{{ post.comment_form.auth.title }}' . "\n" . '</a>',
            '{singlepost:comment:form:name}' => '{{ post.comment_form.name }}',
            '{singlepost:comment:form:site}' => '{{ post.comment_form.site }}',
            '{singlepost:comment:form:email}' => '{{ post.comment_form.email }}',
            '{singlepost:comment:form:captcha}' => '',
            '{singlepost:comment:form:submit}' => '',
            '{singlepost:comment:form:secure}' => '',
            '{singlepost:comment:form:blogid}' =>
                '{{ post.comment_form.comment_reply }}',
            '{singlepost:comment:form:comment_post_id}' => '{{ post.id }}',
            '{singlepost:comment:form:js}' => '',
            'name="addComment"' => 'name="submit"',
            'name="blogID"' => 'name="comment_reply"',
            '{/singlepost:comment:form}' => '{% endif %}',

            '{singlepost:related}' => '',
            '{singlepost:related:entry}' => '{% for related in widgets(\'related_posts\') %}',
            '{singlepost:related:entry:link}' => '{{ related.link }}',
            '{singlepost:related:entry:title}' => '{{ related.title }}',
            '{/singlepost:related:entry}' => '{% endfor %}',
            '{/singlepost:related}' => '',

            '{/if:singlepost}' => '{% else %}' . "\n" .
                '<div>Post tidak ditemukan</div>' . "\n" . '{% endif %}' . "\n" .
                '{% endif %}',

            '{if:guestbook}' => '{# ##########',
            '{/if:guestbook}' => '########## #}',
            '{if:feedback}' => '{# ##########',
            '{/if:feedback}' => '########## #}',

            '{footer}' => '{# footer #}',
            '{/footer}' => '{# end footer #}',

            '{modul:lastviews}' => '{# ##########',
            '{/modul:lastviews}' => '########## #}',
            '{modul:topviews}' => '{# ##########',
            '{/modul:topviews}' => '########## #}',
            '{shoutbook}' => '{# ##########',
            '{/shoutbook}' => '########## #}',
            '{following}' => '{# ##########',
            '{/following}' => '########## #}',
            '{modul:topcomments}' => '{# ##########',
            '{/modul:topcomments}' => '########## #}',

            '{modul:lastcommented}' => '{# widget recent comments #}',
            '{lastcommented:entry}' => '{% for r_com in widgets(\'recent_comments\') %}',
            '{lastcommented:entry:link}' => '{{ r_com.post.link }}',
            '{lastcommented:entry:title}' =>
                '{{ r_com.author_name }} on {{ r_com.post.title }}',
            '{/lastcommented:entry}' => '{% endfor %}',
            '{/modul:lastcommented}' => '{# end widget recent comments #}',

            '{navigation}' => '{# widget navigation #}',
            '{navigation:entry}' => '{% for nav in widgets(\'navigations\') %}',
            '{navigation:entry:code}' => '{{ nav }}',
            '{/navigation:entry}' => '{% endfor %}',
            '{/navigation}' => '{# end widget navigation #}',

            '{category}' => '{# widget category #}',
            '{category:entry}' => '{% for cat in widgets(\'categories\') %}',
            '{category:entry:link}' => '{{ cat.link }}',
            '{category:entry:count}' => '{{ cat.total_posts }}',
            '{category:entry:name}' => '{{ cat.name }}',
            '{/category:entry}' => '{% endfor %}',
            '{/category}' => '{# end widget category #}',

            '{if:notuser}' => '{% if is_guest %}',
            '{/if:notuser}' => '{% endif %}',
            '{if:user}' => '{% if is_user %}',
            '{/if:user}' => '{% endif %}',
            '{user:id}' => '{{ user.id }}',
            '{user:name}' => '{{ user.name }}',
            '{user:site}' => '{{ user.site }}',
            '{site:url}/home.xhtml' => '{{ site.url }}/index.html',
            '{site:url}/feedback.xhtml' => '#',
            '{site:url}/guestbook.xhtml' => '#',
            '{site:url}/follow.xhtml' => '#',
            '/mobile.iwb' => '/?t=mobile',
            '/desktop.iwb' => '/?t=desktop',
            '{site:url}' => '{{ site.url }}',
            '{site:icon}' => '',
            '{site:logo}' => '',
            '{site:metagoogle}' => '{{ site.set.metagoogle }}',
            '{site:statistics:today}' => '{{ site.hits_today }}',
            '{site:statistics:all}' => '{{ site.hits_total }}',
            '{site:description}' => '{{ site.set.description|e }}',
            'login.php?r=' => 'login.php?redirect=',
            'http://www.fastblog.net' => '{{ powered.url }}',
            'http://fastblog.net' => '{{ powered.url }}',
            'http://www.indowapblog.com' => '{{ powered.url }}',
            'http://indowapblog.com' => '{{ powered.url }}',
            );

        $new_content = str_ireplace(array_keys($replaces), array_values($replaces),
            $content); // Replace tags
        $new_content = preg_replace_callback('/\{\# \#\#\#\#\#\#\#\#\#\#(.*?)\#\#\#\#\#\#\#\#\#\# \#\}/is',
            create_function('$matches', 'return "";'), $new_content); // Remove tags unused in johncms blogger edition v2
        $new_content = trim($new_content);
        return $new_content;
    }
}

?>