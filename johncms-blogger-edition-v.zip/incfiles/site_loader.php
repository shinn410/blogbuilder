<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

function handle_html_template($source) {
    global $site;
    if (stripos($source, '</head>') === false) {
        return 'Template Error: end tag of "head" not found!';
    }
    elseif (stripos($source, '</body>') === false) {
        return 'Template Error: end tag of "body" not found!';
    }
    if (!file_exists(ROOTPATH . 'files/cache/blog_ads.dat')) {
        $ads = array();
        $ads['homepage'] = '<!-- Ads Homepage -->';
        $ads['singlepost'] = '<!-- Ads Singlepost -->';
    }
    else {
        $ads = unserialize(file_get_contents(ROOTPATH .
            'files/cache/blog_ads.dat'));
    }

    $replaces = array(
        '</head>' => '<meta name="google-site-verification" content="' .
            htmlentities($site['set']['metagoogle']) . '"/></head>',
        '</body>' => '<script><!-- bottom javascript --></script></body>',
        '[//JCMSBE_ADSX_HOMEPAGE//]' => $ads['homepage'],
        '[//JCMSBE_ADSX_SINGLEPOST//]' => $ads['singlepost'],
        );
    return str_ireplace(array_keys($replaces), array_values($replaces), $source);
}

$_SERVER['PATH_INFO'] = isset($_GET['routes']) ? $_GET['routes'] : '';
include_once (dirname(__file__) . '/route.php');

$act = isset($_GET['act']) ? trim($_GET['act']) : 'index';
$headmod = 'blog';
if (isset($_GET['t'])) {
    session_name('SESID');
    session_start();

    if ($_GET['t'] == 'mobile')
        $_SESSION['skin'] = 'mobile';
    elseif ($_GET['t'] == 'desktop')
        $_SESSION['skin'] = 'desktop';
    $parse = parse_url("http://" . $site_host . $_SERVER['REQUEST_URI']);

    header("Location: http://" . $parse['host'] . htmlentities($parse['path']));
    exit();

}
if ($act == 'content') {
    include (dirname(__file__) . '/blog/content.php');
    exit();
}
elseif ($act == 'site') {
    $path = explode('/', $_SERVER['PATH_INFO'], 6);
    $tpl_dir = str_replace('//', '/', str_replace('\\', '/', dirname(__file__))) .
        '/../sites/' . $site_host . '/site/';
    $indexes = explode('/', str_replace('\\', '/', $path[5]));
    $dir = array();
    foreach ($indexes as $idx) {
        $idx = trim($idx);
        if ($idx != '.' || $idx != '..' || mb_substr($idx, 0, 1) != '.' ||
            mb_substr($idx, -1) != '.')
            $dir[] = $idx;
    }
    $index = implode('/', $dir);

    $show_files = array(
        'jpg',
        'jpeg',
        'png',
        'gif',
        'css',
        'txt',
        'js',
        );
    if (strpos($index, '//') !== false) {
        header('Location: /' . str_replace('//', '/', $index));
        exit();
    }
    elseif (!is_file($tpl_dir . $index)) {
        if (file_exists($tpl_dir . '/404.html'))
            $index = '/404.html';
        else {
            header('Location: http://' . $site_host . '/');
            exit();
        }
    }
    elseif (mb_substr($index, -5) != '.html') {
        $mime_types = include_once (dirname(__file__) . '/mime_types.php');
        $ex = strtolower(substr(strrchr($index, "."), 1));
        if (in_array($ex, array_keys($mime_types)))
            $type = $mime_types[$ex];
        else
            $type = "application/octet-stream";
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $type);
        if (!in_array($ex, $show_files))
            header('Content-Disposition: attachment; filename=' . basename($index));
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($tpl_dir . $index));
        readfile($tpl_dir . $index);
        exit();
    }
}

require_once (dirname(__file__) . '/core.php');

$req = mysql_query("
        SELECT `blog_sites`.*, `users`.`name` AS `author_name`, `users`.`rights`, `users`.`sex`, `users`.`about`  AS `author_about`
        FROM `blog_sites`
        LEFT JOIN `users` ON `blog_sites`.`user_id` = `users`.`id`
        WHERE `blog_sites`.`url` = '" . mysql_real_escape_string($site_host) .
    "'");
if (mysql_num_rows($req) != 1) {
    header('Location: ' . $set['url'] . '/index.php');
    exit();
}

if (isset($_COOKIE['uid']))
    setcookie("uid", "", time() - 7200);
if (isset($_COOKIE['cups']))
    setcookie("cups", "", time() - 7200);

$site1 = mysql_fetch_assoc($req);
$site = array_merge($site1, array(
    'url' => 'http://' . $site1['url'],
    'name' => htmlspecialchars($site1['title'], ENT_QUOTES, 'UTF-8'),
    'title' => htmlspecialchars($site1['title'], ENT_QUOTES, 'UTF-8'),
    'set' => unserialize($site1['settings']),
    'author' => array(
        'id' => $site1['id'],
        'name' => $site1['author_name'],
        'gender' => $site1['sex'],
        'about' => htmlspecialchars($site1['author_about'], ENT_QUOTES, 'UTF-8'),
        ),
    ));
unset($site['settings']);
$timeshift = time() + $timeshift;
if ($site['hits_today_date'] == date("d-m-Y", $timeshift)) {
    $site_hits_today = $site['hits_today'] + 1;
    $site_hits_today_date = $site['hits_today_date'];
}
else {
    $site_hits_today = 1;
    $site_hits_today_date = date("d-m-Y", $timeshift);
}

$kmess = abs(intval($site['set']['postperpage']));
$kmess = $kmess < 1 ? 1 : $kmess;
$kmess = $kmess > 20 ? 20 : $kmess;
$start = isset($_REQUEST['page']) ? $page * $kmess - $kmess : 0;

$default_tpl = $is_mobile ? 'mobile' : 'desktop';
$template = isset($_SESSION['skin']) ? ($_SESSION['skin'] == 'mobile' ? 'mobile' :
    'desktop') : $default_tpl;

require_once str_replace('\\', '/', dirname(__file__)) .
    '/lib/Template/Autoloader.php';
Template_Autoloader::register();
if ($act != 'site') {
    $tpl_dir = str_replace('\\', '/', dirname(__file__)) . '/../sites/' . $site1['url'] .
        '/templates';
    if (!file_exists($tpl_dir . '/' . $template . '.html'))
        $tpl_dir = str_replace('\\', '/', dirname(__file__)) . '/blog';
}
$loader = new Template_Loader_Filesystem($tpl_dir);
$twig = new Template_Environment($loader, array(
    'cache' => false,
    'debug' => true,
    'autoescape' => false,
    ));
$twig->addExtension(new Template_Extension_Debug());
$module = new widgets($site);
function get_module($name, $options = null) {
    global $module;
    return $module->module($name, $options);
}
$moduler = new Template_SimpleFunction("widgets", "get_module");
$twig->addFunction($moduler);
$args = array(
    'site' => $site,
    'powered' => array('url' => $set['url'], 'title' => htmlspecialchars($set['copyright'],
            ENT_QUOTES, 'UTF-8')),
    'is_guest' => $user_id == 0 ? true : false,
    'is_user' => $user_id == 0 ? false : true,
    'user' => $user_id == false ? false : array(
        'id' => $datauser['id'],
        'name' => $datauser['name'],
        'site' => $datauser['www'],
        ),
    'page_title' => htmlspecialchars($site['title'], ENT_QUOTES, 'UTF-8'),
    'singlepostpage' => false,
    'homepage' => false,
    'categorypage' => false,
    'tagpage' => false,
    'searchpage' => false,
    'aboutpage' => false,
    'page_num' => $page,
    );

switch ($act) {
    case 'usersignout':
        if (isset($_SESSION['uid']))
            unset($_SESSION['uid']);
        if (isset($_SESSION['ups']))
            unset($_SESSION['ups']);
        if (isset($_SERVER['HTTP_REFERER']))
            header("Location: " . htmlentities($_SERVER['HTTP_REFERER']));
        else
            header("Location: " . $site['url'] . "/index.html");
        break;

    case 'index':
    case 'category':
    case 'tag':
    case '':
        mysql_query("UPDATE `blog_sites` SET
        `hits_today` = '" . $site_hits_today . "',
        `hits_today_date` = '" . $site_hits_today_date . "',
        `hits_total` = `hits_total` + 1
        WHERE `id` = '" . $site['id'] . "'") or die(mysql_error());
        $args = include_once (dirname(__file__) . '/blog/index.php');
        echo handle_html_template($twig->render($template . '.html', $args));
        break;

    case 'read':
        mysql_query("UPDATE `blog_sites` SET
        `hits_today` = '" . $site_hits_today . "',
        `hits_today_date` = '" . $site_hits_today_date . "',
        `hits_total` = `hits_total` + 1
        WHERE `id` = '" . $site['id'] . "'") or die(mysql_error());
        $args = include_once (dirname(__file__) . '/blog/read.php');
        echo handle_html_template($twig->render($template . '.html', $args));
        break;

    case 'rss':
        include_once (dirname(__file__) . '/blog/rss.php');
        break;

    case 'site':
        echo handle_html_template($twig->render($index, $args));
        break;

    default:
        header('Location: ' . $site['url'] . '/index.html');
        break;
}

?>