<?php

define('_IN_JOHNCMS', 1);

require ('incfiles/core.php');
$referer = isset($_SERVER['HTTP_REFERER']) ? htmlspecialchars($_SERVER['HTTP_REFERER']) :
    core::$system_set['homeurl'];

if (isset($_POST['submit']))
{
    setcookie('cuid', '');
    setcookie('cups', '');
    session_destroy();
    header('Location: ' . $home . '/index.php');
}
else
{
    $textl = $lng['exit'];
    $breadcrumb = functions::breadcrumb(array(array('label' => $lng['exit'])));
    require ('incfiles/head.php');
    echo '<div class="alert alert-danger" style="margin-left:0;margin-right:0;">Kamu yakin akan keluar?</div>' .
        '<form role="form" action="' . $set['homeurl'] . '/exit.php" method="post">' .
        '<p><button class="btn btn-primary" type="submit" name="submit">' . core::$lng['exit'] .
        '</button> <a data-dismiss="modal" class="btn btn-default" href="' . $referer . '">' . core::$lng['cancel'] .
        '</a></p></form>';
    require ('incfiles/end.php');
}
