<?php

define('_IN_JOHNCMS', 1);

$site_host = strtolower($_SERVER['SERVER_NAME']);
$site_host = substr($site_host, 0, 4) == 'www.' ? substr($site_host, 4) : $site_host;

if (is_dir('sites/' . $site_host)) {
    include_once ('incfiles/site_loader.php');
    exit();
}
require ('incfiles/core.php');
if (isset($_GET['__site']) && $_GET['__site'] == 'true') {
    header("Location: " . $set['url'] . "/index.php");
    exit();
}

if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);
if (isset($_GET['err']))
    $act = 404;

switch ($act) {
    case '404':
        $headmod = 'error404';
        require ('incfiles/head.php');


        echo '<div class="error-page"><h2 class="headline text-info"> 404</h2>' .
            '<div class="error-content"><h3><i class="fa fa-warning text-yellow"></i>' .
            ' Oops! Page not found.</h3>' .
            '<p>We could not find the page you were looking for. ' .
            'Meanwhile, you may <a href="' . $home .
            '/">return to homepage</a>.</p>' .
            '</div><!-- /.error-content --></div><!-- /.error-page -->';
        break;

    default:
        if (isset($_SESSION['ref']))
            unset($_SESSION['ref']);
        $headmod = 'mainpage';
        require ('incfiles/head.php');
        if ($user_id == 'x') {
            include 'pages/mainmenu.php';

            if (isset($set['sitemap'])) {
                $set_map = unserialize($set['sitemap']);
                if (($set_map['forum'] || $set_map['lib']) && ($set_map['users'] ||
                    !$user_id) && ($set_map['browsers'] || !$is_mobile)) {
                    $map = new sitemap();
                    echo '<div class="row">' . $map->site() . '</div>';
                }
            }
        }
        else {
            echo '<div class="main-page"><h2 class="text-center">Buat situs web Anda tanpa biaya</h2>' .
                '<p style="margin-bottom:30px;" class="text-center">' .
                htmlspecialchars($set['copyright']) .
                ' adalah tempat terbaik untuk blog pribadi ataupun situs usaha.</p>' .
                '<form role="form" action="' . $home .
                '/pages/blog.php/act/domaincheck" method="post">' .
                '<div style="max-width: 480px !important;margin: 0 auto !important;" ' .
                'class="box box-solid box-default">' .
                '<div class="box-header">' .
                '<h4 class="text-center">Periksa ketersediaan subdomain</h4></div>' .
                '<div class="box-body"><div class="input-group">' .
                '<input class="form-control" name="subdomain" placeholder="Masukan subdomain"/>' .
                '<span class="input-group-btn">' .
                '<button type="submit" class="btn btn-primary btn-flat">Check</button>' .
                '</span></div><p><div class="row">';
            foreach (unserialize($set['blogdomains']) as $domain) {
                echo '<div class="col-xs-6"><div class="checkbox"><label>' .
                    '<input type="checkbox" name="domains[]" value="' . $domain .
                    '"/> ' . $domain . '</label></div></div>';
            }
            echo '</div></p></div></div></form>';
            echo '<div class="row fiture">';
            echo '<div class="col-sm-4"><div class="bg-red fiture-icon">' .
                '<i class="fa fa-rss-square"></i></div>' .
                '<h3 class="fiture-title">Multi Blog</h3><p class="margin">' .
                'Gak perlu bikin banyak akun kalo cuma mau bikin beberapa blog, ' .
                'karena dalam satu akun Kamu bisa bikin lebih dari satu blog.</p></div>';
            echo '<div class="col-sm-4"><div class="bg-green fiture-icon">' .
                '<i class="fa fa-globe"></i></div>' .
                '<h3 class="fiture-title">Membuat Situs</h3><p class="margin">Gak cuma blog aja tapi juga ' .
                'bisa bikin situs di setiap blog yang Kamu buat.</p></div>';
            echo '<div class="col-sm-4"><div class="bg-aqua fiture-icon">' .
                '<i class="fa fa-html5"></i></div>' .
                '<h3 class="fiture-title">HTML Template</h3><p class="margin">' .
                'Hari gini cuma utak atik CSS doang, gak jaman. Di sini Kamu bisa edit html-nya juga ' .
                'dan yang pasti Javascript juga dibolehin kok..</p></div>';
            echo '</div></div>';
        }
        echo '<div class="visible-xs">';
        echo '<div class="list-group">' .
            '<div class="list-group-item list-group-item-success">' .
            '<span class="glyphicon glyphicon-info-sign"></span> ' . $lng['information'] .
            '</div>';

        echo '<a class="list-group-item" href="' . $set['homeurl'] .
            '/news/index.php">' . $lng['news_archive'] . ' <span class="badge">' .
            $mp->newscount . '</span></a>' . '<a class="list-group-item" href="' .
            $set['homeurl'] . '/pages/faq.php">' . $lng['information'] .
            ', FAQ</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
            '/pages/blog.php">Blog Katalog</a>' . '</div>';

        echo '<div class="list-group">' .
            '<div class="list-group-item list-group-item-info"><span class="glyphicon glyphicon-comment">' .
            '</span> ' . $lng['dialogue'] . '</div>';

        if ($set['mod_guest'] || $rights >= 7)
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/guestbook/index.php">' . $lng['guestbook'] .
                ' <span class="badge">' . counters::guestbook() . '</span></a>';

        if ($set['mod_forum'] || $rights >= 7)
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/forum/">' . $lng['forum'] . ' <span class="badge">' . counters::forum() .
                '</span></a>';
        echo '</div>';
        echo '<div class="list-group">' .
            '<div class="list-group-item list-group-item-warning">' .
            '<span class="glyphicon glyphicon-bookmark"></span> ' . $lng['useful'] .
            '</div>';

        if ($set['mod_down'] || $rights >= 7)
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/download/">' . $lng['downloads'] . ' <span class="badge">' .
                counters::downloads() . '</span></a>';

        if ($set['mod_lib'] || $rights >= 7)
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/library/">' . $lng['library'] . ' <span class="badge">' .
                counters::library() . '</span></a>';

        if ($set['mod_gal'] || $rights >= 7)
            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/gallery/">' . $lng['gallery'] . ' <span class="badge">' .
                counters::gallery() . '</span></a>';
        echo '<a class="list-group-item" href="' . $set['homeurl'] .
            '/templates/">Templates</a>';
        echo '</div>';
        if ($user_id || $set['active']) {
            echo '<div class="list-group">' .
                '<div class="list-group-item list-group-item-danger">' .
                '<span class="glyphicon glyphicon-globe"></span> ' . $lng['community'] .
                '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
                '/users/index.php">' . $lng['users'] . ' <span class="badge">' .
                counters::users() . '</span></a>' .
                '<a class="list-group-item" href="' . $set['homeurl'] .
                '/users/album.php">' . $lng['photo_albums'] .
                ' <span class="badge">' . counters::album() . '</span></a>' .
                '</div>';
        }
        echo '<div class="list-group"><a class="list-group-item list-group-item-info" href="' .
            $set['homeurl'] .
            '/http://gazenwagen.com"><span class="glyphicon glyphicon-link"></span> Gazenwagen</a></div>';
        echo '</div>';

        break;
}

require ('incfiles/end.php');
