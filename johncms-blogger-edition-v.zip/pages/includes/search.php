<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = "Pencarian";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
$q = isset($_GET['q']) ? htmlentities($_GET['q']) : '';
echo '<div class="col-sm-offset-4"><form method="get" action="' . $home .
    '/pages/blog.php/act/search">' .
    '<div class="input-group"><input class="form-control" type="text" value="' .
    $q . '" name="q" placeholder="Pencarion posting"/>' .
    '<span class="input-group-btn"><button class="btn btn-primary btn-flat" type="submit">&nbsp;&nbsp;&nbsp;Cari&nbsp;&nbsp;&nbsp;</button>' .
    '</span></div></form></div><hr />';
if ((mb_strlen($q) >= 2 && mb_strlen($q) <= 15))
{
    $total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE `title` LIKE '%" .
        mysql_real_escape_string(functions::search_db($q)) . "%' AND `time`<'" .
        time() . "'"), 0);
    if ($total == 0)
    {
        echo '<div class="alert alert-warning">Tidak menemukan hasil untuk pencarian "' .
            $q . '".</div>';
    }
    else
    {
        echo '<div class="alert alert-info">Ditemukan ' . $total .
            ' hasil untuk pencarian "' . $q . '".</div>';
        $query = mysql_query("SELECT `id`,`site_id`,`user_id`,`title`,`permalink`,`time` FROM `blog_posts` WHERE `title` LIKE '%" .
            mysql_real_escape_string(functions::search_db($q)) .
            "%' AND `time`<'" . time() . "' ORDER BY `time` DESC LIMIT $start, $kmess");
        $blog = array();
        $author = array();
        while ($post = mysql_fetch_array($query))
        {
            if (!isset($blog[$post['site_id']]))
            {
                $blog[$post['site_id']] = mysql_fetch_array(mysql_query("
                SELECT `title`,`url`
                FROM `blog_sites` 
                WHERE `id`='" . $post['site_id'] . "'
                "));
            }
            if (!isset($author[$post['user_id']]))
            {
                $author[$post['user_id']] = mysql_fetch_array(mysql_query("
                SELECT `name` 
                FROM `users` 
                WHERE `id`='" . $post['user_id'] . "'
                "));
            }
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            echo '<a href="//' . $blog[$post['site_id']]['url'] . '/' . $post['permalink'] .
                '.html"><h4>' . str_ireplace($q, "<font color=\"red\"><b>" . $q .
                "</b></font>", $post['title']) . '</h4></a><div class="sub">' .
                '<ul class="list-unstyled">' .
                '<li><i class="fa fa-rss"></i> Blog: <a href="//' . $blog[$post['site_id']]['url'] .
                '/">' . htmlspecialchars($blog[$post['site_id']]['title']) .
                '</a></li>' .
                '<li><i class="fa fa-user"></i> Penulis: <a href="' . $home .
                '/users/profile.php/user/' . $post['user_id'] . '">' . $author[$post['user_id']]['name'] .
                '</a></li>' . '<li><i class="fa fa-clock-o"></i> Waktu: ' .
                functions::display_date($post['time']) . '</ul>' . (($rights ==
                7 || $rights == 9) ? '<div><a href="' . $home .
                '/blogpanel/index.php/act/edit_post/post_id/' . $post['id'] .
                '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $home .
                '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' . $post['id'] .
                '"><i class="fa fa-times"></i> Hapus</a></div>' : '') .
                '</div></div>';
            ++$i;
        }
        if ($total > $kmess)
            echo '<div class="topmenu">' . functions::display_pagination($home .
                '/pages/blog.php/act/search', $start, $total, $kmess, '?q=' . $q .
                '&amp;page=%s') . '</div>';
    }
}
