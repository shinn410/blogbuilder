<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = "Blog Katalog";
$breadcrumb = functions::breadcrumb(array(array('label' => $textl), ));
require (dirname(__file__) . '/../../incfiles/head.php');

echo '<div class="row"><div class="col-sm-6" style="margin-bottom:10px;"><form method="get" action="' .
    $home . '/pages/blog.php/act/whois">' .
    '<div class="input-group"><input class="form-control" type="text" name="domain" value="" ' .
    'placeholder="Example: blog ' . $_SERVER['SERVER_NAME'] . '"/>' .
    '<span class="input-group-btn"><button class="btn btn-primary btn-flat" type="submit">WHOIS</button>' .
    '</span></div></form></div><div class="col-sm-6" style="margin-bottom:10px;"><form method="get" action="' .
    $home . '/pages/blog.php/act/search">' .
    '<div class="input-group"><input class="form-control" type="text" name="q" placeholder="Pencarion posting"/>' .
    '<span class="input-group-btn"><button class="btn btn-primary btn-flat" type="submit">&nbsp;&nbsp;&nbsp;Cari&nbsp;&nbsp;&nbsp;</button>' .
    '</span></div></form></div></div><hr />';
echo '<div class="row">';
echo '<div class="col-sm-4"><h3 class="page-header">Teratas</h3>' .
    '<div class="list-group"><a class="list-group-item" href="' . $home .
    '/pages/blog.php/act/recent_posts"><i class="fa fa-angle-double-right"></i> Posting Terbaru</a>' .
    '<a class="list-group-item" href="' . $home .
    '/pages/blog.php/act/top_comments"><i class="fa fa-angle-double-right"></i> Komentar Terbanyak</a>' .
    '<a class="list-group-item" href="' . $home .
    '/pages/blog.php/act/top_posts"><i class="fa fa-angle-double-right"></i> Posting Teratas</a>' .
    '<a class="list-group-item" href="' . $home .
    '/pages/blog.php/act/top_blogs"><i class="fa fa-angle-double-right"></i> Blog Teratas</a></div></div>';
echo '<div class="col-sm-8"><h3 class="page-header">Kategori</h3><div class="list-group">';
$blog_categories = unserialize($set['blogcategories']);
$in = array();
for ($i = 0; $i < count($blog_categories); $i++)
{
    $in[] = functions::permalink($blog_categories[$i]);
    $cat = functions::permalink($blog_categories[$i]);
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `category`='" .
        strtolower($cat) . "'"), 0);
    echo '<a class="list-group-item" href="' . $home .
        '/pages/blog.php/act/categories/category/' . $cat .
        '"><i class="fa fa-tag"></i> ' . $blog_categories[$i] .
        ' <span class="badge">' . $total . '</span></a>';
}
$total = mysql_result(mysql_query("
SELECT COUNT(*) 
FROM `blog_sites` 
WHERE FIND_IN_SET(category,'" . implode(",", $in) . "') = 0
"), 0);
echo '<a class="list-group-item" href="' . $home .
    '/pages/blog.php/act/categories/category/uncategorized"><i class="fa fa-tag"></i> ' .
    'Uncategorized <span class="badge">' . $total . '</span></a>';
echo '</div></div>';
echo '</div>';
