<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!isset($_GET['category']))
{
    $textl = "Kategori Blog";
    $breadcrumb = functions::breadcrumb(array(
        array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
        array('label' => $textl),
        ));
    require (dirname(__file__) . '/../../incfiles/head.php');
    echo functions::display_error('Tidak ada kategori yang dipilih',
        '<a class="alert-link" href="' . $home . '/blog.php">' . $lng['back'] .
        '</a>');
}
else
{
    $category = htmlentities($_GET['category']);
    $name = ucwords(str_replace("-", " ", $category));
    $textl = "Kategori::" . $name;
    $breadcrumb = functions::breadcrumb(array(
        array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
        array('label' => $textl),
        ));
    require (dirname(__file__) . '/../../incfiles/head.php');
    $total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_sites` WHERE `category`='" .
        mysql_real_escape_string($category) . "'"), 0);
    if ($total == 0)
    {
        echo '<div class="alert alert-warning">Tidak ada blog pada kategori ' .
            $name . '.</div>';
    }
    else
    {
        $author = array();
        $query = mysql_query("SELECT `id`,`user_id`,`title`,`url` FROM `blog_sites` WHERE `category`='" .
            mysql_real_escape_string($category) . "' ORDER BY `id` DESC LIMIT $start, $kmess");
        while ($blog = mysql_fetch_array($query))
        {
            if (!isset($author[$blog['user_id']]))
            {
                $author[$blog['user_id']] = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` 
                        WHERE `id`='" . $blog['user_id'] . "'"));
            }
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            echo '<a href="//' . $blog['url'] .
                '"><h4><i class="fa fa-rss"></i> ' . htmlspecialchars($blog['title']) .
                '</h4></a><div class="sub"><ul class="list-unstyled">' .
                '<li><i class="fa fa-user"></i> Pengelola: <a href="' . $home .
                '/users/profile.php/user/' . $blog['user_id'] . '">' . $author[$blog['user_id']]['name'] .
                '</a></li></ul>';
            if ($blog['user_id'] == $user_id || $rights == 7 || $rights == 9)
            {
                echo '<div><a href="' . $home .
                    '/blogpanel/index.php/act/settings/id/' . $blog['id'] .
                    '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $home .
                    '/blogpanel/index.php/act/delete_blog/id/' . $blog['id'] .
                    '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></div>';
            }
            echo '</div>';
            echo '</div>';
            ++$i;
        }
        if ($total > $kmess)
            echo '<div class="topmenu">' . functions::display_pagination($home .
                '/pages/blog.php/act/categories/category/' . $category . '/', $start,
                $total, $kmess) . '</div>';
    }
}
