<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'Domain Check';
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));

require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form role="form" action="' . $home .
    '/pages/blog.php/act/domaincheck" method="post">' .
    '<div style="max-width: 480px !important;margin: 0 auto !important;" class="box box-solid box-default">' .
    '<div class="box-header"><h4 class="text-center">Periksa ketersediaan subdomain</h4></div>' .
    '<div class="box-body">' .
    '<div class="input-group"><input class="form-control" name="subdomain" placeholder="Masukan subdomain"/>' .
    '<span class="input-group-btn">' .
    '<button type="submit" class="btn btn-primary btn-flat">Check</button>' .
    '</span></div>' . '<p><div class="row">';
foreach (unserialize($set['blogdomains']) as $domain)
{
    echo '<div class="col-xs-6"><div class="checkbox"><label><input type="checkbox" name="domains[]" value="' .
        $domain . '"/> ' . $domain . '</label></div></div>';
}
echo '</div></p></div></div></form>';

$subdomain = isset($_POST['subdomain']) ? functions::permalink(trim($_POST['subdomain'])) : false;
if ($subdomain != false && (mb_strlen($subdomain) < 4 || mb_strlen($subdomain) >
    16))
    $subdomain = false;
$domains = isset($_POST['domains']) ? $_POST['domains'] : false;

$blog_domains = unserialize($set['blogdomains']);

if ($subdomain && $domains && is_array($domains))
{
    echo '<div class="row" style="margin-top:20px;">';
    foreach ($domains as $domain)
    {
        if (in_array($domain, $blog_domains))
        {
            echo '<div class="col-sm-4">';
            $url = $subdomain . '.' . $domain;
            $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `url`='" .
                mysql_real_escape_string($url) . "' OR `url2`='" .
                mysql_real_escape_string($url) . "'"), 0);
            if ($total == 0)
            {
                echo
                    '<div class="box box-solid box-success"><div class="box-header">' .
                    '<h4 class="box-title">' . $url . '</h4></div>' .
                    '<div class="box-body"><div class="alert alert-success">Domain masih tersedia!</div>' .
                    '<p><a class="btn btn-primary btn-block" href="' . $home .
                    '/blogpanel/index.php/act/create_blog/domain/' . $url .
                    '">Pendaftaran</a></p></div></div>';
            }
            else
            {
                echo
                    '<div class="box box-solid box-danger"><div class="box-header">' .
                    '<h4 class="box-title">' . $url . '</h4></div>' .
                    '<div class="box-body"><div class="alert alert-danger">Domain tidak tersedia!</div>' .
                    '<p><a class="btn btn-primary btn-block" href="' . $home .
                    '/pages/blog.php/act/whois/domain/' . $url .
                    '">WHOIS</a></p></div></div>';
            }
            echo '</div>';
        }
    }
    echo '</div>';
}

?>