<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = 'WHOIS';
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

echo '<div class="col-sm-offset-4"><form method="get" action="' . $home .
    '/pages/blog.php/act/whois">' .
    '<div class="input-group"><input class="form-control" type="text" name="domain" value="" ' .
    'placeholder="Example: blog ' . $_SERVER['SERVER_NAME'] . '"/>' .
    '<span class="input-group-btn"><button class="btn btn-primary" type="submit">WHOIS</button>' .
    '</span></div></form></div><hr/>';
if (isset($_GET['domain']))
{
    $domain = strtolower(addslashes(htmlentities($_GET['domain'])));
    if (substr($domain, 0, 4) == "www.")
        $domain = substr($domain, 4);
    $br = mysql_query("SELECT * FROM `blog_sites` WHERE `url`='" .
        mysql_real_escape_string($domain) . "' OR `url2`='" .
        mysql_real_escape_string($domain) . "'");
    if (mysql_num_rows($br) != 0)
    {
        $blog = mysql_fetch_array($br);
        $uz = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`, `ip`, `browser`, `rights` FROM `users` WHERE `id` ='" .
            mysql_real_escape_string($blog['user_id']) . "'");
        $mass1 = mysql_fetch_assoc($uz);
        echo '<div class="row"><div class="col-sm-6"><div class="box box-solid">' .
            '<div class="box-body"><dl class="dl-horizontal">' .
            '<dt>URL Blog</dt><dd><a href="http://' . $domain . '">http://' . $domain .
            '</a></dd><dt>Judul/Nama Blog</dt><dd>' . htmlspecialchars($blog['title']) .
            '</dd><dt>Mendaftar</dt><dd>' . functions::display_date($blog['time']) .
            '</dd></dl></div></div></div>';
        echo '<div class="col-sm-6"><div class="box box-solid"><div class="box-body">';
        echo functions::display_user($mass1);
        echo '</div></div></div></div>';
    }
    else
    {
        echo '<div class="alert alert-danger">Data tidak ditemukan.</div>';
    }
}

?>