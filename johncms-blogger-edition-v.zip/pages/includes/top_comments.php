<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = "Komentar Terbanyak";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `time`<'" .
    time() . "'"), 0);
if ($total == 0)
{
    echo '<div class="alert alert-warning">Belum ada posting.</div>';
}
else
{
    $query = mysql_query("SELECT `site_id`,`user_id`,`title`,`permalink`,`comments`,`time` FROM `blog_posts` 
        WHERE `time`<'" . time() . "' ORDER BY `comments` DESC LIMIT 10");
    $blog = array();
    $author = array();
    while ($post = mysql_fetch_array($query))
    {
        if (!isset($blog[$post['site_id']]))
        {
            $blog[$post['site_id']] = mysql_fetch_array(mysql_query("
                SELECT `title`,`url`
                FROM `blog_sites` 
                WHERE `id`='" . $post['site_id'] . "'
                "));
        }
        if (!isset($author[$post['user_id']]))
        {
            $author[$post['user_id']] = mysql_fetch_array(mysql_query("
                SELECT `name` 
                FROM `users` 
                WHERE `id`='" . $post['user_id'] . "'
                "));
        }
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<a href="//' . $blog[$post['site_id']]['url'] . '/' . $post['permalink'] .
            '.html"><h4>' . htmlspecialchars($post['title']) .
            '</h4></a><div class="sub">' .
            '<ul class="list-unstyled"><li><i class="fa fa-rss"></i> Blog: <a href="//' .
            $blog[$post['site_id']]['url'] . '/">' . htmlspecialchars($blog[$post['site_id']]['title']) .
            '</a></li><li><i class="fa fa-user"></i> Penulis: <a href="' . $home .
            '/users/profile.php/user/' . $post['user_id'] . '">' . $author[$post['user_id']]['name'] .
            '</a></li><li><i class="fa fa-clock-o"></i> Waktu: ' . functions::display_date($post['time']) .
            '</li><li><i class="fa fa-comments"></i> Komentar: ' . $post['comments'] .
            '</li></ul></div>';
        echo '</div>';
        ++$i;
    }
}
