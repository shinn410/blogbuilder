<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = "Top Blog";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

switch ($mod)
{
    case 'all_time':
        $query = "`user_id`!=''";
        $order = "`hits_total`";
        break;
    default:
        $query = "`user_id`!='' AND `hits_today_date`='" . date("d-m-Y", (time() +
            $set['timeshift'])) . "'";
        $order = "`hits_today`";
        break;
}
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs">' . '<li' . ($mod !=
    'all_time' ? ' class="active"' : '') . '><a href="' . $home .
    '/pages/blog.php/act/top_blogs/mod/today">Hari ini</a></li>' . '<li' . ($mod ==
    'all_time' ? ' class="active"' : '') . '><a href="' . $home .
    '/pages/blog.php/act/top_blogs/mod/all_time">Semua waktu</a></li>' . '</ul>' .
    '<div class="tab-content">';
$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_sites` WHERE $query"),
    0);
if ($total == 0)
{
    echo '<div class="alert alert-warning">Belum ada Blog.</div>';
}
else
{
    $req = mysql_query("SELECT `id`,`user_id`,`title`,`url`,`hits_today`,`hits_total` FROM `blog_sites` 
        WHERE $query ORDER BY $order DESC LIMIT 10");
    $author = array();

    while ($blog = mysql_fetch_array($req))
    {
        if (!isset($author[$blog['user_id']]))
        {
            $author[$blog['user_id']] = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` 
                WHERE `id`='" . $blog['user_id'] . "'"));
        }
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<a href="//' . $blog['url'] . '"><h4><i class="fa fa-rss"></i> ' .
            htmlspecialchars($blog['title']) .
            '</h4></a><div class="sub"><ul class="list-unstyled">' .
            '<li><i class="fa fa-user"></i> Pengelola: <a href="' . $home .
            '/users/profile.php/user/' . $blog['user_id'] . '">' . $author[$blog['user_id']]['name'] .
            '</a></li>';
        if ($mod == "all_time")
            echo '<li><i class="fa fa-eye"></i> Hits semua waktu: ' . $blog['hits_total'] .
                '</li>';
        else
            echo '<li><li><i class="fa fa-eye"></i> Hits hari ini: ' . $blog['hits_today'] .
                '</li>';
        echo '</ul>' . (($rights == 7 || $rights == 9) ? '<div><a href="' . $home .
            '/blogpanel/index.php/act/settings/id/' . $blog['id'] .
            '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $home .
            '/blogpanel/index.php/act/delete_blog/id/' . $blog['id'] .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></div>' :
            '') . '</div></div>';
        ++$i;
    }
}
echo '</div><!-- /.tab-content --></div><!-- nav-tabs-custom -->';
