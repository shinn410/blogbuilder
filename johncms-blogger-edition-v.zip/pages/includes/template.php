<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$breadcrumb = functions::breadcrumb(array(
    array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
    array('label' => $textl),
    ));
require ('../incfiles/head.php');
echo '<h3>Twig for Template Designers</h3><p>This document describes the syntax and semantics of the template engine and will be most useful as reference to those creating Twig templates.</p>';
echo '<h3>Synopsis</h3>
<p>A template is simply a text file. It can generate any text-based format (HTML, XML, CSV, LaTeX, etc.). It doesn\'t have a specific extension, .html or .xml are just fine.</p>
<p>A template contains variables or expressions, which get replaced with values when the template is evaluated, and tags, which control the logic of the template.</p>
<p>Below is a minimal template that illustrates a few basics. We will cover further details later on:</p>';
echo '<p><pre><code>&lt;!DOCTYPE html&gt;
&lt;html&gt;
    &lt;head&gt;
        &lt;title&gt;My Webpage&lt;/title&gt;
    &lt;/head&gt;
    &lt;body&gt;
        &lt;ul id=&quot;navigation&quot;&gt;
        {% for item in navigation %}
            &lt;li&gt;&lt;a href=&quot;{{ item.href }}&quot;&gt;{{ item.caption }}&lt;/a&gt;&lt;/li&gt;
        {% endfor %}
        &lt;/ul&gt;

        &lt;h1&gt;My Webpage&lt;/h1&gt;
        {{ a_variable }}
    &lt;/body&gt;
&lt;/html&gt;
</code></pre></p>
<p>There are two kinds of delimiters: {% ... %} and {{ ... }}. The first one is used to execute statements such as for-loops, the latter prints the result of an expression to the template.</p>
<h3>Variables</h3>
<p>The application passes variables to the templates for manipulation in the template. Variables may have attributes or elements you can access, too. The visual representation of a variable depends heavily on the application providing it.</p>
<p>You can use a dot (.) to access attributes of a variable (methods or properties of a PHP object, or items of a PHP array), or the so-called "subscript" syntax ([]):</p>
<p><pre><code>{{ foo.bar }}
{{ foo[\'bar\'] }}</code></pre></p>
<p>When the attribute contains special characters (like - that would be interpreted as the minus operator), use the attribute function instead to access the variable attribute:</p>
<p><pre><code>{# equivalent to the non-working foo.data-foo #}
{{ attribute(foo, \'data-foo\') }}</code></pre></p>
<div class="callout callout-warning">It\'s important to know that the curly braces are not part of the variable but the print statement. When accessing variables inside tags, don\'t put the braces around them.</div>
<p>If a variable or attribute does not exist, you will receive a null value when the strict_variables option is set to false; alternatively, if strict_variables is set, Twig will throw an error.</p>
<div class="callout callout-info">
<h4>Implementation</h4>
<p>For convenience\'s sake foo.bar does the following things on the PHP layer:</p>
<ul>
<li>check if foo is an array and bar a valid element;</li>
<li>if not, and if foo is an object, check that bar is a valid property;</li>
<li>if not, and if foo is an object, check that bar is a valid method (even if bar is the constructor - use __construct() instead);</li>
<li>if not, and if foo is an object, check that getBar is a valid method;</li>
<li>if not, and if foo is an object, check that isBar is a valid method;</li>
<li>if not, return a null value. foo[\'bar\'] on the other hand only works with PHP arrays:</li>
<li>check if foo is an array and bar a valid element;</li>
<li>if not, return a null value.</li>
</ul>
</div>
<div class="callout callout-warning">If you want to access a dynamic attribute of a variable, use the <a href="http://twig.sensiolabs.org/doc/functions/attribute.html">attribute</a> function instead.</div>
<h3>Global Variables</h3>
<p>The following variables are always available in templates:</p>
<ul>
<li>_self: references the current template;</li>
<li>_context: references the current context;</li>
<li>_charset: references the current charset.</li>
</ul>
<h3>Setting Variables</h3>
<p>You can assign values to variables inside code blocks. Assignments use the <a href="http://twig.sensiolabs.org/doc/tags/set.html">set</a> tag:</p>
<p><pre><code>{% set foo = \'foo\' %}
{% set foo = [1, 2] %}
{% set foo = {\'foo\': \'bar\'} %}</code></pre></p>
<h3>Filters</h3>
<p>Variables can be modified by filters. Filters are separated from the variable by a pipe symbol (|) and may have optional arguments in parentheses. Multiple filters can be chained. The output of one filter is applied to the next.</p>
<p>The following example removes all HTML tags from the name and title-cases it:</p>
<p><pre><code>{{ name|striptags|title }}</code></pre></p>
<p>Filters that accept arguments have parentheses around the arguments. This example will join a list by commas:</p>
<p><pre><code>{{ list|join(\', \') }}</code></pre></p>
<p>To apply a filter on a section of code, wrap it in the filter tag:</p>
<p><pre><code>{% filter upper %}
    This text becomes uppercase
{% endfilter %}</code></pre></p>
<p>Go to the filters page to learn more about built-in filters.</p>
<h3>Functions</h3>
<p>Functions can be called to generate content. Functions are called by their name followed by parentheses (()) and may have arguments.</p>
<p>For instance, the range function returns a list containing an arithmetic progression of integers:</p>
<p><pre><code>{% for i in range(0, 3) %}
    {{ i }},
{% endfor %}</code></pre></p>
<p>Go to the functions page to learn more about the built-in functions.</p>
<h3>Named Arguments</h3>
<div class="callout callout-info">New in version 1.12: Support for named arguments was added in Twig 1.12.</div>
<p><pre><code>{% for i in range(low=1, high=10, step=2) %}
    {{ i }},
{% endfor %}</code></pre></p>
<p>Using named arguments makes your templates more explicit about the meaning of the values you pass as arguments:</p>
<p><pre><code>{{ data|convert_encoding(\'UTF-8\', \'iso-2022-jp\') }}

{# versus #}

{{ data|convert_encoding(from=\'iso-2022-jp\', to=\'UTF-8\') }}</code></pre></p>
<p>Named arguments also allow you to skip some arguments for which you don\'t want to change the default value:</p>
<p><pre><code>{# the first argument is the date format, which defaults to the global date format if null is passed #}
{{ "now"|date(null, "Europe/Paris") }}

{# or skip the format value by using a named argument for the time zone #}
{{ "now"|date(timezone="Europe/Paris") }}</code></pre></p>
<p>You can also use both positional and named arguments in one call, in which case positional arguments must always come before named arguments:</p>
<p><pre><code>{{ "now"|date(\'d/m/Y H:i\', timezone="Europe/Paris") }}</code></pre></p>
<div class="callout callout-warning">Each function and filter documentation page has a section where the names of all arguments are listed when supported.</div>
<h3>Control Structure</h3>
<p>A control structure refers to all those things that control the flow of a program - conditionals (i.e. if/elseif/else), for-loops, as well as things like blocks. Control structures appear inside {% ... %} blocks.</p>
</p>For example, to display a list of users provided in a variable called users, use the <a href="http://twig.sensiolabs.org/doc/tags/for.html">for</a> tag:</p>
<p><pre><code>&lt;h1&gt;Members&lt;/h1&gt;
&lt;ul&gt;
    {% for user in users %}
        &lt;li&gt;{{ user.username|e }}&lt;/li&gt;
    {% endfor %}
&lt;/ul&gt;
</code></pre></p>
<p>The <a href="http://twig.sensiolabs.org/doc/tags/if.html">if</a> tag can be used to test an expression:</p>
<p><pre><code>{% if users|length &gt; 0 %}
    &lt;ul&gt;
        {% for user in users %}
            &lt;li&gt;{{ user.username|e }}&lt;/li&gt;
        {% endfor %}
    &lt;/ul&gt;
{% endif %}
</code></pre></p>
<p>Go to the <a href="http://twig.sensiolabs.org/doc/tags/index.html">tags</a> page to learn more about the built-in tags.</p>
<h3>Comments</h3>
<p>To comment-out part of a line in a template, use the comment syntax {# ... #}. This is useful for debugging or to add information for other template designers or yourself:</p>
<p><pre><code>{# note: disabled template because we no longer use this
    {% for user in users %}
        ...
    {% endfor %}
#}</code></pre></p>
<h3>Including other Templates</h3>
<p>The include tag is useful to include a template and return the rendered content of that template into the current one:</p>
<p><pre><code>{% include \'sidebar.html\' %}</code></pre></p>
<p>Per default included templates are passed the current context.</p>
<p>The context that is passed to the included template includes variables defined in the template:</p>
<p><pre><code>{% for box in boxes %}
    {% include "render_box.html" %}
{% endfor %}</code></pre></p>
<p>The included template render_box.html is able to access box.</p>
<p>The filename of the template depends on the template loader. For instance, the Twig_Loader_Filesystem allows you to access other templates by giving the filename. You can access templates in subdirectories with a slash:</p>
<p><pre><code>{% include "sections/articles/sidebar.html" %}</code></pre></p>
<p>This behavior depends on the application embedding Twig.</p>
<h3>Template Inheritance</h3>
<p>The most powerful part of Twig is template inheritance. Template inheritance allows you to build a base "skeleton" template that contains all the common elements of your site and defines blocks that child templates can override.</p>
<p>Sounds complicated but it is very basic. It\'s easier to understand it by starting with an example.</p>
<p>Let\'s define a base template, base.html, which defines a simple HTML skeleton document that you might use for a simple two-column page:</p>
<p><pre><code>&lt;!DOCTYPE html&gt;
&lt;html&gt;

        {% block head %}
            &lt;link rel=&quot;stylesheet&quot; href=&quot;style.css&quot; /&gt;
            &lt;title&gt;{% block title %}{% endblock %} - My Webpage&lt;/title&gt;
        {% endblock %}
    &lt;/head&gt;
    &lt;body&gt;
        &lt;div id=&quot;content&quot;&gt;{% block content %}{% endblock %}&lt;/div&gt;
        &lt;div id=&quot;footer&quot;&gt;
            {% block footer %}
                &amp;copy; Copyright 2011 by &lt;a href=&quot;http://domain.invalid/&quot;&gt;you&lt;/a&gt;.
            {% endblock %}
        &lt;/div&gt;
    &lt;/body&gt;
&lt;/html&gt;
</code></pre></p>
<p>In this example, the <a href="http://twig.sensiolabs.org/doc/tags/block.html">block</a> tags define four blocks that child templates can fill in. All the block tag does is to tell the template engine that a child template may override those portions of the template.</p>
<p>A child template might look like this:</p>
<p><pre><code>{% extends &quot;base.html&quot; %}

{% block title %}Index{% endblock %}
{% block head %}
    {{ parent() }}
    &lt;style type=&quot;text/css&quot;&gt;
        .important { color: #336699; }
    &lt;/style&gt;
{% endblock %}
{% block content %}
    &lt;h1&gt;Index&lt;/h1&gt;
    &lt;p class=&quot;important&quot;&gt;
        Welcome to my awesome homepage.
    &lt;/p&gt;
{% endblock %}
</code></pre></p>
<p>The <a href="http://twig.sensiolabs.org/doc/tags/extends.html">extends</a> tag is the key here. It tells the template engine that this template "extends" another template. When the template system evaluates this template, first it locates the parent. The extends tag should be the first tag in the template.</p>
<p>Note that since the child template doesn\'t define the footer block, the value from the parent template is used instead.</p>
<p>It\'s possible to render the contents of the parent block by using the <a href="http://twig.sensiolabs.org/doc/functions/parent.html">parent</a> function. This gives back the results of the parent block:</p>
<p><pre><code>{% block sidebar %}
    &lt;h3&gt;Table Of Contents&lt;/h3&gt;
    ...
    {{ parent() }}
{% endblock %}
</code></pre><p>
<div class="callout callout-warning">The documentation page for the <a href="http://twig.sensiolabs.org/doc/tags/extends.html">extends</a> tag describes more advanced features like block nesting, scope, dynamic inheritance, and conditional inheritance.</div>
<div class="callout callout-info">Twig also supports multiple inheritance with the so called horizontal reuse with the help of the <a href="http://twig.sensiolabs.org/doc/tags/use.html">use</a> tag. This is an advanced feature hardly ever needed in regular templates.</div>
<h3>HTML Escaping</h3>
<p>When generating HTML from templates, there\'s always a risk that a variable will include characters that affect the resulting HTML. There are two approaches: manually escaping each variable or automatically escaping everything by default.</p>
<p>Twig supports both, automatic escaping is enabled by default.</p>
<div class="callout callout-info">Automatic escaping is only supported if the escaper extension has been enabled (which is the default).</div>
<h4>Working with Manual Escaping</h4>
<p>If manual escaping is enabled, it is your responsibility to escape variables if needed. What to escape? Any variable you don\'t trust.</p>
<p>Escaping works by piping the variable through the <a href="http://twig.sensiolabs.org/doc/filters/escape.html">escape</a> or e filter:</p>
<p><pre><code>{{ user.username|e }}</code></pre></p>
<p>By default, the escape filter uses the html strategy, but depending on the escaping context, you might want to explicitly use any other available strategies:</p>
<p><pre><code>{{ user.username|e(\'js\') }}
{{ user.username|e(\'css\') }}
{{ user.username|e(\'url\') }}
{{ user.username|e(\'html_attr\') }}</code></pre></p>
<h4>Working with Automatic Escaping</h4>
<p>Whether automatic escaping is enabled or not, you can mark a section of a template to be escaped or not by using the autoescape tag:</p>
<p><pre><code>{% autoescape %}
    Everything will be automatically escaped in this block (using the HTML strategy)
{% endautoescape %}</code></pre></p>
<p>By default, auto-escaping uses the html escaping strategy. If you output variables in other contexts, you need to explicitly escape them with the appropriate escaping strategy:</p>
<p><pre><code>{% autoescape \'js\' %}
    Everything will be automatically escaped in this block (using the JS strategy)
{% endautoescape %}</code></pre></p>
<h3>Escaping</h3>
<p>It is sometimes desirable or even necessary to have Twig ignore parts it would otherwise handle as variables or blocks. For example if the default syntax is used and you want to use {{ as raw string in the template and not start a variable you have to use a trick.</p>
<p>The easiest way is to output the variable delimiter ({{) by using a variable expression:</p>
<p><pre><code>{{ \'{{\' }}</code></pre></p>
<p>For bigger sections it makes sense to mark a block <a href="http://twig.sensiolabs.org/doc/tags/verbatim.html">verbatim</a>.</p>
<h3>Macros</h3>
<div class="callout callout-info">New in version 1.12: Support for default argument values was added in Twig 1.12.</div>
<p>Macros are comparable with functions in regular programming languages. They are useful to reuse often used HTML fragments to not repeat yourself.</p>
<p>A macro is defined via the <a href="http://twig.sensiolabs.org/doc/tags/macro.html">macro</a> tag. Here is a small example (subsequently called forms.html) of a macro that renders a form element:</p>
<p><pre><code>{% macro input(name, value, type, size) %}
    &lt;input type=&quot;{{ type|default(\'text\') }}&quot; name=&quot;{{ name }}&quot; value=&quot;{{ value|e }}&quot; size=&quot;{{ size|default(20) }}&quot; /&gt;
{% endmacro %}
</code></pre></p>
<p>Macros can be defined in any template, and need to be "imported" via the <a href="http://twig.sensiolabs.org/doc/tags/import.html">import</a> tag before being used:</p>
<p><pre><code>{% import &quot;forms.html&quot; as forms %}

&lt;p&gt;{{ forms.input(\'username\') }}&lt;/p&gt;
</code></pre></p>
<p>Alternatively, you can import individual macro names from a template into the current namespace via the <a href="http://twig.sensiolabs.org/doc/tags/from.html">from</a> tag and optionally alias them:</p>
<p><pre><code>{% from \'forms.html\' import input as input_field %}

&lt;dl&gt;
    &lt;dt&gt;Username&lt;/dt&gt;
    &lt;dd&gt;{{ input_field(\'username\') }}&lt;/dd&gt;
    &lt;dt&gt;Password&lt;/dt&gt;
    &lt;dd&gt;{{ input_field(\'password\', \'\', \'password\') }}&lt;/dd&gt;
&lt;/dl&gt;
</code></pre></p>
<p>A default value can also be defined for macro arguments when not provided in a macro call:</p>
<p><pre><code>{% macro input(name, value = &quot;&quot;, type = &quot;text&quot;, size = 20) %}
    &lt;input type=&quot;{{ type }}&quot; name=&quot;{{ name }}&quot; value=&quot;{{ value|e }}&quot; size=&quot;{{ size }}&quot; /&gt;
{% endmacro %}
</code></pre></p>
<h3>Expressions</h3>
<p>Twig allows expressions everywhere. These work very similar to regular PHP and even if you\'re not working with PHP you should feel comfortable with it.</p>
<div class="callout callout-info"><p>The operator precedence is as follows, with the lowest-precedence operators listed first: b-and, b-xor, b-or, or, and, ==, !=, <, >, >=, <=, in, matches, starts with, ends with, .., +, -, ~, *, /, //, %, is, **, |, [], and .:</p>
<p><pre><code>{% set greeting = \'Hello \' %}
{% set name = \'Fabien\' %}

{{ greeting ~ name|lower }}   {# Hello fabien #}

{# use parenthesis to change precedence #}
{{ (greeting ~ name)|lower }} {# hello fabien #}</code></pre></p></div>
<h4>Literals</h4>
<div class="callout callout-info">New in version 1.5: Support for hash keys as names and expressions was added in Twig 1.5.</div>
<p>The simplest form of expressions are literals. Literals are representations for PHP types such as strings, numbers, and arrays. The following literals exist:</p>
<ul>
<li>"Hello World": Everything between two double or single quotes is a string. They are useful whenever you need a string in the template (for example as arguments to function calls, filters or just to extend or include a template). A string can contain a delimiter if it is preceded by a backslash (\) -- like in \'It\'s good\'.</li>
<li>42 / 42.23: Integers and floating point numbers are created by just writing the number down. If a dot is present the number is a float, otherwise an integer.</li>
<li>["foo", "bar"]: Arrays are defined by a sequence of expressions separated by a comma (,) and wrapped with squared brackets ([]).</li>
<li>{"foo": "bar"}: Hashes are defined by a list of keys and values separated by a comma (,) and wrapped with curly braces ({}):</li>
<li><p><pre><code>{# keys as string #}
{ \'foo\': \'foo\', \'bar\': \'bar\' }

{# keys as names (equivalent to the previous hash) -- as of Twig 1.5 #}
{ foo: \'foo\', bar: \'bar\' }

{# keys as integer #}
{ 2: \'foo\', 4: \'bar\' }

{# keys as expressions (the expression must be enclosed into parentheses) -- as of Twig 1.5 #}
{ (1 + 1): \'foo\', (a ~ \'b\'): \'bar\' }
</code></pre></p></li>
<li>true / false: true represents the true value, false represents the false value.</li>
<li>null: null represents no specific value. This is the value returned when a variable does not exist. none is an alias for null.</li>
</ul>
<p>Arrays and hashes can be nested:</p>
<p><pre><code>{% set foo = [1, {"foo": "bar"}] %}</code></pre></p>
<p class="callout callout-danger">Using double-quoted or single-quoted strings has no impact on performance but string interpolation is only supported in double-quoted strings.</p>
<h4>Math</h4>
<p>Twig allows you to calculate with values. This is rarely useful in templates but exists for completeness\' sake. The following operators are supported:</p>
<ul>
<li>+: Adds two objects together (the operands are casted to numbers). {{ 1 + 1 }} is 2.</li>
<li>-: Subtracts the second number from the first one. {{ 3 - 2 }} is 1.</li>
<li>/: Divides two numbers. The returned value will be a floating point number. {{ 1 / 2 }} is {{ 0.5 }}.</li>
<li>%: Calculates the remainder of an integer division. {{ 11 % 7 }} is 4.</li>
<li>//: Divides two numbers and returns the floored integer result. {{ 20 // 7 }} is 2, {{ -20 // 7 }} is -3 (this is just syntactic sugar for the <a href="http://twig.sensiolabs.org/doc/filters/round.html">round</a> filter).</li>
<li>*: Multiplies the left operand with the right one. {{ 2 * 2 }} would return 4.</li>
<li>**: Raises the left operand to the power of the right operand. {{ 2 ** 3 }} would return 8.</li>
</ul>
<h4>Logic</h4
<p>You can combine multiple expressions with the following operators:</p>
<ul>
<li>and: Returns true if the left and the right operands are both true.</li>
<li>or: Returns true if the left or the right operand is true.</li>
<li>not: Negates a statement.</li>
<li>(expr): Groups an expression.</li>
</ul>
<p class="callout callout-info">Twig also support bitwise operators (b-and, b-xor, and b-or).</p>
<h4>Comparisons</h4>
<p>The following comparison operators are supported in any expression: ==, !=, <, >, >=, and <=.</p>
<p>You can also check if a string starts with or ends with another string:</p>
<p><pre><code>{% if \'Fabien\' starts with \'F\' %}
{% endif %}

{% if \'Fabien\' ends with \'n\' %}
{% endif %}</code></pre></p>
<div class="callout callout-info"><p>For complex string comparisons, the matches operator allows you to use <a href="http://php.net/manual/en/pcre.pattern.php">regular expressions</a>:</p>
<p><pre><code>{% if phone matches \'/^[\\d\\.]+$/\' %}
{% endif %}</code></pre></p></div>
<h4>Containment Operator</h4>
<p>The in operator performs containment test.</p>
<p>It returns true if the left operand is contained in the right:</p>
<p><pre><code>{# returns true #}

{{ 1 in [1, 2, 3] }}

{{ \'cd\' in \'abcde\' }}</code></pre></p>
<p class="callout callout-info">You can use this filter to perform a containment test on strings, arrays, or objects implementing the Traversable interface.</p>
<p>To perform a negative test, use the not in operator:</p>
<p><pre><code>{% if 1 not in [1, 2, 3] %}

{# is equivalent to #}
{% if not (1 in [1, 2, 3]) %}</code></pre></p>
<h4>Test Operator</h4>
<p>The is operator performs tests. Tests can be used to test a variable against a common expression. The right operand is name of the test:</p>
<p><pre><code>{# find out if a variable is odd #}

{{ name is odd }}</code></pre></p>
<p>Tests can accept arguments too:</p>
<p><pre><code>{% if post.status is constant(\'Post::PUBLISHED\') %}</code></pre></p>
<p>Tests can be negated by using the is not operator:</p>
<p><pre><code>{% if post.status is not constant(\'Post::PUBLISHED\') %}

{# is equivalent to #}
{% if not (post.status is constant(\'Post::PUBLISHED\')) %}</code></pre></p>
<p>Go to the <a href="http://twig.sensiolabs.org/doc/tests/index.html">tests</a> page to learn more about the built-in tests.</p>
<h4>Other Operators</h4>
<div class="callout callout-info">New in version 1.12.0: Support for the extended ternary operator was added in Twig 1.12.0.</div>
<p>The following operators are very useful but don\'t fit into any of the other categories:</p>
<ul>
<li>..: Creates a sequence based on the operand before and after the operator (this is just syntactic sugar for the <a href="http://twig.sensiolabs.org/doc/functions/range.html">range</a> function).</li>
<li>|: Applies a filter.</li>
<li>~: Converts all operands into strings and concatenates them. {{ "Hello " ~ name ~ "!" }} would return (assuming name is \'John\') Hello John!.</li>
<li>., []: Gets an attribute of an object.</li>
<li>?:: The ternary operator:
<p><pre><code>{{ foo ? \'yes\' : \'no\' }}

{# as of Twig 1.12.0 #}
{{ foo ?: \'no\' }} is the same as {{ foo ? foo : \'no\' }}
{{ foo ? \'yes\' }} is the same as {{ foo ? \'yes\' : \'\' }}</code></pre></p></li>
</ul>
<h4>String Interpolation</h4>
<div class="callout callout-info">New in version 1.5: String interpolation was added in Twig 1.5.</div>
<p>String interpolation (#{expression}) allows any valid expression to appear within a double-quoted string. The result of evaluating that expression is inserted into the string:</p>
<p><pre><code>{{ "foo #{bar} baz" }}
{{ "foo #{1 + 2} baz" }}</code></pre></p>
<h4>Whitespace Control</h4>
<div class="callout callout-info">New in version 1.1: Tag level whitespace control was added in Twig 1.1.</div>
<p>The first newline after a template tag is removed automatically (like in PHP.) Whitespace is not further modified by the template engine, so each whitespace (spaces, tabs, newlines etc.) is returned unchanged.</p>
</p>Use the spaceless tag to remove whitespace between HTML tags:</p>
<p><pre><code>{% spaceless %}
    &lt;div&gt;
        &lt;strong&gt;foo bar&lt;/strong&gt;
    &lt;/div&gt;
{% endspaceless %}

{# output will be &lt;div&gt;&lt;strong&gt;foo bar&lt;/strong&gt;&lt;/div&gt; #}
</code></pre></p>
<p>In addition to the spaceless tag you can also control whitespace on a per tag level. By using the whitespace control modifier on your tags, you can trim leading and or trailing whitespace:</p>
<p><pre><code>{% set value = \'no spaces\' %}
{#- No leading/trailing whitespace -#}
{%- if true -%}
    {{- value -}}
{%- endif -%}

{# output \'no spaces\' #}</code></pre></p>
<p>The above sample shows the default whitespace control modifier, and how you can use it to remove whitespace around tags. Trimming space will consume all whitespace for that side of the tag. It is possible to use whitespace trimming on one side of a tag:</p>
<p><pre><code>{% set value = \'no spaces\' %}
&lt;li&gt;    {{- value }}    &lt;/li&gt;

{# outputs \'&lt;li&gt;no spaces    &lt;/li&gt;\' #}
</code></pre></p>
<h3>
	Twig Reference
</h3>
<p>
	Browse the online reference to learn more about built-in features.
</p>
<div class="row">
	<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
		<h4>
			Tags
		</h4>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/autoescape.html">autoescape</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/block.html">block</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/do.html">do</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/embed.html">embed</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/extends.html">extends</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/filter.html">filter</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/flush.html">flush</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/for.html">for</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/from.html">from</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/if.html">if</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/import.html">import</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/include.html">include</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/macro.html">macro</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/sandbox.html">sandbox</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/set.html">set</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/spaceless.html">spaceless</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/use.html">use</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tags/verbatim.html">verbatim</a>
			</li>
		</ul>
	</div>
	<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
		<h4>
			Filters
		</h4>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/abs.html">abs</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/batch.html">batch</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/capitalize.html">capitalize</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/convert_encoding.html">convert_encoding</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/date.html">date</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/date_modify.html">date_modify</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/default.html">default</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/escape.html">escape</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/first.html">first</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/format.html">format</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/join.html">join</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/json_encode.html">json_encode</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/keys.html">keys</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/last.html">last</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/length.html">length</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/lower.html">lower</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/merge.html">merge</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/nl2br.html">nl2br</a>
			</li>
		</ul>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/number_format.html">number_format</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/raw.html">raw</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/replace.html">replace</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/reverse.html">reverse</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/round.html">round</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/slice.html">slice</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/sort.html">sort</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/split.html">split</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/striptags.html">striptags</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/title.html">title</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/trim.html">trim</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/upper.html">upper</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/filters/url_encode.html">url_encode</a>
			</li>
		</ul>
	</div>
	<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
		<h4>
			Functions
		</h4>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/attribute.html">attribute</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/block.html">block</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/constant.html">constant</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/cycle.html">cycle</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/date.html">date</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/dump.html">dump</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/include.html">include</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/max.html">max</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/min.html">min</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/parent.html">parent</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/random.html">random</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/range.html">range</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/source.html">source</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/functions/template_from_string.html">template_from_string</a>
			</li>
		</ul>
	</div>
	<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
		<h4>
			Tests
		</h4>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/constant.html">constant</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/defined.html">defined</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/divisibleby.html">divisibleby</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/empty.html">empty</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/even.html">even</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/iterable.html">iterable</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/null.html">null</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/odd.html">odd</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/tests/sameas.html">sameas</a>
			</li>
		</ul>
	</div>
	<div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
		<h4>
			Operators
		</h4>
		<ul class="list-unstyled">
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#containment-operator">in</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#test-operator">is</a>
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#math">Math</a>
				(+, -, /, %, //, *, **)
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#math">Logic</a>
				(and, or, not, (), b-and, b-xor, b-or)
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#comparisons">Comparisons</a>
				(==, !=, &gt;,&lt; , &lt;=, &gt;=,
				<a href="http://twig.sensiolabs.org/doc/tests/sameas.html">
				===
				</a>
				,
				<br />
				starts with, ends with, matches)
			</li>
			<li>
				<a href="http://twig.sensiolabs.org/doc/templates.html#other-operators">Others</a>
				(.., |, ~, ., [], ?:)
			</li>
		</ul>
	</div>
</div>';
?>