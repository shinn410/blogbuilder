<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = "Posting Terbaru";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Katalog', 'url' => '/pages/blog.php'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

$time = time();
$total = mysql_result(mysql_query("
        SELECT COUNT(DISTINCT `id`)
        FROM `blog_posts`
        WHERE `time`<'" . $time . "'
        "), 0);
if ($total == 0)
{
    echo '<div class="alert alert-info">Belum ada posting</div>';
}
else
{
    $query = mysql_query("
            SELECT `blog_posts`.`id`, `blog_posts`.`site_id`, `blog_posts`.`user_id`, `blog_posts`.`title`,
            `blog_posts`.`permalink`, `blog_posts`.`time`, `users`.`name` AS `author_name`,
            `blog_sites`.`url` AS `blog_url`, `blog_sites`.`title` AS `blog_title`
            FROM `blog_posts`
            LEFT JOIN `users` ON `blog_posts`.`user_id` = `users`.`id`
            LEFT JOIN `blog_sites` ON `blog_posts`.`site_id` = `blog_sites`.`id`
            WHERE `blog_posts`.`time`<'" . $time . "'
            ORDER BY `blog_posts`.`time`
            DESC LIMIT $start, $kmess
            ");
    while ($post = mysql_fetch_array($query))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<a href="//' . $post['blog_url'] . '/' . $post['permalink'] .
            '.html"><h4>' . htmlspecialchars($post['title']) .
            '</h4></a><div class="sub"><ul class="list-unstyled">' .
            '<li><i class="fa fa-rss"></i> Blog: <a href="//' . $post['blog_url'] .
            '/">' . htmlspecialchars($post['blog_title']) . '</a></li>' .
            '<li><i class="fa fa-user"></i> Penulis: <a href="' . $home .
            '/users/profile.php/user/' . $post['user_id'] . '">' . $post['author_name'] .
            '</a></li><li><i class="fa fa-clock-o"></i> Waktu: ' . functions::display_date($post['time']) .
            '</li></ul>' . (($rights == 7 || $rights == 9) ? '<div><a href="' .
            $home . '/blogpanel/index.php/act/edit_post/post_id/' . $post['id'] .
            '"><i class="fa fa-edit"></i> Edit</a>&nbsp;|&nbsp;<a href="' . $home .
            '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' . $post['id'] .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></div>' :
            '') . '</div>';
        echo '</div>';
        ++$i;
    }
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($home .
            '/pages/blog.php/act/recent_posts/', $start, $total, $kmess) .
            '</div>';
}
