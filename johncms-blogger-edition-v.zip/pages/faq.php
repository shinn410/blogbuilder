<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$lng_faq = core::load_lng('faq');
$lng_smileys = core::load_lng('smileys');
$textl = 'FAQ';
$headmod = 'faq';

if (empty($_SESSION['ref']))
{
    $_SESSION['ref'] = isset($_SERVER['HTTP_REFERER']) ? htmlspecialchars($_SERVER['HTTP_REFERER']) :
        $home;
}

$user_smileys = 20;

switch ($act)
{
    case 'template':
        $textl = 'Template';
        include 'includes/template.php';
        break;

    case 'forum':
        $textl = $lng_faq['forum_rules'];
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $lng_faq['forum_rules']),
            ));
        require ('../incfiles/head.php');
        echo '<p>' . $lng_faq['forum_rules_text'] . '</p><p>' . functions::link_back($lng['back'],
            $_SESSION['ref']) . '</p>';
        break;

    case 'tags':
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $textl = $lng_faq['tags']),
            ));
        require ('../incfiles/head.php');
        echo '<div class="menu"><p>' .
            '<table class="table table-striped" cellpadding="3" cellspacing="0">' .
            '<thead><tr><th>BBcode</th><th>Return</th></tr></thead>' .
            '<tbody><tr><td>[php]...[/php]</td><td>' . $lng['tag_code'] .
            '</td></tr><tr><td><a>' . $lng['link'] .
            '</a></td><td>[url=http://site_url]<span style="color:blue">' . $lng_faq['tags_link_name'] .
            '</span>[/url]</td></tr><tr><td>[b]...[/b]</td><td><b>' . $lng['tag_bold'] .
            '</b></td></tr><tr><td>[i]...[/i]</td><td><i>' . $lng['tag_italic'] .
            '</i></td></tr><tr><td>[u]...[/u]</td><td><u>' . $lng['tag_underline'] .
            '</u></td></tr><tr><td>[s]...[/s]</td><td><strike>' . $lng['tag_strike'] .
            '</strike></td></tr>' .
            '<tr><td>[red]...[/red]</td><td><span style="color:red">' . $lng['tag_red'] .
            '</span></td></tr>' .
            '<tr><td>[green]...[/green]</td><td><span style="color:green">' . $lng['tag_green'] .
            '</span></td></tr>' .
            '<tr><td>[blue]...[/blue]</td><td><span style="color:blue">' . $lng['tag_blue'] .
            '</span></td></tr><tr><td>[color=]...[/color]</td><td>' . $lng['color_text'] .
            '</td></tr><tr><td>[bg=][/bg]</td><td>' . $lng['color_bg'] .
            '</td></tr><tr><td>[c]...[/c]</td><td><span class="quote">' . $lng['tag_quote'] .
            '</span></td></tr>' .
            '<tr><td>[*]...[/*]</td><td><span class="bblist">' . $lng['tag_list'] .
            '</span></td></tr><tr><td>Spoiler</td><td>[spoiler=' . $lng['title'] .
            ']' . $lng['text'] . '[/spoiler]</td></tr></tbody>' .
            '</table></p></div>' .
            '<ul class="pager"><li class="previous"><a href="' . $_SESSION['ref'] .
            '">&larr; ' . $lng['back'] . '</a></li></ul>';
        break;

    case 'trans':
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $lng_faq['translit_help']),
            ));
        require ('../incfiles/head.php');
        echo '<div class="help-block"><p>' . $lng_faq['translit_help_text'] .
            '</p></div>';
        echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
            '</p>';
        break;

    case 'smileys':
        $textl = $lng['smileys'];
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $textl),
            ));
        require ('../incfiles/head.php');
        echo '<p>';
        if ($user_id)
        {
            $mycount = !empty($datauser['smileys']) ? count(unserialize($datauser['smileys'])) :
                '0';
            echo '<a class="func" href="' . $set['homeurl'] .
                '/pages/faq.php/act/my_smileys">' . $lng['my_smileys'] .
                ' <span class="badge">' . $mycount . ' / ' . $user_smileys .
                '</span></a>';
        }
        if ($rights >= 1)
            echo '&nbsp;<a class="func" href="' . $set['homeurl'] .
                '/pages/faq.php/act/smadm">' . $lng_faq['smileys_adm'] .
                ' <span class="badge">' . (int)count(glob(ROOTPATH .
                'images/smileys/admin/*.gif')) . '</span></a>';
        echo '</p>';
        $dir = glob(ROOTPATH . 'images/smileys/user/*', GLOB_ONLYDIR);
        foreach ($dir as $val)
        {
            $cat = explode('/', $val);
            $cat = array_pop($cat);
            if (array_key_exists($cat, $lng_smileys))
            {
                $smileys_cat[$cat] = $lng_smileys[$cat];
            }
            else
            {
                $smileys_cat[$cat] = ucfirst($cat);
            }
        }
        asort($smileys_cat);
        $i = 0;
        echo '<div class="list-group">';
        foreach ($smileys_cat as $key => $val)
        {

            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/pages/faq.php/act/smusr/cat/' . urlencode($key) . '">' .
                htmlspecialchars($val) . ' <span class="badge">' . count(glob(ROOTPATH .
                'images/smileys/user/' . $key . '/*.{gif,jpg,png}', GLOB_BRACE)) .
                '</span></a>';

            ++$i;
        }
        echo '</div>';
        echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
            '</p>';
        break;

    case 'smusr':
        $textl = $lng['smileys'];
        $dir = glob(ROOTPATH . 'images/smileys/user/*', GLOB_ONLYDIR);
        foreach ($dir as $val)
        {
            $val = explode('/', $val);
            $cat_list[] = array_pop($val);
        }
        $cat = isset($_GET['cat']) && in_array(trim($_GET['cat']), $cat_list) ?
            trim($_GET['cat']) : $cat_list[0];
        $smileys = glob(ROOTPATH . 'images/smileys/user/' . $cat .
            '/*.{gif,jpg,png}', GLOB_BRACE);
        $total = count($smileys);
        $end = $start + $kmess;
        if ($end > $total)
            $end = $total;
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $lng['smileys'], 'url' =>
                    '/pages/faq.php/act/smileys'),
            array('label' => (array_key_exists($cat, $lng_smileys) ? $lng_smileys[$cat] :
                    ucfirst(htmlspecialchars($cat)))),
            ));
        require ('../incfiles/head.php');
        if ($total)
        {
            if ($user_id)
            {
                $user_sm = isset($datauser['smileys']) ? unserialize($datauser['smileys']) :
                    '';
                if (!is_array($user_sm))
                    $user_sm = array();
                echo '<p><a class="func" href="' . $set['homeurl'] .
                    '/pages/faq.php/act/my_smileys">' . $lng['my_smileys'] .
                    ' <span class="badge">' . count($user_sm) . ' / ' . $user_smileys .
                    '</span></a></p><form role="form" action="' . $set['homeurl'] .
                    '/pages/faq.php/act/set_my_sm/cat/' . $cat . '/start/' . $start .
                    '" method="post">';
            }
            if ($total > $kmess)
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/pages/faq.php/act/smusr&amp;cat=' . urlencode($cat) . '/',
                    $start, $total, $kmess) . '</div>';
            for ($i = $start; $i < $end; $i++)
            {
                $smile = preg_replace('#^(.*?).(gif|jpg|png)$#isU', '$1',
                    basename($smileys[$i], 1));
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                if ($user_id)
                    echo (in_array($smile, $user_sm) ? '' :
                        '<input type="checkbox" name="add_sm[]" value="' . $smile .
                        '" />&#160;');
                echo '<img src="' . $set['homeurl'] . '/images/smileys/user/' .
                    $cat . '/' . basename($smileys[$i]) . '" alt="" />&#160;:' .
                    $smile . ': ' . $lng['lng_or'] . ' :' . functions::trans($smile) .
                    ':';
                echo '</div>';
            }
            if ($user_id)
                echo
                    '<br/><button class="btn btn-primary" type="submit" name="add">' .
                    $lng['add'] . ' </button></form>';
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        if ($total > $kmess)
        {
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/pages/faq.php/act/smusr/cat/' . urlencode($cat) . '?', $start,
                $total, $kmess) . '</div>';
        }
        echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
            '</p>';
        break;

    case 'smadm':
        $textl = $lng_faq['smileys_adm'];
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $lng['smileys'], 'url' =>
                    '/pages/faq.php/act/smileys'),
            array('label' => $lng_faq['smileys_adm']),
            ));
        require ('../incfiles/head.php');
        if ($rights < 1)
        {
            echo functions::display_error($lng['error_wrong_data'], '<a href="' .
                $set['homeurl'] . '/pages/faq.php/act/smileys">&larr; ' . $lng['back'] .
                '</a>');
            require ('../incfiles/end.php');
            exit;
        }
        $user_sm = unserialize($datauser['smileys']);
        if (!is_array($user_sm))
            $user_sm = array();
        echo '<p><a class="func" href="' . $set['homeurl'] .
            '/pages/faq.php/act/my_smileys">' . $lng['my_smileys'] .
            ' <span class="badge">' . count($user_sm) . ' / ' . $user_smileys .
            '</span></a></p><form role="form" action="' . $set['homeurl'] .
            '/pages/faq.php/act/set_my_sm/start/' . $start .
            '/adm" method="post">';
        $array = array();
        $dir = opendir('../images/smileys/admin');
        while (($file = readdir($dir)) !== false)
        {
            if (($file != '.') && ($file != "..") && ($file != "name.dat") && ($file !=
                ".svn") && ($file != "index.php"))
            {
                $array[] = $file;
            }
        }
        closedir($dir);
        $total = count($array);
        if ($total > 0)
        {
            $end = $start + $kmess;
            if ($end > $total)
                $end = $total;
            for ($i = $start; $i < $end; $i++)
            {
                $smile = preg_replace('#^(.*?).(gif|jpg|png)$#isU', '$1', $array[$i],
                    1);
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                $smileys = (in_array($smile, $user_sm) ? '' :
                    '<input type="checkbox" name="add_sm[]" value="' . $smile .
                    '" />&#160;');
                echo $smileys . '<img src="' . $set['homeurl'] .
                    '/images/smileys/admin/' . $array[$i] . '" alt="" /> - :' .
                    $smile . ': ' . $lng['lng_or'] . ' :' . functions::trans($smile) .
                    ':</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        echo '<br/><div><button class="btn btn-primary" type="submit" name="add">' .
            $lng['add'] . '</button></div></form>';
        echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess)
        {
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/pages/faq.php/act/smadm?', $start, $total, $kmess) . '</div>';
        }
        echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
            '</p>';
        break;

    case 'my_smileys':
        $textl = $lng['my_smileys'];
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
            array('label' => $lng['smileys'], 'url' =>
                    '/pages/faq.php/act/smileys'),
            array('label' => $lng['my_smileys']),
            ));
        require ('../incfiles/head.php');
        $smileys = !empty($datauser['smileys']) ? unserialize($datauser['smileys']) :
            array();
        $total = count($smileys);
        if ($total)
            echo '<form role="form" action="' . $set['homeurl'] .
                '/pages/faq.php/act/set_my_sm/start/' . $start .
                '" method="post">';
        if ($total > $kmess)
        {
            $smileys = array_chunk($smileys, $kmess);
            if ($start)
            {
                $key = ($start - $start % $kmess) / $kmess;
                $smileys_view = $smileys[$key];
                if (!count($smileys_view))
                    $smileys_view = $smileys[0];
                $smileys = $smileys_view;
            }
            else
            {
                $smileys = $smileys[0];
            }
        }
        $i = 0;
        foreach ($smileys as $value)
        {
            $smile = ':' . $value . ':';
            echo ($i % 2 ? '<div class="list2">' : '<div class="list1">') .
                '<input type="checkbox" name="delete_sm[]" value="' . $value .
                '" />&#160;' . functions::smileys($smile, $rights >= 1 ? 1 : 0) .
                '&#160;' . $smile . ' ' . $lng['lng_or'] . ' ' . functions::trans($smile) .
                '</div>';
            $i++;
        }
        if ($total)
        {
            echo '<br/><div><button class="btn btn-warning" type="submit" name="delete">' .
                $lng['delete'] . '</button>' . ($total ?
                ' <a class="btn btn-danger" href="' . $set['homeurl'] .
                '/pages/faq.php/act/set_my_sm/clean">' . $lng['clear'] . '</a>' :
                '') . '</div></form>';
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '<br /><a href="' . $set['homeurl'] .
                '/pages/faq.php/act/smileys">' . $lng['add_smileys'] .
                '</a></p></div>';
        }
        echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': ' . $total . ' / ' . $user_smileys . '</div>';
        if ($total > $kmess)
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/pages/faq.php/act/my_smileys/', $start, $total, $kmess) .
                '</div>';
        echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
            '</p>';
        break;

    case 'set_my_sm':
        $adm = isset($_GET['adm']);
        $add = isset($_POST['add']);
        $delete = isset($_POST['delete']);
        $cat = isset($_GET['cat']) ? trim($_GET['cat']) : '';
        if (($adm && !$rights) || ($add && !$adm && !$cat) || ($delete && !$_POST['delete_sm']) ||
            ($add && !$_POST['add_sm']))
        {
            require ('../incfiles/head.php');
            echo functions::display_error($lng['error_wrong_data'], '<a href="' .
                $set['homeurl'] . '/pages/faq.php/act/smileys">' . $lng['smileys'] .
                '</a>');
            require ('../incfiles/end.php');
            exit;
        }
        $smileys = unserialize($datauser['smileys']);
        if (!is_array($smileys))
            $smileys = array();
        if ($delete)
            $smileys = array_diff($smileys, $_POST['delete_sm']);
        if ($add)
        {
            $add_sm = $_POST['add_sm'];
            $smileys = array_unique(array_merge($smileys, $add_sm));
        }
        if (isset($_GET['clean']))
            $smileys = array();
        if (count($smileys) > $user_smileys)
        {
            $smileys = array_chunk($smileys, $user_smileys, true);
            $smileys = $smileys[0];
        }
        mysql_query("UPDATE `users` SET `smileys` = '" .
            mysql_real_escape_string(serialize($smileys)) . "' WHERE `id` = '$user_id'");
        if ($delete || isset($_GET['clean']))
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/pages/faq.php/act/my_smileys/start/' . $start);
        }
        else
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/pages/faq.php/act/' . ($adm ? 'smadm' : 'smusr/cat/' .
                urlencode($cat) . '') . 'start/' . $start . '');
        }
        break;

    case 'avatars':
        $textl = $lng['avatars'];
        if ($id && is_dir(ROOTPATH . 'images/avatars/' . $id))
        {
            $avatar = isset($_GET['avatar']) ? intval($_GET['avatar']) : false;
            if ($user_id && $avatar && is_file('../images/avatars/' . $id . '/' .
                $avatar . '.png'))
            {
                $breadcrumb = functions::breadcrumb(array(
                    array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
                    array('label' => $lng['avatars'], 'url' =>
                            '/pages/faq.php/act/avatars'),
                    array('label' => $lng_faq['set_to_profile']),
                    ));
                require ('../incfiles/head.php');
                if (isset($_POST['submit']))
                {

                    if (@copy('../images/avatars/' . $id . '/' . $avatar .
                        '.png', '../files/users/avatar/' . $user_id . '.png'))
                    {
                        echo '<div class="alert alert-success"><p>' . $lng['avatar_applied'] .
                            '<br /><a class="alert-link" href="' . $set['homeurl'] .
                            '/users/profile.php/act/edit">' . $lng['continue'] .
                            '</a></p></div>';
                    }
                    else
                    {
                        echo functions::display_error($lng['error_avatar_select'],
                            '<a class="alert-link" href="' . $_SESSION['ref'] .
                            '">&larr; ' . $lng['back'] . '</a>');
                    }
                }
                else
                {
                    echo '<div class="alert alert-info"><p><img src="' . $set['homeurl'] .
                        '/images/avatars/' . $id . '/' . $avatar .
                        '.png" alt="" /> ' . $lng_faq['avatar_change_warning'] .
                        '</p></div><div><form role="form" action="' . $set['homeurl'] .
                        '/pages/faq.php/act/avatars/id/' . $id . '/avatar/' . $avatar .
                        '" method="post">' .
                        '<p><button class="btn btn-primary" type="submit" name="submit">' .
                        $lng['save'] . '</button> ' .
                        '<button class="btn btn-danger" data-dismiss="modal" type="button"' . (!
                        $is_modal ? ' onclick="history.back();"' : '') . '>' . $lng['cancel'] .
                        '</button></p></form></div>';
                }
            }
            else
            {
                $breadcrumb = functions::breadcrumb(array(
                    array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
                    array('label' => $lng['avatars'], 'url' =>
                            '/pages/faq.php/act/avatars'),
                    array('label' => htmlentities(file_get_contents(ROOTPATH .
                            'images/avatars/' . $id . '/name.dat'), ENT_QUOTES,
                            'utf-8')),
                    ));

                require ('../incfiles/head.php');
                $array = glob(ROOTPATH . 'images/avatars/' . $id . '/*.png');
                $total = count($array);
                $end = $start + $kmess;
                if ($end > $total)
                    $end = $total;
                if ($total > 0)
                {
                    for ($i = $start; $i < $end; $i++)
                    {
                        echo $i % 2 ? '<div class="list2">' :
                            '<div class="list1">';
                        echo '<img src="' . $set['homeurl'] . '/images/avatars/' .
                            $id . '/' . basename($array[$i]) . '" alt="" />';
                        if ($user_id)
                            echo ' - <a data-toggle="' . functions::set_modal() .
                                '" data-target="#global-modal" href="' . $set['homeurl'] .
                                '/pages/faq.php/act/avatars/id/' . $id .
                                '/avatar/' . basename($array[$i]) . '">' . $lng['select'] .
                                '</a>';
                        echo '</div>';
                    }
                }
                else
                {
                    echo '<div class="alert alert-warning">' . $lng['list_empty'] .
                        '</div>';
                }
                echo
                    '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                    $lng['total'] . ': ' . $total . '</div>';
                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/pages/faq.php/act/avatars/id/' . $id . '?', $start, $total,
                        $kmess) . '</p>';
                }
                echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
                    '</p>';
            }
        }
        else
        {

            $breadcrumb = functions::breadcrumb(array(
                array('label' => 'F.A.Q.', 'url' => '/pages/faq.php'),
                array('label' => $lng['avatars']),
                ));
            require ('../incfiles/head.php');
            $dir = glob(ROOTPATH . 'images/avatars/*', GLOB_ONLYDIR);
            $total = 0;
            $total_dir = count($dir);
            echo '<div class="list-group">';
            for ($i = 0; $i < $total_dir; $i++)
            {
                $count = (int)count(glob($dir[$i] . '/*.png'));
                $total = $total + $count;

                echo '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/pages/faq.php/act/avatars/id/' . basename($dir[$i]) . '">' .
                    htmlentities(file_get_contents($dir[$i] . '/name.dat'),
                    ENT_QUOTES, 'utf-8') . ' <span class="badge">' . $count .
                    '</span></a>';
            }
            echo '</div>';

            echo '<p>' . functions::link_back($lng['back'], $_SESSION['ref']) .
                '</p>';
        }
        break;

    default:
        $breadcrumb = functions::breadcrumb(array(array('label' => $textl)));
        require ('../incfiles/head.php');
        echo '<div class="list-group">' . (@$header != false ?
            '<div class="list-group-item list-group-item-info">F.A.Q.</div>' :
            '') . '<a class="list-group-item' . ($act == 'forum' ? ' active' :
            '') . '" href="' . $set['homeurl'] . '/pages/faq.php/act/forum">' .
            $lng_faq['forum_rules'] . '</a><a class="list-group-item' . ($act ==
            'tags' ? ' active' : '') . '" href="' . $set['homeurl'] .
            '/pages/faq.php/act/tags">' . $lng_faq['tags'] . '</a>';
        if (core::$user_set['translit'])
            echo '<a class="list-group-item' . ($act == 'trans' ? ' active' : '') .
                '" href="' . $set['homeurl'] . '/pages/faq.php/act/trans">' . $lng_faq['translit_help'] .
                '</a>';
        echo '<a class="list-group-item' . ($act == 'avatars' ? ' active' : '') .
            '" href="' . $set['homeurl'] . '/pages/faq.php/act/avatars">' . $lng['avatars'] .
            '</a><a class="list-group-item' . ($act == 'avatars' ? ' active' :
            '') . '" href="' . $set['homeurl'] . '/pages/faq.php/act/smileys">' .
            $lng['smileys'] . '</a><a class="list-group-item" href="' . $set['homeurl'] .
            '/pages/faq.php/act/template">Template</a></div>';
}

require ('../incfiles/end.php');
