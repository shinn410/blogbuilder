<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
switch ($mod)
{
    case 'notifications':
        if (!$user_id)
            exit();
        $req = mysql_query("SELECT `key`,`text` FROM `cms_notifications` WHERE `user_id` = '$user_id' AND `read`='0' ORDER BY `time` DESC LIMIT 10");
        if (mysql_num_rows($req) > 0)
        {
            while ($ntf = mysql_fetch_array($req))
            {
                echo '<li>' . strip_tags($ntf['text']) . ' <a href="' . $home .
                    '/users/notifications.php/read/' . $ntf['key'] .
                    '">[&raquo;]</a></li>';
            }
        }
        break;

    case 'messages':
        if (!$user_id)
        {
            echo '<li><p class="text-danger text-center">Silakan masuk terlebih dahulu</p></li>';
            exit();
        }
        $total = mysql_result(mysql_query("SELECT COUNT(*)
        FROM (SELECT DISTINCT `cms_mail`.`user_id`
        FROM `cms_mail`
        LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id`
        WHERE `cms_mail`.`from_id`='$user_id'
        AND `cms_mail`.`delete`!='$user_id'
        AND `cms_mail`.`sys`='0'
        AND `cms_contact`.`ban`!='1') `tmp`"), 0);

        if ($total)
        {
            $req = mysql_query("SELECT `users`.*, MAX(`cms_mail`.`time`) AS `time`
            FROM `cms_mail`
            LEFT JOIN `users` ON `cms_mail`.`user_id`=`users`.`id`
            LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id`
            AND `cms_contact`.`user_id`='$user_id'
            WHERE `cms_mail`.`from_id`='$user_id'
            AND `cms_mail`.`delete`!='$user_id'
            AND `cms_mail`.`sys`='0'
            AND `cms_contact`.`ban`!='1'
            GROUP BY `cms_mail`.`user_id`
            ORDER BY MAX(`cms_mail`.`time`) DESC
            LIMIT " . $start . "," . $kmess);

            for ($i = 0; $row = mysql_fetch_assoc($req); ++$i)
            {
                $new_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail`
                WHERE `user_id`='{$row['id']}'
                AND `from_id`='$user_id'
                AND `delete`!='$user_id'
                AND `read`!='1'
                AND `sys`!='1'
                "), 0);

                $last_msg = mysql_fetch_assoc(mysql_query("SELECT *
                FROM `cms_mail`
                WHERE `from_id`='$user_id'
                AND `user_id` = '{$row['id']}'
                AND `sys`='0'
                AND `delete` != '$user_id'
                ORDER BY `id` DESC
                LIMIT 1"));
                if (file_exists((ROOTPATH . 'files/users/avatar/' . $row['id'] .
                    '.png')))
                    $img = $set['homeurl'] . '/files/users/avatar/' . $row['id'] .
                        '.png"';
                else
                    $img = $set['homeurl'] . '/images/empty.png';
                echo '<li><a href="' . $home . '/mail/index.php/act/write/id/' .
                    $row['id'] . '"><div class="pull-left"><img src="' . $img .
                    '" class="img-circle" alt=""/></div><h4>' . $row['name'] .
                    '<small><i class="fa fa-clock-o"></i> ' . functions::display_date($last_msg['time']) .
                    '</small></h4><p>' . $new_message .
                    ' pesan baru</p></a></li>';

            }
        }
        else
        {
            echo '<li><p class="text-danger text-center">Tidak ada pesan</p></li>';
        }
        break;

    case 'forumthread':
        $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `close`!='1' AND `refid`='$id'
        ORDER BY `vip` DESC, `time` DESC LIMIT 5");
        if (mysql_num_rows($req))
        {
            echo '<div class="list-group">';
            while ($res = mysql_fetch_array($req))
            {
                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'
                AND `refid`='" . $res['id'] . "' AND `close` != '1'"), 0);
                echo '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $res['id'] . '">' . $res['text'] .
                    ' <span class="badge">' . $colmes . '</span></a>';
            }
            echo '</div>';
        }
        break;
    case 'getchat':
        site_widgets::get_chat(10);
        break;
    case 'sendchat':
        $msg = isset($_POST['msg']) ? $_POST['msg'] : '';
        if (!$user_id)
        {
            exit();
        }
        if (empty($msg))
        {
            exit();
        }
        elseif (mb_strlen($msg) > 150)
        {
            exit();
        }
        mysql_query("INSERT INTO `chats` SET `user_id` = $user_id, `name` = '" .
            mysql_real_escape_string($datauser['name']) . "', `message`= '" .
            mysql_real_escape_string($msg) . "', `date` = '" . time() . "'");
        break;
    default:
        break;
}

?>