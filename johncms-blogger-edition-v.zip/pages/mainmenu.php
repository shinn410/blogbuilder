<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="text-center"><h3>Welcome to ' . $set['copyright'] .
    '</h3><p>The largest Indonesian Community</p><img src="http://site.id/users/avatar.php/user/1/width/60/height/60" data-toggle="tooltip" data-title="Achunk" class="img-circle"/></div>';

$mp = new mainpage();
$site_news = $mp->news;
echo ('<div class="row hidden-xs"><div class="col-sm-6">');
include_once (dirname(__file__) . '/forum_list.php');
echo ('</div><div class="col-sm-6">');

include_once (dirname(__file__) . '/recent_post.php');
echo ('</div></div>');
echo $site_news;
echo '<div class="visible-xs">';

echo '<div class="list-group">' .
    '<div class="list-group-item list-group-item-success"><span class="glyphicon glyphicon-info-sign"></span> ' .
    $lng['information'] . '</div>';

echo '<a class="list-group-item" href="' . $set['homeurl'] . '/news/index.php">' .
    $lng['news_archive'] . ' <span class="badge">' . $mp->newscount .
    '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/pages/faq.php">' . $lng['information'] . ', FAQ</a>' . '</div>';

echo '<div class="list-group">' .
    '<div class="list-group-item list-group-item-info"><span class="glyphicon glyphicon-comment"></span> ' .
    $lng['dialogue'] . '</div>';

if ($set['mod_guest'] || $rights >= 7)
    echo '<a class="list-group-item" href="' . $set['homeurl'] .
        '/guestbook/index.php">' . $lng['guestbook'] . ' <span class="badge">' .
        counters::guestbook() . '</span></a>';

if ($set['mod_forum'] || $rights >= 7)
    echo '<a class="list-group-item" href="' . $set['homeurl'] . '/forum/">' . $lng['forum'] .
        ' <span class="badge">' . counters::forum() . '</span></a>';
echo '</div>';
echo '<div class="list-group">' .
    '<div class="list-group-item list-group-item-warning"><span class="glyphicon glyphicon-bookmark"></span> ' .
    $lng['useful'] . '</div>';

if ($set['mod_down'] || $rights >= 7)
    echo '<a class="list-group-item" href="' . $set['homeurl'] . '/download/">' .
        $lng['downloads'] . ' <span class="badge">' . counters::downloads() .
        '</span></a>';

if ($set['mod_lib'] || $rights >= 7)
    echo '<a class="list-group-item" href="' . $set['homeurl'] . '/library/">' .
        $lng['library'] . ' <span class="badge">' . counters::library() .
        '</span></a>';

if ($set['mod_gal'] || $rights >= 7)
    echo '<a class="list-group-item" href="' . $set['homeurl'] . '/gallery/">' .
        $lng['gallery'] . ' <span class="badge">' . counters::gallery() .
        '</span></a>';
echo '</div>';
if ($user_id || $set['active'])
{
    echo '<div class="list-group">' .
        '<div class="list-group-item list-group-item-danger"><span class="glyphicon glyphicon-globe"></span> ' .
        $lng['community'] . '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/index.php">' . $lng['users'] . ' <span class="badge">' .
        counters::users() . '</span></a>' . '<a class="list-group-item" href="' .
        $set['homeurl'] . '/users/album.php">' . $lng['photo_albums'] .
        ' <span class="badge">' . counters::album() . '</span></a>' . '</div>';
}
echo '<div class="list-group"><a class="list-group-item list-group-item-info" href="' .
    $set['homeurl'] .
    '/http://gazenwagen.com"><span class="glyphicon glyphicon-link"></span> Gazenwagen</a></div>';
echo '</div>';

?>
