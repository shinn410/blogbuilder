<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */
$req = mysql_query("SELECT `id`, `text` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
if (mysql_num_rows($req) != 0)
{
    echo '<div class="panel panel-success hidden-xs">' .
        '<div class="panel-heading"><strong>Forum</strong></div>' .
        '<div class="panel-body">' .
        '<p class="text-center">You and Me together!</p>' . '</div>';
    echo '<div class="list-group">';
    while ($res = mysql_fetch_array($req))
    {
        echo '<div class="list-group-item list-group-item-info"><strong>' . $res['text'] .
            '</strong></div>';
        $req1 = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='r' and `refid`='" .
            $res['id'] . "' ORDER BY `realid`");
        while (($res1 = mysql_fetch_array($req1)) !== false)
        {
            $coltem = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '" .
                $res1['id'] . "'"), 0);
            //$colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'$sql AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
            echo '<a class="list-group-item" data-toggle="popover" title="' . $res1['text'] .
                '" data-content="<b>' . (isset($res1['soft']) ? htmlentities($res1['soft'],
                ENT_QUOTES, 'UTF-8') : '') . '</b>" href="' . $set['homeurl'] .
                '/forum/index.php/id/' . $res1['id'] . '">' . $res1['text'] .
                ' <span class="badge">' . $coltem . '</span></a>';
        }
    }
    echo '</div>';
    echo '</div>';
    $jquery .= '$(\'[data-toggle="popover"]\').popover({
	  \'trigger\' : \'hover\',
	  \'placement\' : \'auto\',
	  \'html\' : \'true\',
	  \'template\' : \'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>\',
	});';
}

?>