<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */
echo '<ul class="list-group">';
echo '<li class="list-group-item list-group-item-success"><strong>Forum Recent Posts</strong></li>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `close` != '1'"),
    0);
if ($total)
{
    $req = mysql_query("SELECT * FROM `forum`
                WHERE `type`='t'" . ($rights >= 7 ? "" : " AND `close` != '1'") .
        "
                ORDER BY `time` DESC
                LIMIT 10;");
    for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
    {
        // echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<li class="list-group-item">';
        $q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type` = 'r' AND `id` = '" .
            $res['refid'] . "' LIMIT 1");
        $razd = mysql_fetch_assoc($q3);
        $q4 = mysql_query("SELECT `id`, `text` FROM `forum` WHERE `type`='f' AND `id` = '" .
            $razd['refid'] . "' LIMIT 1");
        $frm = mysql_fetch_assoc($q4);
        $colmes = mysql_query("SELECT `from`, `time` FROM `forum` WHERE `refid` = '" .
            $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' :
            " AND `close` != '1'") . " ORDER BY `time` DESC");
        $colmes1 = mysql_num_rows($colmes);
        $cpg = ceil($colmes1 / $kmess);
        $nick = mysql_fetch_assoc($colmes);
        // Ikon
        $icons = array(
            (isset($np) ? (!$res['vip'] ? functions::image('op.gif') : '') :
                functions::image('np.gif')),
            ($res['vip'] ? functions::image('pt.gif') : ''),
            ($res['realid'] ? functions::image('rate.gif') : ''),
            ($res['edit'] ? functions::image('tz.gif') : ''));
        echo functions::display_menu($icons, '');
        echo '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $res['id'] .
            '">' . $res['text'] . '</a>&#160;<span class="badge">' . $colmes1 .
            '</span>';
        //if ($cpg > 1)
        echo '&#160;<a class="pull-right" href="' . $set['homeurl'] .
            '/forum/index.php/id/' . $res['id'] . '/page/' . $cpg .
            '"> <span class="glyphicon glyphicon-arrow-right"></span> </a>';
        echo '<div class="sub">' . $res['from'] . ($colmes1 > 1 ?
            '&#160;/&#160;' . $nick['from'] : '') . ' <span class="gray">(' .
            functions::display_date($nick['time']) . ')</span><br />' .
            '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $frm['id'] .
            '">' . $frm['text'] . '</a>&#160;/&#160;<a href="' . $set['homeurl'] .
            '/forum/index.php/id/' . $razd['id'] . '">' . $razd['text'] . '</a>' .
            '</div>';
        echo '</li>';
        // echo '</div>';
    }
}
else
{
    echo '<li class="list-group-item">' . $lng['list_empty'] . '</li>';
}
echo '</ul>';

?>