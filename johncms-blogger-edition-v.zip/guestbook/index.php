<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
$headmod = 'guestbook';
require ('../incfiles/core.php');
if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);

if (isset($_SESSION['ga']) && $rights < 1)
    unset($_SESSION['ga']);

$textl = isset($_SESSION['ga']) ? $lng['admin_club'] : $lng['guestbook'];
ob_start();


if (!$set['mod_guest'] && $rights < 7)
{
    require ('../incfiles/head.php');
    echo '<div class="alert alert-danger"><p>' . $lng['guestbook_closed'] .
        '</p></div>';
    require ('../incfiles/end.php');
    exit;
}
switch ($act)
{
    case 'delpost':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['guestbook'], 'url' =>
                    '/guestbook/index.php/act/ga'),
            array('label' => $textl = $lng['delete_message']),
            ));

        if ($rights >= 6 && $id)
        {
            if (isset($_GET['yes']))
            {
                mysql_query("DELETE FROM `guest` WHERE `id`='" . $id . "'");
                ob_end_clean();
                header("Location: " . core::$system_set['homeurl'] .
                    "/guestbook/");
                exit();
            }
            else
            {
                require ('../incfiles/head.php');
                echo '<div class="alert alert-warning"><p>' . $lng['delete_confirmation'] .
                    '?</div><p><a class="btn btn-primary" href="' . $set['homeurl'] .
                    '/guestbook/index.php/act/delpost/id/' . $id . '/yes">' . $lng['delete'] .
                    '</a>&nbsp;' .
                    '<a class="btn btn-default" data-dismiss="modal" href="' . $set['homeurl'] .
                    '/guestbook/index.php">' . $lng['cancel'] . '</a></p>';
            }
        }
        break;

    case 'say':
        $admset = isset($_SESSION['ga']) ? 1 : 0;


        $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']),
            0, 20)) : '';
        $msg = isset($_POST['msg']) ? functions::checkin(mb_substr(trim($_POST['msg']),
            0, 5000)) : '';
        $trans = isset($_POST['msgtrans']) ? 1 : 0;
        $code = isset($_POST['code']) ? trim($_POST['code']) : '';
        $from = $user_id ? $login : mysql_real_escape_string($name);

        if ($trans)
            $msg = functions::trans($msg);

        $error = array();
        $flood = false;
        if (!isset($_POST['token']) || !isset($_SESSION['token']) || $_POST['token'] !=
            $_SESSION['token'])
        {
            $error[] = $lng['error_wrong_data'];
        }
        if (!$user_id && empty($name))
            $error[] = $lng['error_empty_name'];
        if (empty($msg))
            $error[] = $lng['error_empty_message'];
        if (isset($ban['1']) || isset($ban['13']))
            $error[] = $lng['access_forbidden'];

        if (!$user_id && (empty($code) || mb_strlen($code) < 4 || $code != $_SESSION['code']))
            $error[] = $lng['error_wrong_captcha'];
        unset($_SESSION['code']);
        if ($user_id)
        {

            $flood = functions::antiflood();
        }
        else
        {

            $req = mysql_query("SELECT `time` FROM `guest` WHERE `ip` = '$ip' AND `browser` = '" .
                mysql_real_escape_string($agn) . "' AND `time` > '" . (time() -
                60) . "'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                $flood = time() - $res['time'];
            }
        }
        if ($flood)
            $error = $lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'];
        if (!$error)
        {

            $req = mysql_query("SELECT * FROM `guest` WHERE `user_id` = '$user_id' ORDER BY `time` DESC");
            $res = mysql_fetch_array($req);
            if ($res['text'] == $msg)
            {
                ob_end_clean();
                header("Location: " . core::$system_set['homeurl'] .
                    "/guestbook/index.php");
                exit;
            }
        }
        if (!$error)
        {

            mysql_query("INSERT INTO `guest` SET
                `adm` = '$admset',
                `time` = '" . time() . "',
                `user_id` = '" . ($user_id ? $user_id : 0) . "',
                `name` = '$from',
                `text` = '" . mysql_real_escape_string($msg) . "',
                `ip` = '" . core::$ip . "',
                `browser` = '" . mysql_real_escape_string($agn) . "',
                `otvet` = ''
            ");

            if ($user_id)
            {
                $postguest = $datauser['postguest'] + 1;
                mysql_query("UPDATE `users` SET `postguest` = '$postguest', `lastpost` = '" .
                    time() . "' WHERE `id` = '$user_id'");
            }
            ob_end_clean();
            header("Location: " . core::$system_set['homeurl'] .
                "/guestbook/index.php");
            exit();
        }
        else
        {
            require ('../incfiles/head.php');
            echo functions::display_error($error, '<a class="alert-link" href="' .
                $set['homeurl'] . '/guestbook/index.php">' . $lng['back'] .
                '</a>');
        }
        break;

    case 'otvet':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['guestbook'], 'url' =>
                    '/guestbook/index.php/act/ga'),
            array('label' => $textl = $lng['reply']),
            ));
        if ($rights >= 6 && $id)
        {
            if (isset($_POST['submit']) && isset($_POST['token']) && isset($_SESSION['token']) &&
                $_POST['token'] == $_SESSION['token'])
            {
                $reply = isset($_POST['otv1']) ? functions::checkin(mb_substr(trim
                    ($_POST['otv1']), 0, 5000)) : '';
                mysql_query("UPDATE `guest` SET
                    `admin` = '$login',
                    `otvet` = '" . mysql_real_escape_string($reply) . "',
                    `otime` = '" . time() . "'
                    WHERE `id` = '$id'
                ");
                ob_end_clean();
                header("Location: " . core::$system_set['homeurl'] .
                    "/guestbook/index.php");
                exit();
            }
            else
            {
                require ('../incfiles/head.php');
                $req = mysql_query("SELECT * FROM `guest` WHERE `id` = '$id'");
                $res = mysql_fetch_assoc($req);
                $token = mt_rand(1000, 100000);
                $_SESSION['token'] = $token;
                echo '<div class="menu"><blockquote class="reply"><b>' . $res['name'] .
                    '</b><br />' . functions::checkout($res['text']) .
                    '</blockquote><form name="form1" action="' . $set['homeurl'] .
                    '/guestbook/index.php/act/otvet/id/' . $id .
                    '" method="post"><p><h4 class="page-header">' . $lng['reply'] .
                    '</h4><p>' . bbcode::auto_bb('form1', 'otvr') . '</p>' .
                    '<textarea class="form-control" rows="' . $set_user['field_h'] .
                    '" name="otvr">' . functions::checkout($res['otvet']) .
                    '</textarea></p>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['reply'] . '</button></p>' .
                    '<input type="hidden" name="token" value="' . $token . '"/>' .
                    '</form></div><p>' . functions::link_back($lng['back'],
                    'guestbook/index.php') . '</p>';
            }
        }
        break;

    case 'edit':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['guestbook'], 'url' =>
                    '/guestbook/index.php/act/ga'),
            array('label' => $textl = $lng['edit']),
            ));
        if ($rights >= 6 && $id)
        {
            if (isset($_POST['submit']) && isset($_POST['token']) && isset($_SESSION['token']) &&
                $_POST['token'] == $_SESSION['token'])
            {
                $req = mysql_query("SELECT `edit_count` FROM `guest` WHERE `id`='$id'");
                $res = mysql_fetch_array($req);
                $edit_count = $res['edit_count'] + 1;
                $msg = isset($_POST['msg']) ? functions::checkin(mb_substr(trim
                    ($_POST['msg']), 0, 5000)) : '';
                mysql_query("UPDATE `guest` SET
                    `text` = '" . mysql_real_escape_string($msg) . "',
                    `edit_who` = '$login',
                    `edit_time` = '" . time() . "',
                    `edit_count` = '$edit_count'
                    WHERE `id` = '$id'
                ");
                ob_end_clean();
                header("Location: " . core::$system_set['homeurl'] .
                    "/guestbook/index.php");
                exit();
            }
            else
            {
                require ('../incfiles/head.php');
                $token = mt_rand(1000, 100000);
                $_SESSION['token'] = $token;
                $req = mysql_query("SELECT * FROM `guest` WHERE `id` = '$id'");
                $res = mysql_fetch_assoc($req);
                $text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
                echo '<form name="form" action="' . $set['homeurl'] .
                    '/guestbook/index.php/act/edit/id/' . $id .
                    '" method="post"><div class="form-group"><label>' . $lng['author'] .
                    ': <span class="text-red">' . $res['name'] .
                    '</span></label>';
                echo '<p>' . bbcode::auto_bb('form', 'msg') . '</p>';
                echo '<textarea class="form-control" rows="' . $set_user['field_h'] .
                    '" name="msg">' . $text . '</textarea></div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['save'] . '</button></p>' .
                    '<input type="hidden" name="token" value="' . $token . '"/>' .
                    '</form><p>' . functions::display_translit() . '</p>';
            }
        }
        break;

    case 'clean':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['guestbook'], 'url' =>
                    '/guestbook/index.php/act/ga'),
            array('label' => $textl = $lng['clear']),
            ));
        require ('../incfiles/head.php');
        if ($rights >= 7)
        {
            if (isset($_POST['submit']))
            {

                $adm = isset($_SESSION['ga']) ? 1 : 0;
                $cl = isset($_POST['cl']) ? intval($_POST['cl']) : '';
                switch ($cl)
                {
                    case '1':

                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm' AND `time` < '" .
                            (time() - 86400) . "'");
                        echo '<div class="alert alert-success">' . $lng['clear_day_ok'] .
                            '</div>';
                        break;

                    case '2':

                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm'");
                        echo '<div class="alert alert-success">' . $lng['clear_full_ok'] .
                            '</div>';
                        break;
                    default:

                        mysql_query("DELETE FROM `guest` WHERE `adm`='$adm' AND `time`<='" .
                            (time() - 604800) . "';");
                        echo '<div class="alert alert-success">' . $lng['clear_week_ok'] .
                            '</div>';
                }
                mysql_query("OPTIMIZE TABLE `guest`");
                echo functions::link_back($lng['guestbook'], $home .
                    '/guestbook/index.php');
            }
            else
            {

                echo '<form id="clean" method="post" action="' . $set['homeurl'] .
                    '/guestbook/index.php/act/clean"><label>' . $lng['clear_param'] .
                    '</label>' .
                    '<div class="radio"><label><input type="radio" name="cl" value="0" checked="checked" /> ' .
                    $lng['clear_param_week'] . '</label></div>' .
                    '<div class="radio"><label><input type="radio" name="cl" value="1" /> ' .
                    $lng['clear_param_day'] . '</label></div>' .
                    '<div class="radio"><label><input type="radio" name="cl" value="2" /> ' .
                    $lng['clear_param_all'] . '</label></div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['clear'] . '</button></p></form><div>' . functions::link_back('&larr; ' .
                    $lng['cancel'], '/guestbook/index.php') . '</div>';
            }
        }
        break;

    case 'ga':
        if ($rights >= 1)
        {
            if (isset($_GET['do']) && $_GET['do'] == 'set')
            {
                $_SESSION['ga'] = 1;
            }
            else
            {
                unset($_SESSION['ga']);
            }
        }

    default:
        if (isset($_SESSION['ga']) && $rights >= "1")
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['guestbook'], 'url' =>
                        '/guestbook/index.php/act/ga'),
                array('label' => 'Admin Klub'),
                ));
        }
        else
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                        $lng['guestbook']), ));
        }
        require ('../incfiles/head.php');
        if (!$set['mod_guest'])
            echo '<div class="alert alert-danger">' . $lng['guestbook_closed'] .
                '</div>';
        if ($rights > 0)
        {
            $menu = array();
            $menu[] = '<li' . (!isset($_SESSION['ga']) ? ' class="active"' : '') .
                '><a href="' . $set['homeurl'] .
                '/guestbook/index.php/act/ga"><i class="fa fa-book"></i> ' . $lng['guestbook'] .
                '</a></li>';
            $menu[] = '<li' . (isset($_SESSION['ga']) ? ' class="active"' : '') .
                '><a href="' . $set['homeurl'] .
                '/guestbook/index.php/act/ga/do/set"><i class="fa fa-shield"></i> ' .
                $lng['admin_club'] . '</a></li>';
            if ($rights >= 7)
                $menu[] = '<li class="pull-right"><a href="' . $set['homeurl'] .
                    '/guestbook/index.php/act/clean" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-times"></i> ' .
                    $lng['clear'] . '</a></li>';
            echo '<ul class="nav nav-tabs">' . functions::display_menu($menu, '') .
                '</ul>';
        }

        if (($user_id || $set['mod_guest'] == 2) && !isset($ban['1']) && !isset
            ($ban['13']))
        {
            $token = mt_rand(1000, 100000);
            $_SESSION['token'] = $token;
            echo '<form name="form" action="' . $set['homeurl'] .
                '/guestbook/index.php/act/say" method="post"><div class="form-group">';
            if (!$user_id)
                echo '<label>' . $lng['name'] .
                    ' <small>(max 25)</small>:</label><input class="form-control" type="text" name="name" maxlength="25"/><br/>';
            echo '<label>' . $lng['message'] .
                ' <small>(max 5000)</small>:</label>';
            echo '<p>' . bbcode::auto_bb('form', 'msg') . '</p>';
            echo '<textarea class="form-control" rows="' . $set_user['field_h'] .
                '" name="msg"></textarea></div>';
            if ($set_user['translit'])
                echo '<div class="checkbox"><label>' .
                    '<input type="checkbox" name="msgtrans" value="1" />&nbsp;' .
                    $lng['translit'] . '</label></div>';
            if (!$user_id)
            {

                echo '<div class="form-group"><label>' . $lng['captcha'] .
                    '</label><img class="img-responsive" src="' . $home .
                    '/captcha.php?r=' . rand(1000, 9999) . '" alt="' . $lng['captcha'] .
                    '"/><br />' .
                    '<input class="form-control" type="text" size="5" maxlength="5"  name="code"/></div>';
            }
            echo '<input type="hidden" name="token" value="' . $token . '"/>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['sent'] . '</button></p></form>';
        }
        else
        {
            echo '<div class="alert alert-danger">' . $lng['access_guest_forbidden'] .
                '</div>';
        }

        if (isset($_SESSION['ga']) && $rights >= "1")
        {
            $req = mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='1'");
        }
        else
        {
            $req = mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'");
        }
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='" .
            (isset($_SESSION['ga']) ? 1 : 0) . "'"), 0);
        if ($total)
        {
            if (isset($_SESSION['ga']) && $rights >= "1")
            {

                echo
                    '<h3 class="page-header"><i class="fa fa-shield"></i> Admin Klub</h3>';
                $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
                FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                WHERE `guest`.`adm`='1' ORDER BY `time` DESC LIMIT " . $start .
                    "," . $kmess);
            }
            else
            {
                echo '<h3 class="page-header"><i class="fa fa-comments"></i> ' .
                    $lng['comments'] . '</h3>';

                $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
                FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT " . $start .
                    "," . $kmess);
            }

            for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
            {
                $text = '';
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                if (!$res['id'])
                {

                    $req_g = mysql_query("SELECT `lastdate` FROM `cms_sessions` WHERE `session_id` = '" .
                        md5($res['ip'] . $res['browser']) . "' LIMIT 1");
                    $res_g = mysql_fetch_assoc($req_g);
                    $res['lastdate'] = $res_g['lastdate'];
                }

                $text = ' <span class="gray">(' . functions::display_date($res['time']) .
                    ')</span>';
                if ($res['user_id'])
                {

                    $post = functions::checkout($res['text'], 1, 1);
                    if ($set_user['smileys'])
                        $post = functions::smileys($post, $res['rights'] >= 1 ?
                            1 : 0);
                }
                else
                {

                    $res['name'] = functions::checkout($res['name']);
                    $post = functions::antilink(functions::checkout($res['text'],
                        0, 2));
                }
                if ($res['edit_count'])
                {

                    $post .= '<br /><span class="gray"><small>Изм. <b>' . $res['edit_who'] .
                        '</b> (' . functions::display_date($res['edit_time']) .
                        ') <b>[' . $res['edit_count'] . ']</b></small></span>';
                }
                if (!empty($res['otvet']))
                {

                    $otvet = functions::checkout($res['otvet'], 1, 1);
                    if ($set_user['smileys'])
                        $otvet = functions::smileys($otvet, 0);
                    $post .= '<blockquote><p><strong>' . $res['admin'] .
                        '</strong>: (' . functions::display_date($res['otime']) .
                        ')<br/>' . $otvet . '</p></blockquote>';
                }
                if ($rights >= 6)
                {
                    $subtext = '<a href="' . $set['homeurl'] .
                        '/guestbook/index.php/act/otvet/id/' . $res['gid'] .
                        '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><span class="glyphicon glyphicon-retweet"></span> ' .
                        $lng['reply'] . '</a>' . ($rights >= $res['rights'] ?
                        ' | <a href="' . $set['homeurl'] .
                        '/guestbook/index.php/act/edit/id/' . $res['gid'] .
                        '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
                        '</a> | <a href="' . $set['homeurl'] .
                        '/guestbook/index.php/act/delpost/id/' . $res['gid'] .
                        '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><span class="glyphicon glyphicon-remove"></span> ' .
                        $lng['delete'] . '</a>' : '');
                }
                else
                {
                    $subtext = '';
                }
                $arg = array(
                    'header' => $text,
                    'body' => $post,
                    'sub' => $subtext);
                echo functions::display_user($res, $arg);
                echo '</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['guestbook_empty'] .
                '</p></div>';
        }
        if ($total > $kmess)
        {
            echo '<div>' . functions::display_pagination($set['homeurl'] .
                '/guestbook/index.php?', $start, $total, $kmess) . '</div>';
        }

        break;
}

require ('../incfiles/end.php');
ob_end_flush();
