<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

$headmod = 'notifications';
require ('../incfiles/core.php');
$read = isset($_GET['read']) ? trim($_GET['read']) : false;
if (!$user_id)
{
    header("Location: " . $home . "/login.php");
    exit();
}
if (isset($_GET['makeasread']))
{
    mysql_query("UPDATE `cms_notifications` SET `read`='1' WHERE `user_id` = '" .
        $user_id . "' AND `read`='0'");
    header('Location: ' . $home . '/users/notifications.php');
    exit();
}
elseif ($read)
{
    $req = mysql_query("SELECT * FROM `cms_notifications` WHERE `user_id` = '" .
        $user_id . "' AND `key`='" . mysql_real_escape_string($read) . "'");
    if (mysql_num_rows($req) == 0)
    {
        header('Location: ' . $home . '/users/notifications.php');
        exit();
    }
    $res = mysql_fetch_array($req);
    mysql_query("UPDATE `cms_notifications` SET `read`='1' WHERE id='{$res['id']}'");
    header('Location: ' . $res['link']);
    exit();
}
else
{

    $textl = 'Notifications';
    $breadcrumb = functions::breadcrumb(array(array('label' => $textl), ));
    require ('../incfiles/head.php');
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_notifications` WHERE `user_id` = '" .
        $user_id . "' AND `read`='0'"), 0);
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/users/notifications.php/', $start, $total, $kmess) . '</div>';
    if ($total > 0)
    {
        echo '<p><a class="func" href="' . $home .
            '/users/notifications.php/makeasread">Tandai semua telah dibaca</a></p>';
        $req = mysql_query("SELECT * FROM `cms_notifications` WHERE `user_id` = '" .
            $user_id . "' AND `read`='0' ORDER BY `time` DESC LIMIT $start, $kmess");
        $i = 0;
        while ($res = mysql_fetch_assoc($req))
        {
            if ($res['read'] == 0)
                echo '<div class="gmenu">';
            else
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            echo '<a href="' . $home . '/users/notifications.php/read/' . $res['key'] .
                '">' . strip_tags($res['text']) . '</a>';
            echo '</div>';
            ++$i;
        }
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/users/notifications.php/', $start, $total, $kmess) . '</div>';
    }
}
require ('../incfiles/end.php');

?>