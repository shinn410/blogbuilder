<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

$headmod = 'users';
require ('../incfiles/core.php');

if (!$user_id && !$set['active'])
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require ('../incfiles/end.php');
    exit;
}

$array = array(
    'admlist' => 'includes',
    'birth' => 'includes',
    'online' => 'includes',
    'search' => 'includes',
    'top' => 'includes',
    'userlist' => 'includes');
$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php'))
{
    require_once ($path . $act . '.php');
}
else
{
    $textl = $lng['community'];
    $breadcrumb = functions::breadcrumb(array(array('label' => $textl), ));
    require ('../incfiles/head.php');

    $brth = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `dayb` = '" .
        date('j', time()) . "' AND `monthb` = '" . date('n', time()) .
        "' AND `preg` = '1'"), 0);
    $count_adm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` > 0"),
        0);
    $users_on = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" .
        (time() - 300) . "'"), 0);
    $guests_on = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" .
        (time() - 300) . "'"), 0);
    echo '<p><form class="form-horizontal" role="form" action="' . $set['homeurl'] .
        '/users/search.php" method="post"><label style="display:block;">' .
        '<i class="fa fa-search"></i>&#160;' . $lng['search'] . '</label>' .
        '<div class="input-group">' .
        '<input class="form-control" type="text" name="search"/>' .
        '<span class="input-group-btn">' .
        '<button class="btn btn-primary" type="submit" name="submit">' . $lng['search'] .
        '</button></span></div></form></p><p class="help-block">' . $lng['search_nick_help'] .
        '</p>' . '<div class="list-group"><a class="list-group-item" href="' . $set['homeurl'] .
        '/users/index.php/act/userlist">' . '<i class="fa fa-user"></i> ' . $lng['users'] .
        ' <span class="badge">' . counters::users() . '</span></a>' .
        '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/index.php/act/admlist">' . '<i class="fa fa-shield"></i> ' . $lng['administration'] .
        ' <span class="badge">' . $count_adm . '</span></a>';
    if ($brth)
    {
        echo '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/index.php/act/birth">' . '<i class="fa fa-gift"></i> ' . $lng['birthday_men'] .
            ' <span class="badge">' . $brth . '</span></a>';
    }
    echo '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php"><i class="fa fa-picture-o">' . '</i> ' . $lng['photo_albums'] .
        ' <span class="badge">' . counters::album() .
        '</span></a><a class="list-group-item" href="' . $set['homeurl'] .
        '/users/index.php/act/top">' . '<i class="fa fa-signal"></i> ' . $lng['users_top'] .
        '</a><a class="list-group-item" href="' . $set['homeurl'] .
        '/users/index.php/act/online">' . '<i class="fa fa-eye"></i> ' . $lng['online'] .
        ' <span class="badge">' . $users_on . '/' . $guests_on . '</span>' .
        '</a></div>';
    echo functions::link_back($lng['back'], 'users/index.php');
}

require_once ('../incfiles/end.php');
