<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

require ('../incfiles/core.php');

$textl = 'Verifikasi Pendaftaran';
$breadcrumb = functions::breadcrumb(array(array('label' => $textl)));
require ('../incfiles/head.php');
$code = isset($_GET['code']) ? trim($_GET['code']) : false;
if (!$code)
{
    echo '<div class="alert alert-danger">Kode verifikasi tidak benar!</div>';
}
else
{
    $time = time() - (24 * 3600);
    $req = mysql_query("SELECT * FROM `users_preg` WHERE `code` = '" .
        mysql_real_escape_string($code) . "'");
    if (mysql_num_rows($req) != 1)
    {
        echo '<div class="alert alert-danger">Kode verifikasi tidak benar!</div>';
    }
    else
    {
        $res = mysql_fetch_array($req);
        if ($res['datereg'] < $time)
        {
            echo '<div class="alert alert-danger">Kode verifikasi sudah tidak bisa digunakan</div>';
        }
        else
        {
            $cek = mysql_query("SELECT * FROM `users` WHERE `name` = '" .
                mysql_real_escape_string($res['name']) . "' OR 
            `name_lat` = '" . mysql_real_escape_string($res['name_lat']) .
                "' OR 
            `mail` = '" . mysql_real_escape_string($res['mail']) . "'");
            if (mysql_num_rows($cek) != 0)
            {
                echo
                    '<div class="alert alert-danger">Data-data pada saat pendaftaran sudah digunakan orang lain!' .
                    '<br/>Silakan ulangi pendaftaran lagi.</div>';
            }
            else
            {
                mysql_query("INSERT INTO `users` SET
                `name` = '" . mysql_real_escape_string($res['name']) . "',
                `name_lat` = '" . mysql_real_escape_string($res['name_lat']) .
                    "',
                `password` = '" . mysql_real_escape_string(md5(md5($res['password']))) .
                    "',
                `imname` = '" . mysql_real_escape_string($res['imname']) . "',
                `mail` = '" . mysql_real_escape_string($res['mail']) . "',
                `about` = '" . mysql_real_escape_string($res['about']) . "',
                `sex` = '" . mysql_real_escape_string($res['sex']) . "',
                `rights` = '0',
                `ip` = '" . core::$ip . "',
                `ip_via_proxy` = '" . core::$ip_via_proxy . "',
                `browser` = '" . mysql_real_escape_string($agn) . "',
                `datereg` = '" . time() . "',
                `lastdate` = '" . time() . "',
                `sestime` = '" . time() . "',
                `preg` = '1',
                `set_user` = '',
                `set_forum` = '',
                `set_mail` = '',
                `smileys` = ''
                ") or exit(__line__ . ': ' . mysql_error());
                $usid = mysql_insert_id();

                $set_mail = unserialize($set['setting_mail']);

                if (!isset($set_mail['message_include']))
                {
                    $set_mail['message_include'] = 0;
                }

                if ($set_mail['message_include'])
                {
                    $array = array('{LOGIN}', '{TIME}');
                    $array_replace = array($res['name'], '{TIME=' . time() . '}');

                    if (empty($set['them_message']))
                    {
                        $set['them_message'] = $lng_mail['them_message'];
                    }

                    if (empty($set['reg_message']))
                    {
                        $set['reg_message'] = $lng['hi'] . ", {LOGIN}\r\n" . $lng_mail['pleased_see_you'] .
                            "\r\n" . $lng_mail['come_my_site'] . "\r\n" . $lng_mail['respectfully_yours'];
                    }

                    $theme = str_replace($array, $array_replace, $set['them_message']);
                    $system = str_replace($array, $array_replace, $set['reg_message']);
                    mysql_query("INSERT INTO `cms_mail` SET
			         `user_id` = '0',
			         `from_id` = '" . $usid . "',
			         `text` = '" . mysql_real_escape_string($system) . "',
			         `time` = '" . time() . "',
			         `sys` = '1',
			         `them` = '" . mysql_real_escape_string($theme) . "'
			         ");
                }
                $lng_reg = core::load_lng('registration');
                echo '<div class="alert alert-success"><p><h3>' . $lng_reg['you_registered'] .
                    '</h3>' . $lng_reg['your_id'] . ': <b>' . $usid .
                    '</b><br/>' . $lng_reg['your_login'] . ': <b>' . $res['name'] .
                    '</b><br/>' . $lng_reg['your_password'] . ': <b>' . $res['password'] .
                    '</b></p></div>';

                if ($set['mod_reg'] == 1)
                {
                    echo '<div class="alert alert-warning">' . $lng_reg['moderation_note'] .
                        '</div>';
                }
                else
                {
                    $_SESSION['uid'] = $usid;
                    $_SESSION['ups'] = md5(md5($res['password']));
                    echo '<p>' . functions::link_back($lng_reg['enter'] .
                        ' &rarr;', $home, false) . '</p>';
                }
            }
        }
        mysql_query("DELETE FROM `users_preg` WHERE `id` = {$res['id']}");
    }
}
require ('../incfiles/end.php');

?>