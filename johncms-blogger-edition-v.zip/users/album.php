<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

require ('../incfiles/core.php');
$lng_profile = core::load_lng('profile');
$textl = $lng_profile['album'];
$headmod = 'album';

$max_album = 10;
$max_photo = 200;
$al = isset($_REQUEST['al']) ? abs(intval($_REQUEST['al'])) : null;
$img = isset($_REQUEST['img']) ? abs(intval($_REQUEST['img'])) : null;

if (!$user_id)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require ('../incfiles/end.php');
    exit;
}

$user = functions::get_user($user);
if (!$user)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['user_does_not_exist']);
    require ('../incfiles/end.php');
    exit;
}

function vote_photo($arg = null)
{
    global $lng, $datauser, $user_id, $ban;

    if ($arg)
    {
        $rating = $arg['vote_plus'] - $arg['vote_minus'];
        if ($rating > 0)
            $color = 'bg-green';
        elseif ($rating < 0)
            $color = 'bg-red';
        else
            $color = '';
        $out = '<li><i class="fa fa-bar-chart-o"></i> ' . $lng['rating'] .
            ': <span class="badge ' . $color . '">' . $rating . '</span> ' . '(' .
            $lng['vote_against'] . ': ' . $arg['vote_minus'] . ', ' . $lng['vote_for'] .
            ': ' . $arg['vote_plus'] . ')</li>';
        if ($user_id != $arg['user_id'] && !$ban && $datauser['postforum'] > 10 &&
            $datauser['total_on_site'] > 1200)
        {

            $req = mysql_query("SELECT * FROM `cms_album_votes` WHERE `user_id` = '$user_id' AND `file_id` = '" .
                $arg['id'] . "' LIMIT 1");
            if (!mysql_num_rows($req))
                $out .= '<li><i class="fa fa-check-square-o"></i> ' . $lng['vote'] .
                    ': <a href="' . core::$system_set['homeurl'] .
                    '/users/album.php/act/vote/mod/minus/img/' . $arg['id'] .
                    '"><i class="fa  fa-thumbs-o-down"></i> -1</a> | ' .
                    '<a href="' . core::$system_set['homeurl'] .
                    '/users/album.php/act/vote/mod/plus/img/' . $arg['id'] .
                    '"><i class="fa  fa-thumbs-o-up"></i> +1 </a></li>';
        }
        return $out;
    }
    else
    {
        return false;
    }
}

$array = array(
    'delete' => 'includes/album',
    'edit' => 'includes/album',
    'image_delete' => 'includes/album',
    'image_download' => 'includes/album',
    'image_edit' => 'includes/album',
    'image_move' => 'includes/album',
    'image_upload' => 'includes/album',
    'list' => 'includes/album',
    'new_comm' => 'includes/album',
    'show' => 'includes/album',
    'sort' => 'includes/album',
    'top' => 'includes/album',
    'users' => 'includes/album',
    'vote' => 'includes/album');
$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php'))
{
    require_once ($path . $act . '.php');
}
else
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['users'], 'url' => '/users/'),
        array('label' => $lng['photo_albums']),
        ));
    require ('../incfiles/head.php');
    $albumcount = mysql_result(mysql_query("SELECT COUNT(DISTINCT `user_id`) FROM `cms_album_files`"),
        0);
    $total_mans = mysql_result(mysql_query("SELECT COUNT(DISTINCT `user_id`)
      FROM `cms_album_files`
      LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id`
      WHERE `users`.`sex` = 'm'
    "), 0);
    $total_womans = mysql_result(mysql_query("SELECT COUNT(DISTINCT `user_id`)
      FROM `cms_album_files`
      LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id`
      WHERE `users`.`sex` = 'zh'
    "), 0);
    $newcount = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `time` > '" .
        (time() - 259200) . "' AND `access` > '1'"), 0);
    echo '<div>' . '<a class="func" href="' . $set['homeurl'] .
        '/users/album.php/act/top"><img src="' . $set['homeurl'] .
        '/images/users.png" width="16" height="16"/> ' . $lng_profile['new_photo'] .
        ' <span class="badge">' . $newcount . '</span></a>' .
        '&nbsp;<a class="func" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/last_comm"><img src="' . $set['homeurl'] .
        '/images/guestbook.gif" width="16" height="16"/> ' . $lng_profile['new_comments'] .
        '</a>' . '</div><hr/><div class="row">';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files`" .
        (core::$user_rights >= 6 ? "" : " WHERE `access` = '4'")), 0);
    if ($total)
    {
        echo '<div class="col-sm-6 col-md-4" style="padding-bottom:20px;">' .
            '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel"' .
            ' style="max-width:320px;margin:0 auto !important;"><ol class="carousel-indicators">' .
            '<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>' .
            '<li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>' .
            '<li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>' .
            '<li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>' .
            '<li data-target="#carousel-example-generic" data-slide-to="4" class=""></li>' .
            '</ol><div class="carousel-inner">';

        $req = mysql_query("
            SELECT `cms_album_files`.*, `users`.`name`
            FROM `cms_album_files`" . (core::$user_rights >= 6 ? "" :
            " WHERE ``cms_album_files`.access` = '4'") . "
            LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id`
            ORDER BY `cms_album_files`.`time` DESC
            LIMIT 5
            ");
        $i = 0;
        while ($res = mysql_fetch_assoc($req))
        {
            echo '<div class="item' . ($i == 0 ? ' active' : '') . '">' .
                '<img src="' . $home . '/files/users/album/' . $res['user_id'] .
                '/' . $res['tmb_name'] . '" style="margin: 0 auto !important;">' .
                '<div class="carousel-caption"><a href="' . $home .
                '/users/album.php/act/show/al/' . $res['album_id'] . '/user/' .
                $res['user_id'] . '/id/' . $res['id'] .
                '" style="color: #fff;">' . functions::display_date($res['time']) .
                '<br/>(' . $res['name'] . ')</a></div></div>';
            $i++;
        }
        echo '</div><a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">' .
            '<span class="glyphicon glyphicon-chevron-left"></span></a>' .
            '<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">' .
            '<span class="glyphicon glyphicon-chevron-right"></span></a></div></div>';
    }
    echo '<div class="' . ($total ? 'col-sm-6 col-md-8' : 'col-xs-12') . '">' .
        '<div class="list-group">' .
        '<div class="list-group-item list-group-item-success"><img src="' . $set['homeurl'] .
        '/images/users.png" width="16" height="16" class="left" />&#160;' . $lng['albums'] .
        '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/users/mod/boys">' . $lng['mans'] .
        ' <span class="badge">' . $total_mans . '</span></a>' .
        '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/users/mod/girls">' . $lng['womans'] .
        ' <span class="badge">' . $total_womans . '</span></a>';
    if ($user_id)
    {
        echo '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/album.php/act/list">' . $lng_profile['my_album'] . '</a>';
    }
    echo '</div>' . '<div class="list-group">' .
        '<div class="list-group-item list-group-item-info">' . functions::image('rate.gif') .
        $lng['rating'] . '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/votes">' . $lng_profile['top_votes'] .
        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/downloads">' . $lng_profile['top_downloads'] .
        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/views">' . $lng_profile['top_views'] .
        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/comments">' . $lng_profile['top_comments'] .
        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/album.php/act/top/mod/trash">' . $lng_profile['top_trash'] .
        '</a>' . '</div></div></div>';
}
require ('../incfiles/end.php');

?>