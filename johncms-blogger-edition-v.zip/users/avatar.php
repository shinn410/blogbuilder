<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

require ('../incfiles/lib/class.upload.php');
include_once ('../incfiles/route.php');
$id = isset($_GET['user']) ? abs(intval($_GET['user'])) : 0;

if (file_exists("../files/users/photo/" . $id . ".jpg"))
{
    $image = "../files/users/photo/" . $id . ".jpg";
}
elseif (file_exists("../files/users/avatar/" . $id . ".png"))
{
    $image = "../files/users/avatar/" . $id . ".png";
}
else
{
    $image = "../images/empty.png";
}
$new_y = isset($_GET['y']) ? abs(intval($_GET['y'])) : (isset($_GET['width']) ?
    abs(intval($_GET['width'])) : false);
$new_x = isset($_GET['x']) ? abs(intval($_GET['x'])) : (isset($_GET['height']) ?
    abs(intval($_GET['height'])) : false);
if (!$new_y || !$new_x)
{
    $new_y = 32;
    $new_x = 32;
}
else
{
    if ($new_y > 480)
        $new_y = 480;
    if ($new_x > 680)
        $new_x = 680;
}
$handle = new upload($image);
$handle->image_resize = true;
$handle->image_ratio_crop = true;
$handle->image_y = $new_x;
$handle->image_x = $new_y;
header('Content-type: ' . $handle->file_src_mime);
echo $handle->Process();
exit();

?>