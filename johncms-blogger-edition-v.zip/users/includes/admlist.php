<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $lng['administration'];
$headmod = "admlist";
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['community'], 'url' => '/users/index.php'),
    array('label' => $lng['administration']),
    ));
require ('../incfiles/head.php');

$req = mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` >= 1");
$total = mysql_result($req, 0);
$req = mysql_query("SELECT `id`, `name`, `sex`, `lastdate`, `datereg`, `status`, `rights`,
`ip`, `browser`, `rights` FROM `users` WHERE `rights` >= 1 ORDER BY `rights` DESC LIMIT $start, $kmess");
for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
{
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    echo functions::display_user($res) . '</div>';
}
echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess)
{
    echo '<p>' . functions::display_pagination($set['homeurl'] .
        '/users/index.php/act/admlist/', $start, $total, $kmess) . '</p>';
}
echo '<p>' . functions::link_back($lng['back'], 'users/index.php') . '</p>';
