<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'userstop';
$textl = $lng['users_top'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['community'], 'url' => '/users/index.php'),
    array('label' => $lng['users_top']),
    ));
require ('../incfiles/head.php');

function get_top($order = 'postforum')
{
    $req = mysql_query("SELECT * FROM `users` WHERE `$order` > 0 ORDER BY `$order` DESC LIMIT 9");

    if (mysql_num_rows($req))
    {
        $out = '';
        $i = isset($i) ? $i : 0;
        while ($res = mysql_fetch_assoc($req))
        {
            $out .= $i % 2 ? '<div class="list2">' : '<div class="list1">';
            $out .= functions::display_user($res, array('header' => ('<b>' . $res[$order]) .
                    '</b>')) . '</div>';
            ++$i;
        }
        return $out;
    }
    else
    {
        return '<div class="alert alert-warning"><p>' . $GLOBALS['lng']['list_empty'] .
            '</p></div>';
    }
}

$menu = array(
    (!$mod ? '<li class="active"><a>' . $lng['forum'] . '</a></li>' :
        '<li><a href="' . $set['homeurl'] . '/users/index.php/act/top">' . $lng['forum'] .
        '</a></li>'),
    ($mod == 'guest' ? '<li class="active"><a>' . $lng['guestbook'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/users/index.php/act/top/mod/guest">' . $lng['guestbook'] . '</a></li>'),
    ($mod == 'comm' ? '<li class="active"><a>' . $lng['comments'] . '</a></li>' :
        '<li><a href="' . $set['homeurl'] .
        '/users/index.php/act/top/mod/comm">' . $lng['comments'] . '</a></li>'));
if ($set_karma['on'])
    $menu[] = $mod == 'karma' ? '<li class="active"><a>' . $lng['karma'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/users/index.php/act/top/mod/karma">' . $lng['karma'] . '</a></li>';
switch ($mod)
{
    case 'guest':
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        echo get_top('postguest');
        echo '<div>' . functions::link_back($lng['guestbook'],
            '/guestbook/index.php') . '</div>';
        break;

    case 'comm':
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        echo get_top('komm');

        break;

    case 'karma':
        if ($set_karma['on'])
        {
            echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
                '</ul>';
            $req = mysql_query("SELECT *, (`karma_plus` - `karma_minus`) AS `karma` FROM `users` WHERE (`karma_plus` - `karma_minus`) > 0 ORDER BY `karma` DESC LIMIT 9");
            if (mysql_num_rows($req))
            {
                while ($res = mysql_fetch_assoc($req))
                {
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                    echo functions::display_user($res, array('header' => ('<b>' .
                            $res['karma']) . '</b>')) . '</div>';
                    ++$i;
                }
            }
            else
            {
                echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                    '</p></div>';
            }
        }
        else
        {
            echo functions::display_error('Invalid Request!');
        }
        break;

    default:
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        echo get_top('postforum');
        echo '<div>' . functions::link_back($lng['forum'], '/forum/index.php') .
            '</div>';
}
echo '<p>' . functions::link_back($lng['back'], 'users/index.php') . '</p>';

?>