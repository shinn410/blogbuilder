<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'online';
$textl = $lng['online'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['community'], 'url' => '/users/index.php'),
    array('label' => $textl),
    ));
require ('../incfiles/head.php');
$menu[] = !$mod ? '<li class="active"><a>' . $lng['users'] . '</a></li>' :
    '<li><a href="' . $set['homeurl'] . '/users/index.php/act/online">' . $lng['users'] .
    '</a></li>';
$menu[] = $mod == 'history' ? '<li class="active"><a>' . $lng['history'] .
    '</a></li>' : '<li><a href="' . $set['homeurl'] .
    '/users/index.php/act/online/mod/history">' . $lng['history'] . '</a></li>';
if (core::$user_rights)
{
    $menu[] = $mod == 'guest' ? '<li class="active"><a>' . $lng['guests'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/users/index.php/act/online/mod/guest">' . $lng['guests'] . '</a></li>';
    $menu[] = $mod == 'ip' ? '<li class="active"><a>' . $lng['ip_activity'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/users/index.php/act/online/mod/ip">' . $lng['ip_activity'] .
        '</a></li>';
}

echo '<div class="nav nav-tabs">' . functions::display_menu($menu, '') .
    '</div>';

switch ($mod)
{
    case 'ip':

        $ip_array = array_count_values(core::$ip_count);
        $total = count($ip_array);
        if ($start >= $total)
        {

            $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total %
                $kmess)));
        }
        $end = $start + $kmess;
        if ($end > $total)
            $end = $total;
        arsort($ip_array);
        $i = 0;
        foreach ($ip_array as $key => $val)
        {
            $ip_list[$i] = array($key => $val);
            ++$i;
        }
        if ($total && core::$user_rights)
        {
            if ($total > $kmess)
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/index.php/act/online/mod/ip/', $start, $total, $kmess) .
                    '</div>';
            for ($i = $start; $i < $end; $i++)
            {
                $out = each($ip_list[$i]);
                $ip = long2ip($out[0]);
                if ($out[0] == core::$ip)
                    echo '<div class="gmenu">';
                else
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '[' . $out[1] . ']&#160;&#160;<a href="' . core::$system_set['homeurl'] .
                    '/' . core::$system_set['admp'] .
                    '/index.php/act/search_ip/ip/' . $ip . '">' . $ip . '</a>' .
                    '&#160;&#160;<small>[<a href="' . core::$system_set['homeurl'] .
                    '/' . core::$system_set['admp'] .
                    '/index.php/act/ip_whois/ip/' . $ip . '">?</a>]</small>';
                echo '</div>';
            }
            echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': ' . $total . '</div>';
            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/index.php/act/online/mod/ip/', $start, $total, $kmess) .
                    '</div>';
            }
        }
        require_once ('../incfiles/end.php');
        exit;
        break;

    case 'guest':

        $sql_total = "SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time
            () - 300);
        $sql_list = "SELECT * FROM `cms_sessions` WHERE `lastdate` > " . (time() -
            300) . " ORDER BY `movings` DESC LIMIT ";
        break;

    case 'history':

        $sql_total = "SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time
            () - 172800 . " AND `lastdate` < " . (time() - 310));
        $sql_list = "SELECT * FROM `users` WHERE `lastdate` > " . (time() -
            172800) . " AND `lastdate` < " . (time() - 310) .
            " ORDER BY `sestime` DESC LIMIT ";
        break;

    default:

        $sql_total = "SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time
            () - 300);
        $sql_list = "SELECT * FROM `users` WHERE `lastdate` > " . (time() - 300) .
            " ORDER BY `name` ASC LIMIT ";
}

$total = mysql_result(mysql_query($sql_total), 0);
if ($start >= $total)
{

    $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total % $kmess)));
}

if ($total > $kmess)
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/index.php/act/online/' . ($mod ? 'mod/' . $mod . '/' : ''), $start, $total,
        $kmess) . '</div>';
if ($total)
{
    $req = mysql_query($sql_list . "$start, $kmess");
    $i = 0;
    while (($res = mysql_fetch_assoc($req)) !== false)
    {
        if ($res['id'] == core::$user_id)
            echo '<div class="gmenu">';
        else
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        $arg['stshide'] = 1;
        $arg['header'] = ' <span class="gray">(';
        if ($mod == 'history')
            $arg['header'] .= functions::display_date($res['sestime']);
        else
            $arg['header'] .= $res['movings'] . ' - ' . functions::timecount(time
                () - $res['sestime']);
        $arg['header'] .= ')</span><br /><img src="' . $set['homeurl'] .
            '/images/info.png" width="16" height="16" align="middle" />&#160;' .
            functions::display_place($res['id'], $res['place']);
        echo functions::display_user($res, $arg);
        echo '</div>';
        ++$i;
    }
}
else
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}
echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/index.php/act/online/' . ($mod ? 'mod/' . $mod . '/' : ''), $start, $total,
        $kmess) . '</div>';
}
