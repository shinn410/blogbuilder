<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $user['name'] . ':' . $lng['guestbook'];
$headmod = 'my_guest';
if ($user_id && $user['id'] == $user_id)
    $datauser['comm_old'] = $datauser['comm_count'];
$breadcrumb = functions::breadcrumb(array(
    // array('label' => $lng['users'], 'url' => '/users/'),
    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng['guestbook']),
    ));
require ('../incfiles/head.php');

$context_top = '<div class="callout callout-info"><p>' . functions::display_user($user,
    array('iphide' => 1, )) . '</p></div>';

$arg = array(
    'comments_table' => 'cms_users_guestbook',
    'object_table' => 'users',
    'script' => $set['homeurl'] . '/users/profile.php/act/guestbook',
    'sub_id_name' => 'user',
    'sub_id' => $user['id'],
    'owner' => $user['id'],
    'owner_delete' => true,
    'owner_reply' => true,
    'title' => $lng['comments'],
    'context_top' => $context_top,
    );
$comm = new comments($arg);

if (!$mod && $user['id'] == $user_id && $user['comm_count'] != $user['comm_old'])
{
    mysql_query("UPDATE `users` SET `comm_old` = '" . $user['comm_count'] .
        "' WHERE `id` = '$user_id'");
}

?>