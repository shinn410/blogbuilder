<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = htmlspecialchars($user['name']) . ': ' . $lng_profile['activity'];
$breadcrumb = functions::breadcrumb(array(

    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng_profile['activity']),
    ));
require ('../incfiles/head.php');
$menu = array(
    (!$mod ? '<li class="active"><a>' . $lng['messages'] . '</a></li>' :
        '<li><a href="' . $set['homeurl'] .
        '/users/profile.php/act/activity/user/' . $user['id'] . '">' . $lng['messages'] .
        '</a></li>'),
    ($mod == 'topic' ? '<li class="active"><a>' . $lng['themes'] . '</a></li>' :
        '<li><a href="' . $set['homeurl'] .
        '/users/profile.php/act/activity/mod/topic/user/' . $user['id'] . '">' .
        $lng['themes'] . '</a></li>'),
    ($mod == 'comments' ? '<li class="active"><a>' . $lng['comments'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/users/profile.php/act/activity/mod/comments/user/' . $user['id'] .
        '">' . $lng['comments'] . '</a></li>'),
    );

switch ($mod)
{
    case 'comments':
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `user_id` = '" .
            $user['id'] . "'" . ($rights >= 1 ? '' : " AND `adm` = '0'")), 0);
        echo '<div class="callout callout-info">' . functions::display_user($user,
            array('iphide' => 1, )) . '</div>';
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        $req = mysql_query("SELECT * FROM `guest` WHERE `user_id` = '" . $user['id'] .
            "'" . ($rights >= 1 ? '' : " AND `adm` = '0'") .
            " ORDER BY `id` DESC LIMIT $start, $kmess");
        if (mysql_num_rows($req))
        {
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                echo ($i % 2 ? '<div class="list2">' : '<div class="list1">') .
                    functions::checkout($res['text'], 2, 1) .
                    '<div class="sub">' . '<span class="gray">(' . functions::display_date($res['time']) .
                    ')</span>' . '</div></div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng_profile['guest_empty'] .
                '</p></div>';
        }
        break;

    case 'topic':
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `user_id` = '" .
            $user['id'] . "' AND `type` = 't'" . ($rights >= 7 ? '' :
            " AND `close`!='1'")), 0);
        echo '<div class="callout callout-info">' . functions::display_user($user,
            array('iphide' => 1, )) . '</div>';
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        $req = mysql_query("SELECT * FROM `forum` WHERE `user_id` = '" . $user['id'] .
            "' AND `type` = 't'" . ($rights >= 7 ? '' : " AND `close`!='1'") .
            " ORDER BY `id` DESC LIMIT $start, $kmess");
        if (mysql_num_rows($req))
        {
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                $post = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `refid` = '" .
                    $res['id'] . "'" . ($rights >= 7 ? '' : " AND `close`!='1'") .
                    " ORDER BY `id` ASC LIMIT 1"));
                $section = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = '" .
                    $res['refid'] . "'"));
                $category = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = '" .
                    $section['refid'] . "'"));
                $text = mb_substr($post['text'], 0, 300);
                $text = functions::checkout($text, 2, 1);
                echo ($i % 2 ? '<div class="list2">' : '<div class="list1">') .
                    '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $res['id'] .
                    '">' . $res['text'] . '</a>' . '<br />' . $text .
                    '...<a href="' . $set['homeurl'] . '/forum/index.php/id/' .
                    $res['id'] . '"> &gt;&gt;</a>' . '<div class="sub">' .
                    '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $category['id'] .
                    '">' . $category['text'] . '</a> | ' . '<a href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $section['id'] . '">' . $section['text'] .
                    '</a>' . '<br /><span class="gray">(' . functions::display_date($res['time']) .
                    ')</span>' . '</div></div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        break;

    default:
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `user_id` = '" .
            $user['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' :
            " AND `close`!='1'")), 0);
        echo '<div class="callout callout-info">' . functions::display_user($user,
            array('iphide' => 1, )) . '</div>';
        echo '<ul class="nav nav-tabs">' . functions::display_menu($menu) .
            '</ul>';
        $req = mysql_query("SELECT * FROM `forum` WHERE `user_id` = '" . $user['id'] .
            "' AND `type` = 'm' " . ($rights >= 7 ? '' : " AND `close`!='1'") .
            " ORDER BY `id` DESC LIMIT $start, $kmess");
        if (mysql_num_rows($req))
        {
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                $topic = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = '" .
                    $res['refid'] . "'"));
                $section = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = '" .
                    $topic['refid'] . "'"));
                $category = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = '" .
                    $section['refid'] . "'"));
                $text = mb_substr($res['text'], 0, 300);
                $text = functions::checkout($text, 2, 1);
                $text = preg_replace('#\[c\](.*?)\[/c\]#si',
                    '<div class="quote">\1</div>', $text);
                echo ($i % 2 ? '<div class="list2">' : '<div class="list1">') .
                    '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $topic['id'] .
                    '">' . $topic['text'] . '</a>' . '<br />' . $text .
                    '...<a href="' . $set['homeurl'] .
                    '/forum/index.php/act/post/id/' . $res['id'] .
                    '"> &gt;&gt;</a>' . '<div class="sub">' . '<a href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $category['id'] . '">' . $category['text'] .
                    '</a> | ' . '<a href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $section['id'] . '">' . $section['text'] .
                    '</a>' . '<br /><span class="gray">(' . functions::display_date($res['time']) .
                    ')</span>' . '</div></div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
}
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/users/profile.php/act/activity' . ($mod ? '/mod/' . $mod : '') .
        '/user/' . $user['id'] . '/', $start, $total, $kmess) . '</div>';
}

?>