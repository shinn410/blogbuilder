<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = htmlspecialchars($user['name']) . ': ' . $lng['statistics'];
$breadcrumb = functions::breadcrumb(array(
    // array('label' => $lng['users'], 'url' => '/users/'),
    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng['statistics']),
    ));
require ('../incfiles/head.php');
echo '<div class="callout callout-info">' . functions::display_user($user, array
    ('iphide' => 1, )) . '</div>';
echo '<div class="row">';
echo '<div class="col-sm-6 col-md-8"><div class="box box-solid"><div class="box-header">' .
    '<i class="fa fa-bar-chart-o"></i><h3 class="box-title">' . $lng['statistics'] .
    '</h3></div><div class="box-body"><ul>';
if ($rights >= 7)
{
    if (!$user['preg'] && empty($user['regadm']))
        echo '<li>' . $lng_profile['awaiting_registration'] . '</li>';
    elseif ($user['preg'] && !empty($user['regadm']))
        echo '<li>' . $lng_profile['registration_approved'] . ': ' . $user['regadm'] .
            '</li>';
    else
        echo '<li>' . $lng_profile['registration_free'] . '</li>';
}
echo '<li><span class="gray">' . ($user['sex'] == 'm' ? $lng_profile['registered_m'] :
    $lng_profile['registered_w']) . ':</span> ' . date("d.m.Y", $user['datereg']) .
    '</li>' . '<li><span class="gray">' . ($user['sex'] == 'm' ? $lng_profile['stayed_m'] :
    $lng_profile['stayed_w']) . ':</span> ' . functions::timecount($user['total_on_site']) .
    '</li>';
$lastvisit = time() > $user['lastdate'] + 300 ? date("d.m.Y (H:i)", $user['lastdate']) : false;
if ($lastvisit)
    echo '<li><span class="gray">' . $lng['last_visit'] . ':</span> ' . $lastvisit .
        '</li>';
echo '</ul></div></div>';

echo '<div class="box box-solid"><div class="box-header">' .
    '<i class="fa fa-sitemap"></i><h3 class="box-title">' . $lng_profile['activity'] .
    '</h3></div><div class="box-body"><ul>';
echo '<li><span class="gray">' . $lng['forum'] . ':</span> <a href="' . $set['homeurl'] .
    '/users/profile.php/act/activity/user/' . $user['id'] . '">' . $user['postforum'] .
    '</a></li>' . '<li><span class="gray">' . $lng['guestbook'] .
    ':</span> <a href="' . $set['homeurl'] .
    '/users/profile.php/act/activity/mod/comments/user/' . $user['id'] . '">' .
    $user['postguest'] . '</a></li>' . '<li><span class="gray">' . $lng['comments'] .
    ':</span> ' . $user['komm'] . '</li>' . '</ul></div></div></div>';

echo '<div class="col-sm-6 col-md-4"><div class="box box-solid"><div class="box-header">' .
    '<i class="fa fa-trophy"></i><h3 class="box-title">' . $lng_profile['achievements'] .
    '</h3></div><div class="box-body"><div id="bar-chart" style="height: 222px;"></div>';
$jquery .= 'var bar_data = { data: [["' . $lng['forum'] . '", ' . $user['postforum'] .
    '], ["' . $lng['guestbook'] . '", ' . $user['postguest'] . '], ["' . $lng['comments'] .
    '", ' . $user['komm'] . ']], color: "#3c8dbc" };' .
    '$.plot("#bar-chart", [bar_data], { grid: { ' .
    'borderWidth: 1, borderColor: "#f3f3f3", tickColor: "#f3f3f3" }, series: { bars: { ' .
    'show: true, barWidth: 0.8, align: "center" } }, xaxis: { mode: "categories", ' .
    'tickLength: 0 } });';
$foot = '<!-- FLOT CHARTS --><script src="' . $set['homeurl'] .
    '/theme/default/js/plugins/flot/jquery.flot.min.js" type="text/javascript">' .
    '</script><!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->' .
    '<script src="' . $set['homeurl'] .
    '/theme/default/js/plugins/flot/jquery.flot.resize.min.js" type="text/javascript">' .
    '</script><!-- FLOT PIE PLUGIN - also used to draw donut charts -->' .
    '<script src="' . $set['homeurl'] .
    '/theme/default/js/plugins/flot/jquery.flot.pie.min.js" type="text/javascript">' .
    '</script><!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->' .
    '<script src="' . $set['homeurl'] .
    '/theme/default/js/plugins/flot/jquery.flot.categories.min.js" type="text/javascript">' .
    '</script>';
echo '</div></div></div></div>';

?>