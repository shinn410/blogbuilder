<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = htmlspecialchars($user['name']) . ': ' . $lng_profile['profile_edit'];
$breadcrumb = functions::breadcrumb(array(

    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng['edit']),
    ));
require ('../incfiles/head.php');
if ($user['id'] != $user_id && ($rights < 7 || $user['rights'] > $rights))
{
    echo functions::display_error($lng_profile['error_rights']);
    require ('../incfiles/end.php');
    exit;
}

if ($rights >= 7 && $rights > $user['rights'] && $act == 'reset')
{
    mysql_query("UPDATE `users` SET `set_user` = '', `set_forum` = '', `set_chat` = '' WHERE `id` = '" .
        $user['id'] . "'");
    echo '<div class="alert alert-success"><p>' . $lng['settings_default'] .
        '<br /><a class="alert-link" href="' . $set['homeurl'] .
        '/users/profile.php/user/' . $user['id'] . '">' . $lng['to_form'] .
        '</a></p></div>';
    require ('../incfiles/end.php');
    exit;
}
if (isset($_GET['delavatar']))
{
    @unlink('../files/users/avatar/' . $user['id'] . '.png');
    echo '<div class="alert alert-danger">' . $lng_profile['avatar_deleted'] .
        '</div>';
}
elseif (isset($_GET['delphoto']))
{
    @unlink('../files/users/photo/' . $user['id'] . '.jpg');
    @unlink('../files/users/photo/' . $user['id'] . '_small.jpg');
    echo '<div class="alert alert-danger">' . $lng_profile['photo_deleted'] .
        '</div>';
}
elseif (isset($_POST['submit']))
{
    $error = array();
    $user['imname'] = isset($_POST['imname']) ? functions::check(mb_substr($_POST['imname'],
        0, 25)) : '';
    $user['live'] = isset($_POST['live']) ? functions::check(mb_substr($_POST['live'],
        0, 50)) : '';
    $user['dayb'] = isset($_POST['dayb']) ? intval($_POST['dayb']) : 0;
    $user['monthb'] = isset($_POST['monthb']) ? intval($_POST['monthb']) : 0;
    $user['yearofbirth'] = isset($_POST['yearofbirth']) ? intval($_POST['yearofbirth']) :
        0;
    $user['about'] = isset($_POST['about']) ? functions::check(mb_substr($_POST['about'],
        0, 500)) : '';
    $user['mibile'] = isset($_POST['mibile']) ? functions::check(mb_substr($_POST['mibile'],
        0, 40)) : '';
    if ($rights >= 7)
    {
        $mail = isset($_POST['mail']) ? strtolower(mb_substr($_POST['mail'], 0,
            40)) : $user['mail'];
        if (!filter_var($mail, FILTER_VALIDATE_EMAIL))
        {
            $error[] = 'E-Mail tidak valid';
        }
        else
        {
            $reqq = mysql_query("SELECT * FROM `users` WHERE `id` != '" . $user['id'] .
                "' AND `mail` = '" . mysql_real_escape_string($mail) . "'");
            if (mysql_num_rows($reqq) == 0)
                $user['mail'] = functions::check($mail);
            else
            {
                $error[] = 'E-Mail sudah terdaftar!';
            }
        }
    }
    else
    {
        $user['mail'] = functions::check($user['mail']);
    }
    $user['mailvis'] = isset($_POST['mailvis']) ? 1 : 0;
    $user['icq'] = isset($_POST['icq']) ? intval($_POST['icq']) : 0;
    $user['skype'] = isset($_POST['skype']) ? functions::check(mb_substr($_POST['skype'],
        0, 40)) : '';
    $user['jabber'] = isset($_POST['jabber']) ? functions::check(mb_substr($_POST['jabber'],
        0, 40)) : '';
    $user['www'] = isset($_POST['www']) ? functions::check(mb_substr($_POST['www'],
        0, 40)) : '';

    $user['name'] = isset($_POST['name']) ? functions::check(mb_substr($_POST['name'],
        0, 20)) : $user['name'];
    $user['status'] = isset($_POST['status']) ? functions::check(mb_substr($_POST['status'],
        0, 50)) : '';
    $user['karma_off'] = isset($_POST['karma_off']) ? 1 : 0;
    $user['sex'] = isset($_POST['sex']) && $_POST['sex'] == 'm' ? 'm' : 'zh';
    $user['rights'] = isset($_POST['rights']) ? abs(intval($_POST['rights'])) :
        $user['rights'];

    if ($user['rights'] > $rights || $user['rights'] > 9 || $user['rights'] < 0)
        $user['rights'] = 0;
    if ($rights >= 7)
    {
        if (mb_strlen($user['name']) < 2 || mb_strlen($user['name']) > 20)
            $error[] = $lng_profile['error_nick_lenght'];
        $lat_nick = functions::rus_lat(mb_strtolower($user['name']));
        if (preg_match("/[^0-9a-z\-\@\*\(\)\?\!\~\_\=\[\]]+/", $lat_nick))
            $error[] = $lng_profile['error_nick_symbols'];
    }
    if ($user['dayb'] || $user['monthb'] || $user['yearofbirth'])
    {
        if ($user['dayb'] < 1 || $user['dayb'] > 31 || $user['monthb'] < 1 || $user['monthb'] >
            12)
            $error[] = $lng_profile['error_birth'];
    }
    if ($user['icq'] && ($user['icq'] < 10000 || $user['icq'] > 999999999))
        $error[] = $lng_profile['error_icq'];
    if (!$error)
    {
        mysql_query("UPDATE `users` SET
            `imname` = '" . $user['imname'] . "',
            `live` = '" . $user['live'] . "',
            `dayb` = '" . $user['dayb'] . "',
            `monthb` = '" . $user['monthb'] . "',
            `yearofbirth` = '" . $user['yearofbirth'] . "',
            `about` = '" . $user['about'] . "',
            `mibile` = '" . $user['mibile'] . "',
            `mail` = '" . $user['mail'] . "',
            `mailvis` = '" . $user['mailvis'] . "',
            `icq` = '" . $user['icq'] . "',
            `skype` = '" . $user['skype'] . "',
            `jabber` = '" . $user['jabber'] . "',
            `www` = '" . $user['www'] . "'
            WHERE `id` = '" . $user['id'] . "'
        ");
        if ($rights >= 7)
        {
            mysql_query("UPDATE `users` SET
                `name` = '" . $user['name'] . "',
                `status` = '" . $user['status'] . "',
                `karma_off` = '" . $user['karma_off'] . "',
                `sex` = '" . $user['sex'] . "',
                `rights` = '" . $user['rights'] . "'
                WHERE `id` = '" . $user['id'] . "'
            ");
        }
        if ($user['id'] != $user_id)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/users/profile.php/user/' . $user['id']);
            exit;
        }
        $result = '<div class="alert alert-success">' . $lng_profile['data_saved'] .
            '</div>';
    }
    else
    {
        $result = functions::display_error($error);
    }

}

echo '<form class="form" role="form" action="' . $set['homeurl'] .
    '/users/profile.php/act/edit/user/' . $user['id'] . '" method="post">' . (isset
    ($result) ? $result : '') .
    '<div class="box box-default max-width flat"><div class="box-body"><div class="form-group">' .
    '<label class="control-label">' . $lng['login_name'] . '</label>' .
    '<input class="form-control" type="text" placeholder="' . $user['name_lat'] .
    '" disabled/>' . '</div>';
if ($rights >= 7)
{
    echo '<div class="form-group">' . '<label class="control-label">' . $lng['nick'] .
        ' <span class="label-help">(' . $lng_profile['nick_lenght'] .
        ')</span></label>' . '<input class="form-control" type="text" value="' .
        $user['name'] . '" name="name" />' . '</div>' .
        '<div class="form-group">' . '<label class="control-label">' . $lng['status'] .
        ' <span class="label-help">(' . $lng_profile['status_lenght'] .
        ')</span></label>' . '<input class="form-control" type="text" value="' .
        $user['status'] . '" name="status" />' . '</div>';
}
else
{
    echo '<div class="form-group">' . '<label class="control-label">' . $lng['nick'] .
        '</label>' . '<input type="text" class="form-control" placeholder="' . $user['name'] .
        '" disabled/>' . '</div>' . '<div class="form-group">' .
        '<label class="control-label">' . $lng['status'] . '</label>' .
        '<input type="text" class="form-control" placeholder="' . $user['status'] .
        '" disabled/>' . '</div>';
}
echo '<div class="form-group">' . '<label>' . $lng['avatar'] . '</label>';
$link = '';
if (file_exists(('../files/users/avatar/' . $user['id'] . '.png')))
{
    echo '<img class="thumbnail" style="display:table;margin-bottom:0;" src="' .
        $set['homeurl'] . '/files/users/avatar/' . $user['id'] . '.png" alt="' .
        $user['name'] . '" />';
    $link = '&nbsp;<a class="func" href="' . $set['homeurl'] .
        '/users/profile.php/act/edit/user/' . $user['id'] .
        '/delavatar"><i class="fa fa-times"></i> ' . $lng['delete'] . '</a>';
}
echo '<p>' . '<a class="func" href="' . $set['homeurl'] .
    '/users/profile.php/act/images/mod/avatar/user/' . $user['id'] .
    '"><i class="fa fa-upload"></i> ' . $lng_profile['upload'] . '</a>';
if ($user['id'] == $user_id)
    echo '&nbsp;<a class="func" href="' . $set['homeurl'] .
        '/pages/faq.php/act/avatars"><i class="fa fa-picture-o"></i> ' . $lng['select'] .
        '</a>';
echo $link . '</p></div>';

echo '<div class="form-group"><label>' . $lng_profile['photo'] . '</label>';
$link = '';
if (file_exists('../files/users/photo/' . $user['id'] . '_small.jpg'))
{
    echo '<a class="thumbnail" style="display:table;margin-bottom:0;" href="' .
        $set['homeurl'] . '/files/users/photo/' . $user['id'] .
        '.jpg"><img src="' . $set['homeurl'] . '/files/users/photo/' . $user['id'] .
        '_small.jpg" alt="' . $user['name'] . '" border="0" /></a>';
    $link = '&nbsp;<a class="func" href="' . $set['homeurl'] .
        '/users/profile.php/act/edit/user/' . $user['id'] .
        '/delphoto"><i class="fa fa-times"></i> ' . $lng['delete'] . '</a>';
}
echo '<p><a class="func" href="' . $set['homeurl'] .
    '/users/profile.php/act/images/mod/up_photo/user/' . $user['id'] .
    '"><i class="fa fa-upload"></i> ' . $lng_profile['upload'] . '</a>' . $link .
    '</p></div></div></div>';

echo '<div class="box box-info max-width flat"><div class="box-header">' .
    '<h3 class="box-title"><img src="' . $set['homeurl'] .
    '/images/contacts.png" width="16" height="16" class="left" />&#160;' . $lng_profile['personal_data'] .
    '</h3></div><div class="box-body">';

echo '<div class="form-group"><label>' . $lng_profile['name'] . '</label>' .
    '<input class="form-control" type="text" value="' . $user['imname'] .
    '" name="imname" /></div>';
echo '<div class="form-group"><label>' . $lng_profile['birth_date'] .
    '</label><div class="row"><div class="col-xs-4 col-sm-2">' .
    '<input class="form-control" type="text" value="' . $user['dayb'] .
    '" size="2" maxlength="2" name="dayb" /><p class="help-block">Day of birth. Eg. 22<p></div>' .
    '<div class="col-xs-4 col-sm-2">' .
    '<input class="form-control" type="text" value="' . $user['monthb'] .
    '" size="2" maxlength="2" name="monthb" /><p class="help-block">Month of birth. Eg. 04<p></div>' .
    '<div class="col-xs-4 col-sm-2"><input class="form-control" type="text" value="' .
    $user['yearofbirth'] .
    '" size="4" maxlength="4" name="yearofbirth" /><p class="help-block">Year of birth. Eg. 2014<p></div>' .
    '</div>' . '</div>';
echo '<div class="form-group"><label>' . $lng_profile['city'] . '</label>' .
    '<input class="form-control" type="text" value="' . $user['live'] .
    '" name="live" />' . '</div>';
echo '<div class="form-group"><label>' . $lng_profile['about'] .
    '</label><textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="about">' . $user['about'] . '</textarea>' . '</div>';
echo '</div></div>';
echo '<div class="box box-warning max-width flat"><div class="box-header"><h3 class="box-title"><img src="' .
    $set['homeurl'] .
    '/images/mail.png" width="16" height="16" class="left" />&#160;' . $lng_profile['communication'] .
    '</h3></div><div class="box-body">' . '<div class="form-group">' . '<label>' .
    $lng_profile['phone_number'] . '</label>' .
    '<input class="form-control" type="text" value="' . $user['mibile'] .
    '" name="mibile" />' . '</div>' . '<div class="form-group">' .
    '<label>E-mail</label>' . '<div class="input-group">' .
    '<span class="input-group-addon" data-toggle="tooltip" data-title="' . $lng_profile['show_in_profile'] .
    '">' . '<input name="mailvis" type="checkbox" value="1" ' . ($user['mailvis'] ?
    'checked="checked"' : '') . ' />' . '</span>' .
    '<input class="form-control" type="text" value="' . $user['mail'] .
    '" name="mail" ' . ($rights >= 7 ? '' : 'disabled') . '/>' . '</div>' .
    '<p class="help-block">' . $lng_profile['email_warning'] . ($rights < 7 ?
    '<br/><span class="text-red">To change your email address please contact Administrator!</span>' :
    '') . '</p>' . '</div>' . '<div class="form-group">' . '<label>ICQ</label>' .
    '<input class="form-control" type="text" value="' . $user['icq'] .
    '" name="icq" size="10" maxlength="10" />' . '</div>' .
    '<div class="form-group">' . '<label>Skype</label>' .
    '<input class="form-control" type="text" value="' . $user['skype'] .
    '" name="skype" />' . '</div>' . '<div class="form-group">' .
    '<label>Jabber</label>' . '<input class="form-control" type="text" value="' .
    $user['jabber'] . '" name="jabber" />' . '</div>' .
    '<div class="form-group">' . '<label>' . $lng_profile['site'] . '</label>' .
    '<input class="form-control" type="text" value="' . $user['www'] .
    '" name="www" />' . '</div>' . '</div></div>';

if ($rights >= 7)
{
    echo '<div class="box box-danger max-width flat"><div class="box-header"><h3 class="box-title">' .
        '<img src="' . $set['homeurl'] .
        '/images/settings.png" width="16" height="16" class="left" />&#160;' . $lng['settings'] .
        '</h3></div><div class="box-body">';
    if ($rights == 9)
    {
        echo '<div class="checkbox"><label><input name="karma_off" type="checkbox" value="1" ' . ($user['karma_off'] ?
            'checked="checked"' : '') . ' />&#160;<span class="red"><b>' . $lng_profile['deny_karma'] .
            '</b></span></label></div>';
    }
    echo '<a class="func" href="' . $set['homeurl'] .
        '/users/profile.php/act/password/user/' . $user['id'] .
        '"><i class="fa fa-lock"></i> ' . $lng['change_password'] . '</a>';
    if ($rights > $user['rights'])
        echo '<br/><a class="func" href="' . $set['homeurl'] .
            '/users/profile.php/act/reset/user/' . $user['id'] .
            '"><i class="fa fa-repeat"></i> ' . $lng['reset_settings'] . '</a>';
    echo '<div class="form-group">' . '<label>' . $lng_profile['specify_sex'] .
        '</label>' .
        '<div class="radio"><label><input type="radio" value="m" name="sex" ' . ($user['sex'] ==
        'm' ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['sex_m'] .
        '</label></div>' .
        '<div class="radio"><label><input type="radio" value="zh" name="sex" ' . ($user['sex'] ==
        'zh' ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['sex_w'] .
        '</label></div>' . '</div>';
    if ($user['id'] != $user_id)
    {
        echo '<div class="form-group"><label><img src="' . $set['homeurl'] .
            '/images/forbidden.png" width="16" height="16" class="left" />&#160;' .
            $lng_profile['rank'] . '</label>' .
            '<div class="radio"><label><input type="radio" value="0" name="rights" ' . (!
            $user['rights'] ? 'checked="checked"' : '') . '/>&#160;<b>' . $lng_profile['rank_0'] .
            '</b></label></div>' .
            '<div class="radio"><label><input type="radio" value="3" name="rights" ' . ($user['rights'] ==
            3 ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['rank_3'] .
            '</label></div>' .
            '<div class="radio"><label><input type="radio" value="4" name="rights" ' . ($user['rights'] ==
            4 ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['rank_4'] .
            '</label></div>' .
            '<div class="radio"><label><input type="radio" value="5" name="rights" ' . ($user['rights'] ==
            5 ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['rank_5'] .
            '</label></div>' .
            '<div class="radio"><label><input type="radio" value="6" name="rights" ' . ($user['rights'] ==
            6 ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['rank_6'] .
            '</label></div>';
        if ($rights == 9)
        {
            echo '<div class="radio"><label><input type="radio" value="7" name="rights" ' . ($user['rights'] ==
                7 ? 'checked="checked"' : '') . '/>&#160;' . $lng_profile['rank_7'] .
                '</label></div>' .
                '<div class="radio"><label><input type="radio" value="9" name="rights" ' . ($user['rights'] ==
                9 ? 'checked="checked"' : '') . '/>&#160;<span class="red"><b>' .
                $lng_profile['rank_9'] . '</b></label></div>';
        }
        echo '</div>';
    }
    echo '</div></div>';
}
echo '<p><input class="btn btn-primary" type="submit" value="' . $lng['save'] .
    '" name="submit" /></p></form>';

?>