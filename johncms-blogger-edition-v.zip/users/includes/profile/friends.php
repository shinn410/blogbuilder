<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $lng_profile['friends'];
ob_start();
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng_profile['friends']),
    ));
$main_header = 1;
require ('../incfiles/head.php');
$set_mail = unserialize($set['setting_mail']);

if (!isset($set_mail['cat_friends']))
{
    $set_mail['cat_friends'] = 0;
}

if ($id && $id != $user_id && $do)
{
    $user_target = functions::get_user($id);
    if (!$user_target)
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo functions::display_error($lng['user_does_not_exist']);
        require ('../incfiles/end.php');
        ob_end_flush();
        exit;
    }

    $contacts = mysql_query("SELECT * FROM `cms_contact` LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id` WHERE `cms_contact`.`user_id`='$user_id' AND `cms_contact`.`from_id`='$id'");
    $result = mysql_fetch_assoc($contacts);

    switch ($do)
    {
        case 'add':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(

                array('label' => $user['name'], 'url' =>
                        '/users/profile.php/user/' . $user['id']),
                array('label' => $lng_profile['friends'], 'url' =>
                        '/users/profile.php/user/' . $user['id'] .
                        '/act/friends'),
                array('label' => $lng_profile['in_friend'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<div class="well well-sm">' . functions::display_user($user_target) .
                '</div>';
            $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND ((`from_id`='$id' AND `user_id`='$user_id') OR (`from_id`='$user_id' AND `user_id`='$id'))"),
                0);
            if ($fr != 2)
            {
                if (isset($_POST['submit']))
                {
                    $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$user_id' AND `from_id`='$id'"),
                        0);
                    if ($fr_out)
                    {
                        echo functions::display_error($lng_profile['already_demand']);

                        require_once ('../incfiles/end.php');
                        ob_end_flush();
                        exit;
                    }

                    $fr_in = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `from_id`='$user_id' AND `user_id`='$id'"),
                        0);
                    if ($fr_in)
                    {
                        echo functions::display_error($lng_profile['offer_already']);

                        require_once ('../incfiles/end.php');
                        ob_end_flush();
                        exit;
                    }

                    $friends = isset($_POST['friends']) && $_POST['friends'] >=
                        0 && $_POST['friends'] <= 6 && $set_mail['cat_friends'] ?
                        abs(intval($_POST['friends'])) : 0;
                    $arr_fr = array(
                        1 => $lng_profile['you_my_friends'],
                        $lng_profile['you_my_classfriends'],
                        $lng_profile['you_my_colleagues'],
                        $lng_profile['you_my_best_friends'],
                        $lng_profile['you_my_classmates'],
                        $lng_profile['you_my_relatives']);
                    $my = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `from_id`='$id'"),
                        0);

                    if ($my != 0)
                    {
                        mysql_query("UPDATE `cms_contact` SET
						`type`='2', `time`='" . time() . "', `man`='" . $friends .
                            "' WHERE `user_id`='$user_id' AND `from_id`='$id'");
                    }
                    else
                    {
                        mysql_query("INSERT INTO `cms_contact` SET
						`user_id`='$user_id', `from_id`='$id', `time`='" . time() .
                            "', `type`='2', `man`='" . $friends . "'");
                        mysql_query("INSERT INTO `cms_contact` SET
						`user_id`='$id', `from_id`='$user_id', `time`='" . time() . "'");
                    }

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                        '[/url] ' . $lng_profile['offers_friends'] . ' [url=' .
                        core::$system_set['url'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $user_id .
                        ']' . $lng_profile['confirm'] . '[/url] | [url=' . core::
                        $system_set['url'] .
                        '/users/profile.php/act/friends/do/no/id/' . $user_id .
                        ']' . $lng_profile['decline'] . '[/url]';
                    mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '$id',
					`text` = '$text',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = '{$lng_profile['friendship']}'");

                    if ($friends)
                    {
                        $text1 = '[url=' . core::$system_set['url'] .
                            '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                            '[/url] ' . $arr_fr[$friends] . ' [url=' . core::$system_set['url'] .
                            '/users/profile.php/act/friends/do/okfriends/id/' .
                            $user_id . ']' . $lng_profile['confirm'] . '[/url]';
                        mysql_query("INSERT INTO `cms_mail` SET
						`user_id` = '$user_id', 
						`from_id` = '$id',
						`text` = '$text1',
						`time` = '" . time() . "',
						`sys` = '1',
						`them` = '{$lng_profile['friendship']}'");
                    }
                    header('Location: ' . core::$system_set['homeurl'] .
                        '/users/profile.php/user/' . $id);
                    ob_end_flush();
                    exit();
                    echo '<div class="alert alert-success">' . $lng_profile['demand_friends_sent'] .
                        '</div>';
                }
                else
                {
                    if (!functions::is_ignor($id) && !isset($ban['1']) && !
                        isset($ban['3']))
                    {
                        echo '<form role="form" action="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/add/id/' . $id .
                            '" method="post">
					<div class="alert alert-warning">' . $lng_profile['really_offer_friendship'] .
                            '</div>
					' . ($set_mail['cat_friends'] ?
                            '<div class="radio"><label><input type="radio" value="6" name="friends" />&#160;' .
                            $lng_profile['relative'] . '</label></div>
					<div class="radio"><label><input type="radio" value="5" name="friends" />&#160;' .
                            $lng_profile['classmate'] . '</label></div>
					<div class="radio"><label><input type="radio" value="4" name="friends" />&#160;' .
                            $lng_profile['best_friend'] . '</label></div>
					<div class="radio"><label><input type="radio" value="3" name="friends" />&#160;' .
                            $lng_profile['colleague'] . '</label></div>
					<div class="radio"><label><input type="radio" value="2" name="friends" />&#160;' .
                            $lng_profile['classfriend'] . '</label></div>
					<div class="radio"><label><input type="radio" value="1" name="friends" />&#160;' .
                            $lng_profile['friend'] . '</label></div>' : '') . '
					<input class="btn btn-primary" type="submit" name="submit" value="' . $lng_profile['confirm'] .
                            '"/>
					</form>';
                    }
                    else
                    {
                        echo '<div class="alert alert-danger">' . $lng_profile['error_frienship_you_in_ignor'] .
                            '</div>';
                    }
                }
            }
            else
            {
                echo functions::display_error($lng_profile['user_already_friend']);
            }
            break;

        case 'cancel':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(

                array('label' => $user['name'], 'url' =>
                        '/users/profile.php/user/' . $user['id']),
                array('label' => $lng_profile['friends'], 'url' =>
                        '/users/profile.php/user/' . $user['id'] .
                        '/act/friends'),
                array('label' => $lng_profile['canceled_demand_friend'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            if (!$is_modal)
                echo '<div class="well well-sm">' . functions::display_user($user_target) .
                    '</div>';
            $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND ((`from_id`='$id' AND `user_id`='$user_id') OR (`from_id`='$user_id' AND `user_id`='$id'))"),
                0);

            if ($fr != 2)
            {
                if (isset($_POST['submit']))
                {
                    $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$user_id' AND `from_id`='$id'"),
                        0);
                    if ($fr_out == 0)
                    {
                        echo functions::display_error($lng_profile['not_demand_friendship']);

                        require_once ('../incfiles/end.php');
                        ob_end_flush();
                        exit;
                    }

                    mysql_query("UPDATE `cms_contact` SET
					  `type`='1'
					  WHERE `user_id`='$user_id'
					  AND `from_id`='$id'
					");

                    $text = '[url=' . core::$system_set['homeurl'] .
                        '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                        '[/url] ' . $lng_profile['offers_friends'] . ' [url=' .
                        core::$system_set['homeurl'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $user_id .
                        ']' . $lng_profile['confirm'] . '[/url] | [url=' . $home .
                        '/users/profile.php/act/friends&do=no/id/' . $user_id .
                        ']' . $lng_profile['decline'] . '[/url]';
                    mysql_query("DELETE FROM `cms_mail` WHERE `text`='" .
                        mysql_real_escape_string($text) . "'");
                    header('Location: ' . core::$system_set['homeurl'] .
                        '/users/profile.php/user/' . $id);
                    ob_end_flush();
                    exit();
                    echo '<div class="alert alert-success">' . $lng_profile['demand_cancelled'] .
                        '</div>';
                }
                else
                {

                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/cancel/id/' . $id .
                        '" method="post"><div class="alert alert-warning">' . $lng_profile['really_demand_cancelled'] .
                        '</div>' .
                        '<input class="btn btn-primary" type="submit" name="submit" value="' .
                        $lng_profile['confirm'] . '"/></form>';
                }
            }
            else
            {
                echo functions::display_error($lng_profile['already_your_friend']);
            }
            break;

        case 'okfriends':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                        $lng['personal'], 'url' =>
                        '/users/profile.php/act/office'), array('label' => $lng_profile['friends'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            if ($set_mail['cat_friends'])
            {
                $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `from_id`='$id'"),
                    0);

                if ($fr)
                {
                    $cont = mysql_query("SELECT * FROM `cms_contact` WHERE `user_id`='$id' AND `from_id`='$user_id'");
                    $res = mysql_fetch_assoc($cont);
                    if (isset($_POST['submit']))
                    {
                        $arr_fr = array(
                            1 => $lng_profile['you_my_friends'],
                            $lng_profile['you_my_classfriends'],
                            $lng_profile['you_my_colleagues'],
                            $lng_profile['you_my_best_friends'],
                            $lng_profile['you_my_classmates'],
                            $lng_profile['you_my_relatives']);

                        $text = '[url=' . core::$system_set['homeurl'] .
                            '/users/profile.php/user/' . $id . ']' . $result['name'] .
                            '[/url] ' . $arr_fr[$res['man']] . ' [url=' . core::
                            $system_set['homeurl'] .
                            '/users/profile.php/act/friends&do=okfriends/id/' .
                            $id . ']' . $lng_profile['confirm'] . '[/url]';
                        mysql_query("DELETE FROM `cms_mail` WHERE `user_id` = '$id' AND `from_id` = '$user_id' AND `text`='" .
                            mysql_real_escape_string($text) . "'");
                        $arr_fr1 = array(
                            1 => $lng_profile['you_friends'],
                            $lng_profile['you_classfriends'],
                            $lng_profile['you_colleagues'],
                            $lng_profile['you_best_friends'],
                            $lng_profile['you_classmates'],
                            $lng_profile['you_relatives']);
                        mysql_query("UPDATE `cms_contact` SET `man`='{$res['man']}' WHERE `user_id`='$user_id' AND `from_id`='$id'");
                        echo '<div class="alert alert-success">' . $arr_fr1[$res['man']] .
                            ' ' . $result['name'] . '</div>';
                    }
                    else
                    {
                        $arr_fr2 = array(
                            1 => $lng_profile['friend'],
                            $lng_profile['classfriend'],
                            $lng_profile['colleague'],
                            $lng_profile['best_friend'],
                            $lng_profile['classmate'],
                            $lng_profile['relative']);

                        echo '<div class="gmenu"><form role="form" action="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/okfriends/id/' .
                            $id . '" method="post"><div>
						' . $lng_profile['really_okfriends'] . ' ' . $arr_fr2[$res['man']] .
                            '<br />
						<input class="btn btn-primary" type="submit" name="submit" value="' . $lng_profile['confirm'] .
                            '"/>
						</div></form></div>';
                    }
                }
                else
                {
                    echo functions::display_error($lng['error']);
                }
            }
            else
            {
                echo functions::display_error($lng_profile['function_is_disconnected']);
            }
            break;

        case 'ok':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                        $lng['personal'], 'url' =>
                        '/users/profile.php/act/office'), array('label' => $lng_profile['friends'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND ((`from_id`='$id' AND `user_id`='$user_id') OR (`from_id`='$user_id' AND `user_id`='$id'))"),
                0);

            if ($fr != 2)
            {
                if (isset($_POST['submit']))
                {
                    $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$id' AND `from_id`='$user_id'"),
                        0);

                    if ($fr_out == 0)
                    {
                        echo functions::display_error($lng_profile['not_offers_friendship']);
                        echo '<p>' . functions::link_back($lng['back'],
                            'users/profile.php/user/' . $id) . '</p>';
                        require_once ('../incfiles/end.php');
                        ob_end_flush();
                        exit;
                    }

                    mysql_query("UPDATE `cms_contact` SET
					  `type`='2', `friends`='1'
					  WHERE `user_id`='$user_id'
					  AND `from_id`='$id'
					");

                    mysql_query("UPDATE `cms_contact` SET
					  `friends`='1'
					  WHERE `user_id`='$id'
					  AND `from_id`='$user_id'
					");

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                        '[/url] ' . $lng_profile['complied_friends'];
                    mysql_query("INSERT INTO `cms_mail` SET
					    `user_id` = '$user_id',
					    `from_id` = '$id',
					    `text` = '" . mysql_real_escape_string($text) . "',
					    `time` = '" . time() . "',
					    `sys` = '1',
					    `them` = '{$lng_profile['friendship']}'
					");

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $id . ']' . $result['name'] .
                        '[/url] ' . $lng_profile['offers_friends'] . ' [url=' .
                        core::$system_set['url'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $id . ']' .
                        $lng_profile['confirm'] . '[/url] | [url=' . core::$system_set['url'] .
                        '/users/profile.php/act/friends&do=no/id/' . $id . ']' .
                        $lng_profile['decline'] . '[/url]';
                    mysql_query("DELETE FROM `cms_mail` WHERE `user_id` = '$id' AND `from_id` = '$user_id' AND `text`='" .
                        mysql_real_escape_string($text) . "'");
                    echo '<div class="alert alert-success"><p>' . $lng_profile['confirmed_friendship'] .
                        ' ' . $result['name'] . ' ' . $lng_profile['your_friend'] .
                        '.</p></div>';
                }
                else
                {
                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $id .
                        '" method="post"><div class="alert alert-warning">' . $lng_profile['really_demand_confirm'] .
                        '</div>' .
                        '<input class="btn btn-primary" type="submit" name="submit" value="' .
                        $lng_profile['confirm'] . '"/></form>';
                }
            }
            else
            {
                echo functions::display_error($lng_profile['user_already_friend']);
            }
            break;

        case 'delete':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                        $lng['personal'], 'url' =>
                        '/users/profile.php/act/office'), array('label' => $lng_profile['friends'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND ((`from_id`='$id' AND `user_id`='$user_id') OR (`from_id`='$user_id' AND `user_id`='$id'))"),
                0);

            if ($fr == 2)
            {
                if (isset($_POST['submit']))
                {
                    mysql_query("UPDATE `cms_contact` SET
					  `type`='1',
					  `friends`='0'
					  WHERE `user_id`='$id'
					  AND `from_id`='$user_id'
					");

                    mysql_query("UPDATE `cms_contact` SET
					  `type`='1',
					  `friends`='0'
					  WHERE `user_id`='$user_id'
					  AND `from_id`='$id'
					");

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                        '[/url] ' . $lng_profile['deleted_you_friends'];
                    mysql_query("INSERT INTO `cms_mail` SET
					    `user_id` = '$user_id',
					    `from_id` = '$id',
					    `text` = '" . mysql_real_escape_string($text) . "',
					    `time` = '" . time() . "',
					    `sys` = '1',
					    `them` = '{$lng_profile['friendship']}'
					");
                    echo '<div class="alert alert-danger">' . $lng_profile['you_deleted_friends'] .
                        '</div>';
                }
                else
                {
                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/delete/id/' . $id .
                        '" method="post"><div class="alert alert-warning">' . $lng_profile['really_deleted_friends'] .
                        '</div>' .
                        '<input class="btn btn-primary" type="submit" name="submit" value="' .
                        $lng_profile['confirm'] . '"/></form>';
                }
            }
            else
            {
                echo functions::display_error($lng_profile['removing_not_possible']);
            }
            break;

        case 'no':
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                        $lng['personal'], 'url' =>
                        '/users/profile.php/act/office'), array('label' => $lng_profile['friends'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            $fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND ((`from_id`='$id' AND `user_id`='$user_id') OR (`from_id`='$user_id' AND `user_id`='$id'))"),
                0);

            if ($fr != 2)
            {
                if (isset($_POST['submit']))
                {
                    $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$id' AND `from_id`='$user_id'"),
                        0);

                    if ($fr_out == 0)
                    {
                        echo functions::display_error($lng_profile['not_demand_friendship']);
                        echo '<p>' . functions::link_back($lng['back'],
                            'users/profile.php/user/' . $id) . '</p>';
                        require_once ('../incfiles/end.php');
                        ob_end_flush();
                        exit;
                    }

                    mysql_query("UPDATE `cms_contact` SET `type`='1' WHERE `user_id`='$id' AND `from_id`='$user_id'");

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $user_id . ']' . $user['name'] .
                        '[/url] ' . $lng_profile['canceled_you_demand'];
                    mysql_query("INSERT INTO `cms_mail` SET
					    `user_id` = '$user_id',
					    `from_id` = '$id',
					    `text` = '" . mysql_real_escape_string($text) . "',
					    `time` = '" . time() . "',
					    `sys` = '1',
					    `them` = '{$lng_profile['friendship']}'
					    ");

                    $text = '[url=' . core::$system_set['url'] .
                        '/users/profile.php/user/' . $id . ']' . $result['name'] .
                        '[/url] ' . $lng_profile['offers_friends'] . ' [url=' .
                        core::$system_set['url'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $id . ']' .
                        $lng_profile['confirm'] . '[/url] | [url=' . core::$system_set['url'] .
                        '/users/profile.php/act/friends/do/no/id/' . $id . ']' .
                        $lng_profile['decline'] . '[/url]';
                    mysql_query("DELETE FROM `cms_mail` WHERE `user_id` = '$id' AND `from_id` = '$user_id' AND `text`='" .
                        mysql_real_escape_string($text) . "'");

                    echo '<div class="alert alert-success">' . $lng_profile['canceled_demand'] .
                        '</div>';
                }
                else
                {
                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/no/id/' . $id .
                        '" method="post"><div class="alert alert-warning">' . $lng_profile['really_canceled_demand'] .
                        '</div>' .
                        '<input class="btn btn-primary" type="submit" name="submit" value="' .
                        $lng_profile['confirm'] . '"/></form>';
                }
            }
            else
            {
                echo functions::display_error($lng_profile['already_your_friend']);
            }
            break;

        default:
            echo functions::display_error($lng_profile['pages_not_exist']);
    }
    echo '<p>' . functions::link_back($lng_profile['friends'],
        '/users/profile.php/act/friends') . '</p>';

}
else
{
    if ($user['id'] && $user['id'] != $user_id)
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);

        if ($set_mail['cat_friends'])
        {
            $sort = isset($_REQUEST['sort']) && $_REQUEST['sort'] >= 0 && $_REQUEST['sort'] <=
                6 ? abs(intval($_REQUEST['sort'])) : 0;
            if ($sort)
            {
                $sql = " AND `cms_contact`.`man`='$sort'";
                $nav = '/sort/' . $sort;
            }
            else
            {
                $sql = '';
                $nav = '';
            }
        }
        else
        {
            $sql = '';
            $nav = '';
        }

        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='{$user['id']}' AND `type`='2' AND `friends`='1' AND `ban`!='1'" .
            $sql), 0);

        if ($set_mail['cat_friends'])
        {
            echo '<div class="col-sm-offset-6"><form role="form" action="' . $set['homeurl'] .
                '/users/profile.php/act/friends/user/' . $user['id'] .
                '" method="post"><div class="input-group">
			<select class="form-control" name="sort">
			<option value="0">All</option>
			<option value="1"' . ($sort == 1 ? ' selected="selected"' : '') . '>' . $lng_profile['friend'] .
                '</option>
			<option value="2"' . ($sort == 2 ? ' selected="selected"' : '') . '>' . $lng_profile['classfriend'] .
                '</option>
			<option value="3"' . ($sort == 3 ? ' selected="selected"' : '') . '>' . $lng_profile['colleague'] .
                '</option>
			<option value="4"' . ($sort == 4 ? ' selected="selected"' : '') . '>' . $lng_profile['best_friend'] .
                '</option>
			<option value="5"' . ($sort == 5 ? ' selected="selected"' : '') . '>' . $lng_profile['classmate'] .
                '</option>
			<option value="6"' . ($sort == 6 ? ' selected="selected"' : '') . '>' . $lng_profile['relative'] .
                '</option>
			</select><span class="input-group-btn">
			<button class="btn btn-primary" type="submit">' . $lng_profile['sea_friends'] .
                ' &gt;&gt;</button></span></div></form></div>';
        }
        if ($total)
        {
            $req = mysql_query("SELECT `users`.* FROM `cms_contact`
			LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
			WHERE `cms_contact`.`user_id`='{$user['id']}' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `cms_contact`.`ban`!='1'$sql ORDER BY `cms_contact`.`time` DESC LIMIT " .
                $start . "," . $kmess);

            for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++$i)
            {
                echo $i % 2 ? '<div class="list1">' : '<div class="list2">';

                if ($row['id'] == $user_id)
                {
                    $subtext = '<a href="' . $set['homeurl'] .
                        '/mail/index.php/act/write/id/' . $user['id'] .
                        '"><span class="glyphicon glyphicon-comment"></span> ' .
                        $lng_profile['correspondence'] . '</a>';
                }
                else
                {
                    $subtext = '<a href="' . $set['homeurl'] .
                        '/mail/index.php/act/write/id/' . $row['id'] .
                        '"><span class="glyphicon glyphicon-pencil"></span> ' .
                        $lng['write'] . '</a> | <a href="' . $set['homeurl'] .
                        '/mail/index.php/id/' . $row['id'] .
                        '"><span class="glyphicon glyphicon-plus"></span> ' . $lng_profile['add_contacts'] .
                        '</a> | <a href="' . $set['homeurl'] .
                        '/mail/index.php/act/ignor/id/' . $row['id'] .
                        '/add"><span class="glyphicon glyphicon-ban-circle"></span> ' .
                        $lng_profile['add_ignor'] . '</a>';
                }

                $arg = array('sub' => $subtext);
                if ($row['id'] == $user_id)
                {
                    $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='{$user['id']}' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='{$user['id']}')) AND `sys`!='1' AND `delete`!='$user_id';"),
                        0);
                    $new_count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `cms_mail`.`from_id`='{$user['id']}' AND `cms_mail`.`user_id`='$user_id' AND `read`='0' AND `sys`!='1' AND `delete`!='$user_id';"),
                        0);
                    $arg['header'] = '(' . $count_message . ($new_count_message ?
                        '/<span class="red">+' . $new_count_message . '</span>' :
                        '') . ')';
                }
                echo functions::display_user($row, $arg);
                echo '</div>';
            }
            if ($total > $kmess)
            {
                echo '<p>' . functions::display_pagination($set['homeurl'] .
                    '/users/profile.php/act/friends' . $nav . '/user/' . $user['id'] .
                    '/', $start, $total, $kmess) . '</p>';
            }
            echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': ' . $total . '</div>';


        }
        else
        {

            echo '<div class="alert alert-danger">' . $lng_profile['friends'] .
                '</div>';
        }


    }
    else
    {
        $off = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `from_id`='$user_id' AND `type`='2' AND `friends`='0' AND `ban`='0'"),
            0);
        $dem = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='$user_id' AND `type`='2' AND `friends`='0' AND `ban`='0'"),
            0);
        $friend_online = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact`
				LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
				WHERE `cms_contact`.`user_id`='" . $user_id .
            "' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `cms_contact`.`ban`!='1' AND `users`.`lastdate` > " .
            (time() - 300) . "
				"), 0);
        if ($set_mail['cat_friends'])
        {
            $sort = isset($_REQUEST['sort']) && $_REQUEST['sort'] >= 0 && $_REQUEST['sort'] <=
                6 ? abs(intval($_REQUEST['sort'])) : 0;
            if ($sort)
            {
                $sql = " AND `cms_contact`.`man`='$sort'";
                $nav = '/sort/' . $sort;
            }
            else
            {
                $sql = '';
                $nav = '';
            }
        }
        else
        {
            $sql = '';
            $nav = '';
        }

        $friend_total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact`
			        LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
			        WHERE `cms_contact`.`user_id`='" . $user_id . "'
			        AND `cms_contact`.`type`='2'
			        AND `cms_contact`.`friends`='1'
			        AND `cms_contact`.`ban`!='1'$sql
			    "), 0);
        switch ($do)
        {
            case 'demands':
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo
                    '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li><a href="' .
                    $set['homeurl'] .
                    '/users/profile.php/act/friends"><i class="fa fa-users"></i> ' .
                    $lng_profile['my_friends'] . ' <span class="badge">' . $friend_total .
                    '</span></a><li class="active"><a href="#"><i class="fa fa-reply"></i> ' .
                    $lng_profile['my_demand'] . ($dem ?
                    ' <span class="badge red">' . $dem . '</span>' :
                    ' <span class="badge">' . $dem . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/offers"><i class="fa fa-share"></i> ' .
                    $lng_profile['my_offers'] . ($off ?
                    ' <span class="badge red">' . $off . '</span>' :
                    ' <span class="badge">' . $off . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/online"><i class="fa fa-eye"></i> ' .
                    $lng['online'] . ' <span class="badge">' . $friend_online .
                    '</span></a></li></ul><div class="tab-content">';

                $total = $dem;

                if ($total)
                {
                    $req = mysql_query("SELECT `users`.* FROM `cms_contact`
					LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
					WHERE `cms_contact`.`user_id`='" . $user_id .
                        "' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='0' AND `ban`!='1' ORDER BY `cms_contact`.`time` DESC LIMIT " .
                        $start . "," . $kmess);

                    for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++
                        $i)
                    {
                        echo $i % 2 ? '<div class="list1">' :
                            '<div class="list2">';

                        $subtext = '<a href="' . $set['homeurl'] .
                            '/mail/index.php/act/write/id/' . $row['id'] .
                            '"><span class="glyphicon glyphicon-pencil"></span> ' .
                            $lng['write'] . '</a> | <a href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/cancel/id/' . $row['id'] .
                            '" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><span class="glyphicon glyphicon-remove"></span> ' .
                            $lng_profile['cancel_demand'] . '</a>';
                        $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='{$row['id']}' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='{$row['id']}')) AND `delete`!='$user_id';"),
                            0);
                        $new_count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `cms_mail`.`from_id`='{$row['id']}' AND `cms_mail`.`user_id`='$user_id' AND `read`='0' AND `delete`!='$user_id';"),
                            0);

                        $arg = array('header' => '(' . $count_message . ($new_count_message ?
                                '/<span class="red">+' . $new_count_message .
                                '</span>' : '') . ')', 'sub' => $subtext);
                        echo functions::display_user($row, $arg);
                        echo '</div>';
                    }
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                        '</p></div>';
                }
                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/users/profile.php/act/friends/', $start, $total, $kmess) .
                        '</p>';
                }
                break;

            case 'offers':
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo
                    '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li><a href="' .
                    $set['homeurl'] .
                    '/users/profile.php/act/friends"><i class="fa fa-users"></i> ' .
                    $lng_profile['my_friends'] . ' <span class="badge">' . $friend_total .
                    '</span></a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/demands"><i class="fa fa-reply"></i> ' .
                    $lng_profile['my_demand'] . ($dem ?
                    ' <span class=" badge red">' . $dem . '</span>' :
                    ' <span class="badge">' . $dem . '</span>') .
                    '</a></li><li class="active"><a><i class="fa fa-share"></i> ' .
                    $lng_profile['my_offers'] . ($off ?
                    ' <span class="badge red">' . $off . '</span>' :
                    ' <span class="badge">' . $off . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/online"><i class="fa fa-eye"></i> ' .
                    $lng['online'] . ' <span class="badge">' . $friend_online .
                    '</span></a></li></ul><div class="tab-content">';

                $total = $off;

                if ($total)
                {
                    $req = mysql_query("SELECT `users`.* FROM `cms_contact`
					LEFT JOIN `users` ON `cms_contact`.`user_id`=`users`.`id`
					WHERE `cms_contact`.`from_id`='" . $user_id .
                        "' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='0' AND `ban`!='1' ORDER BY `cms_contact`.`time` DESC LIMIT " .
                        $start . "," . $kmess);

                    for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++
                        $i)
                    {
                        echo $i % 2 ? '<div class="list1">' :
                            '<div class="list2">';
                        $subtext = '<a href="' . $set['homeurl'] .
                            '/mail/index.php/act/write/id/' . $row['id'] .
                            '"><span class="glyphicon glyphicon-pencil"></span> ' .
                            $lng['write'] . '</a> | <a class="underline" href="' .
                            $set['homeurl'] .
                            '/users/profile.php/act/friends/do/ok/id/' . $row['id'] .
                            '" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><i class="fa  fa-check"></i> ' .
                            $lng_profile['confirm_friendship'] .
                            '</a> | <a class="underline" href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/no/id/' . $row['id'] .
                            '" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><i class="fa  fa-times"></i> ' .
                            $lng_profile['decline_friendship'] . '</a>';
                        $count_message = mysql_result(mysql_query("
                                SELECT COUNT(*) FROM `cms_mail` 
                                WHERE ((`user_id`='{$row['id']}' 
                                AND `from_id`='$user_id') 
                                OR (`user_id`='$user_id' 
                                AND `from_id`='{$row['id']}')) 
                                AND `delete`!='$user_id' 
                                AND `spam`='0' 
                                AND `sys`='0';
                                "), 0);
                        $new_count_message = mysql_result(mysql_query("
                                SELECT COUNT(*) FROM `cms_mail` 
                                WHERE `cms_mail`.`from_id`='{$row['id']}' 
                                AND `cms_mail`.`user_id`='$user_id' 
                                AND `read`='0' 
                                AND `delete`!='$user_id' 
                                AND `spam`='0' 
                                AND `sys`='0';
                                "), 0);

                        $arg = array('header' => '(' . $count_message . ($new_count_message ?
                                '/<span class="red">+' . $new_count_message .
                                '</span>' : '') . ')', 'sub' => $subtext);
                        echo functions::display_user($row, $arg);
                        echo '</div>';
                    }
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                        '</p></div>';
                }
                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/users/profile.php/act/friends/do/offers/', $start, $total,
                        $kmess) . '</p>';
                }
                break;

            case 'online':
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo
                    '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li><a href="' .
                    $set['homeurl'] .
                    '/users/profile.php/act/friends"><i class="fa fa-users"></i> ' .
                    $lng_profile['my_friends'] . ' <span class="badge">' . $friend_total .
                    '</span></a><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/demands"><i class="fa fa-reply"></i> ' .
                    $lng_profile['my_demand'] . ($dem ?
                    ' <span class="badge red">' . $dem . '</span>' :
                    ' <span class="badge">' . $dem . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/offers"><i class="fa fa-share"></i> ' .
                    $lng_profile['my_offers'] . ($off ?
                    ' <span class="badge red">' . $off . '</span>' :
                    ' <span class="badge">' . $off . '</span>') .
                    '</a></li><li class="active"><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/online"><i class="fa fa-eye"></i> ' .
                    $lng['online'] . ' <span class="badge">' . $friend_online .
                    '</span></a></li></ul><div class="tab-content">';
                $total = $friend_online;
                if ($total)
                {
                    $req = mysql_query("SELECT `users`.* FROM `cms_contact`
					LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
					WHERE `cms_contact`.`user_id`='" . $user_id .
                        "' AND `cms_contact`.`type`='2' AND `cms_contact`.`friends`='1' AND `cms_contact`.`ban`!='1' AND `users`.`lastdate` > " .
                        (time() - 300) .
                        " ORDER BY `cms_contact`.`time` DESC LIMIT " . $start .
                        "," . $kmess);

                    for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++
                        $i)
                    {
                        echo $i % 2 ? '<div class="list1">' :
                            '<div class="list2">';
                        $subtext = '<a href="' . $set['homeurl'] .
                            '/mail/index.php/act/write/id/' . $row['id'] .
                            '"><span class="glyphicon glyphicon-pencil"></span> ' .
                            $lng['write'] . '</a> | <a href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/delete/id/' . $row['id'] .
                            '"><span class="glyphicon glyphicon-remove"></span> ' .
                            $lng['delete'] . '</a> | <a href="' . $set['homeurl'] .
                            '/mail/index.php/act/ignor/id/' . $row['id'] .
                            '/add"><span class="glyphicon glyphicon-ban-circle"></span> ' .
                            $lng_profile['add_ignor'] . '</a>';
                        $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='{$row['id']}' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='{$row['id']}')) AND `sys`!='1' AND `spam`!='1' AND `delete`!='$user_id';"),
                            0);
                        $new_count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `cms_mail`.`user_id`='{$row['id']}' AND `cms_mail`.`from_id`='$user_id' AND `read`='0' AND `sys`!='1' AND `spam`!='1' AND `delete`!='$user_id';"),
                            0);
                        $arg = array('header' => '(' . $count_message . ($new_count_message ?
                                '/<span class="red">+' . $new_count_message .
                                '</span>' : '') . ')', 'sub' => $subtext);
                        echo functions::display_user($row, $arg);
                        echo '</div>';
                    }
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                        '</p></div>';
                }

                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/users/profile.php/act/friends/', $start, $total, $kmess) .
                        '</p>';
                }
                break;

            default:
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                $total = $friend_total;
                echo
                    '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li class="active"><a><i class="fa fa-users"></i> ' .
                    $lng_profile['my_friends'] . ' <span class="badge">' . $total .
                    '</span></a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/demands"><i class="fa fa-reply"></i> ' .
                    $lng_profile['my_demand'] . ' ' . ($dem ?
                    '<span class="badge red">' . $dem . '</span>' :
                    ' <span class="badge">' . $dem . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/offers"><i class="fa fa-share"></i> ' .
                    $lng_profile['my_offers'] . ' ' . ($off ?
                    '<span class="badge red">' . $off . '</span>' :
                    ' <span class="badge">' . $off . '</span>') .
                    '</a></li><li><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/online"><i class="fa fa-eye"></i> ' .
                    $lng['online'] . ' <span class="badge">' . $friend_online .
                    '</span></a></li></ul><div class="tab-content">';
                if ($set_mail['cat_friends'])
                {
                    echo
                        '<div class="col-sm-offset-6"><form role="form" action="' .
                        $set['homeurl'] .
                        '/users/profile.php/act/friends" method="post"><div class="input-group">' .
                        '<select class="form-control" name="sort">' .
                        '<option value="0">Все</option>' .
                        '<option value="1"' . ($sort == 1 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['friend'] .
                        '</option><option value="2"' . ($sort == 2 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['classfriend'] .
                        '</option><option value="3"' . ($sort == 3 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['colleague'] .
                        '</option><option value="4"' . ($sort == 4 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['best_friend'] .
                        '</option><option value="5"' . ($sort == 5 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['classmate'] .
                        '</option><option value="6"' . ($sort == 6 ?
                        ' selected="selected"' : '') . '>' . $lng_profile['relative'] .
                        '</option></select>' .
                        '<span class="input-group-btn"><input class="btn btn-primary" type="submit" value="' .
                        $lng_profile['sea_friends'] .
                        ' &gt;&gt;"/></span></div></form></div>';
                }
                if ($total)
                {
                    $req = mysql_query("SELECT `users`.* FROM `cms_contact`
				        LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id`
				        WHERE `cms_contact`.`user_id`='" . $user_id . "'
				        AND `cms_contact`.`type`='2'
				        AND `cms_contact`.`friends`='1'
				        AND `cms_contact`.`ban`!='1'$sql
				        ORDER BY `cms_contact`.`time` DESC
				        LIMIT " . $start . "," . $kmess);
                    for ($i = 0; ($row = mysql_fetch_assoc($req)) !== false; ++
                        $i)
                    {
                        echo $i % 2 ? '<div class="list1">' :
                            '<div class="list2">';

                        $subtext = '<a href="' . $set['homeurl'] .
                            '/mail/index.php/act/write/id/' . $row['id'] .
                            '"><span class="glyphicon glyphicon-pencil"></span> ' .
                            $lng['write'] . '</a> | <a href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/delete/id/' . $row['id'] .
                            '" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><span class="glyphicon glyphicon-remove"></span> ' .
                            $lng['delete'] . '</a> | <a href="' . $set['homeurl'] .
                            '/mail/index.php/act/ignor/id/' . $row['id'] .
                            '/add" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><span class="glyphicon glyphicon-ban-circle"></span> ' .
                            $lng_profile['add_ignor'] . '</a>';
                        $count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='{$row['id']}' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='{$row['id']}')) AND `sys`!='1' AND `spam`!='1' AND `delete`!='$user_id';"),
                            0);
                        $new_count_message = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `cms_mail`.`user_id`='{$row['id']}' AND `cms_mail`.`from_id`='$user_id' AND `read`='0' AND `sys`!='1' AND `spam`!='1' AND `delete`!='$user_id';"),
                            0);

                        $arg = array('header' => '(' . $count_message . ($new_count_message ?
                                '/<span class="red">+' . $new_count_message .
                                '</span>' : '') . ')', 'sub' => $subtext);
                        echo functions::display_user($row, $arg);
                        echo '</div>';
                    }
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                        '</p></div>';
                }
                if ($total > $kmess)
                {
                    echo '<p>' . functions::display_pagination($set['homeurl'] .
                        '/users/profile.php/act/friends' . $nav . '/', $start, $total,
                        $kmess) . '</p>';
                }

        }
    }
}
