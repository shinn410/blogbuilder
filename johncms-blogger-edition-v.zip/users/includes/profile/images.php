<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $lng_profile['profile_edit'];
require ('../incfiles/lib/class.upload.php');
if (($user_id != $user['id'] && $rights < 7) || $user['rights'] > $datauser['rights'])
{
    require ('../incfiles/head.php');
    echo display_error($lng_profile['error_rights']);
    require ('../incfiles/end.php');
    exit;
}
switch ($mod)
{
    case 'avatar':
        $textl = $lng_profile['upload_avatar'];
        $breadcrumb = functions::breadcrumb(array(
            // array('label' => $lng['users'], 'url' => '/users/'),
            array('label' => $user['name'], 'url' => '/users/profile.php/user/' .
                    $user['id']),
            array('label' => $lng['edit'], 'url' =>
                    '/users/profile.php/act/edit/user/' . $user['id']),
            array('label' => $textl),
            ));
        require ('../incfiles/head.php');
        if (isset($_POST['submit']))
        {
            $handle = new upload($_FILES['imagefile']);
            if ($handle->uploaded)
            {

                $handle->file_new_name_body = $user['id'];

                $handle->allowed = array(
                    'image/jpeg',
                    'image/gif',
                    'image/png');
                $handle->file_max_size = 1024 * $set['flsz'];
                $handle->file_overwrite = true;
                $handle->image_resize = true;
                $handle->image_x = 32;
                $handle->image_y = 32;
                $handle->image_convert = 'png';
                $handle->process('../files/users/avatar/');
                if ($handle->processed)
                {
                    echo '<div class="alert alert-success"><p>' . $lng_profile['avatar_uploaded'] .
                        '<br /><a class="alert-link" href="' . $set['homeurl'] .
                        '/users/profile.php/act/edit/user/' . $user['id'] . '">' .
                        $lng['continue'] . '</a></p></div>';
                }
                else
                {
                    echo functions::display_error($handle->error);
                }
                $handle->clean();
            }
        }
        else
        {
            echo '<form enctype="multipart/form-data" method="post" action="' .
                $set['homeurl'] .
                '/users/profile.php/act/images/mod/avatar/user/' . $user['id'] .
                '"><div class="form-group"><label>' . $lng_profile['select_image'] .
                '</label><input type="file" name="imagefile" value="" /></div>' .
                '<input type="hidden" name="MAX_FILE_SIZE" value="' . (1024 * $set['flsz']) .
                '" />' .
                '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng_profile['upload'] . '" />' . '</p></form>' .
                '<p class="help-block"><small>' . $lng_profile['select_image_help'] .
                ' ' . $set['flsz'] . ' kb.<br />' . $lng_profile['select_image_help_2'] .
                '<br />' . $lng_profile['select_image_help_3'] . $lng_profile['select_image_help_4'] .
                '</small></p>';
        }
        break;

    case 'up_photo':
        $textl = $lng_profile['upload_photo'];
        $breadcrumb = functions::breadcrumb(array(
            // array('label' => $lng['users'], 'url' => '/users/'),
            array('label' => $user['name'], 'url' => '/users/profile.php/user/' .
                    $user['id']),
            array('label' => $lng['edit'], 'url' =>
                    '/users/profile.php/act/edit/user/' . $user['id']),
            array('label' => $textl),
            ));
        require ('../incfiles/head.php');
        if (isset($_POST['submit']))
        {
            $handle = new upload($_FILES['imagefile']);
            if ($handle->uploaded)
            {

                $handle->file_new_name_body = $user['id'];

                $handle->allowed = array(
                    'image/jpeg',
                    'image/gif',
                    'image/png');
                $handle->file_max_size = 1024 * $set['flsz'];
                $handle->file_overwrite = true;
                $handle->image_resize = true;
                $handle->image_x = 320;
                $handle->image_y = 240;
                $handle->image_ratio_no_zoom_in = true;

                $handle->image_convert = 'jpg';
                $handle->process('../files/users/photo/');
                if ($handle->processed)
                {

                    $handle->file_new_name_body = $user['id'] . '_small';
                    $handle->file_overwrite = true;
                    $handle->image_resize = true;
                    $handle->image_x = 100;
                    $handle->image_ratio_y = true;
                    $handle->image_convert = 'jpg';
                    $handle->process('../files/users/photo/');
                    if ($handle->processed)
                    {
                        echo '<div class="alert alert-success"><p>' . $lng_profile['photo_uploaded'] .
                            '<br /><a class="alert-link" href="' . $set['homeurl'] .
                            '/users/profile.php/act/edit/user/' . $user['id'] .
                            '">' . $lng['continue'] . '</a></p></div>';
                    }
                    else
                    {
                        echo functions::display_error($handle->error);
                    }
                }
                else
                {
                    echo functions::display_error($handle->error);
                }
                $handle->clean();
            }
        }
        else
        {
            echo '<form enctype="multipart/form-data" method="post" action="' .
                $set['homeurl'] .
                '/users/profile.php/act/images/mod/up_photo/user/' . $user['id'] .
                '"><div class="form-group"><label>' . $lng_profile['select_image'] .
                '</label><input type="file" name="imagefile" value="" /></div>' .
                '<input type="hidden" name="MAX_FILE_SIZE" value="' . (1024 * $set['flsz']) .
                '" /><p><input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng_profile['upload'] . '" /></p></form>' .
                '<p class="help-block"><small>' . $lng_profile['select_image_help'] .
                ' ' . $set['flsz'] . 'kb.<br />' . $lng_profile['select_image_help_5'] .
                '<br />' . $lng_profile['select_image_help_3'] . '</small></p>';
        }
        break;
}

?>