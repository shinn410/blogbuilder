<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = 'userban';
$lng_ban = array_merge(core::load_lng('ban'), array('ban_101' => 'Blog'));
$textl = $user['name'] . ': ' . $lng['infringements'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $user['name'], 'url' => '/users/profile.php/user/' . $user['id']),
    array('label' => $lng['infringements']),
    ));
$_SESSION['dismiss_modal'] = 1;
require ('../incfiles/head.php');
$ban = isset($_GET['ban']) ? intval($_GET['ban']) : 0;
switch ($mod)
{
    case 'do':
        if ($rights < 1 || ($rights < 6 && $user['rights']) || ($rights <= $user['rights']))
        {
            echo functions::display_error($lng_ban['ban_rights']);
        }
        else
        {
            echo '<h4 class="page-header">' . $lng_ban['ban_do'] . '</h4>';
            echo '<div class="callout callout-info">' . functions::display_user($user) .
                '</div>';
            if (isset($_POST['submit']))
            {
                $error = false;
                $term = isset($_POST['term']) ? intval($_POST['term']) : false;
                $timeval = isset($_POST['timeval']) ? intval($_POST['timeval']) : false;
                $time = isset($_POST['time']) ? intval($_POST['time']) : false;
                $reason = !empty($_POST['reason']) ? trim($_POST['reason']) : '';
                $banref = isset($_POST['banref']) ? intval($_POST['banref']) : false;
                if (empty($reason) && empty($banref))
                    $reason = $lng_ban['reason_not_specified'];
                if (empty($term) || empty($timeval) || empty($time) || $timeval <
                    1)
                    $error = $lng_ban['error_data'];
                if ($rights == 1 && $term != 14 || $rights == 2 && $term != 12 ||
                    $rights == 3 && $term != 11 || $rights == 4 && $term != 16 ||
                    $rights == 5 && $term != 15)
                    $error = $lng_ban['error_rights_section'];
                if (mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" .
                    $user['id'] . "' AND `ban_time` > '" . time() .
                    "' AND `ban_type` = '$term'"), 0))
                    $error = $lng_ban['error_ban_exist'];
                switch ($time)
                {
                    case 2:
                        if ($timeval > 24)
                            $timeval = 24;
                        $timeval = $timeval * 3600;
                        break;
                    case 3:
                        if ($timeval > 30)
                            $timeval = 30;
                        $timeval = $timeval * 86400;
                        break;
                    case 4:
                        $timeval = 315360000;
                        break;
                    default:
                        if ($timeval > 60)
                            $timeval = 60;
                        $timeval = $timeval * 60;
                }
                if ($datauser['rights'] < 6 && $timeval > 86400)
                    $timeval = 86400;
                if ($datauser['rights'] < 7 && $timeval > 2592000)
                    $timeval = 2592000;
                if (!$error)
                {

                    mysql_query("INSERT INTO `cms_ban_users` SET
                        `user_id` = '" . $user['id'] . "',
                        `ban_time` = '" . (time() + $timeval) . "',
                        `ban_while` = '" . time() . "',
                        `ban_type` = '$term',
                        `ban_who` = '$login',
                        `ban_reason` = '" . mysql_real_escape_string($reason) .
                        "'
                    ");
                    if ($set_karma['on'])
                    {
                        $points = $set_karma['karma_points'] * 2;
                        mysql_query("INSERT INTO `karma_users` SET
                            `user_id` = '0',
                            `name` = '" . $lng_ban['system'] . "',
                            `karma_user` = '" . $user['id'] . "',
                            `points` = '$points',
                            `type` = '0',
                            `time` = '" . time() . "',
                            `text` = '" . $lng['ban'] . " (" . $lng_ban['ban_' .
                            $term] . ")'
                        ");
                        mysql_query("UPDATE `users` SET
                            `karma_minus` = '" . ($user['karma_minus'] + $points) .
                            "'
                            WHERE `id` = '" . $user['id'] . "'
                        ");
                        $text = ' ' . $lng_ban['also_received'] .
                            ' <span class="red">-' . $points . ' ' . $lng['points'] .
                            '</span> ' . $lng_ban['to_karma'];
                    }
                    echo '<div class="alert alert-success">' . $lng_ban['user_banned'] .
                        ' ' . $text . '</div>';
                }
                else
                {
                    echo functions::display_error($error);
                }
            }
            else
            {

                echo '<form role="form" action="' . $set['homeurl'] .
                    '/users/profile.php/act/ban/mod/do/user/' . $user['id'] .
                    '" method="post">' . '<div class="form-group"><label>' . $lng_ban['ban_type'] .
                    '</label>';
                if ($rights >= 6)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="1" checked="checked" />&#160;' .
                        $lng_ban['ban_1'] . '</label></div>';
                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="3" />&#160;' .
                        $lng_ban['ban_3'] . '</label></div>';
                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="10" />&#160;' .
                        $lng_ban['ban_10'] . '</label></div>';
                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="13" />&#160;' .
                        $lng_ban['ban_13'] . '</label></div>';
                }
                if ($rights == 3 || $rights >= 6)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="11" ' . ($rights ==
                        3 ? 'checked="checked"' : '') . '/>&#160;' . $lng_ban['ban_11'] .
                        '</label></div>';
                }
                if ($rights == 1 || $rights >= 6)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="14" />&#160;' .
                        $lng_ban['ban_14'] . '</label></div>';
                }
                if ($rights == 5 || $rights >= 6)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="15" />&#160;' .
                        $lng_ban['ban_15'] . '</label></div>';
                }
                if ($rights == 2 || $rights >= 6)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="12" />&#160;' .
                        $lng_ban['ban_12'] . '</label></div>';
                }
                if ($rights == 7 || $rights >= 9)
                {

                    echo
                        '<div class="radio"><label><input name="term" type="radio" value="101" />&#160;' .
                        $lng_ban['ban_101'] . '</label></div>';
                }
                echo '</div><div class="form-group"><label>' . $lng_ban['ban_time'] .
                    '</label>' .
                    '<div class="input-group"><input class="form-control" type="text" name="timeval" size="2" ' .
                    'maxlength="2" value="12"/><span class="input-group-addon">' .
                    $lng['time'] . '</span></div>' .
                    '<div class="radio"><label><input name="time" type="radio" value="1" />&#160;' .
                    $lng_ban['ban_time_minutes'] . '</label></div>' .
                    '<div class="radio"><label><input name="time" type="radio" value="2" checked="checked" />&#160;' .
                    $lng_ban['ban_time_hours'] . '</label></div>';
                if ($rights >= 6)
                    echo
                        '<div class="radio"><label><input name="time" type="radio" value="3" />&#160;' .
                        $lng_ban['ban_time_days'] . '</label></div>';
                if ($rights >= 7)
                    echo
                        '<div class="radio"><label><input name="time" type="radio" value="4" />&#160;<span class="red">' .
                        $lng_ban['ban_time_before_cancel'] .
                        '</span></label></div>';
                echo '</div><div class="form-group"><label>' . $lng['reason'] .
                    '</label>';
                if (isset($_GET['fid']))
                {

                    $fid = intval($_GET['fid']);
                    echo '<p>' . $lng_ban['infringement'] . ' <a href="' . $set['homeurl'] .
                        '/forum/index.php/act/post/id/' . $fid . '">' . $lng_ban['in_forum'] .
                        '</a><br />' . '<input type="hidden" value="' . $fid .
                        '" name="banref" /></p>';
                }
                echo '<textarea class="form-control" rows="' . $set_user['field_h'] .
                    '" name="reason"></textarea>' .
                    '</div><p><input class="btn btn-primary" type="submit" value="' .
                    $lng['ban_do'] . '" name="submit" />' . '</p></form>';
            }
        }
        break;
    case 'cancel':
        if (!$ban || $user['id'] == $user_id || $rights < 7)
            echo functions::display_error($lng['error_wrong_data']);
        else
        {
            $req = mysql_query("SELECT * FROM `cms_ban_users` WHERE `id` = '$ban' AND `user_id` = '" .
                $user['id'] . "'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                $error = false;
                if ($res['ban_time'] < time())
                    $error = $lng_ban['error_ban_not_active'];
                if (!$error)
                {
                    echo '<h4 class="page-header">' . $lng_ban['ban_cancel'] .
                        '</h4>';
                    echo '<div class="callout callout-info">' . functions::display_user($user) .
                        '</div>';
                    if (isset($_POST['submit']))
                    {
                        mysql_query("UPDATE `cms_ban_users` SET `ban_time` = '" .
                            time() . "' WHERE `id` = '$ban'");
                        echo '<div class="gmenu"><p><h3>' . $lng_ban['ban_cancel_confirmation'] .
                            '</h3></p></div>';
                    }
                    else
                    {
                        echo '<form role="form" action="' . $set['homeurl'] .
                            '/users/profile.php/act/ban/mod/cancel/user/' . $user['id'] .
                            '/ban/' . $ban . '" method="POST">' .
                            '<div class="menu"><p>' . $lng_ban['ban_cancel_help'] .
                            '</p>' .
                            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                            $lng_ban['ban_cancel_do'] . '" /></p>' .
                            '</div></form>' .
                            '<div class="page-header"><a href="' . $set['homeurl'] .
                            '/users/profile.php/act/ban/user/' . $user['id'] .
                            '">' . $lng['back'] . '</a></div>';
                    }
                }
                else
                {
                    echo functions::display_error($error);
                }
            }
            else
            {
                echo functions::display_error($lng['error_wrong_data']);
            }
        }
        break;
    case 'delete':
        if (!$ban || $rights < 9)
            echo functions::display_error($lng['error_wrong_data']);
        else
        {
            $req = mysql_query("SELECT * FROM `cms_ban_users` WHERE `id` = '$ban' AND `user_id` = '" .
                $user['id'] . "'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                if (!$is_modal)
                {
                    echo '<h4 class="page-header">' . $lng_ban['ban_delete'] .
                        '</h4>' . '<div class="callout callout-info">' .
                        functions::display_user($user) . '</div>';
                }
                if (isset($_POST['submit']))
                {
                    mysql_query("DELETE FROM `karma_users` WHERE `karma_user` = '" .
                        $user['id'] . "' AND `user_id` = '0' AND `time` = '" . $res['ban_while'] .
                        "' LIMIT 1");
                    $points = $set_karma['karma_points'] * 2;
                    mysql_query("UPDATE `users` SET
                        `karma_minus` = '" . ($user['karma_minus'] > $points ? $user['karma_minus'] -
                        $points : 0) . "'
                        WHERE `id` = '" . $user['id'] . "'
                    ");
                    mysql_query("DELETE FROM `cms_ban_users` WHERE `id` = '$ban'");
                    echo '<div class="alert alert-success">' . $lng_ban['ban_deleted'] .
                        '<br /><a class="alert-link" href="' . $set['homeurl'] .
                        '/users/profile.php/act/ban/user/' . $user['id'] . '">' .
                        $lng['continue'] . '</a></div>';
                }
                else
                {
                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/users/profile.php/act/ban/mod/delete/user/' . $user['id'] .
                        '/ban/' . $ban . '" method="POST">' .
                        '<div class="alert alert-warning">' . $lng_ban['ban_delete_help'] .
                        '</div>' .
                        '<p><button class="btn btn-primary" type="submit" name="submit">' .
                        $lng['delete'] .
                        '</button>&nbsp;<a class="btn btn-default" href="' . $home .
                        '/users/profile.php/act/ban/user/' . $user['id'] .
                        '" data-dismiss="modal">' . $lng['cancel'] .
                        '</a></p></form>';
                }
            }
            else
            {
                echo functions::display_error($lng['error_wrong_data']);
            }
        }
        break;
    case 'delhist':
        if ($rights == 9)
        {
            if (!$is_modal)
                echo '<h4 class="page-header">' . $lng_ban['infringements_history'] .
                    '</h4>' . '<div class="callout callout-info">' . functions::display_user($user) .
                    '</div>';
            if (isset($_POST['submit']))
            {
                mysql_query("DELETE FROM `cms_ban_users` WHERE `user_id` = '" .
                    $user['id'] . "'");
                echo '<div class="alert alert-success">' . $lng_ban['history_cleared'] .
                    '</div>';
            }
            else
            {
                echo '<form role="form" action="' . $set['homeurl'] .
                    '/users/profile.php/act/ban/mod/delhist/user/' . $user['id'] .
                    '" method="post">' . '<div class="alert alert-warning">' . $lng_ban['clear_confirmation'] .
                    '</div>' .
                    '<p><input class="btn btn-primary" type="submit" value="' .
                    $lng['clear'] . '" name="submit" />' .
                    '&nbsp;<a class="btn btn-default" href="' . $home .
                    '/users/profile.php/act/ban/user/' . $user['id'] .
                    '" data-dismiss="modal">' . $lng['cancel'] .
                    '</a></p></form>';
            }
        }
        else
        {
            echo functions::display_error($lng_ban['error_rights_clear']);
        }
        break;
    default:
        $menu = array();
        if ($rights >= 6)
            $menu[] = '<a class="func" href="' . $home . '/' . $set['admp'] .
                '/index.php/act/ban_panel">' . $lng_ban['ban_panel'] . '</a>';
        if ($rights == 9)
            $menu[] = '<a class="func" href="' . $set['homeurl'] .
                '/users/profile.php/act/ban/mod/delhist/user/' . $user['id'] .
                '" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal">' . $lng_ban['clear_history'] .
                '</a>';
        if (!empty($menu))
            echo '<p>' . functions::display_menu($menu) . '</p>';
        if ($user['id'] != $user_id)
            echo '<h4 class="page-header">' . $lng_ban['infringements_history'] .
                '</h4>';
        else
            echo '<h4 class="page-header">' . $lng_ban['my_infringements'] .
                '</h4>';
        if ($user['id'] != $user_id)
            echo '<div class="callout callout-info">' . functions::display_user($user) .
                '</div>';
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" .
            $user['id'] . "'"), 0);
        if ($total)
        {
            $req = mysql_query("SELECT * FROM `cms_ban_users` WHERE `user_id` = '" .
                $user['id'] . "' ORDER BY `ban_time` DESC LIMIT $start, $kmess");
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                $remain = $res['ban_time'] - time();
                $period = $res['ban_time'] - $res['ban_while'];
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '<img src="' . $set['homeurl'] . '/images/' . ($remain > 0 ?
                    'red' : 'green') .
                    '.gif" width="16" height="16" align="left" />&#160;' . '<b>' .
                    $lng_ban['ban_' . $res['ban_type']] . '</b>' .
                    ' <span class="gray">(' . date("d.m.Y / H:i", $res['ban_while']) .
                    ')</span>' . '<br />' . functions::checkout($res['ban_reason']) .
                    '<div class="sub">';
                if ($rights > 0)
                    echo '<span class="gray">' . $lng_ban['ban_who'] .
                        ':</span> ' . $res['ban_who'] . '<br />';
                echo '<span class="gray">' . $lng['term'] . ':</span> ' . ($period <
                    86400000 ? functions::timecount($period) : $lng_ban['ban_time_before_cancel']);
                if ($remain > 0)
                    echo '<br /><span class="gray">' . $lng['remains'] .
                        ':</span> ' . functions::timecount($remain);
                $menu = array();
                if ($rights >= 7 && $remain > 0)
                    $menu[] = '<a href="' . $set['homeurl'] .
                        '/users/profile.php/act/ban/mod/cancel/user/' . $user['id'] .
                        '/ban/' . $res['id'] . '">' . $lng_ban['ban_cancel_do'] .
                        '</a>';
                if ($rights == 9)
                    $menu[] = '<a href="' . $set['homeurl'] .
                        '/users/profile.php/act/ban/mod/delete/user/' . $user['id'] .
                        '/ban/' . $res['id'] . '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><i class="fa fa-times"></i> ' .
                        $lng_ban['ban_delete_do'] . '</a>';
                if (!empty($menu))
                    echo '<div>' . functions::display_menu($menu) . '</div>';
                echo '</div></div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess)
        {
            echo '<p>' . functions::display_pagination($set['homeurl'] .
                '/users/profile.php/act/ban/user/' . $user['id'] . '?', $start,
                $total, $kmess) . '</p>';
        }
}

?>