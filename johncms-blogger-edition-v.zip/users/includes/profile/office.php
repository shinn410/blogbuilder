<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = 'office';
$breadcrumb = functions::breadcrumb(array(array('label' => $lng_profile['my_office']), ));
$textl = $lng_profile['my_office'];
require ('../incfiles/head.php');

if ($user['id'] != $user_id) {
    echo functions::display_error($lng['access_forbidden']);
    require ('../incfiles/end.php');
    exit;
}

echo '<div class="box box-solid visible-xs"><div class="box-body">Your login as <strong>' .
    $login . '</strong></div></div>';
$out = '<div class="row">';
$total_photo = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_album_files` 
            WHERE `user_id` = '$user_id'
            "), 0);
$total_friends = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_contact`
            WHERE `user_id`='$user_id' 
            AND `type`='2' 
            AND `friends`='1'
            "), 0);
$new_friends = mysql_result(mysql_query("
            SELECT COUNT(*) 
            FROM `cms_contact` 
            WHERE `from_id`='$user_id' 
            AND `type`='2' 
            AND `friends`='0';
            "), 0);
$online_friends = mysql_result(mysql_query("
            SELECT COUNT(*) 
            FROM `cms_contact` 
            LEFT JOIN `users` ON `cms_contact`.`from_id`=`users`.`id` 
            WHERE `cms_contact`.`user_id`='$user_id' 
            AND `cms_contact`.`type`='2' 
            AND `cms_contact`.`friends`='1' 
            AND `lastdate` > " . (time() - 300) . "
            "), 0);
$total_blog = mysql_result(mysql_query("
            SELECT COUNT(*) 
            FROM `blog_sites` 
            WHERE `user_id`='$user_id'
            "), 0);
$out .= '<div class="col-sm-6"><div class="list-group">' .
    '<div class="list-group-item list-group-item-success">' . $lng_profile['my_actives'] .
    '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php"><i class="fa fa-user"></i> ' . $lng_profile['my_profile'] .
    '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/blogpanel"><i class="fa fa-rss-square"></i> Blog <span class="badge">' . $total_blog .
    '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/stat"><i class="fa fa-bar-chart-o"></i> ' . $lng['statistics'] .
    '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/album.php/act/list"><i class="fa fa-picture-o"></i> ' . $lng['photo_album'] .
    ' <span class="badge">' . $total_photo . '</span></a>' .
    '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/guestbook"><i class="fa fa-book"></i> ' . $lng['guestbook'] .
    ' <span class="badge">' . $user['comm_count'] . '</span></a>';
if ($rights >= 1) {
    $guest = counters::guestbook(2);
    $out .= '<a class="list-group-item list-group-item-danger" href="' . $set['homeurl'] .
        '/guestbook/index.php/act/ga/do/set"><i class="fa fa-shield"></i> ' . $lng['admin_club'] .
        ' <span class="badge">' . $guest . '</span></a>';
}
$out .= '</div></div>';

$count_input = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail` 
            LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` 
            AND `cms_contact`.`user_id`='$user_id' 
            WHERE `cms_mail`.`from_id`='$user_id' 
            AND `cms_mail`.`sys`='0' 
            AND `cms_mail`.`delete`!='$user_id' 
            AND `cms_contact`.`ban`!='1' 
            AND `spam`='0'
            "), 0);
$count_output = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail`
            LEFT JOIN `cms_contact` ON `cms_mail`.`from_id`=`cms_contact`.`from_id` 
            AND `cms_contact`.`user_id`='$user_id'
            WHERE `cms_mail`.`user_id`='$user_id' 
            AND `cms_mail`.`delete`!='$user_id' 
            AND `cms_mail`.`sys`='0' 
            AND `cms_contact`.`ban`!='1'
            "), 0);
$count_output_new = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail`
            LEFT JOIN `cms_contact` ON `cms_mail`.`from_id`=`cms_contact`.`from_id` 
            AND `cms_contact`.`user_id`='$user_id'
            WHERE `cms_mail`.`user_id`='$user_id' 
            AND `cms_mail`.`delete`!='$user_id' 
            AND `cms_mail`.`read`='0' 
            AND `cms_mail`.`sys`='0' 
            AND `cms_contact`.`ban`!='1'
            "), 0);
$count_systems = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail`
            WHERE `from_id`='$user_id' 
            AND `delete`!='$user_id' 
            AND `sys`='1'
            "), 0);
$count_systems_new = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail`
            WHERE `from_id`='$user_id' 
            AND `delete`!='$user_id' 
            AND `sys`='1' 
            AND `read`='0'
            "), 0);
$count_file = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_mail`
            WHERE (`user_id`='$user_id' OR `from_id`='$user_id') 
            AND `delete`!='$user_id' 
            AND `file_name`!='';
            "), 0);
$out .= '<div class="col-sm-6"><div class="list-group">' .
    '<div class="list-group-item list-group-item-info">' . $lng_profile['my_mail'] .
    '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/index.php/act/input"><i class="fa fa-mail-forward"></i> ' . $lng_profile['received'] .
    ' <span class="badge">' . $count_input . ($new_mail ? ' / +' . $new_mail :
    '') . '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/index.php/act/output"><i class="fa fa-mail-reply"></i> ' . $lng_profile['sent'] .
    ' <span class="badge">' . $count_output . ($count_output_new ?
    ' / <span class="red">+' . $count_output_new . '</span>' : '') .
    '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/index.php/act/systems"><i class="fa fa-info-circle"></i> ' . $lng_profile['systems'] .
    ' <span class="badge">' . $count_systems . ($count_systems_new ? ' / +' . $count_systems_new :
    '') . '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/index.php/act/files"><i class="fa fa-file"></i> ' . $lng['files'] .
    ' <span class="badge">' . $count_file . '</span></a>';
if (empty($ban['1']) && empty($ban['3'])) {
    $out .= '<a class="list-group-item list-group-item-danger" href="' . $set['homeurl'] .
        '/mail/index.php/act/write" method="post"><i class="fa fa-pencil"></i> ' .
        $lng['write'] . '</a>';
}
$out .= '</div></div>';
$out .= '</div><div class="row">';
$count_contacts = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_contact`
            WHERE `user_id`='" . $user_id . "' 
            AND `ban`!='1';
            "), 0);
$count_ignor = mysql_result(mysql_query("
            SELECT COUNT(*)
            FROM `cms_contact`
            WHERE `user_id`='" . $user_id . "' 
            AND `ban`='1';
            "), 0);
$out .= '<div class="col-sm-6"><div class="list-group">' .
    '<div class="list-group-item list-group-item-warning">' . $lng['contacts'] .
    '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/"><i class="fa fa-users"></i> ' . $lng['contacts'] .
    ' <span class="badge">' . $count_contacts . '</span></a>' .
    '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/friends"><i class="fa fa-users"></i> ' . $lng_profile['friends'] .
    ' <span class="badge">' . $total_friends . ($new_friends ? ' / +' . $new_friends :
    '') . '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/friends/do/online"><i class="fa fa-eye"></i> ' . $lng_profile['friends'] .
    ' ' . $lng['online'] . ' <span class="badge">' . $online_friends .
    '</span></a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/mail/index.php/act/ignor"><i class="fa fa-ban"></i> ' . $lng_profile['banned'] .
    ' <span class="badge">' . $count_ignor . '</span></a>' . '</div></div>';

$out .= '<div class="col-sm-6"><div class="list-group">' .
    '<div  class="list-group-item list-group-item-danger">' . $lng['settings'] .
    '</div>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/settings"><i class="fa fa-cog"></i> ' . $lng['system_settings'] .
    '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/edit"><i class="fa fa-user"></i> ' . $lng_profile['profile_edit'] .
    '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
    '/users/profile.php/act/password"><i class="fa fa-lock"></i> ' . $lng['change_password'] .
    '</a>';
if ($rights >= 1) {
    $out .= '<a class="list-group-item list-group-item-danger" href="' . $set['homeurl'] .
        '/' . $set['admp'] . '/index.php"><i class="fa fa-shield"></i> ' . $lng['admin_panel'] .
        '</a>';
}
$out .= '</div></div>';

$out .= '</div>';
echo $out;

?>