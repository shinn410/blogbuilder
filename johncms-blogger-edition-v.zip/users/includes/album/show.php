<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');


if (!$al)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}
$req = mysql_query("SELECT * FROM `cms_album_cat` WHERE `id` = '$al'");
if (!mysql_num_rows($req))
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}
$album = mysql_fetch_assoc($req);
$view = isset($_GET['view']);
$textl = functions::checkout($album['name']);
if ($id)
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
        array('label' => $user['name'], 'url' =>
                '/users/album.php/act/list/user/' . $user['id']),
        array('label' => $textl, 'url' => '/users/album.php/act/show/al/' . $al .
                '/user/' . $user['id']),
        ));
    $main_header = 1;
}
else
{
    $breadcrumb = functions::breadcrumb(array(
        array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
        array('label' => $user['name'], 'url' =>
                '/users/album.php/act/list/user/' . $user['id']),
        array('label' => $textl),
        ));
}

require ('../incfiles/head.php');
if (($user['id'] == $user_id) && (empty($ban) || $rights >= 7) && !$id)
{
    echo '<p><a class="func" href="' . $set['homeurl'] .
        '/users/album.php/act/image_upload/al/' . $al . '/user/' . $user['id'] .
        '"><i class="fa fa-upload"></i> ' . $lng_profile['image_add'] .
        '</a></p>';
}

if ($album['access'] != 2)
{
    unset($_SESSION['ap']);
}
if ($album['access'] == 1 && $user['id'] != $user_id && $rights < 7)
{

    echo functions::display_error($lng['access_forbidden'],
        '<a class="alert-link" href="' . $set['homeurl'] .
        '/users/album.php/act/list/user/' . $user['id'] . '">' . $lng_profile['album_list'] .
        '</a>');
    require ('../incfiles/end.php');
    exit;
}
elseif ($album['access'] == 2 && $user['id'] != $user_id && $rights < 7)
{

    if (isset($_POST['password']))
    {
        if ($album['password'] == trim($_POST['password']))
        {
            $_SESSION['ap'] = $album['password'];
        }
        else
        {
            $error = functions::display_error($lng['error_wrong_password']);
        }
    }
    if (!isset($_SESSION['ap']) || $_SESSION['ap'] != $album['password'])
    {
        echo '<form action="' . $set['homeurl'] .
            '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] .
            '" method="post">' . (isset($error) ? $error : '') .
            '<div class="form-group">' . '<label>' . $lng['password'] .
            '</label><input class="form-control" type="text" name="password"/>' .
            '<p class="help-block">' . $lng_profile['album_password'] .
            '</p></div>' .
            '<p><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['login'] . '</button></p>' . '</form>';
        require ('../incfiles/end.php');
        exit;
    }
}
elseif ($album['access'] == 3 && $user['id'] != $user_id && $rights < 6 && !
    functions::is_friend($user['id']))
{

    echo functions::display_error($lng_profile['friends_only'],
        '<a class="alert-link" href="' . $set['homeurl'] .
        '/users/album.php/act/list/user/' . $user['id'] . '">' . $lng_profile['album_list'] .
        '</a>');
    require ('../incfiles/end.php');
    exit;
}
if (!$id)
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" .
        $user['id'] . "' AND `album_id` = '$al'"), 0);
    if ($total)
    {
        $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `user_id` = '" .
            $user['id'] . "' AND `album_id` = '$al' ORDER BY `id` DESC LIMIT $start, $kmess");
        echo '<div class="row">';
        while (($res = mysql_fetch_assoc($req)) !== false)
        {
            echo '<div class="col-xs-6 col-sm-3 col-lg-2">';
            echo '<a class="thumbnail" href="' . $home .
                '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] .
                '/id/' . $res['id'] . '">' . '<img class="img-reponsive" src="' .
                $set['homeurl'] . '/files/users/album/' . $user['id'] . '/' . $res['tmb_name'] .
                '" /></a></div>';
        }
        echo '</div>';
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] . '/' .
            ($view ? 'view/?' : '?'), $start, $total, $kmess) . '</div>';
    }
}
else
{
    $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `id` = '$id' AND `user_id` = '" .
        $user['id'] . "' AND `album_id` = '$al'");
    if (mysql_num_rows($req))
    {
        $res = mysql_fetch_array($req);
        array_push($breadcrumbs, array('label' => 'Foto:#' . $res['id']));
        echo functions::main_header('Foto:#' . $res['id'], functions::breadcrumb
            ($breadcrumbs));
        echo '<div class="row"><div class="col-sm-8">';
        echo '<p><img class="thumbnail img-responsive" style="margin:0 auto !important;" src="' .
            $set['homeurl'] . '/files/users/album/' . $user['id'] . '/' . $res['img_name'] .
            '" />';
        echo '</div><div class="col-sm-4">';
        echo '<div class="box box-solid"><div class="box-body">';
        echo (!empty($res['description']) ? '<p>' . functions::smileys(functions::checkout
            ($res['description'], 1)) . '</p><hr />' : '');
        echo '<ul class="list-unstyled">' . vote_photo($res) .
            '<li><i class="fa fa-eye"></i> ' . $lng['count_views'] . ': ' . $res['views'] .
            '</li><li><i class="fa fa-download"></i> ' . $lng['count_downloads'] .
            ': ' . $res['downloads'] . '</li>' .
            '<li><i class="fa fa-clock-o"></i> ' . $lng['date'] . ': ' .
            functions::display_date($res['time']) . '</li>' .
            '<li><i class="fa fa-comments"></i> ' . $lng['comments'] . ' (' . $res['comm_count'] .
            ')</li></ul><p>' . '<a class="btn btn-primary btn-block" href="' . $set['homeurl'] .
            '/users/album.php/act/image_download/img/' . $res['id'] .
            '"><i class="fa fa-download"></i> ' . $lng['download'] . '</a>' .
            '</p></div></div>';
        if ($user['id'] == $user_id || core::$user_rights >= 6)
        {
            echo '<ul class="nav nav-pills">';
            echo functions::display_menu(array(
                '<li><a href="' . $set['homeurl'] .
                    '/users/album.php/act/image_edit/img/' . $res['id'] .
                    '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
                    '</a></li>',
                '<li><a href="' . $set['homeurl'] .
                    '/users/album.php/act/image_move/img/' . $res['id'] .
                    '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-move"></span> ' . $lng['move'] .
                    '</a></li>',
                '<li><a class="delete" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal" href="' . $home .
                    '/users/album.php/act/image_delete/img/' . $res['id'] .
                    '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-remove"></span> ' . $lng['delete'] .
                    '</a>'));
            if ($user['id'] == $user_id)
                echo '<li><a href="' . $set['homeurl'] .
                    '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] .
                    '/id/' . $res['id'] .
                    '/mod/profile#set"><span class="glyphicon glyphicon-user"></span> ' .
                    $lng_profile['photo_profile'] . '</a></li>';
            echo '</ul>';
            if ($user['id'] == $user_id && $mod == 'profile')
            {
                if (file_exists('../files/users/photo/' . $user_id .
                    '_small.jpg'))
                    unlink('../files/users/photo/' . $user_id . '_small.jpg');

                include_once ('../incfiles/lib/class.upload.php');
                $handle = new upload('../files/users/album/' . $user['id'] . '/' .
                    $res['tmb_name']);
                $handle->file_new_name_body = $user_id . '_small';
                $handle->image_resize = true;
                $handle->image_ratio_crop = true;
                $handle->image_y = 64;
                $handle->image_x = 64;
                $handle->image_convert = 'jpg';
                $handle->process('../files/users/photo/');
                if ($handle->processed)
                {
                    copy('../files/users/album/' . $user['id'] . '/' . $res['img_name'],
                        '../files/users/photo/' . $user_id . '.jpg');
                    if ($is_mobile)
                        echo '<div class="alert alert-success" id="#set">' . $lng_profile['photo_profile_ok'] .
                            '</div>';
                    else
                    {
                        echo functions::modal('<div class="alert alert-success">' .
                            $lng_profile['photo_profile_ok'] . '</div>', array('id' =>
                                'set', 'title' => $lng_profile['photo_profile']), true);
                        $jquery .= '$("#set").modal("show");';
                    }
                }
            }
        }
        echo '</div></div>';
        $arg = array(
            'comments_table' => 'cms_album_comments',
            'object_table' => 'cms_album_files',
            'script' => $set['homeurl'] . '/users/album.php/act/show/al/' . $al .
                '/user/' . $user['id'],
            'sub_id_name' => 'id',
            'sub_id' => $id,
            'owner' => $user['id'],
            'owner_delete' => true,
            'owner_reply' => true,
            'owner_edit' => false,
            'title' => $lng['comments'],
            'context_top' => '',
            'context_bottom' => '',
            );

        if (core::$user_id == $user['id'] && $res['unread_comments'])
            mysql_query("UPDATE `cms_album_files` SET `unread_comments` = '0' WHERE `id` = '$id' LIMIT 1");

        $comm = new comments($arg);

        if ($comm->added && core::$user_id != $user['id'])
            mysql_query("UPDATE `cms_album_files` SET `unread_comments` = '1' WHERE `id` = '$id' LIMIT 1");
    }
    else
    {
        array_push($breadcrumbs, array('label' => 'Not Found'));
        echo functions::main_header($textl, functions::breadcrumb($breadcrumbs));
        echo '<div class="alert alert-danger">Foto tidak ditemukan!</div>';
    }
}
