<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($img && $user['id'] == $user_id || $rights >= 6)
{
    $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `id` = '$img' AND `user_id` = '" .
        $user['id'] . "'");
    if (mysql_num_rows($req))
    {
        $image = mysql_fetch_assoc($req);
        $breadcrumb = functions::breadcrumb(array(
            array('label' => $lng['users'], 'url' => '/users/'),
            array('label' => $lng['photo_albums'], 'url' =>
                    'users/album.php/act/show/al/' . $image['album_id'] .
                    '/user/' . $user['id']),
            array('label' => $lng_profile['image_move']),
            ));
        require ('../incfiles/head.php');
        if (isset($_POST['submit']))
        {
            $req_a = mysql_query("SELECT * FROM `cms_album_cat` WHERE `id` = '$al' AND `user_id` = '" .
                $user['id'] . "'");
            if (mysql_num_rows($req_a))
            {
                $res_a = mysql_fetch_assoc($req_a);
                mysql_query("UPDATE `cms_album_files` SET
                    `album_id` = '$al',
                    `access` = '" . $res_a['access'] . "'
                    WHERE `id` = '$img'
                ");
                echo '<div class="alert alert-success"><p>' . $lng_profile['image_moved'] .
                    '<br />' . '<a class="alert-link" href="' . $set['homeurl'] .
                    '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] .
                    '">' . $lng['continue'] . '</a></p></div>';
            }
            else
            {
                echo functions::display_error($lng['error_wrong_data']);
            }
        }
        else
        {
            $req = mysql_query("SELECT * FROM `cms_album_cat` WHERE `user_id` = '" .
                $user['id'] . "' AND `id` != '" . $image['album_id'] .
                "' ORDER BY `sort` ASC");
            if (mysql_num_rows($req))
            {
                echo '<form role="form" action="' . $set['homeurl'] .
                    '/users/album.php/act/image_move/img/' . $img . '/user/' . $user['id'] .
                    '" method="post">' . '<div class="form-group">' .
                    '<label class="control-label">' . $lng_profile['album_select'] .
                    '</label>' . '<select class="form-control" name="al">';
                while ($res = mysql_fetch_assoc($req))
                {
                    echo '<option value="' . $res['id'] . '">' . functions::checkout($res['name']) .
                        '</option>';
                }
                echo '</select>' . '</div>' .
                    '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                    $lng['move'] . '"/> <a class="btn btn-default" href="' . $set['homeurl'] .
                    '/users/album.php/act/show/al/' . $image['album_id'] .
                    '/user/' . $user['id'] . '">' . $lng['cancel'] . '</a></p>' .
                    '</form>';
            }
            else
            {
                echo functions::display_error($lng_profile['image_move_error'],
                    '<a class="alert-link" href="' . $set['homeurl'] .
                    '/users/album.php/act/list/user/' . $user['id'] . '">' . $lng['continue'] .
                    '</a>');
            }
        }
    }
    else
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
    }
}

?>