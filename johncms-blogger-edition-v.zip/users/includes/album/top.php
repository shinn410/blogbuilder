<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

switch ($mod)
{
    case 'my_new_comm':
        if (!core::$user_id || core::$user_id != $user['id'])
        {
            require ('../incfiles/head.php');
            echo functions::display_error($lng['wrong_data']);
            require ('../incfiles/end.php');
            exit;
        }
        $title = $lng_profile['unread_comments'];
        $select = "";
        $join = "INNER JOIN `cms_album_comments` ON `cms_album_files`.`id` = `cms_album_comments`.`sub_id`";
        $where = "`cms_album_files`.`user_id` = '" . core::$user_id .
            "' AND `cms_album_files`.`unread_comments` = 1 GROUP BY `cms_album_files`.`id`";
        $order = "`cms_album_comments`.`time` DESC";
        $link = '/mod/my_new_comm';
        break;

    case 'last_comm':
        $total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `sub_id`) FROM `cms_album_comments` WHERE `time` >" .
            (time() - 86400)), 0);
        $title = $lng_profile['new_comments'];
        $select = "";
        $join = "INNER JOIN `cms_album_comments` ON `cms_album_files`.`id` = `cms_album_comments`.`sub_id`";
        $where = "`cms_album_comments`.`time` > " . (time() - 86400) .
            " GROUP BY `cms_album_files`.`id`";
        $order = "`cms_album_comments`.`time` DESC";
        $link = '/mod/last_comm';
        break;

    case 'views':
        $title = $lng_profile['top_views'];
        $select = "";
        $join = "";
        $where = "`cms_album_files`.`views` > '0'" . (core::$user_rights >= 6 ?
            "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`views` DESC";
        $link = '/mod/views';
        break;

    case 'downloads':
        $title = $lng_profile['top_downloads'];
        $select = "";
        $join = "";
        $where = "`cms_album_files`.`downloads` > 0" . (core::$user_rights >= 6 ?
            "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`downloads` DESC";
        $link = '/mod/downloads';
        break;

    case 'comments':
        $title = $lng_profile['top_comments'];
        $select = "";
        $join = "";
        $where = "`cms_album_files`.`comm_count` > '0'" . (core::$user_rights >=
            6 ? "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`comm_count` DESC";
        $link = '/mod/comments';
        break;

    case 'votes':
        $title = $lng_profile['top_votes'];
        $select = ", (`vote_plus` - `vote_minus`) AS `rating`";
        $join = "";
        $where = "(`vote_plus` - `vote_minus`) > 2" . (core::$user_rights >= 6 ?
            "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`rating` DESC";
        $link = '/mod/votes';
        break;

    case 'trash':
        $title = $lng_profile['top_trash'];
        $select = ", (`vote_plus` - `vote_minus`) AS `rating`";
        $join = "";
        $where = "(`vote_plus` - `vote_minus`) < -2" . (core::$user_rights >= 6 ?
            "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`rating` ASC";
        $link = '/mod/trash';
        break;

    default:
        $title = $lng_profile['new_photo'];
        $select = "";
        $join = "";
        $where = "`cms_album_files`.`time` > '" . (time() - 259200) . "'" . (core::
            $user_rights >= 6 ? "" : " AND `cms_album_files`.`access` = '4'");
        $order = "`cms_album_files`.`time` DESC";
        $link = '';
}

unset($_SESSION['ref']);
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
    array('label' => $title),
    ));
$textl = $title;
require ('../incfiles/head.php');

if ($mod == 'my_new_comm')
{
    $total = $new_album_comm;
}
elseif (!isset($total))
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE $where"),
        0);
}

if ($total)
{
    $req = mysql_query("
      SELECT `cms_album_files`.*, `users`.`name` AS `user_name`, `cms_album_cat`.`name` AS `album_name` $select
      FROM `cms_album_files`
      LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id`
      LEFT JOIN `cms_album_cat` ON `cms_album_files`.`album_id` = `cms_album_cat`.`id`
      $join
      WHERE $where
      ORDER BY $order
      LIMIT $start, $kmess
    ");
    echo '<div class="row">';
    while ($res = mysql_fetch_assoc($req))
    {
        echo '<div class="col-xs-6 col-sm-3 col-lg-2">';

        if ($res['access'] == 4 || core::$user_rights >= 7)
        {
            echo '<a class="thumbnail" href="' . $home .
                '/users/album.php/act/show/al/' . $res['album_id'] . '/user/' .
                $res['user_id'] . '/id/' . $res['id'] . '">' .
                '<img class="img-reponsive" src="' . $set['homeurl'] .
                '/files/users/album/' . $res['user_id'] . '/' . $res['tmb_name'] .
                '" /></a>';
        }
        elseif ($res['access'] == 3)
        {

            echo '<div class="bg-red"><h4 class="text-center">' . $lng_profile['friends_only'] .
                '</h4></div>';
        }
        elseif ($res['access'] == 2)
        {

            echo '<div class="bg-red"><i class="fa fa-lock fa-5x"></i></div>';
        }

        echo '</div>';
    }
    echo '</div>';
}
else
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}

if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/users/album.php/act/top' . $link . '/', $start, $total, $kmess) .
        '</div>';
}
