<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $lng_profile['image_delete'];
if ($img && $user['id'] == $user_id || $rights >= 6)
{
    $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `id` = '$img' AND `user_id` = '" .
        $user['id'] . "' LIMIT 1");
    if (mysql_num_rows($req))
    {
        $res = mysql_fetch_assoc($req);
        $album = $res['album_id'];
        $cat_al = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `cms_album_cat` WHERE `id` = '$album'"));
        $breadcrumb = functions::breadcrumb(array(
            array('label' => $lng['users'], 'url' => '/users/'),
            array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
            array('label' => $lng_profile['my_album'], 'url' =>
                    '/users/album.php/act/list/user/' . $user['id']),
            array('label' => functions::checkout($cat_al['name']), 'url' =>
                    '/users/album.php/act/show/al/' . $album . '/user/' . $user['id']),
            array('label' => $lng_profile['image_delete'])));

        if (isset($_POST['submit']))
        {

            @unlink('../files/users/album/' . $user['id'] . '/' . $res['img_name']);
            @unlink('../files/users/album/' . $user['id'] . '/' . $res['tmb_name']);

            mysql_query("DELETE FROM `cms_album_files` WHERE `id` = '$img'");
            mysql_query("DELETE FROM `cms_album_votes` WHERE `file_id` = '$img'");
            mysql_query("OPTIMIZE TABLE `cms_album_votes`");
            mysql_query("DELETE FROM `cms_album_comments` WHERE `sub_id` = '$img'");
            mysql_query("OPTIMIZE TABLE `cms_album_comments`");
            header('Location: ' . core::$system_set['homeurl'] .
                '/users/album.php/act/show/al/' . $album . '/user/' . $user['id']);
        }
        else
        {
            require ('../incfiles/head.php');
            echo '<form role="form" action="' . $set['homeurl'] .
                '/users/album.php/act/image_delete/img/' . $img . '/user/' . $user['id'] .
                '" method="post">' . '<div class="alert alert-danger">' . '<p>' .
                $lng_profile['image_delete_warning'] . '</p>' . '</div>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['delete'] . '</button> <a class="btn btn-default" href="' .
                $set['homeurl'] . '/users/album.php/act/show/al/' . $album .
                'user/' . $user['id'] . '" data-dismiss="modal">' . $lng['cancel'] .
                '</a></p>' . '</form>';
        }
    }
    else
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
    }
}

?>