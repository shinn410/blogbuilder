<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');


if ($al && $user['id'] == $user_id && empty($ban) || $rights >= 7)
{
    $req_a = mysql_query("SELECT * FROM `cms_album_cat` WHERE `id` = '$al' AND `user_id` = '" .
        $user['id'] . "'");
    if (!mysql_num_rows($req_a))
    {
        require ('../incfiles/head.php');

        echo functions::display_error($lng['error_wrong_data']);
        require ('../incfiles/end.php');
        exit;
    }
    $res_a = mysql_fetch_assoc($req_a);
    require ('../incfiles/lib/class.upload.php');
    $breadcrumb = functions::breadcrumb(array(
        array('label' => $lng['users'], 'url' => '/users/'),
        array('label' => $lng['photo_albums'], 'url' =>
                'users/album.php/act/show/al/' . $al . '/user/' . $user['id']),
        array('label' => $lng_profile['upload_photo']),
        ));
    require ('../incfiles/head.php');
    if (isset($_POST['submit']))
    {
        $handle = new upload($_FILES['imagefile']);
        if ($handle->uploaded)
        {

            $handle->file_new_name_body = 'img_' . time();
            $handle->allowed = array(
                'image/jpeg',
                'image/gif',
                'image/png');
            $handle->file_max_size = 1024 * $set['flsz'];


            $handle->image_convert = 'jpg';


            $handle->process('../files/users/album/' . $user['id'] . '/');
            $img_name = $handle->file_dst_name;
            if ($handle->processed)
            {

                $handle->file_new_name_body = 'tmb_' . time();
                $handle->image_resize = true;
                $handle->image_x = 320;
                $handle->image_y = 320;


                $handle->image_convert = 'jpg';
                $handle->process('../files/users/album/' . $user['id'] . '/');
                $tmb_name = $handle->file_dst_name;
                if ($handle->processed)
                {
                    $description = isset($_POST['description']) ? trim($_POST['description']) :
                        '';
                    $description = mb_substr($description, 0, 500);
                    mysql_query("INSERT INTO `cms_album_files` SET
                        `album_id` = '$al',
                        `user_id` = '" . $user['id'] . "',
                        `img_name` = '" . mysql_real_escape_string($img_name) .
                        "',
                        `tmb_name` = '" . mysql_real_escape_string($tmb_name) .
                        "',
                        `description` = '" . mysql_real_escape_string($description) .
                        "',
                        `time` = '" . time() . "',
                        `access` = '" . $res_a['access'] . "'
                    ");
                    echo '<div class="alert alert-success"><p>' . $lng_profile['photo_uploaded'] .
                        '. ' . '<a class="alert-link" href="' . $set['homeurl'] .
                        '/users/album.php/act/show/al/' . $al . '/user/' . $user['id'] .
                        '">' . $lng['continue'] . ' &raquo;</a></p></div>';
                }
                else
                {
                    echo functions::display_error($handle->error);
                }
            }
            else
            {
                echo functions::display_error($handle->error);
            }
            $handle->clean();
        }
    }
    else
    {
        echo '<form enctype="multipart/form-data" method="post" action="' . $set['homeurl'] .
            '/users/album.php/act/image_upload/al/' . $al . '/user/' . $user['id'] .
            '">' . '<div class="form-group">' .
            '<label class="control-label dis-block">' . $lng_profile['select_image'] .
            '</label>' . '<input type="file" name="imagefile" value="" />' .
            '</div>' . '<div class="form-group">' .
            '<label class="control-label">' . $lng['description'] . '</label>' .
            '<textarea class="form-control" name="description" rows="' . $set_user['field_h'] .
            '"></textarea>' . '<p class="help-block">' . $lng['not_mandatory_field'] .
            ', max. 500</p>' . '</div>' .
            '<input type="hidden" name="MAX_FILE_SIZE" value="' . (1024 * $set['flsz']) .
            '" />' .
            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng_profile['upload'] . '" /></p>' . '</form>' .
            '<div class="alert alert-info"><small>' . $lng_profile['select_image_help'] .
            ' ' . $set['flsz'] . 'kb.<br />' . $lng_profile['select_image_help_5'] .
            '</small></div>' . '<p>' . functions::link_back($lng['back'],
            'users/album.php/act/show/al/' . $al . '/user/' . $user['id']) .
            '</p>';
    }
}
