<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($img && $user['id'] == $user_id || $rights >= 6)
{
    $req = mysql_query("SELECT * FROM `cms_album_files` WHERE `id` = '$img' AND `user_id` = '" .
        $user['id'] . "'");
    if (mysql_num_rows($req))
    {
        $res = mysql_fetch_assoc($req);
        $album = $res['album_id'];
        $cat_al = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `cms_album_cat` WHERE `id` = '$album'"));
        $breadcrumb = functions::breadcrumb(array(
            array('label' => $lng['users'], 'url' => '/users/'),
            array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
            array('label' => $user['name'], 'url' =>
                    '/users/album.php/act/list/user/' . $user['id']),
            array('label' => functions::checkout($cat_al['name']), 'url' =>
                    '/users/album.php/act/show/al/' . $album . '/user/' . $user['id']),
            array('label' => $lng_profile['image_edit']),
            ));
        if (isset($_POST['submit']))
        {
            if (!isset($_SESSION['post']))
            {
                $_SESSION['post'] = true;
                $sql = '';
                $rotate = isset($_POST['rotate']) ? intval($_POST['rotate']) : 0;
                $brightness = isset($_POST['brightness']) ? intval($_POST['brightness']) :
                    0;
                $contrast = isset($_POST['contrast']) ? intval($_POST['contrast']) :
                    0;
                $description = isset($_POST['description']) ? trim($_POST['description']) :
                    '';
                $description = mb_substr($description, 0, 500);
                if ($rotate == 1 || $rotate == 2 || ($brightness > 0 && $brightness <
                    5) || ($contrast > 0 && $contrast < 5))
                {
                    $path = '../files/users/album/' . $user['id'] . '/';
                    require ('../incfiles/lib/class.upload.php');
                    $handle = new upload($path . $res['img_name']);

                    $handle->file_new_name_body = 'img_' . time();
                    if ($rotate == 1 || $rotate == 2)
                        $handle->image_rotate = ($rotate == 2 ? 90 : 270);
                    if ($brightness > 0 && $brightness < 5)
                    {
                        switch ($brightness)
                        {
                            case 1:
                                $handle->image_brightness = -40;
                                break;

                            case 2:
                                $handle->image_brightness = -20;
                                break;

                            case 3:
                                $handle->image_brightness = 20;
                                break;

                            case 4:
                                $handle->image_brightness = 40;
                                break;
                        }
                    }
                    if ($contrast > 0 && $contrast < 5)
                    {
                        switch ($contrast)
                        {
                            case 1:
                                $handle->image_contrast = -50;
                                break;

                            case 2:
                                $handle->image_contrast = -25;
                                break;

                            case 3:
                                $handle->image_contrast = 25;
                                break;

                            case 4:
                                $handle->image_contrast = 50;
                                break;
                        }
                    }
                    $handle->process($path);
                    $img_name = $handle->file_dst_name;
                    if ($handle->processed)
                    {

                        $handle->file_new_name_body = 'tmb_' . time();
                        if ($rotate == 1 || $rotate == 2)
                            $handle->image_rotate = ($rotate == 2 ? 90 : 270);
                        if ($brightness > 0 && $brightness < 5)
                        {
                            switch ($brightness)
                            {
                                case 1:
                                    $handle->image_brightness = -40;
                                    break;

                                case 2:
                                    $handle->image_brightness = -20;
                                    break;

                                case 3:
                                    $handle->image_brightness = 20;
                                    break;

                                case 4:
                                    $handle->image_brightness = 40;
                                    break;
                            }
                        }
                        if ($contrast > 0 && $contrast < 5)
                        {
                            switch ($contrast)
                            {
                                case 1:
                                    $handle->image_contrast = -50;
                                    break;

                                case 2:
                                    $handle->image_contrast = -25;
                                    break;

                                case 3:
                                    $handle->image_contrast = 25;
                                    break;

                                case 4:
                                    $handle->image_contrast = 50;
                                    break;
                            }
                        }
                        $handle->image_resize = true;
                        $handle->image_x = 80;
                        $handle->image_y = 80;
                        $handle->image_ratio_crop = true;
                        $handle->image_ratio_no_zoom_in = true;
                        $handle->process($path);
                        $tmb_name = $handle->file_dst_name;
                    }
                    $handle->clean();
                    @unlink('../files/users/album/' . $user['id'] . '/' . $res['img_name']);
                    @unlink('../files/users/album/' . $user['id'] . '/' . $res['tmb_name']);
                    $sql = "`img_name` = '" . mysql_real_escape_string($img_name) .
                        "', `tmb_name` = '" . mysql_real_escape_string($tmb_name) .
                        "',";
                }
                mysql_query("UPDATE `cms_album_files` SET $sql
                    `description` = '" . mysql_real_escape_string($description) .
                    "'
                    WHERE `id` = '$img'
                ");
            }
            header('Location: ' . $set['homeurl'] .
                '/users/album.php/act/show/al/' . $album . '/user/' . $user['id'] .
                '/id/' . $res['id']);
            exit;
        }
        else
        {
            unset($_SESSION['post']);
            require ('../incfiles/head.php');
            echo '<div class="row"><div class="col-sm-4"><p><img class="thumbnail" style="display:block;" src="' .
                $set['homeurl'] . '/files/users/album/' . $user['id'] . '/' . $res['tmb_name'] .
                '" /></p></div>';
            echo '<div class="col-sm-8"><form role="form" action="' . $set['homeurl'] .
                '/users/album.php/act/image_edit/img/' . $img . '/user/' . $user['id'] .
                '" method="post"><div class="form-group">' . '<label>' . $lng['description'] .
                '</label>' .
                '<textarea class="form-control" name="description" rows="' . $set_user['field_h'] .
                '">' . functions::checkout($res['description']) . '</textarea>' .
                '<p class="help-block">' . $lng['not_mandatory_field'] .
                ', max. 500</p>' . '</div>' . '<div class="alert alert-danger">' .
                '<label>Яркость</label>' .
                '<table border="0" cellspacing="0" cellpadding="0" style="text-align:center"><tr>' .
                '<td><input type="radio" name="brightness" value="1"/></td>' .
                '<td><input type="radio" name="brightness" value="2"/></td>' .
                '<td><input type="radio" name="brightness" value="0" checked="checked"/></td>' .
                '<td><input type="radio" name="brightness" value="3"/></td>' .
                '<td><input type="radio" name="brightness" value="4"/></td>' .
                '</tr><tr>' . '<td>-2</td>' . '<td>-1</td>' . '<td>0</td>' .
                '<td>+1</td>' . '<td>+2</td>' . '</tr></table>' .
                '<label>Контрастность</label>' .
                '<table border="0" cellspacing="0" cellpadding="0" style="text-align:center"><tr>' .
                '<td><input type="radio" name="contrast" value="1"/></td>' .
                '<td><input type="radio" name="contrast" value="2"/></td>' .
                '<td><input type="radio" name="contrast" value="0" checked="checked"/></td>' .
                '<td><input type="radio" name="contrast" value="3"/></td>' .
                '<td><input type="radio" name="contrast" value="4"/></td>' .
                '</tr><tr>' . '<td>-2</td>' . '<td>-1</td>' . '<td>0</td>' .
                '<td>+1</td>' . '<td>+2</td>' . '</tr></table>' .
                '<label for="rotate">' . $lng_profile['image_rotate'] .
                '</label>' .
                '<div class="radio"><label><input type="radio" name="rotate" value="0" checked="checked"/>&#160;' .
                $lng_profile['image_rotate_not'] . '</label></div>' .
                '<div class="radio"><label><input type="radio" name="rotate" value="2"/>&#160;' .
                $lng_profile['image_rotate_right'] . '</label></div>' .
                '<div class="radio"><label><input type="radio" name="rotate" value="1"/>&#160;' .
                $lng_profile['image_rotate_left'] . '</label></div>' .
                '<p class="help-block">' . $lng_profile['image_edit_warning'] .
                '</p>' . '</div>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['save'] . '</button>' .
                ' <a class="btn btn-default" href="' . $set['homeurl'] .
                '/users/album.php/act/show/al/' . $album . '/user/' . $user['id'] .
                '/id/' . $res['id'] . '">' . $lng['cancel'] .
                '</a></p></form></div></div>';
        }
    }
    else
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
    }
}
else
{
    header('Location: ' . $home . '/');
    exit;
}

?>