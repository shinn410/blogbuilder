<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $user['name'];
$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
    array('label' => $textl),
    ));
require ('../incfiles/head.php');

if (isset($_SESSION['ap']))
{
    unset($_SESSION['ap']);
}
$req = mysql_query("SELECT * FROM `cms_album_cat` WHERE `user_id` = '" . $user['id'] .
    "' " . ($user['id'] == $user_id || $rights >= 6 ? "" : "AND `access` > 1") .
    " ORDER BY `sort` ASC");
$total = mysql_num_rows($req);
if ($user['id'] == $user_id && $total < $max_album && empty($ban) || $rights >=
    7)
{
    echo '<p><a class="func" href="' . $set['homeurl'] .
        '/users/album.php/act/edit/user/' . $user['id'] .
        '"><i class="fa fa-plus"></i> ' . $lng_profile['album_create'] .
        '</a></p>';
}
echo '<div class="callout callout-info"><p>' . functions::display_user($user,
    array('iphide' => 1, )) . '</p></div>';
if ($total)
{
    $i = 0;
    while ($res = mysql_fetch_assoc($req))
    {
        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `album_id` = '" .
            $res['id'] . "'"), 0);
        echo ($i % 2 ? '<div class="list2">' : '<div class="list1">') .
            '<a href="' . $set['homeurl'] . '/users/album.php/act/show/al/' . $res['id'] .
            '/user/' . $user['id'] .
            '"><strong><i class="fa fa-picture-o"></i> ' . functions::checkout($res['name']) .
            '</strong></a>&#160;<span class="badge pull-right">' . $count .
            '</span>';
        if ($user['id'] == $user_id || $rights >= 6 || !empty($res['description']))
        {
            $menu = array(
                '<a href="' . $set['homeurl'] .
                    '/users/album.php/act/sort/mod/up/al/' . $res['id'] .
                    '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-chevron-up"></span> ' .
                    $lng['up'] . '</a>',
                '<a href="' . $set['homeurl'] .
                    '/users/album.php/act/sort/mod/down/al/' . $res['id'] .
                    '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-chevron-down"></span> ' .
                    $lng['down'] . '</a>',
                '<a href="' . $set['homeurl'] . '/users/album.php/act/edit/al/' .
                    $res['id'] . '/user/' . $user['id'] .
                    '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
                    '</a>',
                '<a href="' . $set['homeurl'] .
                    '/users/album.php/act/delete/al/' . $res['id'] . '/user/' .
                    $user['id'] .
                    '"><span class="glyphicon glyphicon-remove"></span> ' . $lng['delete'] .
                    '</a>');
            echo '<div class="sub">' . (!empty($res['description']) ?
                '<div class="gray">' . functions::checkout($res['description'],
                1, 1) . '</div>' : '') . ($user['id'] == $user_id && empty($ban) ||
                $rights >= 6 ? functions::display_menu($menu, ' | ') : '') .
                '</div>';
        }
        echo '</div>';
        ++$i;
    }
}
else
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}
echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
echo '<p>' . functions::link_back($lng['back'], 'users/album.php') . '</p>';
