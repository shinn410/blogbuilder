<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$breadcrumb = functions::breadcrumb(array(
    array('label' => $lng['photo_albums'], 'url' => '/users/album.php'),
    array('label' => $lng['list']),
    ));
require ('../incfiles/head.php');

switch ($mod)
{
    case 'boys':
        $sql = "WHERE `users`.`sex` = 'm'";
        break;

    case 'girls':
        $sql = "WHERE `users`.`sex` = 'zh'";
        break;
    default:
        $sql = "WHERE `users`.`sex` != ''";
}

echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs">';
echo (!$mod ? '<li class="active"><a><i class="fa fa-users"></i> ' . $lng['all'] .
    '</a></li>' : '<li><a href="' . $set['homeurl'] .
    '/users/album.php/act/users"><i class="fa fa-users"></i> ' . $lng['all'] .
    '</a></li>');
echo ($mod == 'boys' ? '<li class="active"><a><i class="fa fa-male"></i> ' . $lng['mans'] .
    '</a></li>' : '<li><a href="' . $set['homeurl'] .
    '/users/album.php/act/users/mod/boys"><i class="fa fa-male"></i> ' . $lng['mans'] .
    '</a></li>');
echo ($mod == 'girls' ? '<li class="active"><a><i class="fa fa-female"></i> ' .
    $lng['womans'] . '</a></li>' : '<li><a href="' . $set['homeurl'] .
    '/users/album.php/act/users/mod/girls"><i class="fa fa-female"></i> ' . $lng['womans'] .
    '</a></li>');
echo '</ul><div class="tab-content">';

$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `user_id`)
    FROM `cms_album_files`
    LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id` $sql
"), 0);
if ($total)
{
    $req = mysql_query("SELECT `cms_album_files`.*, COUNT(`cms_album_files`.`id`) AS `count`, `users`.`id` AS `uid`, `users`.`name` AS `nick`
        FROM `cms_album_files`
        LEFT JOIN `users` ON `cms_album_files`.`user_id` = `users`.`id` $sql
        GROUP BY `cms_album_files`.`user_id` ORDER BY `users`.`name` ASC LIMIT $start, $kmess
    ");
    $i = 0;
    echo '<div class="list-group">';
    while ($res = mysql_fetch_assoc($req))
    {

        echo '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/album.php/act/list/user/' . $res['uid'] .
            '"><i class="fa fa-user"></i> ' . $res['nick'] .
            ' <span class="badge">' . $res['count'] . '</span></a>';
        ++$i;
    }
    echo '</div>';
}
else
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}
echo '</div></div>';
echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/users/album.php/act/users' . ($mod ? '/mod/' . $mod : '') . '?', $start,
        $total, $kmess) . '</div>';
}
echo '<p>' . functions::link_back($lng['back'], 'users/album.php') . '</p>';
