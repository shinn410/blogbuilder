<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);

$headmod = 'usersearch';
require ('../incfiles/core.php');
$textl = $lng['search_user'];
require ('../incfiles/head.php');
echo functions::breadcrumb(array(
    array('label' => $lng['community'], 'url' => '/users/index.php'),
    array('label' => $lng['search_user']),
    ));
echo '<h1 class="page-header">' . $lng['search_user'] . '</h1>';
/*
* -----------------------------------------------------------------
* Принимаем данные, выводим форму поиска
* -----------------------------------------------------------------
*/
$search_post = isset($_POST['search']) ? trim($_POST['search']) : false;
$search_get = isset($_GET['search']) ? rawurldecode(trim($_GET['search'])) : '';
$search = $search_post ? $search_post : $search_get;
echo '<div class="well well-sm"><form class="form-horizontal" role="form" action="' .
    $set['homeurl'] . '/users/search.php" method="post">' .
    '<div class="input-group">' .
    '<input class="form-control" type="text" name="search" value="' . functions::checkout($search) .
    '" />' . '<span class="input-group-btn">' .
    '<button class="btn btn-primary" type="submit" name="submit">' . $lng['search'] .
    '</button>' . '</span>' . '</div>' . '</form></div>';

/*
* -----------------------------------------------------------------
* Проверям на ошибки
* -----------------------------------------------------------------
*/
$error = array();
if (!empty($search) && (mb_strlen($search) < 2 || mb_strlen($search) > 20))
    $error[] = $lng['nick'] . ': ' . $lng['error_wrong_lenght'];
if (preg_match("/[^1-9a-z\-\@\*\(\)\?\!\~\_\=\[\]]+/", functions::rus_lat(mb_strtolower
    ($search))))
    $error[] = $lng['nick'] . ': ' . $lng['error_wrong_symbols'];
if ($search && !$error)
{
    /*
    * -----------------------------------------------------------------
    * Выводим результаты поиска
    * -----------------------------------------------------------------
    */
    $search_db = functions::rus_lat(mb_strtolower($search));
    $search_db = strtr($search_db, array('_' => '\\_', '%' => '\\%'));
    $search_db = '%' . $search_db . '%';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `name_lat` LIKE '" .
        mysql_real_escape_string($search_db) . "'"), 0);
    echo '<h2 class="page-header">' . $lng['search_results'] . '</h2>';
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/users/search.php/search/' . urlencode($search) . '/', $start, $total,
            $kmess) . '</div>';
    if ($total > 0)
    {
        $req = mysql_query("SELECT * FROM `users` WHERE `name_lat` LIKE '" .
            mysql_real_escape_string($search_db) . "' ORDER BY `name` ASC LIMIT $start, $kmess");
        $i = 0;
        while ($res = mysql_fetch_assoc($req))
        {
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            $res['name'] = mb_strlen($search) < 2 ? $res['name'] : preg_replace('|(' .
                preg_quote($search, '/') . ')|siu',
                '<span style="background-color: #FFFF33">$1</span>', $res['name']);
            echo functions::display_user($res);
            echo '</div>';
            ++$i;
        }
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['search_results_empty'] .
            '</p></div>';
    }
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/users/search.php/search/' . urlencode($search) . '/?', $start, $total,
            $kmess) . '</div>';
    }
}
else
{
    if ($error)
        echo functions::display_error($error);
    echo '<div class="alert alert-info"><small>' . $lng['search_nick_help'] .
        '</small></div>';
}
echo '<p>' . ($search && !$error ? functions::link_back($lng['search_new'],
    '/users/search.php') : functions::link_back($lng['back'], 'users/index.php'));

require ('../incfiles/end.php');

?>