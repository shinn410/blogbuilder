<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

require ('../incfiles/core.php');
$lng_profile = core::load_lng('profile');

if (!$user_id)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require ('../incfiles/end.php');
    exit;
}

$user = functions::get_user($user);
if (!$user)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['user_does_not_exist']);
    require ('../incfiles/end.php');
    exit;
}

$array = array(
    'activity' => 'includes/profile',
    'ban' => 'includes/profile',
    'edit' => 'includes/profile',
    'images' => 'includes/profile',
    'info' => 'includes/profile',
    'ip' => 'includes/profile',
    'guestbook' => 'includes/profile',
    'karma' => 'includes/profile',
    'office' => 'includes/profile',
    'password' => 'includes/profile',
    'reset' => 'includes/profile',
    'settings' => 'includes/profile',
    'stat' => 'includes/profile',
    'friends' => 'includes/profile',
    );

$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php'))
{
    require_once ($path . $act . '.php');
}
else
{
    $headmod = 'profile,' . $user['id'];
    $textl = $lng['profile'] . ': ' . htmlspecialchars($user['name']);
    $breadcrumb = functions::breadcrumb(array(
        array('label' => $lng['users'], 'url' => '/users/index.php/act/userlist'),
        array('label' => $user['name']),
        ));
    require ('../incfiles/head.php');
    $menu = array();
    if ($user['id'] == $user_id || $rights == 9 || ($rights == 7 && $rights > $user['rights']))
    {
        $menu[] = '<a class="func" href="' . $set['homeurl'] .
            '/users/profile.php/act/edit/user/' . $user['id'] .
            '"><i class="fa fa-edit"></i> ' . $lng['edit'] . '</a>';
    }
    if ($user['id'] != $user_id && $rights > $user['rights'])
    {
        $menu[] = '<a class="func" href="' . $set['homeurl'] .
            '/users/profile.php/act/ban/mod/do/user/' . $user['id'] .
            '"><i class="fa fa-ban"></i> ' . $lng['ban_do'] . '</a>';
    }
    if ($user['id'] != $user_id && $rights >= 7 && $rights > $user['rights'])
    {
        $menu[] = '<a class="func text-danger" href="' . $set['homeurl'] . '/' .
            $set['admp'] . '/index.php/act/usr_del/id/' . $user['id'] .
            '"><i class="fa fa-times"></i> ' . $lng['delete'] . '</a>';
    }
    if (!empty($menu))
    {
        echo '<p>' . implode('&nbsp;', $menu) . '</p>';
    }
    echo '<div class="row">';
    if ($is_modal && ($user['id'] == $user_id))
        echo '<div class="col-xs-12">';
    else
        echo '<div class="col-sm-6">';
    if ($user['dayb'] == date('j', time()) && $user['monthb'] == date('n', time
        ()))
    {
        echo '<div class="callout callout-danger">' . $lng['birthday'] .
            '!!!</div>';
    }

    $arg = array(
        'lastvisit' => 1,
        'iphist' => 1,
        'header' => '<b>ID:' . $user['id'] . '</b>');

    if ($user['id'] != core::$user_id)
    {
        $arg['footer'] = '<span class="gray">' . core::$lng['where'] .
            ':</span> ' . functions::display_place($user['id'], $user['place']);
    }

    echo '<div class="box box-solid"><div class="box-body">';
    echo '<p>' . functions::display_user($user, $arg) . '</p>';

    if ($rights >= 7 && !$user['preg'] && empty($user['regadm']))
    {
        echo '<div class="alert alert-danger">' . $lng_profile['awaiting_registration'] .
            '</div>';
    }

    if ($set_karma['on'])
    {
        $karma = $user['karma_plus'] - $user['karma_minus'];
        if ($karma > 0)
        {
            $images = ($user['karma_minus'] ? ceil($user['karma_plus'] / $user['karma_minus']) :
                $user['karma_plus']) > 10 ? '2' : '1';
            echo '<div class="gmenu">';
        }
        else
            if ($karma < 0)
            {
                $images = ($user['karma_plus'] ? ceil($user['karma_minus'] / $user['karma_plus']) :
                    $user['karma_minus']) > 10 ? '-2' : '-1';
                echo '<div class="callout callout-danger">';
            }
            else
            {
                $images = 0;
                echo '<div class="callout callout-info">';
            }
            echo '<table  width="100%"><tr><td width="22" valign="top"><img src="' .
                $set['homeurl'] . '/images/k_' . $images . '.gif"/></td><td>' .
                '<b>' . $lng['karma'] . ' (' . $karma . ')</b>' .
                '<div class="sub">' . '<span class="green"><a href="' . $set['homeurl'] .
                '/users/profile.php/act/karma/user/' . $user['id'] .
                '/type/1"><span class="glyphicon glyphicon-thumbs-up"></span> ' .
                $lng['vote_for'] . ' (' . $user['karma_plus'] .
                ')</a></span> | ' . '<span class="red"><a href="' . $set['homeurl'] .
                '/users/profile.php/act/karma/user/' . $user['id'] .
                '"><span class="glyphicon glyphicon-thumbs-down"></span> ' . $lng['vote_against'] .
                ' (' . $user['karma_minus'] . ')</a></span>';
        if ($user['id'] != $user_id)
        {
            if (!$datauser['karma_off'] && (!$user['rights'] || ($user['rights'] &&
                !$set_karma['adm'])) && $user['ip'] != $datauser['ip'])
            {
                $sum = mysql_result(mysql_query("SELECT SUM(`points`)
                FROM `karma_users`
                WHERE `user_id` = '$user_id'
                AND `time` >= '" . $datauser['karma_time'] . "'"), 0);
                $count = mysql_result(mysql_query("SELECT COUNT(*)
                FROM `karma_users`
                WHERE `user_id` = '$user_id'
                AND `karma_user` = '" . $user['id'] . "'
                AND `time` > '" . (time() - 86400) . "'"), 0);
                if (!$ban && $datauser['postforum'] >= $set_karma['forum'] && $datauser['total_on_site'] >=
                    $set_karma['karma_time'] && ($set_karma['karma_points'] - $sum) >
                    0 && !$count)
                {
                    echo '<br /><a href="' . $set['homeurl'] .
                        '/users/profile.php/act/karma/mod/vote/user/' . $user['id'] .
                        '">' . $lng['vote'] . '</a>';
                }
            }
        }
        else
        {
            $total_karma = mysql_result(mysql_query("SELECT COUNT(*)
            FROM `karma_users`
            WHERE `karma_user` = '$user_id'
            AND `time` > " . (time() - 86400)), 0);
            if ($total_karma > 0)
            {
                echo '<br /><a href="' . $set['homeurl'] .
                    '/users/profile.php/act/karma/mod/new">' . $lng['responses_new'] .
                    '</a> (' . $total_karma . ')';
            }
        }
        echo '</div></td></tr></table></div>';
    }
    echo '</div></div>';
    $sidebar = '';

    if (!$is_modal)
    {
        $total_photo = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" .
            $user['id'] . "'"), 0);
        $sidebar .= '<div class="list-group">' .
            '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/profile.php/act/info/user/' . $user['id'] .
            '"><i class="fa fa-info-circle"></i> ' . $lng['information'] .
            '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/profile.php/act/activity/user/' . $user['id'] .
            '"><i class="fa fa-sitemap"></i> ' . $lng_profile['activity'] .
            '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/profile.php/act/stat/user/' . $user['id'] .
            '"><i class="fa fa-bar-chart-o"></i> ' . $lng['statistics'] . '</a>';
        $bancount = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" .
            $user['id'] . "'"), 0);
        if ($bancount)
            $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                '/users/profile.php/act/ban/user/' . $user['id'] .
                '"><i class="fa fa-ban"></i> ' . $lng['infringements'] .
                ' <span class="badge">' . $bancount . '</span></a>';
        $total_friends = mysql_result(mysql_query("SELECT COUNT(*)
    FROM `cms_contact`
    WHERE `user_id`='{$user['id']}'
    AND `type`='2'
    AND `friends`='1'"), 0);
        $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/album.php/act/list/user/' . $user['id'] .
            '"><i class="fa fa-picture-o"></i> ' . $lng['photo_album'] .
            ' <span class="badge">' . $total_photo . '</span></a>' .
            '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/profile.php/act/guestbook/user/' . $user['id'] .
            '"><i class="fa fa-book"></i> ' . $lng['guestbook'] .
            ' <span class="badge">' . $user['comm_count'] . '</span></a>' .
            '<a class="list-group-item" href="' . $set['homeurl'] .
            '/users/profile.php/act/friends/user/' . $user['id'] .
            '"><i class="fa fa-users"></i> ' . $lng_profile['friends'] .
            ' <span class="badge">' . $total_friends . '</span></a>' . '</div>';
    }
    if ($user['id'] != $user_id)
    {
        $sidebar .= '<div class="list-group">';
        if (!functions::is_ignor($user['id']) && functions::is_contact($user['id']) !=
            2)
        {
            if (!functions::is_friend($user['id']))
            {
                $fr_in = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact`
                WHERE `type`='2'
                AND `from_id`='$user_id'
                AND `user_id`='{$user['id']}'"), 0);
                $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact`
                WHERE `type`='2'
                AND `user_id`='$user_id'
                AND `from_id`='{$user['id']}'"), 0);
                if ($fr_in == 1)
                {
                    $friend = '<a class="list-group-item" href="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/ok/id/' . $user['id'] .
                        '"><i class="fa fa-plus"></i> ' . $lng_profile['confirm_friendship'] .
                        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
                        '/users/profile.php/act/friends/do/no/id/' . $user['id'] .
                        '"><i class="fa fa-times"></i> ' . $lng_profile['decline_friendship'] .
                        '</a>';
                }
                else
                    if ($fr_out == 1)
                    {
                        $friend = '<a class="list-group-item" href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/cancel/id/' . $user['id'] .
                            '" data-toggle="' . functions::set_modal() .
                            '" data-target="#global-modal"><i class="fa fa-times"></i> ' .
                            $lng_profile['canceled_demand_friend'] . '</a>';
                    }
                    else
                    {
                        $friend = '<a class="list-group-item" data-toggle="' .
                            functions::set_modal() . '" ' .
                            'data-target="#global-modal" href="' . $set['homeurl'] .
                            '/users/profile.php/act/friends/do/add/id/' . $user['id'] .
                            '"><i class="fa fa-plus"></i> ' . $lng_profile['in_friend'] .
                            '</a>';
                    }
            }
            else
            {
                $friend = '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/users/profile.php/act/friends/do/delete/id/' . $user['id'] .
                    '"><i class="fa fa-times"></i> ' . $lng_profile['remov_friend'] .
                    '</a>';
            }
            $sidebar .= $friend;
        }

        if (functions::is_contact($user['id']) != 2)
        {
            if (!functions::is_contact($user['id']))
            {
                $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/mail/index.php/id/' . $user['id'] .
                    '"><i class="fa fa-users"></i> ' . $lng_profile['add_contacts'] .
                    '</a>';
            }
            else
            {
                $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/mail/index.php/act/deluser/id/' . $user['id'] .
                    '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-users"></i> ' .
                    $lng_profile['delete_contacts'] . '</a>';
            }
        }

        if (functions::is_contact($user['id']) != 2)
        {
            $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                '/mail/index.php/act/ignor/id/' . $user['id'] .
                '/add" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal">' . '<i class="fa fa-ban"></i>  ' .
                $lng_profile['add_ignor'] . '</a>';
        }
        else
        {
            $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                '/mail/index.php/act/ignor/id/' . $user['id'] .
                '/del" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal">' .
                '<i class="fa fa-times"></i> ' . $lng_profile['delete_ignor'] .
                '</a>';
        }

        if (!functions::is_ignor($user['id']) && functions::is_contact($user['id']) !=
            2 && empty($ban['1']) && empty($ban['3']))
        {
            $sidebar .= '<a class="list-group-item" href="' . $set['homeurl'] .
                '/mail/index.php/act/write/id/' . $user['id'] .
                '" data-toggle="' . functions::set_modal() .
                '" data-target="#global-modal">' .
                '<i class="fa fa-envelope"></i> ' . $lng['write'] . '</a>';
        }
        $sidebar .= '</div>';
    }
    echo $sidebar;

    echo '</div>';
    echo '<div class="col-sm-6">';
    echo '<h3 class="page-header" style="margin-bottom:10px;">Blogs</h3>';
    $ubl = mysql_query("SELECT `id`,`title`,`url` FROM `blog_sites` WHERE `user_id`='" .
        $user['id'] . "'");
    $total_blog = mysql_num_rows($ubl);
    if ($total_blog)
    {
        echo '<ul class="list-group">';
        while ($blog = mysql_fetch_array($ubl))
        {
            echo '<li class="list-group-item">';
            echo '<a href="//' . $blog['url'] .
                '"><i class="fa fa-rss-square"></i> ' . htmlspecialchars($blog['title']) .
                '</a>';
            if ($user['id'] == $user_id || $rights == 7 || $rights == 9)
            {
                echo '<ul><li><a href="' . $home .
                    '/blogpanel/index.php/act/settings/id/' . $blog['id'] .
                    '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $home .
                    '/blogpanel/index.php/act/delete_blog/id/' . $blog['id'] .
                    '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></li></ul>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
    else
    {
        echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
    }
    if ($total_blog)
    {
        echo '<h3 class="page-header" style="margin-top:20px;margin-bottom:10px;">Blog Updates</h3>';
        $total_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `user_id`='" .
            $user['id'] . "' AND `time`<'" . time() . "'"), 0);
        if ($total_post)
        {
            echo '<ul class="list-group">';
            $new_posts = mysql_query("SELECT `id`,`site_id`,`title`,`permalink`,`time` FROM `blog_posts` WHERE `user_id`='" .
                $user['id'] . "' AND `time`<'" . time() .
                "' ORDER BY `time` DESC LIMIT 10");
            while ($post = mysql_fetch_array($new_posts))
            {
                $_blog = mysql_fetch_array(mysql_query("SELECT `url` FROM `blog_sites` WHERE `id`='" .
                    $post['site_id'] . "'"));
                echo '<li class="list-group-item">';
                echo '<a href="//' . $_blog['url'] . '/' . $post['permalink'] .
                    '.html">' . htmlspecialchars($post['title']) .
                    '</a><ul><li>' . functions::display_date($post['time']) .
                    '</li>';
                if ($user['id'] == $user_id || $rights == 7 || $rights == 9)
                {
                    echo '<li><a href="' . $home .
                        '/blogpanel/index.php/act/edit_post/post_id/' . $post['id'] .
                        '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $home .
                        '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' .
                        $post['id'] . '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></li>';
                }
                echo '</ul></li>';
            }
            echo '</ul>';
        }
        else
        {
            echo '<div class="alert alert-warning">' . $lng['list_empty'] .
                '</div>';
        }
    }
    echo '</div>';
    echo '</div>';
    if ($is_modal)
    {
        echo '<hr /><p class="text-right"><a class="func" href="' . $home .
            '/users/profile.php/user/' . $user['id'] . '">Kunjungi profil ' . $user['name'] .
            ' <i class="fa fa-angle-double-right"></i></a></p>';
    }
}

require_once ('../incfiles/end.php');
