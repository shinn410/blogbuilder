<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

$headmod = 'library';
require_once ('../incfiles/core.php');
$lng_lib = core::load_lng('library');
$textl = $lng['library'];

$error = '';
if (!$set['mod_lib'] && $rights < 7)
    $error = $lng_lib['library_closed'];
elseif ($set['mod_lib'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error)
{
    require_once ('../incfiles/head.php');
    echo '<div class="alert alert-danger"><p>' . $error . '</p></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if ($id)
{
    $req = mysql_query("SELECT * FROM `lib` WHERE `id`= '$id'");
    if (mysql_num_rows($req) == 0)
    {
        header('Location: ' . $home . '/library/');
        exit();
    }
    $zag = mysql_fetch_array($req);
    $hdr = $zag['type'] == 'bk' ? $zag['name'] : $zag['text'];
    $hdr = htmlentities(mb_substr($hdr, 0, 30), ENT_QUOTES, 'UTF-8');
    $textl = mb_strlen($zag['text']) > 30 ? $hdr . '...' : $hdr;
}
$main_header = 1;
require_once ('../incfiles/head.php');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['library'])));
$mods = array(
    'java',
    'new',
    'moder',
    'addkomm',
    'komm',
    'del',
    'edit',
    'load',
    'write',
    'mkcat',
    'topread',
    );
if ($act && ($key = array_search($act, $mods)) !== false && file_exists('includes/' .
    $mods[$key] . '.php'))
{
    require ('includes/' . $mods[$key] . '.php');
}
else
{
    if (!$set['mod_lib'])
        $warning = '<div class="alert alert-warning">' . $lng_lib['library_closed'] .
            '</div>';
    $brcm = array();
    if (!$id)
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<p><a class="func" href="' . $set['homeurl'] .
            '/library/search.php"><i class="fa fa-search"></i> ' . $lng['search'] .
            '</a>';
        if ($rights == 5 || $rights >= 6)
        {

            $req = mysql_query("SELECT COUNT(*) FROM `lib` WHERE `type` = 'bk' AND `moder` = '0'");
            $res = mysql_result($req, 0);
            if ($res > 0)
                $warning2 = '<div class="alert alert-danger">' . $lng['on_moderation'] .
                    ': <a class="alert-link" href="' . $set['homeurl'] .
                    '/library/index.php/act/moder">' . $res . '</a></div>';
        }

        $req = mysql_query("SELECT COUNT(*) FROM `lib` WHERE `time` > '" . (time
            () - 259200) . "' AND `type`='bk' AND `moder`='1'");
        $res = mysql_result($req, 0);
        if ($res > 0)
            echo '&nbsp;<a class="func" href="' . $set['homeurl'] .
                '/library/index.php/act/new"><i class="fa fa-flash"></i> ' . $lng_lib['new_articles'] .
                ' <span class="badge">' . $res . '</span></a>';
        echo '&nbsp;<a class="func" href="' . $set['homeurl'] .
            '/library/index.php/act/topread"><i class="fa fa-eye"></i> ' . $lng_lib['most_readed'] .
            '</a>';
        echo '</p>';
        if (isset($warning))
            echo $warning;
        if (isset($warning2))
            echo $warning2;
        $id = 0;
        $tip = "cat";
    }
    else
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $tip = $zag['type'];
        if ($tip == 'cat')
        {
            $dnam1 = $zag;
            $brcm[] = '<li class="active">' . $dnam1['text'] . '</li>';
            $page_header = $dnam1['text'];
        }
        else
        {
            $dnam = mysql_query("select `id`, `refid`, `text` from `lib` where type = 'cat' and id = '" .
                $zag['refid'] . "'");
            $dnam1 = mysql_fetch_array($dnam);
            $brcm[] = '<li class="active">' . htmlentities($zag['name'],
                ENT_QUOTES, 'UTF-8') . '</li>';
            $brcm[] = '<li><a href="' . $set['homeurl'] .
                '/library/index.php/id/' . $dnam1['id'] . '">' . $dnam1['text'] .
                '</a></li>';
            $page_header = htmlentities($zag['name'], ENT_QUOTES, 'UTF-8');
        }
        $dnam2 = mysql_query("select `id`, `refid`, `text` from `lib` where type = 'cat' and id = '" .
            $dnam1['refid'] . "'");
        $dnam3 = mysql_fetch_array($dnam2);
        $catname = "$dnam3[text]";
        $dirid = "$dnam1[id]";
        $nadir = $dnam1['refid'];
        while ($nadir != "0")
        {
            $brcm[] = '<li><a href="' . $set['homeurl'] .
                '/library/index.php/id/' . $nadir . '">' . $catname .
                '</a></li>';
            $dnamm = mysql_query("select `id`, `refid`, `text` from `lib` where type = 'cat' and id = '" .
                $nadir . "'");
            $dnamm1 = mysql_fetch_array($dnamm);
            $dnamm2 = mysql_query("select `id`, `refid`, `text` from `lib` where type = 'cat' and id = '" .
                $dnamm1['refid'] . "'");
            $dnamm3 = mysql_fetch_array($dnamm2);
            $nadir = $dnamm1['refid'];
            $catname = $dnamm3['text'];
        }
        $brcm[] = '<li><a href="' . $set['homeurl'] . '/library/index.php">' . $lng['library'] .
            '</a></li>';
        echo '<ol class="breadcrumb no-print">';
        $nom = count($brcm);
        while ($nom--)
            echo $brcm[$nom];
        echo '</ol>';
    }

    switch ($tip)
    {
        case 'cat':
            $req = mysql_query("SELECT COUNT(*) FROM `lib` WHERE `type` = 'cat' AND `refid` = '$id'");
            $totalcat = mysql_result($req, 0);
            $bkz = mysql_query("SELECT COUNT(*) FROM `lib` WHERE `type` = 'bk' AND `refid` = '$id' AND `moder`='1'");
            $totalbk = mysql_result($bkz, 0);
            if ($totalcat > 0)
            {
                $total = $totalcat;

                $req = mysql_query("SELECT `id`, `text`  FROM `lib` WHERE `type` = 'cat' AND `refid` = '$id' LIMIT " .
                    $start . "," . $kmess);
                $i = 0;
                echo '<div class="list-group">';
                while ($cat1 = mysql_fetch_array($req))
                {
                    $cat2 = mysql_query("select `id` from `lib` where type = 'cat' and refid = '" .
                        $cat1['id'] . "'");
                    $totalcat2 = mysql_num_rows($cat2);
                    $bk2 = mysql_query("select `id` from `lib` where type = 'bk' and refid = '" .
                        $cat1['id'] . "' and moder='1'");
                    $totalbk2 = mysql_num_rows($bk2);
                    if ($totalcat2 != 0)
                    {
                        $kol = "$totalcat2 kat.";
                    }
                    elseif ($totalbk2 != 0)
                    {
                        $kol = "$totalbk2 artikel.";
                    }
                    else
                    {
                        $kol = "0";
                    }

                    echo '<a class="list-group-item" href="' . $set['homeurl'] .
                        '/library/index.php/id/' . $cat1['id'] .
                        '"><span class="glyphicon glyphicon-book"></span> ' . $cat1['text'] .
                        ' <span class="badge">' . $kol . '</span></a>';
                    ++$i;
                }
                echo '</div>';

            }
            elseif ($totalbk > 0)
            {
                $total = $totalbk;
                if ($total > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                        '/library/index.php/id/' . $id . '/', $start, $total, $kmess) .
                        '</div>';
                $bk = mysql_query("select * from `lib` where type = 'bk' and refid = '" .
                    $id . "' and moder='1' order by `time` desc LIMIT " . $start .
                    "," . $kmess);
                $i = 0;
                while ($bk1 = mysql_fetch_array($bk))
                {
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                    echo '<b><a href="' . $set['homeurl'] .
                        '/library/index.php/id/' . $bk1['id'] .
                        '"><span class="glyphicon glyphicon-file"></span> ' .
                        htmlentities($bk1['name'], ENT_QUOTES, 'UTF-8') .
                        '</a></b><br/>';
                    echo htmlentities($bk1['announce'], ENT_QUOTES, 'UTF-8');
                    echo '<div class="sub"><span class="gray">' . $lng_lib['added'] .
                        ':</span> ' . $bk1['avtor'] . ' (' . functions::display_date($bk1['time']) .
                        ')<br />';
                    echo '<span class="gray">' . $lng_lib['reads'] . ':</span> ' .
                        $bk1['count'] . '</div></div>';
                    ++$i;
                }

            }
            else
            {
                $total = 0;
                echo '<div class="alert alert-warning">' . $lng['list_empty'] .
                    '</div>';
            }

            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/library/index.php/id/' . $id . '/', $start, $total, $kmess) .
                    '</div>';
            }
            echo '<hr class="hidden-xs"/><ul class="nav nav-pills">';
            if (($rights == 5 || $rights >= 6) && $id != 0)
            {
                $ct = mysql_query("select `id` from `lib` where type='cat' and refid='" .
                    $id . "'");
                $ct1 = mysql_num_rows($ct);
                if ($ct1 == 0)
                {
                    echo '<li><a href="' . $set['homeurl'] .
                        '/library/index.php/act/del/id/' . $id .
                        '"><i class="fa fa-times"></i> ' . $lng_lib['delete_category'] .
                        '</a></li>';
                }
                echo '<li><a href="' . $set['homeurl'] .
                    '/library/index.php/act/edit/id/' . $id .
                    '"><i class="fa fa-edit"></i> ' . $lng_lib['edit_category'] .
                    '</a></li>';
            }
            if (($rights == 5 || $rights >= 6) && (isset($zag['ip']) && $zag['ip'] ==
                1 || $id == 0))
            {
                echo '<li><a href="' . $set['homeurl'] .
                    '/library/index.php/act/mkcat/id/' . $id .
                    '"><i class="fa fa-plus"></i> ' . $lng_lib['create_category'] .
                    '</a></li>';
            }
            if (isset($zag['ip']) && $zag['ip'] == 0 && $id != 0)
            {
                if (($rights == 5 || $rights >= 6) || ($zag['soft'] == 1 && !
                    empty($_SESSION['uid'])))
                {
                    echo "<li><a href='" . $home .
                        "/library/index.php/act/write/id/" . $id . "'><i class=\"fa fa-pencil\"></i> " .
                        $lng_lib['write_article'] . "</a></li>";
                }
                if ($rights == 5 || $rights >= 6)
                {
                    echo "<li><a href='" . $home .
                        "/library/index.php/act/load/id/" . $id . "'><i class=\"fa fa-upload\"></i> " .
                        $lng_lib['upload_article'] . "</a></li>";
                }
            }
            echo '</ul>';
            if ($id)
                echo '<p>' . functions::link_back($lng_lib['to_library'],
                    'library/') . '</p>';
            break;

        case 'bk':
            if (!empty($_SESSION['symb']))
            {
                $simvol = $_SESSION['symb'];
            }
            else
            {
                $simvol = 2000;

            }

            if (!isset($_SESSION['lib']) || isset($_SESSION['lib']) && $_SESSION['lib'] !=
                $id)
            {
                $_SESSION['lib'] = $id;
                $libcount = intval($zag['count']) + 1;
                mysql_query("UPDATE `lib` SET  `count` = '$libcount' WHERE `id` = '$id'");
            }

            $symbols = core::$is_mobile ? 3000 : 7000;
            $req = mysql_fetch_assoc(mysql_query("SELECT CHAR_LENGTH(`text`) / $symbols AS `count_pages` FROM `lib` WHERE `id`= '$id'"));
            $count_pages = ceil($req['count_pages']);
            $start_pos = $page == 1 ? 1 : $page * $symbols - $symbols;
            $req = mysql_fetch_assoc(mysql_query("SELECT SUBSTRING(`text`, $start_pos, " .
                ($symbols + 100) . ") AS `text` FROM `lib` WHERE `id` = '$id'"));
            if ($page == 1)
            {
                $int_start = 0;
            }
            else
            {
                if (false === ($pos1 = mb_strpos($req['text'], "\r\n")))
                    $pos1 = 100;
                if (false === ($pos2 = mb_strpos($req['text'], ' ')))
                    $pos2 = 100;
                $int_start = $pos1 >= $pos2 ? $pos2 : $pos1;
                $start = $page - 1;
            }
            if ($count_pages == 1 || $page == $count_pages)
            {
                $int_lenght = $symbols;
            }
            else
            {
                $tmp = mb_substr($req['text'], $symbols, 100);
                if (($pos1 = mb_strpos($tmp, "\r\n")) === false)
                    $pos1 = 100;
                if (($pos2 = mb_strpos($tmp, ' ')) === false)
                    $pos2 = 100;
                $int_lenght = $symbols + ($pos1 >= $pos2 ? $pos2 : $pos1) - $int_start;
            }
            $text = functions::checkout(mb_substr($req['text'], $int_start, $int_lenght),
                1, 1);
            if ($set_user['smileys'])
                $text = functions::smileys($text, $rights ? 1 : 0);
            echo '<div class="box box-solid"><div class="box-header"><h3 class="box-title">' .
                htmlentities($zag['name'], ENT_QUOTES, 'UTF-8') .
                '</h3></div><div class="box-body">' . $text .
                '</div><div class="box-footer"><ul class="list-unstyled"><li>' .
                '<i class="fa fa-user"></i> ' . $lng_lib['added'] . ': ' . $zag['avtor'] .
                ' (' . functions::display_date($zag['time']) . ')</li>' .
                '<li><i class="fa fa-eye"></i> ' . $lng_lib['reads'] . ': ' . $zag['count'] .
                '</li>';

            if ($set['mod_lib_comm'] || $rights >= 7)
            {
                $km = mysql_query("select `id` from `lib` where type = 'komm' and refid = '" .
                    $id . "'");
                $km1 = mysql_num_rows($km);
                echo "<li class='no-print'><i class=\"fa fa-comments\"></i> <a href='" .
                    $home . "/library/index.php/act/komm/id/" . $id . "'>" . $lng['comments'] .
                    "</a> ($km1)</li>";
            }
            echo '</ul></div></div>';
            if ($count_pages > 1)
            {
                echo '<div class="topmenu no-print">' . functions::display_pagination($set['homeurl'] .
                    '/library/index.php/id/' . $id . '/', $start, $count_pages,
                    1) . '</div>';
            }
            echo '<ul class="nav nav-pills no-print">';
            if ($rights == 5 || $rights >= 6)
            {
                echo '<li><a href="' . $set['homeurl'] .
                    '/library/index.php/act/edit/id/' . $id .
                    '"><i class="fa fa-edit"></i> ' . $lng['edit'] . '</a></li>';
                echo '<li><a href="' . $set['homeurl'] .
                    '/library/index.php/act/del/id/' . $id .
                    '"><i class="fa fa-times"></i> ' . $lng['delete'] .
                    '</a></li>';
            }
            echo '<li><a href="javascript:;" onclick="window.print()">' .
                '<i class="fa fa-print"></i> Print</a></li>';
            echo '<li><a href="' . $set['homeurl'] .
                '/library/index.php/act/java/id/' . $id .
                '"><i class="fa fa-download"></i> ' . $lng_lib['download_java'] .
                '</a></li>';
            echo '</ul>';
            echo '<p class="no-print">' . functions::link_back($lng_lib['to_library'],
                'library/') . '</p>';
            break;
        default:
            header("location: " . $home . "/library/index.php");
            break;
    }
}

require_once ('../incfiles/end.php');

?>
