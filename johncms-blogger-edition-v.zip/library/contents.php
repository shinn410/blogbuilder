<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$textl = $lng['library'] . ' Map';
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $textl)));
require ('../incfiles/head.php');
$map = new sitemap();
echo $map->library_contents();
require ('../incfiles/end.php');

?>