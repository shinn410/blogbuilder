<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights == 5 || $rights >= 6)
{
    if ($_GET['id'] == "" || $_GET['id'] == "0")
    {
        header("location: " . $home . "/library/index.php");
        exit;
    }
    $req = mysql_query("SELECT * FROM `lib` WHERE `id` = '" . $id . "'");
    if (mysql_num_rows($req) == 0)
    {
        header("location: " . $home . "/library/index.php");
        exit();
    }
    $ms = mysql_fetch_array($req);
    if (isset($_POST['submit']))
    {
        switch ($ms['type'])
        {
            case "bk":


                if (empty($_POST['name']))
                {
                    echo functions::main_header($breadcrumbs[count($breadcrumbs) -
                        1]['label'], $breadcrumb);
                    echo functions::display_error($lng['error_empty_title'],
                        '<a class="alert-link" href="' . $set['homeurl'] .
                        '/library/index.php/act/edit/id/' . $id . '">' . $lng['repeat'] .
                        '</a>');
                    require_once ('../incfiles/end.php');
                    exit;
                }
                if (empty($_POST['text']))
                {
                    echo functions::main_header($breadcrumbs[count($breadcrumbs) -
                        1]['label'], $breadcrumb);
                    echo functions::display_error($lng['error_empty_text'],
                        '<a class="alert-link" href="' . $set['homeurl'] .
                        '/library/index.php/act/edit/id/' . $id . '">' . $lng['repeat'] .
                        '</a>');
                    require_once ('../incfiles/end.php');
                    exit;
                }
                $text = trim($_POST['text']);
                $autor = isset($_POST['autor']) ? functions::check($_POST['autor']) :
                    '';
                $count = isset($_POST['count']) ? abs(intval($_POST['count'])) :
                    '0';
                if (!empty($_POST['anons']))
                {
                    $anons = mb_substr(trim($_POST['anons']), 0, 100);
                }
                else
                {
                    $anons = mb_substr($text, 0, 100);
                }
                mysql_query("UPDATE `lib` SET
                    `name` = '" . mysql_real_escape_string(mb_substr(trim($_POST['name']),
                    0, 100)) . "',
                    `announce` = '" . mysql_real_escape_string($anons) . "',
                    `text` = '" . mysql_real_escape_string($text) . "',
                    `avtor` = '$autor',
                    `count` = '$count'
                    WHERE `id` = '$id'
                ");
                header('location: ' . $home . '/library/index.php/id/' . $id);
                break;

            case "cat":


                $text = functions::check($_POST['text']);
                if (!empty($_POST['user']))
                {
                    $user = intval($_POST['user']);
                }
                else
                {
                    $user = 0;
                }
                $mod = intval($_POST['mod']);
                mysql_query("UPDATE `lib` SET
                `text` = '" . $text . "',
                `ip` = '" . $mod . "',
                `soft` = '" . $user . "'
                WHERE `id` = '" . $id . "'");
                header('location: ' . $home . '/library/index.php/id/' . $id);
                break;
            default:


                $text = functions::check($_POST['text']);
                mysql_query("update `lib` set text='" . $text . "' where id='" .
                    $id . "';");
                header("location: " . $home . "/library/index.php/id/$ms[refid]");
                break;
        }
    }
    else
    {
        switch ($ms['type'])
        {
            case 'bk':
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                            $lng['library'], 'url' => 'library/index.php/id/' .
                            $id), array('label' => $lng_lib['edit_article'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo '<!-- <h1 class="page-header">' . $lng_lib['edit_article'] .
                    '</h1> -->';
                echo '<form role="form" action="' . $set['homeurl'] .
                    '/library/index.php/act/edit/id/' . $id . '" method="post">' .
                    '<div class="form-group">' .
                    '<label class="control-label dis-block">' . $lng['title'] .
                    '</label>' .
                    '<input class="form-control" type="text" name="name" value="' .
                    htmlentities($ms['name'], ENT_QUOTES, 'UTF-8') . '"/>' .
                    '</div>' . '<div class="form-group">' .
                    '<label class="control-label dis-block">' . $lng_lib['announce'] .
                    '</label>' .
                    '<input class="form-control" type="text" name="anons" value="' .
                    htmlentities($ms['announce'], ENT_QUOTES, 'UTF-8') . '"/>' .
                    '<p class="help-block">' . $lng_lib['announce_help'] .
                    '</p>' . '</div>' . '<div class="form-group">' .
                    '<label class="control-label dis-block">' . $lng['text'] .
                    '</label>' .
                    '<textarea class="form-control" rows="5" name="text">' .
                    htmlentities($ms['text'], ENT_QUOTES, 'UTF-8') .
                    '</textarea>' . '</div>' .
                    '<div class="alert alert-danger">' .
                    '<div class="form-group">' .
                    '<label class="control-label dis-block">' . $lng['author'] .
                    '</label>' .
                    '<input class="form-control" type="text" name="autor" value="' .
                    $ms['avtor'] . '"/>' . '</div>' . '<div class="form-group">' .
                    '<label class="control-label dis-block">' . $lng_lib['reads'] .
                    '</label>' .
                    '<input class="form-control" type="text" name="count" value="' .
                    $ms['count'] . '" size="4"/>' . '</div>' . '</div>' .
                    '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                    $lng['save'] . '"/></p>' . '</form>' . '<p>' . functions::link_back($lng['back'],
                    'library/index.php/id/' . $id) . '</p>';
                break;

            case "cat":
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                            $lng['library'], 'url' => 'library/index.php/id/' .
                            $id), array('label' => $lng_lib['edit_category'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo '<!-- <h1 class="page-header">' . $lng_lib['edit_category'] .
                    '</h1> -->';
                echo '<form action="' . $set['homeurl'] .
                    '/library/index.php/act/edit/id/' . $id . '" method="post">' .
                    '<div class"form-group">' .
                    '<label class="control-label dis-block">' . $lng['title'] .
                    '</label>' .
                    '<input class="form-control" type="text" name="text" value="' .
                    $ms['text'] . '"/>' . '</div>' . '<div class"form-group">' .
                    '<label class="control-label dis-block">' . $lng_lib['category_type'] .
                    '</label>' . '<select class="form-control" name="mod">';
                if ($ms['ip'] == 1)
                {
                    echo '<option value="1">' . $lng['categories'] .
                        '</option><option value="0">' . $lng_lib['articles'] .
                        '</option>';
                }
                else
                {
                    echo '<option value="0">' . $lng_lib['articles'] .
                        '</option><option value="1">' . $lng['categories'] .
                        '</option>';
                }
                echo '</select>' . '<p class="help-block">' . $lng_lib['edit_category_help'] .
                    '</p>' . '</div>';
                if ($ms['soft'] == 1)
                {
                    echo
                        '<div class="checkbox"><label><input type="checkbox" name="user" value="1" checked="checked" /> ' .
                        $lng_lib['allow_to_add'] . '</label></div>';
                }
                else
                {
                    echo
                        '<div class="checkbox"><label><input type="checkbox" name="user" value="1"/> ' .
                        $lng_lib['allow_to_add'] . '</label></div>';
                }
                echo
                    '<input class="btn btn-primary" type="submit" name="submit" value="' .
                    $lng['save'] . '"/>' . '</form>' . '<p>' . functions::link_back($lng['back'],
                    'library/index.php/id/' . $ms['refid']) . '</p>';
                break;
        }
    }
}
else
{
    header("location: " . $home . "/library/index.php");
}

?>