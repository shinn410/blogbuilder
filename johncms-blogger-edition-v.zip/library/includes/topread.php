<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['library'],
            'url' => 'library/index.php/'), array('label' => $lng_lib['top_read'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if ($start > 50)
    $start = 40;
$req = mysql_query("select * from `lib` where `type` = 'bk' and `moder`='1' and `count`>'0' ORDER BY `count` DESC LIMIT " .
    $start . "," . $kmess);
$total = mysql_num_rows($req);
if ($total)
{
    $i = 0;
    while ($res = mysql_fetch_array($req))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<b><a href="' . $set['homeurl'] . '/library/index.php/id/' . $res['id'] .
            '"><span class="glyphicon glyphicon-file"></span> ' . htmlentities($res['name'],
            ENT_QUOTES, 'UTF-8') . '</a></b><br/>';
        echo htmlentities($res['announce'], ENT_QUOTES, 'UTF-8');
        echo '<div class="sub"><span class="gray">' . $lng_lib['added'] .
            ':</span> ' . $res['avtor'] . ' (' . functions::display_date($res['time']) .
            ')<br />';
        echo '<span class="gray">' . $lng_lib['reads'] . ':</span> ' . $res['count'] .
            '</br/>';


        $nadir = $res['refid'];
        $dirlink = $nadir;
        $pat = "";
        while ($nadir != "0")
        {
            $dnew = mysql_query("select * from `lib` where type = 'cat' and id = '" .
                $nadir . "';");
            $dnew1 = mysql_fetch_array($dnew);
            $pat = $dnew1['text'] . '/' . $pat;
            $nadir = $dnew1['refid'];
        }
        $l = mb_strlen($pat);
        $pat1 = mb_substr($pat, 0, $l - 1);
        echo '[<a href="' . $set['homeurl'] . '/library/index.php/id/' . $dirlink .
            '"><span class="glyphicon glyphicon-book"></span> ' . $pat1 .
            '</a>]</div>';
        echo '</div>';
        ++$i;
    }
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/library/index.php/act/topread/', $start, $total, $kmess) .
            '</div>';
}
else
{
    echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
}
echo '<p>' . functions::link_back($lng_lib['to_library'], 'library/') . '</p>';
