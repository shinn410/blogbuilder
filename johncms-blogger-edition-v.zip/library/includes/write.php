<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if (!$id)
{
    header("location: " . $home . "/library/index.php");
    exit;
}


$old = ($rights > 0) ? 5 : 60;
if ($datauser['lastpost'] > (time() - $old))
{
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo '<div class="alert alert-danger">' . $lng['error_flood'] . ' ' . $old .
        ' ' . $lng['sec'] . '<br/><a class="alert-link" href ="index.php/id/' .
        $id . '">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$typ = mysql_query("select * from `lib` where id='" . $id . "';");
if (mysql_num_rows($typ) == 0)
{
    header("location: " . $home . "/library/index.php");
    exit();
}
$ms = mysql_fetch_array($typ);
if ($ms['type'] != "cat")
{
    header("location: " . $home . "/library/index.php");
    exit();
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['library'],
            'url' => 'library/index.php/id/' . $id), array('label' => $lng_lib['write_article'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if ($ms['ip'] == 0)
{
    if (($rights == 5 || $rights >= 6) || ($ms['soft'] == 1 && !empty($_SESSION['uid'])))
    {
        if (isset($_POST['submit']))
        {
            if (empty($_POST['name']))
            {
                echo "<div class='alert alert-danger'>" . $lng['error_empty_title'] .
                    "<br/><a class='alert-link' href='" . $home .
                    "/library/index.php/act/write/id/" . $id . "'>" . $lng['repeat'] .
                    "</a></div>";
                require_once ('../incfiles/end.php');
                exit;
            }
            if (empty($_POST['text']))
            {
                echo "<div class='alert alert-danger'>" . $lng['error_empty_text'] .
                    "<br/><a class='alert-link' href='" . $home .
                    "/library/index.php/act/write/id/" . $id . "'>" . $lng['repeat'] .
                    "</a></div>";
                require_once ('../incfiles/end.php');
                exit;
            }
            $text = trim($_POST['text']);
            if (!empty($_POST['anons']))
            {
                $anons = mb_substr(trim($_POST['anons']), 0, 100);
            }
            else
            {
                $anons = mb_substr($text, 0, 100);
            }
            if ($rights == 5 || $rights >= 6)
            {
                $md = 1;
            }
            else
            {
                $md = 0;
            }
            mysql_query("INSERT INTO `lib` SET
                `refid` = '$id',
                `time` = '" . time() . "',
                `type` = 'bk',
                `name` = '" . mysql_real_escape_string(mb_substr(trim($_POST['name']),
                0, 100)) . "',
                `announce` = '" . mysql_real_escape_string($anons) . "',
                `text` = '" . mysql_real_escape_string($text) . "',
                `avtor` = '$login',
                `ip` = '$ip',
                `soft` = '" . mysql_real_escape_string($agn) . "',
                `moder` = '$md'
            ");
            $cid = mysql_insert_id();
            if ($md == 1)
            {
                $return = $lng_lib['article_added'];
            }
            else
            {
                $return = $lng_lib['article_added'] . '<br/>' . $lng_lib['article_added_thanks'];
            }
            mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
                "' WHERE `id` = '" . $user_id . "'");
            echo '<div class="alert alert-success"><p>' . $return .
                '</p><p><a class="alert-link" href="' . $set['homeurl'] .
                '/library/index.php/id/' . $cid . '">' . $lng_lib['to_article'] .
                '</a></p></div>';
        }
        else
        {
            echo '<form role="form" action="' . $set['homeurl'] .
                '/library/index.php/act/write/id/' . $id . '" method="post">';
            echo '<div class="form-group">' . '<label class="control-label">' .
                $lng['title'] .
                ' <span class="label-help">(max. 100)</span></label>' .
                '<input class="form-control" type="text" name="name"/>' .
                '</div>';
            echo '<div class="form-group">' . '<label class="control-label">' .
                $lng_lib['announce'] .
                ' <span class="label-help">(max. 100)</span></label>' .
                '<input class="form-control" type="text" name="anons"/>' .
                '</div>';
            echo '<div class="form-group">' . '<label class="control-label">' .
                $lng['text'] . '</label>' .
                '<textarea class="form-control" name="text" rows="' . $set_user['field_h'] .
                '"></textarea>' . '</div>';
            echo '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng['save'] . '"/></p>';
            echo '</form><p>' . functions::link_back($lng['back'],
                'library/index.php/id/' . $id) . '</p>';
        }
    }
    else
    {
        header("location: " . $home . "/library/index.php");
    }
}

?>