<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights == 5 || $rights >= 6)
{
    if ($_GET['id'] == "")
    {
        header("location: " . $home . "/library/index.php");
        exit;
    }
    $typ = mysql_query("select * from `lib` where id='" . $id . "';");
    $ms = mysql_fetch_array($typ);
    if ($id != 0 && ($ms['type'] == "bk" || $ms['type'] == "komm"))
    {
        header("location: " . $home . "/library/index.php");
        exit;
    }
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['library'],
                'url' => 'library/index.php/id/' . $id), array('label' => $lng_lib['create_category'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if (isset($_POST['submit']))
    {
        if (empty($_POST['text']))
        {
            echo functions::display_error($lng['error_empty_title'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/library/index.php/act/mkcat/id/' . $id . '">' . $lng['repeat'] .
                '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        $text = functions::check($_POST['text']);
        $user = isset($_POST['user']);
        $typs = intval($_POST['typs']);
        mysql_query("INSERT INTO `lib` SET
            `refid` = '$id',
            `time` = '" . time() . "',
            `type` = 'cat',
            `text` = '$text',
            `ip` = '$typs',
            `soft` = '$user'
        ");
        $cid = mysql_insert_id();
        echo "<div class='alert alert-success'>" . $lng_lib['category_created'] .
            "<br/><a class='alert-link' href='" . $home .
            "/library/index.php/id/" . $cid . "'>" . $lng_lib['to_category'] .
            "</a></div>";
    }
    else
    {
        echo '<form role="form" action="' . $set['homeurl'] .
            '/library/index.php/act/mkcat/id/' . $id . '" method="post">' .
            '<div class"form-group">' .
            '<label class="control-label dis-block">' . $lng['title'] .
            '</label>' . '<input class="form-control" type="text" name="text"/>' .
            '</div>' . '<div class"form-group">' .
            '<label class="control-label dis-block">' . $lng_lib['category_type'] .
            '</label>' . '<select class="form-control" name="typs">' .
            '<option value="1">' . $lng_lib['categories'] . '</option>' .
            '<option value="0">' . $lng_lib['articles'] . '</option>' .
            '</select>' . '</div>' .
            '<div class="checkbox"><label><input type="checkbox" name="user" value="1"/> ' .
            $lng_lib['if_articles'] . '</label></div>' .
            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['save'] . '"/></p>' . '</form>' . '<p>' . functions::link_back($lng['back'],
            'library/index.php/id/' . $id) . '</p>';
    }
}
else
{
    header("location: " . $home . "/library/index.php");
    exit();
}

?>