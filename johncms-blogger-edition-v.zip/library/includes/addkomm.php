<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($user_id && !isset($ban['1']) && !isset($ban['10']) && ($set['mod_lib_comm'] ||
    $rights >= 7))
{
    if (!$id)
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo functions::display_error('Forbidden!');
        require_once ('../incfiles/end.php');
        exit;
    }
    $req = mysql_query("SELECT `name` FROM `lib` WHERE `type` = 'bk' AND `id` = '" .
        $id . "' LIMIT 1");
    if (mysql_num_rows($req) != 1)
    {
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);

        echo functions::display_error('Not Found!<br/><a class="alert-link" href="' .
            $set['homeurl'] . '/library/index.php">Back</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    $res = mysql_fetch_array($req);
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['library'], 'url' => 'library/index.php/'),
        array('label' => htmlentities($res['name'], ENT_QUOTES, 'UTF-8'), 'url' =>
                'library/index.php/id/' . $id),
        array('label' => $lng['comments'], 'url' =>
                '/library/index.php/act/komm/id/' . $id),
        array('label' => $lng_lib['write_comment']),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo '<!-- <h1 class="page-header">' . $lng_lib['write_comment'] .
        '</h1> -->';

    $flood = functions::antiflood();
    if ($flood)
    {
        echo functions::display_error($lng['error_flood'] . ' ' . $flood . ' ' .
            $lng['sec'], '<a class="alert-link" href="' . $set['homeurl'] .
            '/library/index.php/act/komm/id/' . $id . '">' . $lng['back'] .
            '</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    if (isset($_POST['submit']))
    {
        if ($_POST['msg'] == "")
        {
            echo functions::display_error($lng['error_empty_message'] .
                "<br/><a class=\"alert-link\" href='" . $home .
                "/library/index.php/act/komm/id/" . $id . "'>" . $lng['back'] .
                "</a>");
            require_once ('../incfiles/end.php');
            exit;
        }
        $msg = functions::check($_POST['msg']);
        if (isset($_POST['msgtrans']) && $_POST['msgtrans'] == 1)
        {
            $msg = functions::trans($msg);
        }
        $msg = mb_substr($msg, 0, 500);
        $agn = strtok($agn, ' ');
        mysql_query("INSERT INTO `lib` SET
            `refid` = '" . $id . "',
            `time` = '" . time() . "',
            `type` = 'komm',
            `avtor` = '" . $login . "',
            `count` = '" . $user_id . "',
            `text` = '" . mysql_real_escape_string($msg) . "',
            `ip` = '" . $ip . "',
            `soft` = '" . mysql_real_escape_string($agn) . "'
        ");
        $fpst = $datauser['komm'] + 1;
        mysql_query("UPDATE `users` SET
            `komm`='" . $fpst . "',
            `lastpost` = '" . time() . "'
            WHERE `id`='" . $user_id . "'
        ");
        echo '<div class="alert alert-success">' . $lng_lib['comment_added'] .
            '</div>';
    }
    else
    {
        echo "<form action='" . $home . "/library/index.php/act/addkomm/id/" . $id .
            "' method='post'>
        <div class='form-group'>
        <label class='control-label'>" . $lng['message'] . "</label>
        <textarea class='form-control' rows='3' name='msg'></textarea>
        </div>
        <div class='checkbox'><label><input type='checkbox' name='msgtrans' value='1' /> " .
            $lng['translit'] . "</label></div>
        <input class='btn btn-primary' type='submit' name='submit' value='" . $lng['save'] .
            "' />
        </form><br/>";
        echo '<p>' . functions::display_translit() . '</p>';
    }
    echo '<p>' . functions::link_back($lng_lib['to_comments'],
        'library/index.php/act/komm/id/' . $id) . '</p>';
}
else
{

    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo functions::display_error('Forbidden!');
}

?>