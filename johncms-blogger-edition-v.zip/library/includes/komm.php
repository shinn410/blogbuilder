<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$id)
{
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo functions::display_error('ERROR', '<a class="alert-link" href="' . $set['homeurl'] .
        '/library/index.php">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}
if (!$set['mod_lib_comm'] && $rights < 7)
{
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo functions::display_error($lng['comments_closed'],
        '<a class="alert-link" href="' . $set['homeurl'] .
        '/library/index.php">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}

$req = mysql_query("SELECT `name` FROM `lib` WHERE `type` = 'bk' AND `id` = '" .
    $id . "' LIMIT 1");
if (mysql_num_rows($req) != 1)
{
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);

    echo functions::display_error('ERROR', '<a class="alert-link" href="' . $set['homeurl'] .
        '/library/index.php">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}
$article = mysql_fetch_array($req);

$req = mysql_query("SELECT COUNT(*) FROM `lib` WHERE `type` = 'komm' AND `refid` = '" .
    $id . "'");
$countm = mysql_result($req, 0);
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['library'], 'url' => 'library/index.php/'),
    array('label' => htmlentities($article['name'], ENT_QUOTES, 'UTF-8'), 'url' =>
            'library/index.php/id/' . $id),
    array('label' => $lng['comments'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
echo '<!-- <h1 class="page-header">' . $lng['comments'] . '</h1> -->';

if ($user_id && !isset($ban['1']) && !isset($ban['10']))
{
    echo '<p><a class="btn btn-primary" href="' . $set['homeurl'] .
        '/library/index.php/act/addkomm/id/' . $id . '">' . $lng['write'] .
        '</a></p>';
}

$mess = mysql_query("SELECT * FROM `lib` WHERE `type` = 'komm' AND `refid` = '" .
    $id . "' ORDER BY `time` DESC LIMIT " . $start . "," . $kmess);
$i = 0;
if ($countm)
{
    while ($mass = mysql_fetch_array($mess))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        $uz = mysql_query("select * from `users` where name='" . functions::check
            ($mass['avtor']) . "';");
        $mass1 = mysql_fetch_array($uz);
        if ((!empty($_SESSION['uid'])) && ($_SESSION['uid'] != $mass1['id']))
        {
            echo "<a href='" . $home . "/users/profile.php/user/" . $mass1['id'] .
                "'>$mass[avtor]</a>";
        }
        else
        {
            echo $mass['avtor'];
        }
        switch ($mass1['rights'])
        {
            case 7:
                echo ' Adm ';
                break;

            case 6:
                echo ' Smd ';
                break;

            case 5:
                echo ' Mod ';
                break;

            case 1:
                echo ' Kil ';
                break;
        }
        $ontime = $mass1['lastdate'];
        $ontime2 = $ontime + 300;
        if (time() > $ontime2)
        {
            echo '<font color="#FF0000"> [Off]</font>';
        }
        else
        {
            echo '<font color="#00AA00"> [ON]</font>';
        }
        echo '(' . functions::display_date($mass['time']) . ')<br/>';
        if ($set_user['smileys'])
        {
            $tekst = functions::smileys($mass['text'], ($mass1['rights'] >= 1) ?
                1 : 0);
        }
        else
        {
            $tekst = $mass['text'];
        }
        echo "$tekst<br/>";
        if ($rights == 5 || $rights >= 6)
        {
            echo long2ip($mass['ip']) . " - $mass[soft]<br/><a href='" . $home .
                "/library/index.php/act/del/id/" . $mass['id'] . "'><span class=\"glyphicon glyphicon-remove\"></span> " .
                $lng['delete'] . "</a>";
        }
        echo '</div>';
        ++$i;
    }
}
else
{
    echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
}


if ($countm > $kmess)
{
    echo '<p>' . functions::display_pagination($set['homeurl'] .
        '/library/index.php/act/komm/id/' . $id . '/', $start, $countm, $kmess) .
        '</p>';
}
echo '<p>' . functions::link_back($lng['back'], 'library/index.php/id/' . $id) .
    '</p>';
