<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);

require ('../incfiles/core.php');
$lng_forum = core::load_lng('forum');
if (isset($_SESSION['ref']))
    unset($_SESSION['ref']);

$set_forum = $user_id && !empty($datauser['set_forum']) ? unserialize($datauser['set_forum']) :
    array(
    'farea' => 0,
    'upfp' => 0,
    'preview' => 1,
    'postclip' => 1,
    'postcut' => 2);

$ext_arch = array(
    'zip',
    'rar',
    '7z',
    'tar',
    'gz',
    'apk');

$ext_audio = array('mp3', 'amr');

$ext_doc = array(
    'txt',
    'pdf',
    'doc',
    'docx',
    'rtf',
    'djvu',
    'xls',
    'xlsx');

$ext_java = array(
    'sis',
    'sisx',
    'apk');

$ext_pic = array(
    'jpg',
    'jpeg',
    'gif',
    'png',
    'bmp');

$ext_sis = array('sis', 'sisx');

$ext_video = array(
    '3gp',
    'avi',
    'flv',
    'mpeg',
    'mp4');

$ext_win = array('exe', 'msi');

$ext_other = array('wmf');

$error = '';
if (!$set['mod_forum'] && $rights < 7)
    $error = $lng_forum['forum_closed'];
elseif ($set['mod_forum'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error)
{
    require ('../incfiles/head.php');
    echo '<div class="alert alert-danger"><p>' . $error . '</p></div>';
    require ('../incfiles/end.php');
    exit;
}

$headmod = $id ? 'forum,' . $id : 'forum';

if (empty($id))
{
    $textl = '' . $lng['forum'] . '';
}
else
{
    $req = mysql_query("SELECT `text` FROM `forum` WHERE `id`= '" . $id . "'");
    $res = mysql_fetch_assoc($req);
    $hdr = strtr($res['text'], array(
        '&laquo;' => '',
        '&raquo;' => '',
        '&quot;' => '',
        '&amp;' => '',
        '&lt;' => '',
        '&gt;' => '',
        '&#039;' => ''));
    $hdr = mb_substr($hdr, 0, 30);
    $hdr = functions::checkout($hdr);
    $textl = mb_strlen($res['text']) > 30 ? $hdr . '...' : $hdr;
}

$mods = array(
    'addfile',
    'addvote',
    'close',
    'deltema',
    'delvote',
    'editpost',
    'editvote',
    'file',
    'files',
    'filter',
    'loadtem',
    'massdel',
    'new',
    'nt',
    'per',
    'post',
    'ren',
    'restore',
    'say',
    'tema',
    'users',
    'vip',
    'vote',
    'who',
    'curators',
    );
$main_header = 1;
if ($act && ($key = array_search($act, $mods)) !== false && file_exists('includes/' .
    $mods[$key] . '.php'))
{
    require ('includes/' . $mods[$key] . '.php');
}
else
{
    require ('../incfiles/head.php');

    if (!$set['mod_forum'])
        echo '<div class="alert alert-warning">' . $lng_forum['forum_closed'] .
            '</div>';
    elseif ($set['mod_forum'] == 3)
        echo '<div class="alert alert-danger">' . $lng['read_only'] . '</div>';
    if (!$user_id)
    {
        if (isset($_GET['newup']))
            $_SESSION['uppost'] = 1;
        if (isset($_GET['newdown']))
            $_SESSION['uppost'] = 0;
    }
    if ($id)
    {
        $type = mysql_query("SELECT * FROM `forum` WHERE `id`= '$id'");
        if (!mysql_num_rows($type))
        {

            echo functions::display_error($lng_forum['error_topic_deleted'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/forum/index.php">' . $lng['to_forum'] . '</a>');
            require ('../incfiles/end.php');
            exit;
        }
        $type1 = mysql_fetch_assoc($type);

        if ($user_id && $type1['type'] == 't')
        {
            $req_r = mysql_query("SELECT * FROM `cms_forum_rdm` WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            if (mysql_num_rows($req_r))
            {
                $res_r = mysql_fetch_assoc($req_r);
                if ($type1['time'] > $res_r['time'])
                    mysql_query("UPDATE `cms_forum_rdm` SET `time` = '" . time() .
                        "' WHERE `topic_id` = '$id' AND `user_id` = '$user_id' LIMIT 1");
            }
            else
            {
                mysql_query("INSERT INTO `cms_forum_rdm` SET `topic_id` = '$id', `user_id` = '$user_id', `time` = '" .
                    time() . "'");
            }
        }

        $res = true;
        $allow = 0;
        $tree = array();
        $parent = $type1['refid'];
        while ($parent != '0' && $res != false)
        {
            $req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$parent' LIMIT 1");
            $res = mysql_fetch_assoc($req);
            if ($res['type'] == 'f' || $res['type'] == 'r')
            {
                $tree[] = array('label' => $res['text'], 'url' =>
                        '/forum/index.php/id/' . $parent);

                if ($res['type'] == 'r' && !empty($res['edit']))
                {
                    $allow = intval($res['edit']);
                }
            }
            $parent = $res['refid'];
        }
        $tree[] = array('label' => $lng['forum'], 'url' => '/forum/index.php');

        krsort($tree);
        if ($type1['type'] != 't' && $type1['type'] != 'm')
            $tree[] = array('label' => $type1['text']);
        $page_title = $type1['text'];

        $sql = ($rights == 9) ? "" : " AND `del` != '1'";
        if ($type1['type'] == 'f')
        {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `cat` = '$id'" .
                $sql), 0);
            if ($count > 0)
                $filelink = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/act/files/c/' . $id . '" title="' . $lng_forum['files_category'] .
                    '">' . $lng_forum['files_category'] . '</a>';
        }
        elseif ($type1['type'] == 'r')
        {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `subcat` = '$id'" .
                $sql), 0);
            if ($count > 0)
                $filelink = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/act/files/s/' . $id . '" title="' . $lng_forum['files_section'] .
                    '">' . $lng_forum['files_section'] . '</a>';
        }
        elseif ($type1['type'] == 't')
        {
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `topic` = '$id'" .
                $sql), 0);
            if ($count > 0)
                $filelink = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/act/files/t/' . $id . '" title="' . $lng_forum['files_topic'] .
                    '"><i class="fa fa-file"></i> ' . $lng_forum['files_topic'] .
                    '</a>';
        }
        $filelink = isset($filelink) ? $filelink : false;


        $wholink = false;
        if ($user_id && $type1['type'] == 't')
        {
            $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " .
                (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " .
                (time() - 300) . " AND `place` = 'forum,$id'"), 0);
            $wholink = '<a class="func" href="' . $set['homeurl'] .
                '/forum/index.php/act/who/id/' . $id .
                '"><i class="fa fa-question-circle"></i> ' . $lng_forum['who_here'] .
                ' (' . $online_u . '&#160;/&#160;' . $online_g . ')</a>';
        }

        if (!$user_id)
        {
            if ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0))
            {
                $ntop = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $id . '/page/' . $page . '/newup">' .
                    $lng_forum['new_on_top'] . '</a>';
            }
            else
            {
                $ntop = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $id . '/page/' . $page .
                    '/newdown">' . $lng_forum['new_on_bottom'] . '</a>';
            }
        }
        else
        {
            $ntop = false;
        }
        $breadcrumb = functions::breadcrumb($tree);
        echo functions::main_header($tree[count($tree) - 1]['label'], $breadcrumb);
        echo '<p id="up">' . counters::forum_new(1) . '<a class="func" href="' .
            $set['homeurl'] . '/forum/search.php/id/' . $id .
            '"><i class="fa fa-search"></i> ' . $lng['search'] . '</a>' . ($filelink ?
            $filelink : '') . ($ntop ? $ntop : '') . ($wholink ? $wholink : '');
        if ($type1['type'] == 't')
        {
            if ($type1['realid'])
            {
                $topic_vote = mysql_fetch_assoc(mysql_query("SELECT `name`, `time`, `count` FROM `cms_forum_vote` WHERE `type`='1' AND `topic`='$id' LIMIT 1"));
            }
            $filter = isset($_SESSION['fsort_id']) && $_SESSION['fsort_id'] == $id ?
                1 : 0;
            $curators = !empty($type1['curators']) ? unserialize($type1['curators']) :
                array();
            $curator = false;
            if ($rights < 6 && $rights != 3 && $user_id)
            {
                if (array_key_exists($user_id, $curators))
                    $curator = true;
            }
        }
        echo '</p>';

        switch ($type1['type'])
        {
            case 'f':
                $req = mysql_query("SELECT `id`, `text`, `soft`, `edit` FROM `forum` WHERE `type`='r' AND `refid`='$id' ORDER BY `realid`");
                $total = mysql_num_rows($req);
                if ($total)
                {
                    $i = 0;
                    echo '<div class="list-group">';
                    while (($res = mysql_fetch_assoc($req)) !== false)
                    {

                        echo '<a href="' . $set['homeurl'] .
                            '/forum/index.php/id/' . $res['id'] .
                            '" class="list-group-item">';
                        $coltem = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '" .
                            $res['id'] . "'"), 0);
                        echo '<h4 class="list-group-item-heading"><strong>' . $res['text'] .
                            '</strong> ' . ($coltem ?
                            '<span class="badge pull-right">' . $coltem .
                            '</span>' : '') . '</h4>';
                        if (!empty($res['soft']))
                            echo '<p class="list-group-item-text">' . $res['soft'] .
                                '</p>';
                        echo '</a>';
                        ++$i;
                    }
                    echo '</div>';
                    unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng_forum['section_list_empty'] .
                        '</p></div>';
                }
                echo
                    '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                    $lng['total'] . ': ' . $total . '</div>';
                break;

            case 'r':
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `refid`='$id'" .
                    ($rights >= 7 ? '' : " AND `close`!='1'")), 0);
                if (($user_id && !isset($ban['1']) && !isset($ban['11']) && $set['mod_forum'] !=
                    4) || core::$user_rights)
                {

                    echo '<a href="' . $set['homeurl'] .
                        '/forum/index.php/act/nt/id/' . $id .
                        '" class="btn btn-default btn-sm btn-flat" style="margin-bottom:10px;"><i class="fa fa-plus"></i> ' .
                        $lng_forum['new_topic'] . '</a>';
                }
                if ($total)
                {
                    $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t'" .
                        ($rights >= 7 ? '' : " AND `close`!='1'") .
                        " AND `refid`='$id' ORDER BY `vip` DESC, `time` DESC LIMIT $start, $kmess");
                    $i = 0;
                    echo '<ul class="list-group">';
                    while (($res = mysql_fetch_assoc($req)) !== false)
                    {
                        echo '<li class="list-group-item">';
                        $nikuser = mysql_query("SELECT `from` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" .
                            $res['id'] . "' ORDER BY `time` DESC LIMIT 1");
                        $nam = mysql_fetch_assoc($nikuser);
                        $colmes = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m' AND `refid`='" .
                            $res['id'] . "'" . ($rights >= 7 ? '' :
                            " AND `close` != '1'"));
                        $colmes1 = mysql_result($colmes, 0);
                        $cpg = ceil($colmes1 / $kmess);
                        $np = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `time` >= '" .
                            $res['time'] . "' AND `topic_id` = '" . $res['id'] .
                            "' AND `user_id`='$user_id'"), 0);

                        $img = ($np ? (!$res['vip'] ? functions::image('op.gif') :
                            '') : functions::image('np.gif')) . ($res['vip'] ?
                            functions::image('pt.gif') : '') . ($res['realid'] ?
                            functions::image('rate.gif') : '') . ($res['edit'] ?
                            functions::image('tz.gif') : '');

                        echo '<a  href="' . $set['homeurl'] .
                            '/forum/index.php/id/' . $res['id'] .
                            '"><h4 class="list-group-item-heading">' . $img . $res['text'] .
                            ' <span class="badge pull-right">' . $colmes1 .
                            '</span></h4></a>';
                        if ($cpg > 1)
                        {

                        }
                        echo '<p class="list-group-item-text">';
                        echo $res['from'];
                        if (!empty($nam['from']))
                        {
                            echo '&#160;/&#160;' . $nam['from'];
                        }
                        echo ' <span class="label label-default">' . functions::display_date($res['time']) .
                            '</span>';
                        if ($cpg > 1)
                        {
                            echo '<a class="pull-right" href="' . $set['homeurl'] .
                                '/forum/index.php/id/' . $res['id'] . '/page/' .
                                $cpg .
                                '"><span class="glyphicon glyphicon-arrow-right"></span></a>';
                        }
                        echo '</p>';
                        echo '</li>';
                        ++$i;
                    }
                    echo '</ul>';
                    unset($_SESSION['fsort_id']);
                    unset($_SESSION['fsort_users']);
                }
                else
                {
                    echo '<div class="alert alert-warning"><p>' . $lng_forum['topic_list_empty'] .
                        '</p></div>';
                }
                echo
                    '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                    $lng['total'] . ': ' . $total . '</div>';
                if ($total > $kmess)
                {
                    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                        '/forum/index.php/id/' . $id . '/?', $start, $total, $kmess) .
                        '</div>';
                }
                break;

            case 't':

                $sql = '';
                if ($filter && !empty($_SESSION['fsort_users']))
                {

                    $sw = 0;
                    $sql = ' AND (';
                    $fsort_users = unserialize($_SESSION['fsort_users']);
                    foreach ($fsort_users as $val)
                    {
                        if ($sw)
                            $sql .= ' OR ';
                        $sortid = intval($val);
                        $sql .= "`forum`.`user_id` = '$sortid'";
                        $sw = 1;
                    }
                    $sql .= ')';
                }

                if ($rights < 6 && $type1['close'] == 1)
                {
                    echo '<div class="alert alert-danger"><p>' . $lng_forum['topic_deleted'] .
                        '<br/><a class="alert-link" href="' . $set['homeurl'] .
                        '/forum/index.php/id/' . $type1['refid'] . '">' . $lng_forum['to_section'] .
                        '</a></p></div>';
                    require ('../incfiles/end.php');
                    exit;
                }

                $colmes = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='m'$sql AND `refid`='$id'" .
                    ($rights >= 7 ? '' : " AND `close` != '1'")), 0);
                if ($start >= $colmes)
                {

                    $start = max(0, $colmes - (($colmes % $kmess) == 0 ? $kmess :
                        ($colmes % $kmess)));
                }


                if ($colmes > $kmess)
                {

                }

                if ($type1['close'])
                {
                    echo '<div class="alert alert-danger">' . $lng_forum['topic_delete_who'] .
                        ': <b>' . $type1['close_who'] . '</b></div>';
                }
                elseif (!empty($type1['close_who']) && $rights >= 7)
                {
                    echo '<div class="alert alert-info">' . $lng_forum['topic_delete_whocancel'] .
                        ': <b>' . $type1['close_who'] . '</b></div>';
                }

                if ($type1['edit'])
                {
                    echo '<div class="alert alert-danger">' . $lng_forum['topic_closed'] .
                        '</div>';
                }

                if ($type1['realid'])
                {
                    echo '<div  class="callout callout-info">';
                    $clip_forum = isset($_GET['clip']) ? '?clip' : '';
                    $vote_user = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote_users` WHERE `user`='$user_id' AND `topic`='$id'"),
                        0);

                    echo '<div class="lead">' . functions::checkout($topic_vote['name']) .
                        '</div>';
                    $vote_result = mysql_query("SELECT `id`, `name`, `count` FROM `cms_forum_vote` WHERE `type`='2' AND `topic`='" .
                        $id . "' ORDER BY `id` ASC");
                    if (!$type1['edit'] && !isset($_GET['vote_result']) && $user_id &&
                        $vote_user == 0)
                    {

                        echo '<form role="form" action="' . $set['homeurl'] .
                            '/forum/index.php/act/vote/id/' . $id .
                            '" method="post">';
                        while (($vote = mysql_fetch_assoc($vote_result)) !== false)
                        {
                            echo '<div class="radio">' .
                                '<label><input type="radio" value="' . $vote['id'] .
                                '" name="vote"/> ' . functions::checkout($vote['name'],
                                0, 1) . '</label>' . '</div>';
                        }
                        echo
                            '<p><button class="btn btn-primary btn-sm" type="submit" name="submit">' .
                            $lng['vote'] .
                            '</button><br /><a class="func" href="' . $set['homeurl'] .
                            '/forum/index.php/id/' . $id . '/start/' . $start .
                            '/vote_result' . $clip_forum .
                            '"><span class="glyphicon glyphicon-stats"></span> ' .
                            $lng_forum['results'] . '</a></p></form>';
                    }
                    else
                    {

                        while (($vote = mysql_fetch_assoc($vote_result)) !== false)
                        {
                            $count_vote = $topic_vote['count'] ? round(100 / $topic_vote['count'] *
                                $vote['count']) : 0;
                            echo '<div class="text-muted">' . functions::checkout($vote['name'],
                                0, 1) . ' [' . $vote['count'] . ']</div>';
                            echo '<div class="progress xs">' .
                                '<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="' .
                                $count_vote .
                                '" aria-valuemin="0" aria-valuemax="100" style="width: ' .
                                $count_vote . '%">' . '<span class="sr-only">' .
                                $count_vote . '%</span>' . '</div>' . '</div>';
                        }
                        echo '<div>' . $lng_forum['total_votes'] . ': ';
                        if ($user_id && core::$user_data['rights'] > 6)
                            echo '<a class="func" href="' . $set['homeurl'] .
                                '/forum/index.php/act/users/id/' . $id .
                                '"><span class="badge">' . $topic_vote['count'] .
                                '</span></a>';
                        else
                            echo $topic_vote['count'];
                        echo '</div>';
                        if ($user_id && $vote_user == 0)
                            echo '<div><a class="func" href="' . $set['homeurl'] .
                                '/forum/index.php/id/' . $id . '/start/' . $start .
                                $clip_forum . '">' . $lng['vote'] . '</a></div>';
                    }
                    echo '</div>';
                }
                $curators = !empty($type1['curators']) ? unserialize($type1['curators']) :
                    array();
                $curator = false;
                if ($rights < 6 && $rights != 3 && $user_id)
                {
                    if (array_key_exists($user_id, $curators))
                        $curator = true;
                }
                if (($set_forum['postclip'] == 2 && ($set_forum['upfp'] ? $start <
                    (ceil($colmes - $kmess)) : $start > 0)) || isset($_GET['clip']))
                {
                    $postreq = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
                    FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                    WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'" . ($rights >=
                        7 ? "" : " AND `forum`.`close` != '1'") . "
                    ORDER BY `forum`.`id` LIMIT 1");
                    $postres = mysql_fetch_assoc($postreq);
                    echo '<div class="alert alert-info"><p>';
                    if ($postres['sex'])
                        echo functions::image(($postres['sex'] == 'm' ? 'm' :
                            'w') . ($postres['datereg'] > time() - 86400 ?
                            '_new.png' : '.png')) . '&#160;';
                    else
                        echo '<img src="' . $set['homeurl'] .
                            '/images/del.png" width="10" height="10" alt=""/>&#160;';
                    if ($user_id && $user_id != $postres['user_id'])
                    {
                        echo '<a href="' . $set['homeurl'] .
                            '/users/profile.php/user/' . $postres['user_id'] .
                            '"><b>' . $postres['from'] . '</b></a> ';
                        $requot =
                            '<a data-toggle="tooltip" data-title="Reply" href="' .
                            $set['homeurl'] . '/forum/index.php/act/say/id/' . $postres['id'] .
                            '/start/' . $start . '"> ' . $lng_forum['reply_btn'] .
                            '</a> ' .
                            '<a data-toggle="tooltip" data-title="Quote" href="' .
                            $set['homeurl'] . '/forum/index.php/act/say/id/' . $postres['id'] .
                            '/start/' . $start . '/cyt"> ' . $lng_forum['cytate_btn'] .
                            '</a> ';
                    }
                    else
                    {
                        echo '<b>' . $postres['from'] . '</b> ';
                    }
                    $user_rights = array(
                        3 => '(FMod)',
                        6 => '(Smd)',
                        7 => '(Adm)',
                        9 => '(SV!)');
                    echo @$user_rights[$postres['rights']];
                    echo (time() > $postres['lastdate'] + 300 ?
                        ' <span class="label label-danger offline">Off</span> ' :
                        ' <span class="label label-danger online">ON</span> ');
                    echo ' <a href="' . $set['homeurl'] .
                        '/forum/index.php/act/post/id/' . $postres['id'] .
                        '" data-toggle="tooltip" data-title="Link to post">[#]</a> ';
                    if (isset($requot))
                        echo $requot;
                    echo ' <span class="gray">(' . functions::display_date($postres['time']) .
                        ')</span><br/>';
                    if ($postres['close'])
                    {
                        echo '<span class="red">' . $lng_forum['post_deleted'] .
                            '</span><br/>';
                    }
                    echo functions::checkout(mb_substr($postres['text'], 0, 500),
                        0, 2);
                    if (mb_strlen($postres['text']) > 500)
                        echo '...<a href="' . $set['homeurl'] .
                            '/forum/index.php/act/post/id/' . $postres['id'] .
                            '">' . $lng_forum['read_all'] . '</a>';
                    echo '</p></div>';
                }
                if ($filter)
                    echo '<div class="alert alert-info">' . $lng_forum['filter_on'] .
                        '</div>';

                if ($user_id)
                    $order = $set_forum['upfp'] ? 'DESC' : 'ASC';
                else
                    $order = ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] ==
                        0)) ? 'ASC' : 'DESC';

                $req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
                FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
                WHERE `forum`.`type` = 'm' AND `forum`.`refid` = '$id'" . ($rights >=
                    7 ? "" : " AND `forum`.`close` != '1'") . "$sql ORDER BY `forum`.`id` $order LIMIT $start, $kmess");

                if (($user_id && !$type1['edit'] && $set_forum['upfp'] && $set['mod_forum'] !=
                    3 && $allow != 4) || ($rights >= 7 && $set_forum['upfp']))
                {
                    echo '<div class="gmenu"><form name="form1" action="' . $set['homeurl'] .
                        '/forum/index.php/act/say/id/' . $id .
                        '" method="post">';
                    if ($set_forum['farea'])
                    {
                        $token = mt_rand(1000, 100000);
                        $_SESSION['token'] = $token;
                        echo '<p>' . bbcode::auto_bb('form1', 'msg') . '</p>' .
                            '<textarea class="form-control" rows="' . $set_user['field_h'] .
                            '" name="msg"></textarea>' .
                            '<div class="checkbox"><label><input type="checkbox" name="addfiles" value="1" /> ' .
                            $lng_forum['add_file'] . '</label></div>' . ($set_user['translit'] ?
                            '<div class="checkbox"></label><input type="checkbox" name="msgtrans" value="1" /> ' .
                            $lng['translit'] . '</label></div>' : '') .
                            '<p><button class="btn btn-primary" type="submit" name="submit">' .
                            $lng['write'] . '</button>' . ($set_forum['preview'] ?
                            ' <button class="btn btn-info" type="submit">' . $lng['preview'] .
                            '</button>' : '') .
                            '<input type="hidden" name="token" value="' . $token .
                            '"/>' . '</p></form></div>';
                    }
                    else
                    {
                        echo '<p><input type="submit" name="submit" value="' . $lng['write'] .
                            '"/></p></form></div>';
                    }
                }
                if ($rights == 3 || $rights >= 6)
                    echo '<form role="form" action="' . $set['homeurl'] .
                        '/forum/index.php/act/massdel/id/' . $id .
                        '" method="post">';
                $i = 1;
                while (($res = mysql_fetch_assoc($req)) !== false)
                {
                    if ($res['close'])
                        echo '<div class="alert alert-danger">';
                    else
                        echo $i % 2 ? '<div class="list2">' :
                            '<div class="list1">';
                    if ($set_user['avatar'])
                    {
                        echo '<table cellpadding="0" cellspacing="0" id="post' .
                            $res['id'] . '"><tr><td>';
                        if (file_exists(('../files/users/avatar/' . $res['user_id'] .
                            '.png')))
                            echo '<img src="' . $set['homeurl'] .
                                '/files/users/avatar/' . $res['user_id'] .
                                '.png" width="32" height="32" alt="' . $res['from'] .
                                '" />&#160;';
                        else
                            echo '<img src="' . $set['homeurl'] .
                                '/images/empty.png" width="32" height="32" alt="' .
                                $res['from'] . '" />&#160;';
                        echo '</td><td>';
                    }
                    if ($res['sex'])
                        echo functions::image(($res['sex'] == 'm' ? 'm' : 'w') .
                            ($res['datereg'] > time() - 86400 ? '_new' : '') .
                            '.png', array('class' => 'icon-inline'));
                    else
                        echo functions::image('del.png');

                    if ($user_id && $user_id != $res['user_id'])
                    {
                        echo '<a href="' . $set['homeurl'] .
                            '/users/profile.php/user/' . $res['user_id'] .
                            '"><b>' . $res['from'] . '</b></a> ';
                    }
                    else
                    {
                        echo '<b>' . $res['from'] . '</b> ';
                    }

                    $user_rights = array(
                        3 => '(FMod)',
                        6 => '(Smd)',
                        7 => '(Adm)',
                        9 => '(SV!)');
                    echo @$user_rights[$res['rights']];

                    echo (time() > $res['lastdate'] + 300 ?
                        ' <span class="label label-danger offline">Off</span> ' :
                        ' <span class="label label-success online">ON</span> ');
                    echo '<a href="' . $set['homeurl'] .
                        '/forum/index.php/act/post/id/' . $res['id'] .
                        '" data-toggle="tooltip" data-title="Link to post">[#]</a>';

                    if ($user_id && $user_id != $res['user_id'])
                    {
                        echo
                            '&#160;<a data-toggle="tooltip" data-title="Reply" href="' .
                            $set['homeurl'] . '/forum/index.php/act/say/id/' . $res['id'] .
                            '/start/' . $start . '">' . $lng_forum['reply_btn'] .
                            '</a>&#160;' .
                            '<a data-toggle="tooltip" data-title="Quote" href="' .
                            $set['homeurl'] . '/forum/index.php/act/say/id/' . $res['id'] .
                            '/start/' . $start . '/cyt">' . $lng_forum['cytate_btn'] .
                            '</a> ';
                    }

                    echo ' <span class="gray">(' . functions::display_date($res['time']) .
                        ')</span><br />';

                    if (!empty($res['status']))
                        echo '<div class="status">' . functions::image('label.png',
                            array('class' => 'icon-inline')) . $res['status'] .
                            '</div>';
                    if ($set_user['avatar'])
                        echo '</td></tr></table>';
                    $text = $res['text'];
                    if ($set_forum['postcut'])
                    {

                        switch ($set_forum['postcut'])
                        {
                            case 2:
                                $cut = 1000;
                                break;

                            case 3:
                                $cut = 3000;
                                break;
                            default:
                                $cut = 500;
                        }
                    }
                    if ($set_forum['postcut'] && mb_strlen($text) > $cut)
                    {
                        $text = mb_substr($text, 0, $cut);
                        $text = functions::checkout($text, 1, 1);
                        $text = preg_replace('#\[c\](.*?)\[/c\]#si',
                            '<div class="quote">\1</div>', $text);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 :
                                0);
                        echo bbcode::notags($text) . '...<br /><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/post/id/' . $res['id'] . '">' .
                            $lng_forum['read_all'] . ' &gt;&gt;</a>';
                    }
                    else
                    {

                        $text = functions::checkout($text, 1, 1);
                        if ($set_user['smileys'])
                            $text = functions::smileys($text, $res['rights'] ? 1 :
                                0);
                        echo $text;
                    }
                    if ($res['kedit'])
                    {

                        echo '<br /><span class="gray"><small>' . $lng_forum['edited'] .
                            ' <b>' . $res['edit'] . '</b> (' . functions::display_date($res['tedit']) .
                            ') <b>[' . $res['kedit'] . ']</b></small></span>';
                    }

                    $freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" .
                        $res['id'] . "'");
                    if (mysql_num_rows($freq) > 0)
                    {
                        $fres = mysql_fetch_assoc($freq);
                        $fls = round(@filesize('../files/forum/attach/' . $fres['filename']) /
                            1024, 2);
                        echo
                            '<div class="gray" style="font-size: x-small; background-color: rgba(128, 128, 128, 0.1); padding: 2px 4px; margin-top: 4px">' .
                            $lng_forum['attached_file'] . ':';

                        $att_ext = strtolower(functions::format('./files/forum/attach/' .
                            $fres['filename']));
                        $pic_ext = array(
                            'gif',
                            'jpg',
                            'jpeg',
                            'png');
                        if (in_array($att_ext, $pic_ext))
                        {
                            echo '<div><a href="' . $set['homeurl'] .
                                '/forum/index.php/act/file/id/' . $fres['id'] .
                                '">';
                            echo '<img src="' . $set['homeurl'] .
                                '/forum/thumbinal.php?file=' . (urlencode($fres['filename'])) .
                                '" alt="' . $lng_forum['click_to_view'] .
                                '" /></a></div>';
                        }
                        else
                        {
                            echo '<br /><a href="' . $set['homeurl'] .
                                '/forum/index.php/act/file/id/' . $fres['id'] .
                                '">' . $fres['filename'] . '</a>';
                        }
                        echo ' (' . $fls . ' kb.)<br/>';
                        echo $lng_forum['downloads'] . ': ' . $fres['dlcount'] .
                            ' ' . $lng_forum['time'] . '</div>';
                        $file_id = $fres['id'];
                    }

                    if ((($rights == 3 || $rights >= 6 || $curator) && $rights >=
                        $res['rights']) || ($res['user_id'] == $user_id && !$set_forum['upfp'] &&
                        ($start + $i) == $colmes && $res['time'] > time() - 300) ||
                        ($res['user_id'] == $user_id && $set_forum['upfp'] && $start ==
                        0 && $i == 1 && $res['time'] > time() - 300) || ($i == 1 &&
                        $allow == 2 && $res['user_id'] == $user_id))
                    {

                        $menu = array(
                            '<a data-toggle="' . ($is_mobile ? 'disabled-modal' :
                                'modal') .
                                '" data-target="#global-modal" href="' . $set['homeurl'] .
                                '/forum/index.php/act/editpost/id/' . $res['id'] .
                                '"><span class="glyphicon glyphicon-edit"></span> ' .
                                $lng['edit'] . '</a>',
                            ($rights >= 7 && $res['close'] == 1 ? '<a href="' .
                                $set['homeurl'] .
                                '/forum/index.php/act/editpost/do/restore/id/' .
                                $res['id'] .
                                '"><span class="glyphicon glyphicon-repeat"></span> ' .
                                $lng_forum['restore'] . '</a>' : ''),
                            ($res['close'] == 1 ? '' :
                                '<a class="delete" href="' . $home .
                                '/forum/index.php/act/editpost/id/' . $res['id'] .
                                '/do/del" data-toggle="' . ($is_mobile ?
                                'disabled-modal' : 'modal') .
                                '" data-target="#global-modal">' .
                                '<span class="glyphicon glyphicon-remove"></span> ' .
                                $lng['delete'] . '</a>'));
                        echo '<div class="sub">';
                        if ($rights == 3 || $rights >= 6)
                            echo '<input type="checkbox" name="delch[]" value="' .
                                $res['id'] . '"/>&#160;';
                        echo functions::display_menu($menu, ' | ');
                        if ($res['close'])
                        {
                            echo '<div class="red">' . $lng_forum['who_delete_post'] .
                                ': <b>' . $res['close_who'] . '</b></div>';
                        }
                        elseif (!empty($res['close_who']))
                        {
                            echo '<div class="green">' . $lng_forum['who_restore_post'] .
                                ': <b>' . $res['close_who'] . '</b></div>';
                        }
                        if ($rights == 3 || $rights >= 6)
                        {
                            if ($res['ip_via_proxy'])
                            {
                                echo
                                    '<div class="gray"><b class="red"><a href="' .
                                    $set['homeurl'] . '/' . $set['admp'] .
                                    '/index.php/act/search_ip/ip/' . long2ip($res['ip']) .
                                    '">' . long2ip($res['ip']) . '</a></b> - ' .
                                    '<a href="' . $set['homeurl'] . '/' . $set['admp'] .
                                    '/index.php/act/search_ip/ip/' . long2ip($res['ip_via_proxy']) .
                                    '">' . long2ip($res['ip_via_proxy']) .
                                    '</a>' . ' - ' . $res['soft'] . '</div>';
                            }
                            else
                            {
                                echo '<div class="gray"><a href="' . $set['homeurl'] .
                                    '/' . $set['admp'] .
                                    '/index.php/act/search_ip/ip/' . long2ip($res['ip']) .
                                    '">' . long2ip($res['ip']) . '</a> - ' . $res['soft'] .
                                    '</div>';
                            }
                        }
                        echo '</div>';
                    }
                    echo '</div>';
                    ++$i;
                }
                if ($rights == 3 || $rights >= 6)
                {
                    echo
                        '<hr/><p><button class="btn btn-warning btn-flat" type="submit" data-toggle="tooltip" data-placement="right" title="Delete selcted items">' .
                        $lng['delete'] . '</button></p>';
                    echo '</form>';
                }

                if (($user_id && !$type1['edit'] && !$set_forum['upfp'] && $set['mod_forum'] !=
                    3 && $allow != 4) || ($rights >= 7 && !$set_forum['upfp']))
                {
                    if ($set_forum['farea'])
                    {
                        echo '<div class="gmenu"><form name="form2" action="' .
                            $set['homeurl'] . '/forum/index.php/act/say/id/' . $id .
                            '" method="post">';
                        $token = mt_rand(1000, 100000);
                        $_SESSION['token'] = $token;
                        echo '<p>' . bbcode::auto_bb('form2', 'msg') . '</p>';
                        echo '<textarea class="form-control" rows="' . $set_user['field_h'] .
                            '" name="msg"></textarea>' .
                            '<div class="checkbox"><label><input type="checkbox" name="addfiles" value="1" /> ' .
                            $lng_forum['add_file'] . '</label></div>';
                        if ($set_user['translit'])
                            echo
                                '<div class="checkbox"><label><input type="checkbox" name="msgtrans" value="1" /> ' .
                                $lng['translit'] . '</label></div>';
                        echo
                            '<p><button class="btn btn-primary" type="submit" name="submit">' .
                            $lng['write'] . '</button> ' . ($set_forum['preview'] ?
                            ' <button class="btn btn-info" type="submit">' . $lng['preview'] .
                            '</button>' : '') .
                            '</p><input type="hidden" name="token" value="' . $token .
                            '"/>' . '</form></div>';
                    }
                    else
                    {
                        echo '<div class="well well-sm"><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/say/id/' . $id .
                            '" class="btn btn-primary btn-flat" data-toggle="' . ($is_mobile ?
                            'disabled-modal' : 'modal') .
                            '" data-target="#global-modal">' . $lng['write'] .
                            '</a></div>';
                    }
                }

                echo
                    '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                    $lng['total'] . ': ' . $colmes . '</div>';
                if ($colmes > $kmess)
                {
                    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                        '/forum/index.php/id/' . $id . '?', $start, $colmes, $kmess) .
                        '</div>';
                }
                else
                {

                }

                if ($curators)
                {
                    $array = array();
                    foreach ($curators as $key => $value)
                        $array[] = '<a href="' . $set['homeurl'] .
                            '/users/profile.php/user/' . $key . '">' . $value .
                            '</a>';
                    echo '<div class="alert alert-info"><strong>' . $lng_forum['curators'] .
                        '</strong>: ' . implode(', ', $array) . '</div>';
                }
                echo '<ul class="nav nav-pills">';
                if ($rights == 3 || $rights >= 6)
                {
                    if ($rights >= 7)
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/curators/id/' . $id .
                            '/start/' . $start .
                            '"><span class="glyphicon glyphicon-briefcase"></span> ' .
                            $lng_forum['curators_of_the_topic'] . '</a></li>';
                    echo isset($topic_vote) && $topic_vote > 0 ? '<li><a href="' .
                        $set['homeurl'] . '/forum/index.php/act/editvote/id/' .
                        $id .
                        '"><span class="glyphicon glyphicon-stats"></span> ' . $lng_forum['edit_vote'] .
                        '</a></li><li><a href="' . $set['homeurl'] .
                        '/forum/index.php/act/delvote/id/' . $id .
                        '"><span class="glyphicon glyphicon-stats"></span> ' . $lng_forum['delete_vote'] .
                        '</a></li>' : '<li><a href="' . $set['homeurl'] .
                        '/forum/index.php/act/addvote/id/' . $id .
                        '"><span class="glyphicon glyphicon-stats"></span> ' . $lng_forum['add_vote'] .
                        '</a></li>';
                    echo '<li><a href="' . $set['homeurl'] .
                        '/forum/index.php/act/ren/id/' . $id .
                        '"><span class="glyphicon glyphicon-edit"></span> ' . $lng_forum['topic_rename'] .
                        '</a></li>';

                    if ($type1['edit'] == 1)
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/close/id/' . $id .
                            '"><span class="glyphicon glyphicon-eye-open"></span> ' .
                            $lng_forum['topic_open'] . '</a></li>';
                    else
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/close/id/' . $id .
                            '/closed"><span class="glyphicon glyphicon-lock"></span> ' .
                            $lng_forum['topic_close'] . '</a></li>';

                    if ($type1['close'] == 1)
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/restore/id/' . $id .
                            '"><span class="glyphicon glyphicon-repeat"></span> ' .
                            $lng_forum['topic_restore'] . '</a></li>';
                    echo '<li><a href="' . $set['homeurl'] .
                        '/forum/index.php/act/deltema/id/' . $id .
                        '"><span class="glyphicon glyphicon-remove"></span>  ' .
                        $lng_forum['topic_delete'] . '</a></li>';
                    if ($type1['vip'] == 1)
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/vip/id/' . $id .
                            '"><span class="glyphicon glyphicon-star-empty"></span> ' .
                            $lng_forum['topic_unfix'] . '</a></li>';
                    else
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/vip/id/' . $id .
                            '/vip"><span class="glyphicon glyphicon-star"></span> ' .
                            $lng_forum['topic_fix'] . '</a></li>';
                    echo '<li><a href="' . $set['homeurl'] .
                        '/forum/index.php/act/per/id/' . $id .
                        '"><span class="glyphicon glyphicon-move"></span> ' . $lng_forum['topic_move'] .
                        '</a></li>';
                }
                if ($wholink)
                    if ($filter)
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/filter/id/' . $id .
                            '/do/unset"><span class="glyphicon glyphicon-filter"></span> ' .
                            $lng_forum['filter_cancel'] . '</a></li>';
                    else
                        echo '<li><a href="' . $set['homeurl'] .
                            '/forum/index.php/act/filter/id/' . $id . '/start/' .
                            $start .
                            '"><span class="glyphicon glyphicon-filter"></span> ' .
                            $lng_forum['filter_on_author'] . '</a></li>';
                echo '<li><a href="' . $set['homeurl'] .
                    '/forum/index.php/act/tema/id/' . $id .
                    '"><span class="glyphicon glyphicon-download-alt"></span> ' .
                    $lng_forum['download_topic'] . '</a></li>';
                echo '</ul>';

                echo '<script type="text/javascript">
	                $(document).ready(function(){
	                 $("a.delete").click(function(){
			 var _id = $(this).attr("data-id");
	                 $("div.actionConfirm div.btn-group a.btn-primary").attr("href","forum/index.php/act/editpost/do/delete/id/" + _id);
			 $("div.actionConfirm div.btn-group a.btn-info").attr("href","forum/index.php/act/editpost/do/delete/hide/true/id/" + _id);
			 });
	                 });
	             </script>';
                $body = '<div class="alert alert-warning">' . $lng_forum['delete_last_post_warning'] .
                    '</div>' . '<p class="help-block">' . $lng_forum['delete_post_help'] .
                    '</p>';
                $body .=
                    '<div class="actionConfirm"><div class="btn-group"><a class="btn btn-sm btn-primary" href="">' .
                    $lng['delete'] . '</a></div>';
                if ($rights == 9)
                    $body .=
                        ' <div class="btn-group"><a class="btn btn-sm btn-info" href="">' .
                        $lng['hide'] . '</a></div>';
                $body .=
                    ' <div class="btn-group"><button type="button" class="btn btn-default" data-dismiss="modal">' .
                    $lng['cancel'] . '</button></div></div>';
                echo functions::modal($body, array('id' => 'delConfirm', 'title' =>
                        $lng_forum['delete_post']), true);
                break;

            default:
                echo functions::display_error($lng['error_wrong_data']);
                break;
        }
    }
    else
    {
        if (!$user_id)
        {
            if ((empty($_SESSION['uppost'])) || ($_SESSION['uppost'] == 0))
            {
                $ntop = '<a class="func" href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $id . '/page/' . $page .
                    '/newup"><i class="fa fa-sort-up"></i> ' . $lng_forum['new_on_top'] .
                    '</a>';
            }
            else
            {
                $ntop = '<a class="func"  href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $id . '/page/' . $page .
                    '/newdown"><i class="fa fa-sort-down"></i> ' . $lng_forum['new_on_bottom'] .
                    '</a>';
            }
        }
        else
        {
            $ntop = false;
        }
        $breadcrumb = functions::breadcrumb($brc = array(array('label' => $lng['forum']), ));
        echo functions::main_header($brc[count($brc) - 1]['label'], $breadcrumb);

        $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files`" .
            ($rights >= 7 ? '' : " WHERE `del` != '1'")), 0);
        echo '<p>' . counters::forum_new(1) . '<a class="func" href="' . $set['homeurl'] .
            '/forum/search.php"><i class="fa fa-search"></i> ' . $lng['search'] .
            '</a>' . '<a class="func" href="' . $set['homeurl'] .
            '/forum/index.php/act/files"><i class="fa fa-file"></i> ' . $lng_forum['files_forum'] .
            ' (' . $count . ')</a>' . ($ntop ? $ntop : '') . '</p>';
        $req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
        $i = 0;
        echo '<div class="list-group">';
        while (($res = mysql_fetch_array($req)) !== false)
        {

            echo '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $res['id'] .
                '" class="list-group-item">';
            $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" .
                $res['id'] . "'"), 0);
            echo '<h4 class="list-group-item-heading"><strong>' . $res['text'] .
                '</strong> <span class="badge pull-right">' . $count .
                '</span></h4>';
            if (!empty($res['soft']))
                echo '<p class="list-group-item-text">' . $res['soft'] . '</p>';
            echo '</a>';
            ++$i;
        }
        echo '</div>';
        $online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " .
            (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        $online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " .
            (time() - 300) . " AND `place` LIKE 'forum%'"), 0);
        if ($user_id)
            echo '<a class="func" style="margin-top:10px;" href="' . $set['homeurl'] .
                '/forum/index.php/act/who"><i class="fa fa-question-circle"></i> ' .
                $lng_forum['who_in_forum'] . ' (' . $online_u . '&#160;/&#160;' .
                $online_g . ')</a>';
        else
            echo '<h4>' . $lng_forum['who_in_forum'] . ' <span class="badge">' .
                $online_u . '&#160;/&#160;' . $online_g . '</span></h4>';
        unset($_SESSION['fsort_id']);
        unset($_SESSION['fsort_users']);
    }

    echo '<p>' . ($id ? functions::link_back($lng['to_forum'],
        '/forum/index.php') : '');
    if (!$id)
    {
        echo '<a class="func" href="' . $home .
            '/pages/faq.php/act/forum" data-toggle="' . ($is_mobile ?
            'disabled-modal' : 'modal') . '" data-target="#global-modal">' .
            '<i class="fa fa-exclamation-circle"></i> ' . $lng_forum['forum_rules'] .
            '</a>';
    }
    echo '</p>';
}

require_once ('../incfiles/end.php');
