<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $lng_forum['voting_users'];
require ('../incfiles/head.php');
$topic_vote = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote` WHERE `type` = '1' AND `topic` = '$id'"),
    0);
if ($topic_vote == 0)
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id),
        array('label' => $textl),
        ));

    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}
else
{
    $topic_vote = mysql_fetch_array(mysql_query("SELECT `name`, `time`, `count` FROM `cms_forum_vote` WHERE `type` = '1' AND `topic` = '$id' LIMIT 1"));
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id),
        array('label' => $textl),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_vote_users` WHERE `topic`='$id'"),
        0);
    $req = mysql_query("SELECT `cms_forum_vote_users`.*, `users`.`rights`, `users`.`lastdate`, `users`.`name`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`
    FROM `cms_forum_vote_users` LEFT JOIN `users` ON `cms_forum_vote_users`.`user` = `users`.`id`
    WHERE `cms_forum_vote_users`.`topic`='$id' LIMIT $start,$kmess");
    $i = 0;
    while ($res = mysql_fetch_array($req))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo functions::display_user($res, array('iphide' => 1));
        echo '</div>';
        ++$i;
    }
    if ($total == 0)
        echo '<div class="menu">' . $lng_forum['voting_users_empty'] . '</div>';
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {
        echo '<p>' . functions::display_pagination($set['homeurl'] .
            '/forum/index.php/act/users/id/' . $id . '/', $start, $total, $kmess) .
            '</p>';
    }
}

require ('../incfiles/end.php');

?>