<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require ('../incfiles/head.php');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id .
            '/start/' . $start),
    array('label' => $lng_forum['curators']),
    ));
if (core::$user_rights >= 7)
{
    $req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 't'");
    if (!mysql_num_rows($req) || $rights < 7)
    {
        echo functions::display_error($lng_forum['error_topic_deleted']);
        require ('../incfiles/end.php');
        exit;
    }
    $topic = mysql_fetch_assoc($req);
    $req = mysql_query("SELECT `forum`.*, `users`.`id`
        FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
        WHERE `forum`.`refid`='$id' AND `users`.`rights` < 6 AND `users`.`rights` != 3 GROUP BY `forum`.`from` ORDER BY `forum`.`from`");
    $total = mysql_num_rows($req);
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    echo '<div class="well well-sm">' . $res['text'] . '</div>';
    $curators = array();
    $users = !empty($topic['curators']) ? unserialize($topic['curators']) :
        array();
    if (isset($_POST['submit']))
    {
        $users = isset($_POST['users']) ? $_POST['users'] : array();
        if (!is_array($users))
            $users = array();
    }
    if ($total > 0)
    {
        echo '<form role="form" action="' . $set['homeurl'] .
            '/forum/index.php/act/curators/id/' . $id . '/start/' . $start .
            '" method="post">';
        $i = 0;
        while ($res = mysql_fetch_array($req))
        {
            $checked = array_key_exists($res['user_id'], $users) ? true : false;
            if ($checked)
                $curators[$res['user_id']] = $res['from'];
            echo ($i++ % 2 ? '<div class="list2">' : '<div class="list1">') .
                '<input type="checkbox" name="users[' . $res['user_id'] .
                ']" value="' . $res['from'] . '"' . ($checked ?
                ' checked="checked"' : '') . '/>&#160;' . '<a href="' . $set['homeurl'] .
                '/users/profile.php/user/' . $res['user_id'] . '">' . $res['from'] .
                '</a></div>';
        }
        echo '<p><button class="btn btn-primary" type="submit" name="submit">' .
            $lng_forum['assign'] . '</button></p></form>';
        if (isset($_POST['submit']))
            mysql_query("UPDATE `forum` SET `curators`='" .
                mysql_real_escape_string(serialize($curators)) .
                "' WHERE `id` = '$id'");

    }
    else
        echo functions::display_error($lng['list_empty']);
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    echo '<p>' . functions::link_back($lng['back'], 'forum/index.php/id/' . $id .
        '/start/' . $start) . '</p>';
}
