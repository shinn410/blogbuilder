<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (!$user_id || !$id)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}
$req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 'm' " .
    ($rights >= 7 ? "" : " AND `close` != '1'"));
if (mysql_num_rows($req))
{
    $res = mysql_fetch_assoc($req);

    $topic = mysql_fetch_assoc(mysql_query("SELECT `refid`, `curators` FROM `forum` WHERE `id` = " .
        $res['refid']));
    $curators = !empty($topic['curators']) ? unserialize($topic['curators']) :
        array();

    if (array_key_exists($user_id, $curators))
        $rights = 3;
    $page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" .
        $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">=" : "<=") . " '$id'" .
        ($rights < 7 ? " AND `close` != '1'" : '')), 0) / $kmess);
    $posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" .
        $res['refid'] . "' AND `close` != '1'"), 0);
    $link = $home . '/forum/index.php/id/' . $res['refid'] . '/page/' . $page;
    $error = false;
    if ($rights == 3 || $rights >= 6)
    {

        if ($res['user_id'] != $user_id)
        {
            $req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '" . $res['user_id'] .
                "'");
            if (mysql_num_rows($req_u))
            {
                $res_u = mysql_fetch_assoc($req_u);
                if ($res_u['rights'] > $datauser['rights'])
                    $error = $lng['error_edit_rights'] . '<br /><a href="' . $link .
                        '">' . $lng['back'] . '</a>';
            }
        }
    }
    else
    {

        if ($res['user_id'] != $user_id)
            $error = $lng_forum['error_edit_another'] . '<br /><a href="' . $link .
                '">' . $lng['back'] . '</a>';
        if (!$error)
        {
            $section = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `id` = " .
                $topic['refid']));
            $allow = !empty($section['edit']) ? intval($section['edit']) : 0;

            $check = true;
            if ($allow == 2)
            {
                $first = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `refid` = '" .
                    $res['refid'] . "' ORDER BY `id` ASC LIMIT 1"));
                if ($first['user_id'] == $user_id && $first['id'] == $id)
                {
                    $check = false;
                }
            }

            if ($check)
            {
                $req_m = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" .
                    $res['refid'] . "' ORDER BY `id` DESC LIMIT 1");
                $res_m = mysql_fetch_assoc($req_m);
                if ($res_m['user_id'] != $user_id)
                {
                    $error = $lng_forum['error_edit_last'] . '<br /><a href="' .
                        $link . '">' . $lng['back'] . '</a>';
                }
                elseif ($res['time'] < time() - 300)
                {
                    $error = $lng_forum['error_edit_timeout'] .
                        '<br /><a href="' . $link . '">' . $lng['back'] . '</a>';
                }
            }
        }
    }
}
else
{
    $error = $lng_forum['error_post_deleted'] .
        '<br /><a class="alert-link" href="' . $set['homeurl'] .
        '/forum/index.php">' . $lng['forum'] . '</a>';
}
if (!$error)
{
    switch ($do)
    {
        case 'restore':
            $req_u = mysql_query("SELECT `postforum` FROM `users` WHERE `id` = '" .
                $res['user_id'] . "'");
            if (mysql_num_rows($req_u))
            {

                $res_u = mysql_fetch_assoc($req_u);
                mysql_query("UPDATE `users` SET `postforum` = '" . ($res_u['postforum'] +
                    1) . "' WHERE `id` = '" . $res['user_id'] . "'");
            }
            mysql_query("UPDATE `forum` SET `close` = '0', `close_who` = '$login' WHERE `id` = '$id'");
            $req_f = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '$id' LIMIT 1");
            if (mysql_num_rows($req_f))
            {
                mysql_query("UPDATE `cms_forum_files` SET `del` = '0' WHERE `post` = '$id' LIMIT 1");
            }
            header('Location: ' . $link);
            break;

        case 'delete':
            if ($res['close'] != 1)
            {
                $req_u = mysql_query("SELECT `postforum` FROM `users` WHERE `id` = '" .
                    $res['user_id'] . "'");
                if (mysql_num_rows($req_u))
                {

                    $res_u = mysql_fetch_assoc($req_u);
                    $postforum = $res_u['postforum'] > 0 ? $res_u['postforum'] -
                        1 : 0;
                    mysql_query("UPDATE `users` SET `postforum` = '" . $postforum .
                        "' WHERE `id` = '" . $res['user_id'] . "'");
                }
            }
            if ($rights == 9 && !isset($_GET['hide']))
            {

                $req_f = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '$id' LIMIT 1");
                if (mysql_num_rows($req_f))
                {

                    $res_f = mysql_fetch_assoc($req_f);
                    unlink('../files/forum/attach/' . $res_f['filename']);
                    mysql_query("DELETE FROM `cms_forum_files` WHERE `post` = '$id' LIMIT 1");
                }

                $page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" .
                    $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">" :
                    "<") . " '$id'"), 0) / $kmess);
                mysql_query("DELETE FROM `forum` WHERE `id` = '$id'");
                if ($posts < 2)
                {

                    header('Location: ' . core::$system_set['homeurl'] .
                        '/forum/index.php/act/deltema/id/' . $res['refid']);
                }
                else
                {
                    header('Location: ' . core::$system_set['homeurl'] .
                        '/forum/index.php/id/' . $res['refid'] . '/page/' . $page);
                }
            }
            else
            {

                $req_f = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '$id' LIMIT 1");
                if (mysql_num_rows($req_f))
                {

                    mysql_query("UPDATE `cms_forum_files` SET `del` = '1' WHERE `post` = '$id' LIMIT 1");
                }
                if ($posts == 1)
                {

                    $res_l = mysql_fetch_assoc(mysql_query("SELECT `refid` FROM `forum` WHERE `id` = '" .
                        $res['refid'] . "'"));
                    mysql_query("UPDATE `forum` SET `close` = '1', `close_who` = '$login' WHERE `id` = '" .
                        $res['refid'] . "' AND `type` = 't'");
                    header('Location: ' . core::$system_set['homeurl'] .
                        '/forum/index.php/id/' . $res_l['refid']);
                }
                else
                {
                    mysql_query("UPDATE `forum` SET `close` = '1', `close_who` = '$login' WHERE `id` = '$id'");
                    header('Location: ' . core::$system_set['homeurl'] .
                        '/forum/index.php/id/' . $res['refid'] . '/page/' . $page);
                }
            }
            break;

        case 'del':
            $textl = $lng_forum['delete_post'];
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['forum'], 'url' => $link),
                array('label' => $textl),
                ));
            require ('../incfiles/head.php');
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            if ($posts == 1)
                echo '<div class="alert alert-danger">' . $lng_forum['delete_last_post_warning'] .
                    '</div>';
            echo '<div class="alert alert-warning">' . $lng['delete_confirmation'] .
                '</div>';
            echo '<p class="help-block"><small>' . $lng_forum['delete_post_help'] .
                '</small></p>';
            echo '<p><a class="btn btn-primary" href="' . $set['homeurl'] .
                '/forum/index.php/act/editpost/do/delete/id/' . $id . '">' . $lng['delete'] .
                '</a>';
            if ($rights == 9)
                echo '&nbsp;<a class="btn btn-info" href="' . $set['homeurl'] .
                    '/forum/index.php/act/editpost/do/delete/hide/true/id/' . $id .
                    '">' . $lng['hide'] . '</a>';
            echo '&nbsp;<a data-dismiss="modal" class="btn btn-default" href="' .
                $link . '">' . $lng['cancel'] . '</a></p>';
            echo '<p>' . functions::link_back($lng['back'], $link) . '</p>';
            break;

        default:
            $msg = isset($_POST['msg']) ? functions::checkin(trim($_POST['msg'])) :
                '';
            if (isset($_POST['msgtrans']))
                $msg = functions::trans($msg);
            if (isset($_POST['submit']))
            {
                if (empty($_POST['msg']))
                {
                    require ('../incfiles/head.php');
                    echo functions::display_error($lng['error_empty_message'],
                        '<a href="' . $set['homeurl'] .
                        '/forum/index.php/act/editpost/id/' . $id . '">' . $lng['repeat'] .
                        '</a>');
                    require ('../incfiles/end.php');
                    exit;
                }
                mysql_query("UPDATE `forum` SET
                    `tedit` = '" . time() . "',
                    `edit` = '$login',
                    `kedit` = '" . ($res['kedit'] + 1) . "',
                    `text` = '" . mysql_real_escape_string($msg) . "'
                    WHERE `id` = '$id'
                ");
                header('Location: ' . core::$system_set['homeurl'] .
                    '/forum/index.php/id/' . $res['refid'] . '/page/' . $page);
            }
            else
            {
                $msg_pre = functions::checkout($msg, 1, 1);
                if ($set_user['smileys'])
                    $msg_pre = functions::smileys($msg_pre, $datauser['rights'] ?
                        1 : 0);
                $msg_pre = preg_replace('#\[c\](.*?)\[/c\]#si',
                    '<div class="quote">\1</div>', $msg_pre);
                $textl = $lng_forum['edit_message'];
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['forum'], 'url' => $link),
                    array('label' => $lng_forum['edit_message']),
                    ));
                require ('../incfiles/head.php');
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                if ($msg && !isset($_POST['submit']))
                {
                    $user = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '" .
                        $res['user_id'] . "' LIMIT 1"));
                    echo '<div class="list1">' . functions::display_user($user,
                        array(
                        'iphide' => 1,
                        'header' => '<span class="gray">(' . functions::display_date
                            ($res['time']) . ')</span>',
                        'body' => $msg_pre)) . '</div>';
                }
                echo '<div><form role="form" name="form" action="' . $set['homeurl'] .
                    '/forum/index.php/act/editpost/id/' . $id . '/start/' . $start .
                    '" method="post">';
                echo '<p>' . bbcode::auto_bb('form', 'msg') . '</p>';
                echo '<textarea class="form-control" rows="' . $set_user['field_h'] .
                    '" name="msg">' . (empty($_POST['msg']) ? htmlentities($res['text'],
                    ENT_QUOTES, 'UTF-8') : functions::checkout($_POST['msg'])) .
                    '</textarea><br/>';
                if ($set_user['translit'])
                    echo '<input type="checkbox" name="msgtrans" value="1" ' . (isset
                        ($_POST['msgtrans']) ? 'checked="checked" ' : '') .
                        '/> ' . $lng['translit'];
                echo
                    '<button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['save'] . '</button> ' . ($set_forum['preview'] ?
                    ' <button class="btn btn-info" type="submit">' . $lng['preview'] .
                    '</button>' : '') . '</form></div>' . '<p>' . functions::display_translit() .
                    '</p>' . '<p>' . functions::link_back($lng['back'], $link) .
                    '</p>';
            }
    }
}
else
{
    require ('../incfiles/head.php');
    echo functions::display_error($error);
}
