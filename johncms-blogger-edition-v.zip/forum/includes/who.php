<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $lng_forum['who_in_forum'];
$headmod = $id ? 'forum,' . $id : 'forumwho';
require_once ('../incfiles/head.php');
if (!$user_id)
{
    header('Location: ' . core::$system_set['homeurl'] . '/forum/index.php');
    exit;
}

if ($id)
{
    $req = mysql_query("SELECT `text` FROM `forum` WHERE `id` = '$id' AND `type` = 't'");
    if (mysql_num_rows($req))
    {
        $res = mysql_fetch_assoc($req);
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['forum'], 'url' => '/forum/index.php'),
            array('label' => $res['text'], 'url' => '/forum/index.php/id/' . $id),
            array('label' => $lng_forum['who_in_topic']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if ($rights > 0)
        {
            echo '<ul class="nav nav-tabs">' . ($do == 'guest' ? '<li><a href="' .
                $set['homeurl'] . '/forum/index.php/act/who/id/' . $id . '">' .
                $lng['authorized'] . '</a></li><li class="active"><a>' . $lng['guests'] .
                '</a></li>' : '<li class="active"><a>' . $lng['authorized'] .
                '</a></li><li><a href="' . $set['homeurl'] .
                '/forum/index.php/act/who/do/guest/id/' . $id . '">' . $lng['guests'] .
                '</a></li>') . '</ul>';
        }
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `" . ($do ==
            'guest' ? 'cms_sessions' : 'users') . "` WHERE `lastdate` > " . (time
            () - 300) . " AND `place` = 'forum,$id'"), 0);
        if ($start >= $total)
        {

            $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total %
                $kmess)));
        }
        if ($total > $kmess)
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/forum/index.php/act/who/id/' . $id . '/' . ($do == 'guest/?' ?
                'do/guest/?' : ''), $start, $total, $kmess) . '</div>';
        if ($total)
        {
            $req = mysql_query("SELECT * FROM `" . ($do == 'guest' ?
                'cms_sessions' : 'users') . "` WHERE `lastdate` > " . (time() -
                300) . " AND `place` = 'forum,$id' ORDER BY " . ($do == 'guest' ?
                "`movings` DESC" : "`name` ASC") . " LIMIT $start, $kmess");
            for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
            {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                $set_user['avatar'] = 0;
                echo functions::display_user($res, 0, ($act == 'guest' || ($rights >=
                    1 && $rights >= $res['rights']) ? 1 : 0));
                echo '</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
    }
    else
    {
        header('Location: ' . core::$system_set['homeurl'] . '/forum/index.php');
    }
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/forum/index.php/act/who/id/' . $id . '/' . ($do == 'guest/?' ?
            'do/guest?' : ''), $start, $total, $kmess) . '</div>';
    }
    echo '<p>' . functions::link_back($lng_forum['to_topic'],
        '/forum/index.php/id/' . $id) . '</p>';
}
else
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['forum'], 'url' => '/forum/index.php'),
        array('label' => $lng_forum['who_in_forum']),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if ($rights > 0)
        echo '<ul class="nav nav-tabs">' . ($do == 'guest' ? '<li><a href="' . $set['homeurl'] .
            '/forum/index.php/act/who">' . $lng['users'] .
            '</a></li><li class="active"><a>' . $lng['guests'] . '</a></li>' :
            '<li class="active"><a>' . $lng['users'] . '</a></li><li><a href="' .
            $set['homeurl'] . '/forum/index.php/act/who/do/guest">' . $lng['guests'] .
            '</a></li>') . '</ul>';
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `" . ($do == 'guest' ?
        "cms_sessions" : "users") . "` WHERE `lastdate` > " . (time() - 300) .
        " AND `place` LIKE 'forum%'"), 0);
    if ($start >= $total)
    {

        $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total % $kmess)));
    }
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($home .
            '/forum/index.php/act/who/' . ($do == 'guest/?' ? 'do/guest/?' : ''),
            $start, $total, $kmess) . '</div>';
    if ($total)
    {
        $req = mysql_query("SELECT * FROM `" . ($do == 'guest' ? "cms_sessions" :
            "users") . "` WHERE `lastdate` > " . (time() - 300) .
            " AND `place` LIKE 'forum%' ORDER BY " . ($do == 'guest' ?
            "`movings` DESC" : "`name` ASC") . " LIMIT $start, $kmess");
        for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
        {
            if ($res['id'] == core::$user_id)
                echo '<div class="gmenu">';
            else
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

            $place = '';
            switch ($res['place'])
            {
                case 'forum':
                    $place = '<a href="' . $set['homeurl'] .
                        '/forum/index.php">' . $lng_forum['place_main'] . '</a>';
                    break;

                case 'forumwho':
                    $place = $lng_forum['place_list'];
                    break;

                case 'forumfiles':
                    $place = '<a href="' . $set['homeurl'] .
                        '/forum/index.php/act/files">' . $lng_forum['place_files'] .
                        '</a>';
                    break;

                case 'forumnew':
                    $place = '<a href="' . $set['homeurl'] .
                        '/forum/index.php/act/new">' . $lng_forum['place_new'] .
                        '</a>';
                    break;

                case 'forumsearch':
                    $place = '<a href="' . $set['homeurl'] .
                        '/forum/search.php">' . $lng_forum['place_search'] .
                        '</a>';
                    break;

                default:
                    $where = explode(",", $res['place']);
                    if ($where[0] == 'forum' && intval($where[1]))
                    {
                        $req_t = mysql_query("SELECT `type`, `refid`, `text` FROM `forum` WHERE `id` = '$where[1]'");
                        if (mysql_num_rows($req_t))
                        {
                            $res_t = mysql_fetch_assoc($req_t);
                            $link = '<a href="' . $set['homeurl'] .
                                '/forum/index.php/id/' . $where[1] . '">' . $res_t['text'] .
                                '</a>';
                            switch ($res_t['type'])
                            {
                                case 'f':
                                    $place = $lng_forum['place_category'] .
                                        ' &quot;' . $link . '&quot;';
                                    break;

                                case 'r':
                                    $place = $lng_forum['place_section'] .
                                        ' &quot;' . $link . '&quot;';
                                    break;

                                case 't':
                                    $place = (isset($where[2]) ? $lng_forum['place_write'] .
                                        ' &quot;' : $lng_forum['place_topic'] .
                                        ' &quot;') . $link . '&quot;';
                                    break;

                                case 'm':
                                    $req_m = mysql_query("SELECT `text` FROM `forum` WHERE `id` = '" .
                                        $res_t['refid'] . "' AND `type` = 't'");
                                    if (mysql_num_rows($req_m))
                                    {
                                        $res_m = mysql_fetch_assoc($req_m);
                                        $place = (isset($where[2]) ? $lng_forum['place_answer'] :
                                            $lng_forum['place_topic']) .
                                            ' &quot;<a href="' . $set['homeurl'] .
                                            '/forum/index.php/id/' . $res_t['refid'] .
                                            '">' . $res_m['text'] . '</a>&quot;';
                                    }
                                    break;
                            }
                        }
                    }
            }
            $arg = array('stshide' => 1, 'header' => ('<br /><img src="' . $set['homeurl'] .
                    '/images/info.png" width="16" height="16" align="middle" />&#160;' .
                    $place));
            echo functions::display_user($res, $arg);
            echo '</div>';
        }
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/forum/index.php/act/who/' . ($do == 'guest/?' ? 'do/guest/?' : ''),
            $start, $total, $kmess) . '</div>';
    }
    echo '<p>' . functions::link_back($lng['to_forum'], '/forum/index.php') .
        '</p>';
}

?>