<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $lng['forum'] . ' | ' . $lng['unread'];
$headmod = 'forumnew';
require ('../incfiles/head.php');
unset($_SESSION['fsort_id']);
unset($_SESSION['fsort_users']);
if (empty($_SESSION['uid']))
{
    if (isset($_GET['newup']))
    {
        $_SESSION['uppost'] = 1;
    }
    if (isset($_GET['newdown']))
    {
        $_SESSION['uppost'] = 0;
    }
}
if ($user_id)
{
    switch ($do)
    {
        case 'reset':
            $req = mysql_query("SELECT `forum`.`id`
            FROM `forum` LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
            WHERE `forum`.`type`='t'
            AND `cms_forum_rdm`.`topic_id` IS Null");
            while ($res = mysql_fetch_assoc($req))
            {
                mysql_query("INSERT INTO `cms_forum_rdm` SET
                    `topic_id` = '" . $res['id'] . "',
                    `user_id` = '$user_id',
                    `time` = '" . time() . "'
                ");
            }
            $req = mysql_query("SELECT `forum`.`id` AS `id`
            FROM `forum` LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
            WHERE `forum`.`type`='t'
            AND `forum`.`time` > `cms_forum_rdm`.`time`");
            while ($res = mysql_fetch_array($req))
            {
                mysql_query("UPDATE `cms_forum_rdm` SET
                    `time` = '" . time() . "'
                    WHERE `topic_id` = '" . $res['id'] . "' AND `user_id` = '$user_id'
                ");
            }
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['forum'], 'url' => '/forum/index.php'),
                array('label' => $lng_forum['unread_reset']),
                ));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<div class="alert alert-success"><p>' . $lng_forum['unread_reset_done'] .
                '<br /><a class="alert-link" href="' . $set['homeurl'] .
                '/forum/index.php">' . $lng_forum['to_forum'] . '</a></p></div>';
            break;

        case 'period':
            $vr = isset($_REQUEST['vr']) ? abs(intval($_REQUEST['vr'])) : 24;
            $vr1 = time() - $vr * 3600;
            if ($rights == 9)
            {
                $req = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `time` > '$vr1'");
            }
            else
            {
                $req = mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `time` > '$vr1' AND `close` != '1'");
            }
            $count = mysql_result($req, 0);

            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['forum'], 'url' => '/forum/index.php'),
                array('label' => $lng_forum['unread_all_for_period'] . ' ' . $vr .
                        ' ' . $lng_forum['hours']),
                ));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);

            echo '<div class="topmenu">' .
                '<form class="form-inline" role="form" action="' . $set['homeurl'] .
                '/forum/index.php/act/new/do/period" method="post">' .
                '<div class="form-group"><input class="form-control" type="text" maxlength="3" name="vr" value="' .
                $vr . '" size="3"/></div>' .
                ' <button class="btn btn-primary" type="submit" name="submit">' .
                $lng['show_for_period'] . '</button>' . '</form>' . '</div>';

            if ($count > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/forum/index.php/act/new/do/period/vr/' . $vr . '/', $start,
                    $count, $kmess) . '</div>';
            }

            if ($count > 0)
            {
                if ($rights == 9)
                {
                    $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `time` > '" .
                        $vr1 . "' ORDER BY `time` DESC LIMIT " . $start . "," .
                        $kmess);
                }
                else
                {
                    $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `time` > '" .
                        $vr1 .
                        "' AND `close` != '1' ORDER BY `time` DESC LIMIT " . $start .
                        "," . $kmess);
                }
                for ($i = 0; $res = mysql_fetch_array($req); ++$i)
                {
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                    $q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" .
                        $res['refid'] . "'");
                    $razd = mysql_fetch_array($q3);
                    $q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" .
                        $razd['refid'] . "'");
                    $frm = mysql_fetch_array($q4);
                    $colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" .
                        $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' :
                        " AND `close` != '1'") . " ORDER BY `time` DESC");
                    $colmes1 = mysql_num_rows($colmes);
                    $cpg = ceil($colmes1 / $kmess);
                    $nick = mysql_fetch_array($colmes);

                    if ($res['edit'])
                    {
                        echo functions::image('tz.gif');
                    }
                    elseif ($res['close'])
                    {
                        echo functions::image('dl.gif');
                    }
                    else
                    {
                        echo functions::image('np.gif');
                    }

                    if ($res['realid'] == 1)
                    {
                        echo functions::image('rate.gif');
                    }

                    echo '&#160;<a href="' . $set['homeurl'] .
                        '/forum/index.php/id/' . $res['id'] . ($cpg > 1 && $set_forum['upfp'] &&
                        $set_forum['postclip'] ? '/clip/true' : '') . ($set_forum['upfp'] &&
                        $cpg > 1 ? '/page/' . $cpg : '') . '">' . $res['text'] .
                        '</a>&#160;[' . $colmes1 . ']';
                    if ($cpg > 1)
                    {
                        echo '<a href="' . $set['homeurl'] .
                            '/forum/index.php/id/' . $res['id'] . (!$set_forum['upfp'] &&
                            $set_forum['postclip'] ? '/clip/true' : '') . ($set_forum['upfp'] ?
                            '' : '/page/' . $cpg) . '">&#160;&gt;&gt;</a>';
                    }

                    echo '<br /><div class="sub"><a href="' . $set['homeurl'] .
                        '/forum/index.php/id/' . $razd['id'] . '">' . $frm['text'] .
                        '&#160;/&#160;' . $razd['text'] . '</a><br />';
                    echo $res['from'];

                    if ($colmes1 > 1)
                    {
                        echo '&#160;/&#160;' . $nick['from'];
                    }

                    echo ' <span class="gray">' . functions::display_date($nick['time']) .
                        '</span>';
                    echo '</div></div>';
                }
            }
            else
            {
                echo '<div class="alert alert-info"><p>' . $lng_forum['unread_period_empty'] .
                    '</p></div>';
            }
            echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': ' . $count . '</div>';
            if ($count > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/index.php/act/new/do/period/vr/' . $vr . '/', $start, $count,
                    $kmess) . '</div>';
            }
            break;

        default:
            $total = counters::forum_new();
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['forum'], 'url' => '/forum/index.php'),
                array('label' => $lng['unread']),
                ));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            if ($total > $kmess)
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/forum/index.php/act/new/', $start, $total, $kmess) .
                    '</div>';
            if ($total > 0)
            {
                $req = mysql_query("SELECT * FROM `forum`
                LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '$user_id'
                WHERE `forum`.`type`='t'" . ($rights >= 7 ? "" :
                    " AND `forum`.`close` != '1'") . "
                AND (`cms_forum_rdm`.`topic_id` Is Null
                OR `forum`.`time` > `cms_forum_rdm`.`time`)
                ORDER BY `forum`.`time` DESC
                LIMIT $start, $kmess");
                for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
                {
                    if ($res['close'])
                        echo '<div class="alert alert-danger">';
                    else
                        echo $i % 2 ? '<div class="list2">' :
                            '<div class="list1">';
                    $q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type` = 'r' AND `id` = '" .
                        $res['refid'] . "' LIMIT 1");
                    $razd = mysql_fetch_assoc($q3);
                    $q4 = mysql_query("SELECT `id`, `text` FROM `forum` WHERE `type`='f' AND `id` = '" .
                        $razd['refid'] . "' LIMIT 1");
                    $frm = mysql_fetch_assoc($q4);
                    $colmes = mysql_query("SELECT `from`, `time` FROM `forum` WHERE `refid` = '" .
                        $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' :
                        " AND `close` != '1'") . " ORDER BY `time` DESC");
                    $colmes1 = mysql_num_rows($colmes);
                    $cpg = ceil($colmes1 / $kmess);
                    $nick = mysql_fetch_assoc($colmes);

                    $icons = array(
                        (isset($np) ? (!$res['vip'] ? functions::image('op.gif') :
                            '') : functions::image('np.gif')),
                        ($res['vip'] ? functions::image('pt.gif') : ''),
                        ($res['realid'] ? functions::image('rate.gif') : ''),
                        ($res['edit'] ? functions::image('tz.gif') : ''));
                    echo functions::display_menu($icons, '');
                    echo '<a href="' . $set['homeurl'] . '/forum/index.php/id/' .
                        $res['id'] . ($cpg > 1 && $set_forum['upfp'] && $set_forum['postclip'] ?
                        '/clip/true' : '') . ($set_forum['upfp'] && $cpg > 1 ?
                        '/page/' . $cpg : '') . '">' . $res['text'] .
                        '</a>&#160;[' . $colmes1 . ']';
                    if ($cpg > 1)
                        echo '&#160;<a href="' . $set['homeurl'] .
                            '/forum/index.php/id/' . $res['id'] . (!$set_forum['upfp'] &&
                            $set_forum['postclip'] ? '/clip/true' : '') . ($set_forum['upfp'] ?
                            '' : '/page/' . $cpg) . '">&gt;&gt;</a>';
                    echo '<div class="sub">' . $res['from'] . ($colmes1 > 1 ?
                        '&#160;/&#160;' . $nick['from'] : '') .
                        ' <span class="gray">(' . functions::display_date($nick['time']) .
                        ')</span><br />' . '<a href="' . $set['homeurl'] .
                        '/forum/index.php/id/' . $frm['id'] . '">' . $frm['text'] .
                        '</a>&#160;/&#160;<a href="' . $set['homeurl'] .
                        '/forum/index.php/id/' . $razd['id'] . '">' . $razd['text'] .
                        '</a>' . '</div></div>';
                }
            }
            else
            {
                echo '<div class="alert alert-info"><p>' . $lng['list_empty'] .
                    '</p></div>';
            }
            echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': ' . $total . '</div>';
            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/forum/index.php/act/new?', $start, $total, $kmess) .
                    '</div>';
            }

            if ($total)
            {
                echo '<p><a class="btn btn-danger" href="' . $set['homeurl'] .
                    '/forum/index.php/act/new/do/reset">' . $lng_forum['unread_reset'] .
                    '</a></p>';
            }

    }
}
else
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['forum'], 'url' => '/forum/index.php'),
        array('label' => $lng_forum['unread_last_10']),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    $req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' AND `close` != '1' ORDER BY `time` DESC LIMIT 10");
    if (mysql_num_rows($req))
    {
        for ($i = 0; $res = mysql_fetch_assoc($req); ++$i)
        {
            $q3 = mysql_query("select `id`, `refid`, `text` from `forum` where type='r' and id='" .
                $res['refid'] . "' LIMIT 1");
            $razd = mysql_fetch_assoc($q3);
            $q4 = mysql_query("select `id`, `refid`, `text` from `forum` where type='f' and id='" .
                $razd['refid'] . "' LIMIT 1");
            $frm = mysql_fetch_assoc($q4);
            $nikuser = mysql_query("SELECT `from`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" .
                $res['id'] . "'ORDER BY `time` DESC");
            $colmes1 = mysql_num_rows($nikuser);
            $cpg = ceil($colmes1 / $kmess);
            $nam = mysql_fetch_assoc($nikuser);
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

            $icons = array(
                ($res['vip'] ? functions::image('pt.gif') : ''),
                ($res['realid'] ? functions::image('rate.gif') : ''),
                ($res['edit'] ? functions::image('tz.gif') : ''));
            echo functions::display_menu($icons, '');
            echo '<a href="' . $set['homeurl'] . '/forum/index.php/id/' . $res['id'] .
                '">' . $res['text'] . '</a>&#160;[' . $colmes1 . ']';
            if ($cpg > 1)
                echo '&#160;<a href="' . $set['homeurl'] .
                    '/forum/index.php/id/' . $res['id'] . '/clip/true/page/' . $cpg .
                    '">&gt;&gt;</a>';
            echo '<br/><div class="sub"><a href="' . $set['homeurl'] .
                '/forum/index.php/id/' . $razd['id'] . '">' . $frm['text'] .
                '&#160;/&#160;' . $razd['text'] . '</a><br />';
            echo $res['from'];
            if (!empty($nam['from']))
            {
                echo '&#160;/&#160;' . $nam['from'];
            }
            echo ' <span class="gray">' . date("d.m.y / H:i", $nam['time']) .
                '</span>';
            echo '</div></div>';
        }
    }
    else
    {
        echo '<div class="alert alert-info"><p>' . $lng['list_empty'] .
            '</p></div>';
    }

}
echo '<p>' . functions::link_back($lng_forum['to_forum'], '/forum/index.php/') .
    '</p>';
