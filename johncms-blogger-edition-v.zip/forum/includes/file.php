<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

/*
* ////////////////////////////////////////////////////////////////////////////////
* // JohnCMS                Mobile Content Management System                    //
* // Project site:          http://johncms.com                                  //
* // Support site:          http://gazenwagen.com                               //
* ////////////////////////////////////////////////////////////////////////////////
* // Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
* // Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
* //                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
* ////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
$error = false;
if ($id)
{
    /*
    * -----------------------------------------------------------------
    * Скачивание прикрепленного файла Форума
    * -----------------------------------------------------------------
    */
    $req = mysql_query("SELECT * FROM `cms_forum_files` WHERE `id` = '$id'");
    if (mysql_num_rows($req))
    {
        $res = mysql_fetch_array($req);
        if (file_exists('../files/forum/attach/' . $res['filename']))
        {
            $dlcount = $res['dlcount'] + 1;
            mysql_query("UPDATE `cms_forum_files` SET  `dlcount` = '$dlcount' WHERE `id` = '$id'");
            header('Location: ' . core::$system_set['homeurl'] .
                '/files/forum/attach/' . $res['filename']);
        }
        else
        {
            $error = true;
        }
    }
    else
    {
        $error = true;
    }
    if ($error)
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_file_not_exist'], '<a href="' .
            $set['homeurl'] . '/forum/index.php">' . $lng['to_forum'] . '</a>');
        require ('../incfiles/end.php');
        exit;
    }
}
else
{
    header('Location: ' . core::$system_set['homeurl'] . '/forum/index.php');
}

?>