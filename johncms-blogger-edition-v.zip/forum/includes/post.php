<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (empty($_GET['id']))
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}

$req = mysql_query("SELECT `forum`.*, `users`.`sex`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`datereg`
FROM `forum` LEFT JOIN `users` ON `forum`.`user_id` = `users`.`id`
WHERE `forum`.`type` = 'm' AND `forum`.`id` = '$id'" . ($rights >= 7 ? "" :
    " AND `forum`.`close` != '1'") . " LIMIT 1");
$res = mysql_fetch_array($req);
if ($res === false)
{
    require ('../incfiles/head.php');
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}

$them = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum` WHERE `type` = 't' AND `id` = '" .
    $res['refid'] . "'"));

$page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" .
    $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">=" : "<=") . " '$id'"),
    0) / $kmess);
$textl = $lng_forum['read_all'];
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['forum'], 'url' => '/forum/index.php'),
    array('label' => $them['text'], 'url' => '/forum/index.php/id/' . $res['refid'] .
            '/page/' . $page),
    array('label' => $lng_forum['read_all']),
    ));
require ('../incfiles/head.php');
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
echo '<p class="text-right no-print"><button class="btn btn-default btn-flat" type="button" ' .
    'onclick="window.print()">' .
    '<i class="fa fa-print"></i> Print</button></p>';
echo '<div class="box box-solid"><div class="box-body">';

if ($set_user['avatar'])
{
    echo '<table cellpadding="0" cellspacing="0"><tr><td>';
    if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
        echo '<img src="' . $set['homeurl'] . '/files/users/avatar/' . $res['user_id'] .
            '.png" width="32" height="32" alt="' . $res['from'] . '" />&#160;';
    else
        echo '<img src="' . $set['homeurl'] .
            '/images/empty.png" width="32" height="32" alt="' . $res['from'] .
            '" />&#160;';
    echo '</td><td>';
}
if ($res['sex'])
    echo functions::image(($res['sex'] == 'm' ? 'm' : 'w') . ($res['datereg'] >
        time() - 86400 ? '_new' : '') . '.png', array('class' => 'icon-inline'));
else
    echo functions::image('del.png');

if ($user_id && $user_id != $res['user_id'])
{
    echo '<a href="' . $set['homeurl'] . '/users/profile.php/user/' . $res['user_id'] .
        '"><b>' . $res['from'] . '</b></a> ';
}
else
{
    echo '<b>' . $res['from'] . '</b> ';
}

$user_rights = array(
    3 => '(FMod)',
    6 => '(Smd)',
    7 => '(Adm)',
    9 => '(SV!)');
echo @$user_rights[$res['rights']];

echo (time() > $res['lastdate'] + 300 ?
    ' <span class="label label-danger offline">Off</span> ' :
    ' <span class="label label-success online">ON</span> ');
echo '<a href="' . $set['homeurl'] . '/forum/index.php/act/post/id/' . $res['id'] .
    '"  data-toggle="tooltip" data-title="Link to post">[#]</a>';

if ($user_id && $user_id != $res['user_id'])
{
    echo '&#160;<a href="' . $set['homeurl'] . '/forum/index.php/act/say/id/' .
        $res['id'] . '/start/' . $start . '">' . $lng_forum['reply_btn'] .
        '</a>&#160;' . '<a href="' . $set['homeurl'] .
        '/forum/index.php/act/say/id/' . $res['id'] . '/start/' . $start .
        '/cyt">' . $lng_forum['cytate_btn'] . '</a> ';
}

echo ' <span class="gray">(' . functions::display_date($res['time']) .
    ')</span><br />';

if (!empty($res['status']))
    echo '<div class="status">' . functions::image('label.png', array('class' =>
            'icon-inline')) . $res['status'] . '</div>';
if ($set_user['avatar'])
    echo '</td></tr></table>';

$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = nl2br($text);
$text = bbcode::tags($text);
if ($set_user['smileys'])
    $text = functions::smileys($text, ($res['rights'] >= 1) ? 1 : 0);
echo $text . '';

$freq = mysql_query("SELECT * FROM `cms_forum_files` WHERE `post` = '" . $res['id'] .
    "'");
if (mysql_num_rows($freq) > 0)
{
    $fres = mysql_fetch_assoc($freq);
    $fls = round(@filesize('../files/forum/attach/' . $fres['filename']) / 1024,
        2);
    echo '<div class="gray" style="font-size: x-small; background-color: rgba(128, 128, 128, 0.1); padding: 2px 4px; margin-top: 4px">' .
        $lng_forum['attached_file'] . ':';

    $att_ext = strtolower(functions::format('./files/forum/attach/' . $fres['filename']));
    $pic_ext = array(
        'gif',
        'jpg',
        'jpeg',
        'png');
    if (in_array($att_ext, $pic_ext))
    {
        echo '<p><a href="' . $set['homeurl'] . '/forum/index.php/act/file/id/' .
            $fres['id'] . '">';
        echo '<img src="' . $set['homeurl'] . '/forum/thumbinal.php?file=' . (urlencode
            ($fres['filename'])) . '" alt="' . $lng_forum['click_to_view'] .
            '" /></a></p>';
    }
    else
    {
        echo '<br /><a href="' . $set['homeurl'] .
            '/forum/index.php/act/file/id/' . $fres['id'] . '">' . $fres['filename'] .
            '</a>';
    }
    echo ' (' . $fls . ' kb.)<br/>';
    echo $lng_forum['downloads'] . ': ' . $fres['dlcount'] . ' ' . $lng_forum['time'] .
        '</div>';
    $file_id = $fres['id'];
}

if ((($rights == 3 || $rights >= 6 || $curator) && $rights >= $res['rights']) ||
    ($res['user_id'] == $user_id && !$set_forum['upfp'] && ($start + $i) == $colmes &&
    $res['time'] > time() - 300) || ($res['user_id'] == $user_id && $set_forum['upfp'] &&
    $start == 0 && $i == 1 && $res['time'] > time() - 300) || ($i == 1 && $allow ==
    2 && $res['user_id'] == $user_id))
{

    $menu = array(
        '<a href="' . $set['homeurl'] . '/forum/index.php/act/editpost/id/' . $res['id'] .
            '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
            '</a>',
        ($rights >= 7 && $res['close'] == 1 ? '<a href="' . $set['homeurl'] .
            '/forum/index.php/act/editpost/do/restore/id/' . $res['id'] .
            '"><span class="glyphicon glyphicon-repeat"></span> ' . $lng_forum['restore'] .
            '</a>' : ''),
        ($res['close'] == 1 ? '' : '<a href="' . $set['homeurl'] .
            '/forum/index.php/act/editpost/do/del/id/' . $res['id'] .
            '"><span class="glyphicon glyphicon-remove"></span> ' . $lng['delete'] .
            '</a>'));
    echo '<div class="sub">';
    echo functions::display_menu($menu);
    if ($res['close'])
    {
        echo '<div class="red">' . $lng_forum['who_delete_post'] . ': <b>' . $res['close_who'] .
            '</b></div>';
    }
    elseif (!empty($res['close_who']))
    {
        echo '<div class="green">' . $lng_forum['who_restore_post'] . ': <b>' .
            $res['close_who'] . '</b></div>';
    }
    if ($rights == 3 || $rights >= 6)
    {
        if ($res['ip_via_proxy'])
        {
            echo '<div class="gray"><b class="red"><a href="' . $set['homeurl'] .
                '/' . $set['admp'] . '/index.php/act/search_ip/ip/' . long2ip($res['ip']) .
                '">' . long2ip($res['ip']) . '</a></b> - ' . '<a href="' . $set['homeurl'] .
                '/' . $set['admp'] . '/index.php/act/search_ip/ip/' . long2ip($res['ip_via_proxy']) .
                '">' . long2ip($res['ip_via_proxy']) . '</a>' . ' - ' . $res['soft'] .
                '</div>';
        }
        else
        {
            echo '<div class="gray"><a href="' . $set['homeurl'] . '/' . $set['admp'] .
                '/index.php/act/search_ip/ip/' . long2ip($res['ip']) . '">' .
                long2ip($res['ip']) . '</a> - ' . $res['soft'] . '</div>';
        }
    }
    echo '</div>';
}

echo '</div></div>';
echo '<p class="no-print">' . functions::link_back($lng_forum['back_to_topic'],
    '/forum/index.php/id/' . $res['refid'] . '/page/' . $page) . '</p>';
