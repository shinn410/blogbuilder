<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights == 3 || $rights >= 6)
{
    if (!$id)
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require ('../incfiles/end.php');
        exit;
    }

    $req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 't'");
    if (!mysql_num_rows($req))
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng_forum['error_topic_deleted']);
        require ('../incfiles/end.php');
        exit;
    }
    $res = mysql_fetch_assoc($req);
    if (isset($_POST['submit']))
    {
        $del = isset($_POST['del']) ? intval($_POST['del']) : null;
        if ($del == 2 && core::$user_rights == 9)
        {
            $req1 = mysql_query("SELECT * FROM `cms_forum_files` WHERE `topic` = '$id'");
            if (mysql_num_rows($req1))
            {
                while ($res1 = mysql_fetch_assoc($req1))
                {
                    unlink('../files/forum/attach/' . $res1['filename']);
                }
                mysql_query("DELETE FROM `cms_forum_files` WHERE `topic` = '$id'");
                mysql_query("OPTIMIZE TABLE `cms_forum_files`");
            }
            mysql_query("DELETE FROM `forum` WHERE `refid` = '$id'");
            mysql_query("DELETE FROM `forum` WHERE `id`='$id'");
        }
        elseif ($del = 1)
        {
            mysql_query("UPDATE `forum` SET `close` = '1', `close_who` = '$login' WHERE `id` = '$id'");
            mysql_query("UPDATE `cms_forum_files` SET `del` = '1' WHERE `topic` = '$id'");
        }
        header('Location: ' . core::$system_set['homeurl'] .
            '/forum/index.php/id/' . $res['refid']);
    }
    else
    {
        require ('../incfiles/head.php');
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id),
            array('label' => $lng_forum['topic_delete']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<div class="alert alert-danger"><form method="post" action="' . $set['homeurl'] .
            '/forum/index.php/act/deltema/id/' . $id . '">' . '<h3>' . $lng['delete_confirmation'] .
            '</h3>' .
            '<div class="radio"><label><input type="radio" value="1" name="del" checked="checked"/>&#160;' .
            $lng['hide'] . '</label></div>' . (core::$user_rights == 9 ?
            '<div class="radio"><label><input type="radio" value="2" name="del" />&#160;' .
            $lng['delete'] . '</label></div>' : '') .
            '<p><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['do'] . '</button></p>' . '</form></div>' . '<p>' . functions::link_back($lng['back'],
            'forum/index.php/id/' . $id) . '</p>';
    }
}
else
{
    echo functions::display_error($lng['access_forbidden']);
}
