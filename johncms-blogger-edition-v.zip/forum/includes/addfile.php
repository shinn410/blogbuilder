<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require ('../incfiles/head.php');
if (!$id || !$user_id)
{
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}

$req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id'");
$res = mysql_fetch_assoc($req);
if ($res['type'] != 'm' || $res['user_id'] != $user_id)
{
    echo functions::display_error($lng['error_wrong_data']);
    require ('../incfiles/end.php');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $res['refid'] .
            '/page/' . $page),
    array('label' => $lng_forum['add_file']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);

if ($res['time'] < (time() - 180))
{
    echo functions::display_error($lng_forum['upload_timeout'], '<a href="' . $set['homeurl'] .
        '/forum/index.php/id/' . $res['refid'] . '/page/' . $page . '">' . $lng['back'] .
        '</a>');
    require ('../incfiles/end.php');
    exit;
}

$exist = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_files` WHERE `post` = '$id'"),
    0);
if ($exist)
{
    echo functions::display_error($lng_forum['error_file_uploaded']);
    require ('../incfiles/end.php');
    exit;
}

if (isset($_POST['submit']))
{
    $do_file = false;
    $file = '';
    if ($_FILES['fail']['size'] > 0)
    {

        $do_file = true;
        $file = functions::rus_lat(mb_strtolower($_FILES['fail']['name']));
        $fsize = $_FILES['fail']['size'];
    }
    if ($do_file)
    {

        $al_ext = array_merge($ext_win, $ext_java, $ext_sis, $ext_doc, $ext_pic,
            $ext_arch, $ext_video, $ext_audio, $ext_other);
        $ext = explode(".", $file);
        $error = array();

        if ($fsize > 1024 * $set['flsz'])
            $error[] = $lng_forum['error_file_size'] . ' ' . $set['flsz'] .
                'kb.';

        if (count($ext) != 2)
            $error[] = $lng_forum['error_file_name'];

        if (!in_array($ext[1], $al_ext))
            $error[] = $lng_forum['error_file_ext'] . ':<br />' . implode(', ',
                $al_ext);

        if (mb_strlen($ext[0]) == 0)
        {
            $ext[0] = '---';
        }
        $ext[0] = str_replace(" ", "_", $ext[0]);
        $fname = mb_substr($ext[0], 0, 32) . '.' . $ext[1];

        if (preg_match("/[^\da-z_\-.]+/", $fname))
            $error[] = $lng_forum['error_file_symbols'];

        if (file_exists("../files/forum/attach/$fname"))
        {
            $fname = time() . $fname;
        }

        if (!$error && $do_file)
        {

            if ((move_uploaded_file($_FILES["fail"]["tmp_name"],
                "../files/forum/attach/$fname")) == true)
            {
                @chmod("$fname", 0777);
                @chmod("../files/forum/attach/$fname", 0777);
                echo '<div class="alert alert-success">' . $lng_forum['file_uploaded'] .
                    '</div>';
            }
            else
            {
                $error[] = $lng_forum['error_upload_error'];
            }
        }

        if (!$error)
        {

            $ext = strtolower($ext[1]);
            if (in_array($ext, $ext_win))
                $type = 1;
            elseif (in_array($ext, $ext_java))
                $type = 2;
            elseif (in_array($ext, $ext_sis))
                $type = 3;
            elseif (in_array($ext, $ext_doc))
                $type = 4;
            elseif (in_array($ext, $ext_pic))
                $type = 5;
            elseif (in_array($ext, $ext_arch))
                $type = 6;
            elseif (in_array($ext, $ext_video))
                $type = 7;
            elseif (in_array($ext, $ext_audio))
                $type = 8;
            else
                $type = 9;

            $req2 = mysql_query("SELECT * FROM `forum` WHERE `id` = '" . $res['refid'] .
                "'");
            $res2 = mysql_fetch_array($req2);
            $req3 = mysql_query("SELECT * FROM `forum` WHERE `id` = '" . $res2['refid'] .
                "'");
            $res3 = mysql_fetch_array($req3);

            mysql_query("INSERT INTO `cms_forum_files` SET
                        `cat` = '" . $res3['refid'] . "',
                        `subcat` = '" . $res2['refid'] . "',
                        `topic` = '" . $res['refid'] . "',
                        `post` = '$id',
                        `time` = '" . $res['time'] . "',
                        `filename` = '" . mysql_real_escape_string($fname) . "',
                        `filetype` = '$type'
                    ");
        }
        else
        {
            echo functions::display_error($error, '<a class="alert-link" href="' .
                $set['homeurl'] . '/forum/index.php/act/addfile/id/' . $id .
                '">' . $lng['repeat'] . '</a>');
            echo '<p>' . functions::link_back($lng['back'],
                'forum/index.php/id/' . $res['refid']) . '</p>';
        }
    }
    else
    {
        echo '<div class="alert alert-danger">' . $lng_forum['error_upload_error'] .
            '</div>';
    }
    $pa = mysql_query("SELECT `id` FROM `forum` WHERE `type` = 'm' AND `refid` = '" .
        $res['refid'] . "'");
    $pa2 = mysql_num_rows($pa);
    $page = ceil($pa2 / $kmess);
    echo '<p>' . functions::link_back($lng['continue'] . ' &rarr;',
        '/forum/index.php/id/' . $res['refid'] . '/page/' . $page . '#post' . $res['id'], false) .
        '</p>';
}
else
{
    echo '<form role="form" action="' . $set['homeurl'] .
        '/forum/index.php/act/addfile/id/' . $id .
        '" method="post" enctype="multipart/form-data">';
    echo '<div class="form-group">' . '<label>' . $lng_forum['select_file'] .
        '</label>';
    if (stristr($agn, 'Opera/8.01'))
    {
        echo '<input name="fail1" value =""/>&#160;<br/><a href="' . $set['homeurl'] .
            '/op:fileselect">' . $lng_forum['select_file'] . '</a>';
    }
    else
    {
        echo '<input type="file" name="fail"/>';
    }
    echo '<p class="help-block">' . $lng_forum['max_size'] . ': ' . $set['flsz'] .
        'kb.</p>' . '</div>';
    echo '<p><button class="btn btn-primary" type="submit" name="submit">' . $lng_forum['upload'] .
        '</button></p></form>';
    echo '<p>' . functions::link_back($lng['back'], 'forum/index.php/id/' . $res['refid']) .
        '</p>';
}
