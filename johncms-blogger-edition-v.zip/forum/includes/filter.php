<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require ('../incfiles/head.php');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id .
            '/start/' . $start),
    array('label' => $lng_forum['filter_on_author']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if (!$id)
{
    echo functions::display_error($lng['error_wrong_data']);
    echo '<p>' . functions::link_back($lng_forum['return_to_topic'],
        '/forum/index.php/id/' . $id . '/start/' . $start) . '</p>';
    require ('../incfiles/end.php');
    exit;
}
switch ($do)
{
    case 'unset':
        unset($_SESSION['fsort_id']);
        unset($_SESSION['fsort_users']);
        header("Location: " . core::$system_set['homeurl'] .
            "/forum/index.php/id/$id");
        break;

    case 'set':
        $users = isset($_POST['users']) ? $_POST['users'] : '';
        if (empty($_POST['users']))
        {
            echo '<div class="alert alert-danger"><p>' . $lng_forum['error_author_select'] .
                '</p></div>';
            echo '<p>' . functions::link_back($lng_forum['return_to_topic'],
                '/forum/index.php/id/' . $id . '/start/' . $start) . '</p>';
            require ('../incfiles/end.php');
            exit;
        }
        $array = array();
        foreach ($users as $val)
        {
            $array[] = intval($val);
        }
        $_SESSION['fsort_id'] = $id;
        $_SESSION['fsort_users'] = serialize($array);
        header("Location: " . core::$system_set['homeurl'] .
            "/forum/index.php/id/$id");
        break;

    default:
        $req = mysql_query("SELECT *, COUNT(`from`) AS `count` FROM `forum` WHERE `refid` = '$id' GROUP BY `from` ORDER BY `from`");
        $req = mysql_query("SELECT *, COUNT(`from`) AS `count` FROM `forum` WHERE `refid` = '$id' GROUP BY `from` ORDER BY `from`");
        $total = mysql_num_rows($req);
        if ($total > 0)
        {
            echo '<form role="form" action="' . $set['homeurl'] .
                '/forum/index.php/act/filter/id/' . $id . '/start/' . $start .
                '/do/set" method="post">';
            $i = 0;
            while ($res = mysql_fetch_array($req))
            {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '<input type="checkbox" name="users[]" value="' . $res['user_id'] .
                    '"/>&#160;' . '<a href="' . $set['homeurl'] .
                    '/users/profile.php/user/' . $res['user_id'] . '">' . $res['from'] .
                    '</a> [' . $res['count'] . ']</div>';
                ++$i;
            }
            echo '<br/><button class="btn btn-primary" type="submit" name="submit">' .
                $lng_forum['filter_to'] . '</button><br/>' .
                '<div class="alert alert-info" style="margin-top:10px;"><small>' .
                $lng_forum['filter_on_author_help'] . '</small></div>' .
                '</form>';
        }
        else
        {
            echo functions::display_error($lng['error_wrong_data']);
        }
}
echo '<p>' . functions::link_back($lng_forum['return_to_topic'],
    '/forum/index.php/id/' . $id . '/start/' . $start) . '</p>';
