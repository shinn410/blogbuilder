<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

/*
* ////////////////////////////////////////////////////////////////////////////////
* // JohnCMS                Mobile Content Management System                    //
* // Project site:          http://johncms.com                                  //
* // Support site:          http://gazenwagen.com                               //
* ////////////////////////////////////////////////////////////////////////////////
* // Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
* // Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
* //                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
* ////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if (($rights != 3 && $rights < 6) || !$id)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$req = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND (`type` = 't' OR `type` = 'm')");
if (mysql_num_rows($req))
{
    $res = mysql_fetch_assoc($req);
    mysql_query("UPDATE `forum` SET `close` = '0', `close_who` = '$login' WHERE `id` = '$id'");
    if ($res['type'] == 't')
    {
        header('Location: ' . core::$system_set['homeurl'] .
            '/forum/index.php/id/' . $id);
    }
    else
    {
        $page = ceil(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `refid` = '" .
            $res['refid'] . "' AND `id` " . ($set_forum['upfp'] ? ">=" : "<=") .
            " '" . $id . "'"), 0) / $kmess);
        header('Location: ' . core::$system_set['homeurl'] .
            '/forum/index.php/id/' . $res['refid'] . '/page/' . $page);
    }
}
else
{
    header('Location: ' . core::$system_set['homeurl'] . '/forum/index.php');
}

?>