<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights == 3 || $rights >= 6)
{
    if (!$id)
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require ('../incfiles/end.php');
        exit;
    }
    $typ = mysql_query("SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 't'");
    if (!mysql_num_rows($typ))
    {
        require ('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require ('../incfiles/end.php');
        exit;
    }
    if (isset($_POST['submit']))
    {
        $razd = isset($_POST['razd']) ? abs(intval($_POST['razd'])) : false;
        if (!$razd)
        {
            require ('../incfiles/head.php');
            echo functions::display_error($lng['error_wrong_data']);
            require ('../incfiles/end.php');
            exit;
        }
        $typ1 = mysql_query("SELECT * FROM `forum` WHERE `id` = '$razd' AND `type` = 'r'");
        if (!mysql_num_rows($typ1))
        {
            require ('../incfiles/head.php');
            echo functions::display_error($lng['error_wrong_data']);
            require ('../incfiles/end.php');
            exit;
        }
        mysql_query("UPDATE `forum` SET
            `refid` = '$razd'
            WHERE `id` = '$id'
        ");
        header("Location: " . core::$system_set['homeurl'] .
            "/forum/index.php/id/$id");
    }
    else
    {
        $ms = mysql_fetch_assoc($typ);
        require ('../incfiles/head.php');
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['forum'], 'url' => '/forum/index.php/id/' . $id),
            array('label' => $lng_forum['topic_move']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if (empty($_GET['other']))
        {
            $rz = mysql_query("select * from `forum` where id='" . $ms['refid'] .
                "';");
            $rz1 = mysql_fetch_assoc($rz);
            $other = $rz1['refid'];
        }
        else
        {
            $other = intval(functions::check($_GET['other']));
        }
        $fr = mysql_query("select * from `forum` where id='" . $other . "';");
        $fr1 = mysql_fetch_assoc($fr);
        echo '<form role="form" action="' . $set['homeurl'] .
            '/index.php/act/per/id/' . $id . '" method="post">' .
            '<div class="form-group">' . '<label>' . $lng['category'] .
            '</label><br/>' .
            '<input class="form-control" id="disabledInput" type="text" placeholder="' .
            $fr1['text'] . '" disabled>' . '</div>' . '<div class="form-group">' .
            '<label for="razd">' . $lng['section'] . '</label>' .
            '<select class="form-control" name="razd">';
        $raz = mysql_query("SELECT * FROM `forum` WHERE `refid` = '$other' AND `type` = 'r' AND `id` != '" .
            $ms['refid'] . "' ORDER BY `realid` ASC");
        while ($raz1 = mysql_fetch_assoc($raz))
        {
            echo '<option value="' . $raz1['id'] . '">' . $raz1['text'] .
                '</option>';
        }
        echo '</select></div>' .
            '<p><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['move'] . '</button></p>' . '</form>' .
            '<div class="list-group">' .
            '<div class="list-group-item list-group-item-info">' . $lng_forum['other_categories'] .
            '</div>';
        $frm = mysql_query("SELECT * FROM `forum` WHERE `type` = 'f' AND `id` != '$other' ORDER BY `realid` ASC");
        $i = isset($i) ? $i : 0;
        while ($frm1 = mysql_fetch_assoc($frm))
        {

            echo '<a class="list-group-item" href="' . $set['homeurl'] .
                '/forum/index.php/act/per/id/' . $id . '/other/' . $frm1['id'] .
                '">' . $frm1['text'] . '</a>';
            ++$i;
        }
        echo '</div>';
        echo '<p>' . functions::link_back($lng['back'], 'forum/index.php/id/' .
            $id) . '</p>';
    }
}

?>