<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights == 3 || $rights >= 6)
{
    require ('../incfiles/head.php');
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(
        array('label' => $lng['forum'], 'url' => '/forum/index.php'),
        array('label' => $lng['delete']),
        ));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if (isset($_GET['yes']))
    {
        $dc = $_SESSION['dc'];
        $prd = $_SESSION['prd'];
        foreach ($dc as $delid)
        {
            mysql_query("UPDATE `forum` SET
                `close` = '1',
                `close_who` = '$login'
                WHERE `id` = '" . intval($delid) . "'
            ");
        }
        echo '<div class="alert alert-success">' . $lng_forum['mass_delete_confirm'] .
            '</div>';
        echo '<p>' . functions::link_back($lng['back'], $prd) . '</p>';
    }
    else
    {
        if (empty($_POST['delch']))
        {
            echo '<div class="alert alert-danger">' . $lng_forum['error_mass_delete'] .
                '</div>';
            echo '<p>' . functions::link_back($lng['back'], htmlspecialchars(getenv
                ("HTTP_REFERER"))) . '</p>';
            require ('../incfiles/end.php');
            exit;
        }
        foreach ($_POST['delch'] as $v)
        {
            $dc[] = intval($v);
        }
        $_SESSION['dc'] = $dc;
        $_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
        echo '<div class="alert alert-warning">' . $lng['delete_confirmation'] .
            '</div>' . '<a class="btn btn-danger" href="' . $set['homeurl'] .
            '/forum/index.php/act/massdel/yes">' . $lng['delete'] . '</a>' .
            ' <a class="btn btn-primary" href="' . htmlspecialchars(getenv("HTTP_REFERER")) .
            '">' . $lng['cancel'] . '</a>';
        echo '<p>' . functions::link_back($lng['back'], htmlspecialchars(getenv
            ("HTTP_REFERER"))) . '</p>';
    }
}

?>