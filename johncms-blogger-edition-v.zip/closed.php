<!DOCTYPE HTML>
<html>
	<head>
		<title>
			Akses ditutup!
		</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<link href="http://fonts.googleapis.com/css?family=Courgette" rel="stylesheet" type="text/css"/>
		<style type="text/css">
			body {
			font-family: 'Courgette ',cursive;
			}

			body {
			background:#f3f3e1;
			}

			.wrap {
			width:100%;
			}

			.logo,.text {
			text-align:center;
			margin:50px 0 0 0;
			}

			img.img {
			width:180px;
			}

			.sub a {
			color:white;
			background:#8F8E8C;
			text-decoration:none;
			padding:4px 70px;
			font-size:13px;
			font-family:arial,serif;
			font-weight:bold;
			-webkit-border-radius:3em;
			-moz-border-radius:.1em;
			-border-radius:.1em;
			}

			.footer {
			color:#8F8E8C;
			position:absolute;
			right:10px;
			bottom:2px;
			font-size:10px;
			}

			.footer a {
			color:rgb(228,146,162);
			}
		</style>
	</head>
	<body>
		<div class="wrap">
			<div class="text">
				<h2>
					Perhatian!
				</h2>
				<p>
					Mohon maaf untuk sementar waktu akses ke situs sedang ditutup.
				</p>
				<p>
					Silakan coba beberapa saat lagi.
				</p>
			</div>
		</div>
		<div class="footer">
			Powered By
			<a href="http://johncms.com">JohnCMS</a>
		</div>
	</body>
</html>