<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
    mysql_real_escape_string($id) . "' AND `type`='file'");
if (!$user_id)
{
    header("location: " . $home . "/templates/index.php");
    exit;
}

if (mysql_num_rows($treq) == 0)
{
    header("Location: " . $home . "/templates/index.php");
    exit;
}
$tres = mysql_fetch_array($treq);
$template = $tres['template'];
if (!isset($_SESSION['set']))
    $_SESSION['set'] = md5(time());
$submit = $_SESSION['set'];
$textl = "Memasang";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Templates', 'url' => '/templates'),
    array('label' => htmlspecialchars($tres['name']), 'url' =>
            '/templates/detail.php/id/' . $tres['id']),
    array('label' => $textl),
    ));
require ('../incfiles/head.php');

$req = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='" . $user_id .
    "'");
if (mysql_num_rows($req) == 0)
{
    echo '<div class="alert alert-danger">' .
        'Kamu belum memiliki satu pun blog. ' .
        'Untuk membuat blog silakan <a class="alert-link" href="' . $home .
        '/blogpanel/act/create_blog">klik di sini</a>.</div>';
    require ('../incfiles/end.php');
    exit;
}
if (isset($_POST[$submit]))
{
    unset($_SESSION['set']);
    $blog_id = abs(intval(@$_POST['blog_id']));

    $b = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='" .
        mysql_real_escape_string($blog_id) . "' AND `user_id`='" . $user_id .
        "'");
    if (mysql_num_rows($b) == 0)
        $error = 'Blog yang dipilih tidak benar.';
    if (empty($error))
    {
        $bl = mysql_fetch_array($b);
        if (!is_dir('../sites/' . $bl['url'] . '/templates/'))
            mkdir('../sites/' . $bl['url'] . '/templates/', 0777);
        if (copy("../files/templates/files/" . $template . ".html", '../sites/' .
            $bl['url'] . '/templates/' . $tres['theme'] . '.html'))
        {
            $total_usage = mysql_result(mysql_query("SELECT COUNT(*) FROM `templates` WHERE `user_id`='" .
                $user_id . "' AND `name`='" . $bl['id'] . "' AND `template`='" .
                $tres['id'] . "' AND `type`='set'"), 0);
            if ($total_usage == 0)
            {
                mysql_query("INSERT INTO `templates` SET `user_id`='" . $user_id .
                    "',`name`='" . $bl['id'] . "',`template`='" . $tres['id'] .
                    "',`text`='" . $bl['url'] . "',`type`='set',`time`='" . time
                    () . "'");
            }
            else
            {
                mysql_query("UPDATE `templates` SET `time`='" . time() .
                    "' WHERE `user_id`='" . $user_id . "' AND `name`='" . $bl['id'] .
                    "' AND `template`='" . $tres['id'] . "' AND `type`='set'");
            }
            echo '<div class="alert alert-success">Template <a class="alert-link" href="' .
                $home . '/templates/detail.php/id/' . $tres['id'] . '">' .
                htmlspecialchars($tres['name']) .
                '</a> berhasil dipasang pada <a class="alert-link" href="http://' .
                $bl['url'] . '">' . htmlspecialchars($bl['title']) . '</a>';
        }
        else
        {
            echo functions::display_error('Template gagal dipasang.');
        }
    }
    else
    {
        echo functions::display_error($error .
            '<br /><a class="alert-link" href="' . $home .
            '/templates/set.php/id/' . $tres['id'] . '">Ulangi</a>');
    }
}
else
{
    echo '<form method="post" action="' . $home . '/templates/set.php/id/' . $tres['id'] .
        '"><div class="form-group"><label>Pilih Blog</label>';
    while ($blog = mysql_fetch_array($req))
    {
        echo '<div class="radio"><label><input type="radio" name="blog_id" value="' .
            $blog['id'] . '"/>&nbsp;' . htmlspecialchars($blog['title']) .
            '</label></div>';
    }
    echo '</div><p><input class="btn btn-primary" type="submit" name="' . $submit .
        '" value="Pasang Template"/></p></form>';
}
require ('../incfiles/end.php');

?>