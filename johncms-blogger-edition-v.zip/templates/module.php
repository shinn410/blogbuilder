<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
if ($rights == 7 || $rights == 9)
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) .
        "' AND (`type`='xfile' OR `type`='file')");
}
else
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) . "' AND `type`='file'");
}
if (mysql_num_rows($treq) == 0)
{
    header("Location: " . $home . "/templates/index.php");
    exit;
}
$tres = mysql_fetch_array($treq);
if (!$user_id or !isset($_SESSION['auth']))
{
    header("location: " . $home . "/templates/detail.php/id/" . $tres['id']);
    exit;
}
switch ($act)
{
    case 'delete':
        $template = $tres['template'];
        if ((($tres['user_id'] == $user_id) || $rights == 7 || $rights == 9) &&
            $_SESSION['auth'] == $_GET['sess'])
        {
            if (unlink("../files/templates/files/" . $template . ".html") === false)
            {
                require ("../incfiles/head.php");
                echo
                    '<div class="alert alert-danger">Gagal menghapus file!</div>';
                require ("../incfiles/end.php");
                exit();
            }
            if (file_exists("../files/templates/screenshot/" . $template .
                ".jpg"))
                unlink("../files/templates/screenshot/" . $template . ".jpg");
            if (file_exists("../files/templates/description/" . $template .
                ".txt"))
                unlink("../files/templates/description/" . $template . ".txt");
            if (file_exists("../files/templates/download/" . $template . ".zip"))
                unlink("../files/templates/download/" . $template . ".zip");
            mysql_query("DELETE FROM `templates` WHERE `template`='" . $tres['id'] .
                "' AND `type`='comment'");
            mysql_query("DELETE FROM `templates` WHERE `template`='" . $tres['id'] .
                "' AND `type`='like'");
            mysql_query("DELETE FROM `templates` WHERE `template`='" . $tres['id'] .
                "' AND `type`='notlike'");
            mysql_query("DELETE FROM `templates` WHERE `id`='" . $tres['id'] .
                "' AND (`type`='file' OR `type`='xfile')");
        }
        header("Location: " . $home . "/templates/index.php");
        break;

    case 'accept':
        if ($rights == 7 || $rights == 9)
        {
            mysql_query("UPDATE `templates` SET `type`='file' WHERE `id`='" . $tres['id'] .
                "'");
        }
        header("Location: " . $home . "/templates/detail.php/id/" . $tres['id']);
        break;
    case 'add_comment':
        if (!isset($_POST['submit']) or $_SESSION['auth'] != $_POST['sess'] or
            mb_strlen($_POST['msg']) < 2 or mb_strlen($_POST['msg']) > 5000)
        {
            header("Location: " . $home . "/templates/detail.php/id/" . $tres['id']);
            exit;
        }
        mysql_query("INSERT INTO `templates` SET `user_id`='" . $user_id .
            "',`name`='" . mysql_real_escape_string($datauser['name']) .
            "',`template`='" . $tres['id'] . "',`text`='" .
            mysql_real_escape_string($_POST['msg']) .
            "',`type`='comment',`time`='" . mysql_real_escape_string(time()) .
            "'");
        header("Location: " . $home . "/templates/detail.php/id/" . $tres['id']);
        break;
    case 'delete_comment':
        if (($_GET['sess'] == $_SESSION['auth']) and ($tres['user_id'] == $user_id or
            $rights == 7 or $rights == 9))
        {
            unset($_SESSION['auth']);
            mysql_query("DELETE FROM `templates` WHERE `id`='" .
                mysql_real_escape_string($_GET['cid']) . "' AND `template`='" .
                $tres['id'] . "' AND `type`='comment'");
        }
        header("Location: " . $home . "/templates/detail.php/id/" . $tres['id']);
        break;
    default:
        header("Location: " . $home . "/templates/detail.php/id/" . $tres['id']);
        break;
}

?>