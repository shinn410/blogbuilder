<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
    mysql_real_escape_string($id) . "' AND `type`='file'");

function create_zip($files = array(), $destination = '', $overwrite = false)
{
    if (file_exists($destination) && !$overwrite)
    {
        return false;
    }
    $valid_files = array();
    if (is_array($files))
    {
        foreach ($files as $file)
        {
            if (file_exists($file))
            {
                $valid_files[] = $file;
            }
        }
    }
    if (count($valid_files))
    {
        $zip = new ZipArchive();
        if ($zip->open($destination, $overwrite ? ZIPARCHIVE::OVERWRITE :
            ZIPARCHIVE::CREATE) !== true)
        {
            return false;
        }
        foreach ($valid_files as $file)
        {
            $zip->addFile($file, basename($file));
        }
        $zip->close();
        return file_exists($destination);
    }
    else
    {
        return false;
    }
}

$archive = isset($_GET['archive']) ? strtolower(str_replace(' ', '-',
    preg_replace('#([\W_]+)#', ' ', $_GET['archive']))) : false;
if (mysql_num_rows($treq) == 0)
{
    header("Location: " . $home . "/templates/");
    exit();
}
$tres = mysql_fetch_array($treq);
$template = $tres['template'];
if ($archive || $archive == "zip")
{
    $files = array(
        "../files/templates/files/" . $template . ".html",
        "../files/templates/description/" . $template . ".txt",
        "../files/templates/screenshot/" . $template . ".jpg");
    create_zip($files, "../files/templates/download/" . $template . ".zip", false);
    if (file_exists("../files/templates/download/" . $template . ".zip"))
        header("Location: " . $home . "/files/templates/download/" . $template .
            ".zip");
    else
        header("Location: " . $home . "/templates/download.php/template/" . $template);
    exit();
}
$file_location = "../files/templates/files/" . $template . ".html";
$name = $tres['template'] . ".html";
header('Content-Description: File Transfer');
header('Content-Type: text/html');
header('Content-Disposition: attachment; filename=' . $name);
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . $tres['size']);
readfile($file_location);
exit();

?>