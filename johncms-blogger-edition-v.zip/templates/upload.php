<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
$headmod = "templates";
require ('../incfiles/core.php');
$textl = "Upload";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Templates', 'url' => '/templates'),
    array('label' => $textl),
    ));
if (!$user_id)
{

    header('Location: ' . $home . '/templates/index.php');
    exit();
}
$blog_preview = mysql_fetch_array(mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '" .
    mysql_real_escape_string($set['blogpreview']) . "'"));
if (!$blog_preview)
{
    require ('../incfiles/head.php');
    echo functions::display_error("Blog untuk preview template tidak ada.");
    require ('../incfiles/end.php');
    exit();
}
$blogpreview = "u" . $blog_preview['user_id'] . "-b" . $blog_preview['id'];
ini_set("ignore_user_abort", true);
if (isset($_POST['upload']))
{
    $err = array();
    if ($_POST['tmp'] == "mobile")
    {
        $temp = "mobile";
        $wd = 480;
    }
    else
    {
        $temp = "desktop";
        $wd = 1024;
    }
    $template_file = trim($_POST['nama']);
    $template_name = ucwords($template_file);
    $template_file = str_replace(' ', '_', ucwords(str_replace('-', ' ',
        functions::permalink($template_file)))) . '-' . strtolower(functions::generate_password
        ());
    $desc = str_replace("|", "-", str_replace("^", "'", $_POST['description']));
    $types = array(
        "application/xml",
        "text/xml",
        "text/html",
        "text/xhtml",
        );
    if (file_exists("../files/templates/files/" . $template_file . ".html"))
    {
        $err[] = "Nama file sudah ada.";
    }
    elseif (!in_array($_FILES['fail']['type'], $types))
    {
        $err[] = "Jenis file tidak benar";
    }
    elseif (substr($_FILES['fail']['name'], -5) != ".html" && substr($_FILES['fail']['name'],
        -4) != ".xml")
    {
        $err[] = "Ekstensi file tidak benar.";
    }
    elseif ($_FILES['fail']['size'] > 501024)
    {
        $err[] = "Ukuran file melebihi 50 kb.";
    }
    elseif (strlen($template_name) > 30 or strlen($template_name) < 4)
    {
        $err[] = "Nama file minimal 4 dan maksimal 30 karakter.";
    }
    elseif (mb_strlen($desc) < 5 or mb_strlen($desc) > 5000)
    {
        $err[] = "Keterangan minimal 5 dan maksimal 5000 karakter.";
    }
    else
    {
        if (is_file("../sites/" . $blog_preview['url'] . "/templates/" . $temp .
            ".html"))
            unlink("../sites/" . $blog_preview['url'] . "/templates/" . $temp .
                ".html");
        if (move_uploaded_file($_FILES['fail']['tmp_name'],
            "../files/templates/files/" . $template_file . ".html"))
        {
            include_once '../incfiles/lib/TemplateGenerator.php';
            $updateContent = new TemplateGenerator(file_get_contents("../files/templates/files/" .
                $template_file . ".html"));
            @file_put_contents("../files/templates/files/" . $template_file .
                ".html", $updateContent);
            @file_put_contents("../files/templates/description/" . $template_file .
                ".txt", $desc);
            @copy("../files/templates/files/" . $template_file . ".html",
                "../sites/" . $blog_preview['url'] . "/templates/" . $temp .
                ".html");
            ini_set("user_agent", $_SERVER['HTTP_USER_AGENT']);
            @copy("http://mini.site-shot.com/" . $wd . "/400/jpeg/?http://" . $blog_preview['url'] .
                "/?t=" . $temp . "&rand" . rand(100000, 99999) . "=src" . time(),
                "../files/templates/screenshot/" . $template_file . ".jpg");
            if ($rights == 7 || $rights == 9)
                $tipe = "file";
            else
                $tipe = "xfile";
            mysql_query("INSERT INTO `templates` SET `user_id`='" . $user_id .
                "', `user_name`='" . mysql_real_escape_string($datauser['name']) .
                "', `name`='" . mysql_real_escape_string($template_name) .
                "', `template`='" . mysql_real_escape_string($template_file) .
                "', `theme`='" . mysql_real_escape_string($temp) . "', `size`='" .
                mysql_real_escape_string($_FILES['fail']['size']) .
                "', `text`='" . mysql_real_escape_string($desc) . "', `type`='" .
                $tipe . "', `time`='" . time() . "'");
            $tid = mysql_insert_id();
            if ($tipe == "xfile")
            {
                require ('../incfiles/head.php');
                echo '<div class="alert alert-success">' .
                    'Template berhasil diupload. Mohon tunggu, ' .
                    'template Kamu sedang menunggu moderasi Administrator.<br />' .
                    '<a class="alert-link" href="' . $home .
                    '/templates/">Kembali</a></div>';
                require ('../incfiles/end.php');
                exit();
            }
            else
            {
                header("Location: " . $home . "/templates/detail.php/id/" . $tid);
                exit();
            }
        }
        else
        {
            $err[] = "Gagal mengupload file. Cobalah beberapa saat lagi.";
        }
    }
}
require ('../incfiles/head.php');

echo '<div class="callout callout-danger"><h4>Ketentuan</h4><ol>' .
    '<li>Dilarang mengupload template yang sudah ada.</li>' .
    '<li>Dilarang memodifikasi template orang lain lalu menguploadnya tanpa seijin pemilik.</li>' .
    '<li>Dilarang menggunakan HTML MyWapBlog.</li></ol>' .
    'Jika ketentuan di atas dilanggar maka template yang diupload akan dihapus dan pemblokiran akun Anda.</div>';

echo '<form action="' . $home .
    '/templates/upload.php" method="post" enctype="multipart/form-data">';
if (isset($err))
    echo functions::display_error($err);
echo '<div class="form-group"><label>File</label>' .
    '<input name="MAX_FILE_SIZE" value="522880" type="hidden"/>' .
    '<input type="file" name="fail"/><p class="help-block">' .
    '<small>Ekstensi file harus .html dan ukuran maksimal 50 kb.</small></p></div>' .
    '<div class="form-group"><label>Nama</label>' .
    '<input class="form-control" type="text" name="nama" maxlength="30" value=""/>' .
    '<p class="help-block"><small>Tanpa ekstensi, 4 - 30 karakter</small></p></div>' .
    '<div class="form-group"><label>Template</label><select class="form-control" name="tmp">' .
    '<option value="mobile">Mobile</option>' .
    '<option value="desktop">Desktop</option></select></div>' .
    '<div class="form-group"><label>Keterangan</label>' .
    '<textarea class="form-control" name="description" rows="5"></textarea>' .
    '<p class="help-block"><small>Minimal 5 dan maksimal 5000 karakter</small></p></div>' .
    '<p><button class="btn btn-primary" name="upload" type="submit">Upload</button></p></form>';
require ('../incfiles/end.php');

?>
