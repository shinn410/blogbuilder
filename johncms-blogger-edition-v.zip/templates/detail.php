<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$headmod = "templates";
$textl = "Detil";
if ($rights == 7 || $rights == 9)
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) .
        "' AND (`type`='file' OR `type`='xfile')");
}
else
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) . "' AND `type`='file'");
}
if (mysql_num_rows($treq) == 0)
{
    $breadcrumb = functions::breadcrumb(array(
        array('label' => 'Templates', 'url' => '/templates'),
        array('label' => $textl),
        ));

    require ('../incfiles/head.php');
    echo functions::display_error("Template tidak ditemukan");
    require ('../incfiles/end.php');
    exit;
}
$tres = mysql_fetch_array($treq);
$textl = htmlspecialchars($tres['name']);
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Templates', 'url' => '/templates'),
    array('label' => $textl),
    ));
require ('../incfiles/head.php');
$template = $tres['template'];
echo '<div class="box box-solid"><div class="box-body"><div class="row"><div class="col-sm-4">';
$_SESSION['auth'] = md5(rand(111111, 999999));
$del = false;
$size = round($tres['size'] / 1024, 2);
if (file_exists("../files/templates/screenshot/" . $template . ".jpg"))
    $src = $home . '/files/templates/screenshot/' . $template . '.jpg';
else
    $src = $home . '/files/templates/screenshot/no-preview.jpg';
echo '<a class="thumbnail" style="height:240px;overflow:hidden;" href="' . $src .
    '"><img class="img-responsive" src="' . $src .
    '" alt=""/></a><div class="text-center margin"><a href="' . $home .
    '/templates/demo.php/id/' . $tres['id'] .
    '" class="btn btn-default"><i class="fa fa-eye"></i> Preview</a>&nbsp;<a href="' .
    $home . '/templates/download.php/id/' . $tres['id'] .
    '" class="btn btn-default"><i class="fa fa-download"></i> Download</a>';
echo '</div><hr class="visible-xs"/></div>' . '<div class="col-sm-8">';
$totemp = mysql_result(mysql_query("SELECT COUNT(*) FROM `templates` WHERE `user_id`='" .
    mysql_real_escape_string($tres['user_id']) . "' AND `type`='file'"), 0);
$total_comment = mysql_result(mysql_query("SELECT COUNT(*) FROM `templates` WHERE `template`='" .
    $tres['id'] . "' AND `type`='comment'"), 0);
$total_set = mysql_result(mysql_query("SELECT COUNT(*) FROM `templates` WHERE `template`='" .
    $tres['id'] . "' AND `type`='set'"), 0);
echo '<h3>' . htmlspecialchars($tres['name']) .
    '</h3><ul class="list-unstyled"><li>Template: ' . ucfirst($tres['theme']) .
    '</li><li>Ukuran: ' . $size . ' kb</li>' . '<li>Diupload: ' . functions::display_date($tres['time']) .
    '</li><li>Penerbit: <a data-toggle="tooltip" data-title="Kunjungi profil ' .
    $tres['user_name'] . '" href="' . $home . '/users/profile.php/user/' . $tres['user_id'] .
    '">' . $tres['user_name'] .
    '</a>&nbsp;&nbsp;&nbsp;<a data-toggle="tooltip" data-title="Lihat semua template yang dipublikasikan oleh ' .
    $tres['user_name'] . '" href="' . $home . '/templates/index.php/author/' . $tres['user_id'] .
    '"><span class="badge bg-red">' . $totemp . '</span></a></li>' .
    '<li>Keterangan:: ' . functions::smileys(functions::checkout($tres['text'],
    1, 1)) . '</li></ul>';
$_SESSION['auth'] = md5(rand(111111, 999999));
$del = false;
if ($user_id)
{
    echo '<div class="sub">';
    if ($tres['type'] == "xfile" and $rights >= 7)
        echo '<a class="func" href="' . $home .
            '/templates/module.php/act/accept/id/' . $tres['id'] . '/sess/' . $_SESSION['auth'] .
            '">Setujui</a>&nbsp;';
    if ($rights >= 7)
        echo '<a class="func" href="' . $home . '/templates/edit.php/id/' . $tres['id'] .
            '"><i class="fa fa-edit"></i> Edit</a>&nbsp;';
    if (($tres['user_id'] == $user_id) || $rights >= 7)
    {
        $del = true;
        echo '<a class="func" href="' . $home .
            '/templates/module.php/act/delete/id/' . $tres['id'] . '/sess/' . $_SESSION['auth'] .
            '" onclick="return confirm(\'Kamu yakin akan menghapus ini?\')"><i class="fa fa-times"></i> Hapus</a>&nbsp;';
    }
    echo '<a class="func" href="' . $home . '/templates/set.php/id/' . $tres['id'] .
        '/sess/' . $_SESSION['auth'] . '" data-toggle="' . functions::set_modal() .
        '" data-target="#global-modal" ><i class="fa fa-wrench"></i> Pasang template</a></div>';
}
echo '</div>';

echo '</div></div></div>';
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs">' . '<li' . (!$act ||
    ($act == 'comment') ? ' class="active"' : '') . '><a href="' . $home .
    '/templates/detail.php/act/comment/id/' . $tres['id'] . '">Komentar (' . $total_comment .
    ')</a></li><li' . (($act == 'set') ? ' class="active"' : '') . '><a href="' .
    $home . '/templates/detail.php/act/set/id/' . $tres['id'] . '">Digunakan (' .
    $total_set . ')</a></li></ul>';
echo '<div class="tab-content">';
if ($user_id)
{
    $i = 0;
    switch ($act)
    {
        case 'set':
            $total = $total_set;
            echo '<div class="alert alert-info">Berikut adalah blog yang pernah menggunakan template ini.</div>';
            if ($total == 0)
            {
                echo
                    '<div class="alert alert-warning">Belum ada yang menggunakan template ini</div>';
            }
            else
            {
                $qu = mysql_query("SELECT * FROM `templates` WHERE `template`='" .
                    $tres['id'] .
                    "' AND `type`='set' ORDER BY `time` DESC LIMIT $start,$kmess;");
                while ($co = mysql_fetch_array($qu))
                {
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                    $blog = mysql_fetch_array(mysql_query("SELECT `title`,`url` FROM `blog_sites` WHERE `id`='" .
                        mysql_real_escape_string($co['name']) . "'"));
                    echo '<i class="fa fa-rss-square"></i> ';
                    if ($blog)
                        echo '<a href="http://' . $blog['url'] . '">' .
                            htmlspecialchars($blog['title']) . '</a><br />(' .
                            functions::display_date($co['time']) . ')</div>';
                    else
                        echo htmlspecialchars($co['text']) . '<br />(' .
                            functions::display_date($co['time']) . ')</div>';
                    $i++;
                }
                if ($total > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination($home .
                        '/templates/detail.php/act/set/id/' . $tres['id'] . '/',
                        $start, $total, $kmess) . '</div>';
            }
            break;
        case 'comment':
        default:
            $total = $total_comment;
            echo '<p><form name="form" action="' . $home .
                '/templates/module.php/act/add_comment/id/' . $tres['id'] .
                '" method="post"><div class="form-group"><label>Komentar</label>' .
                '<textarea class="form-control" rows="' . $set_user['field_h'] .
                '" name="msg"></textarea></div><input type="hidden" name="sess" value="' .
                $_SESSION['auth'] .
                '"/><p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['sent'] . '</button></p></form></p>';
            if ($total == 0)
            {
                echo '<div class="alert alert-warning">Belum ada komentar</div>';
            }
            else
            {
                $qu = mysql_query("SELECT * FROM `templates` WHERE `template`='" .
                    $tres['id'] .
                    "' AND `type`='comment' ORDER BY `time` DESC LIMIT $start,$kmess;");
                while ($co = mysql_fetch_array($qu))
                {
                    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                    echo '<img src="' . $home . '/users/avatar.php/user/' . $co['user_id'] .
                        '" alt=""/> <a href="' . $home .
                        '/users/profile.php/user/' . $co['id'] . '">' .
                        htmlspecialchars($co['name']) . '</a> (' . functions::display_date($co['time']) .
                        ')<br />' . functions::smileys(functions::checkout($co['text'],
                        1, 1));
                    if ($del == true)
                        echo '<div class="sub"><a href="' . $home .
                            '/templates/module.php/act/delete_comment/id/' . $tres['id'] .
                            '/cid/' . $co['id'] . '/sess/' . $_SESSION['auth'] .
                            '" onclick="return confirm(\'Kamu yakin akan menghapus ini?\')"><i class="fa fa-times"></i> Hapus</a></div>';
                    echo '</div>';
                    $i++;
                }
                if ($total > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination($home .
                        '/templates/detail.php/act/comment/id=' . $tres['id'] .
                        '/', $start, $total, $kmess) . '</div>';
            }
            break;
    }
}
require ('../incfiles/end.php');

?>
