<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$author = isset($_GET['author']) ? abs(intval($_GET['author'])) : false;
$theme = isset($_GET['theme']) ? trim($_GET['theme']) : false;
$search = isset($_GET['search']) ? trim($_GET['search']) : false;
$headmod = "templates";
$textl = "Templates";
$breadcrumb = functions::breadcrumb(array(array('label' => $textl)));
require ('../incfiles/head.php');
if ($author)
{
    $sql_query = " `user_id`='" . mysql_real_escape_string($author) . "' AND";
    $link = "author/" . htmlentities($author) . "/";
}
elseif ($search && (mb_strlen($search) > 1) && (mb_strlen($search) < 10))
{
    $search_db = functions::rus_lat(mb_strtolower($search));
    $search_db = strtr($search_db, array('_' => '\\_', '%' => '\\%'));
    $search_db = '%' . $search_db . '%';

    $sql_query = " (`name` LIKE '" . mysql_real_escape_string($search_db) .
        "' OR `template` LIKE '" . mysql_real_escape_string($search_db) .
        "') AND";
    $link = "search/" . htmlentities($search) . "/";
}
elseif ($theme && ($theme == "mobile"))
{
    $sql_query = " `theme`='mobile' AND";
    $link = "theme/mobile/";
}
elseif ($theme && ($theme == "desktop"))
{
    $sql_query = " `theme`='desktop' AND";
    $link = "/theme/desktop/;";
}
else
{
    $sql_query = "";
    $link = "";
}
if (($rights == 7 || $rights == 9) && ($theme == "moderated"))
{
    $tipe = 'xfile';
    $link = "theme/moderated/";
}
else
{
    $tipe = 'file';
}

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `templates` WHERE" . $sql_query .
    " `type`='" . $tipe . "'"), 0);
echo '<div class="col-sm-offset-6"><form method="get" action="' . $home .
    '/templates/index.php">' . '<div class="input-group">' .
    '<input class="form-control" type="text" name="search" value="' . $search .
    '"/><span class="input-group-btn">' .
    '<button class="btn btn-primary" type="submit">Cari</button>' .
    '</div></form></div>';
echo '<hr />';
if ($search and mb_strlen($search) > 1 and mb_strlen($search) < 10)
    echo '<div class="alert alert-info">Ditemukan <b>' . $total .
        '</b> untuk pencarian <b>' . $search . '</b></div>';
elseif ($author && $author != $user_id)
{
    $q = mysql_query("SELECT `name` FROM `users` WHERE `id`='" .
        mysql_real_escape_string($author) . "'");
    if (mysql_num_rows($q))
    {
        $p = mysql_fetch_assoc($q);
        echo '<div class="callout callout-info">' .
            'Penampilkan template yang dipublikasikan oleh <a href="' . $home .
            '/users/profile.php/user/' . $author . '"><strong>' . $p['name'] .
            '</strong></a></div>';
    }
}
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li' . ($link == '' ?
    ' class="active"' : '') . '><a href="' . $home .
    '/templates/index.php">Semua</a></li>' . '<li' . ($theme && $theme ==
    'mobile' ? ' class="active"' : '') . '><a href="' . $home .
    '/templates/index.php/theme/mobile">Mobile</a></li>' . '<li' . ($theme && $theme ==
    'desktop' ? ' class="active"' : '') . '><a href="' . $home .
    '/templates/index.php/theme/desktop">Desktop</a></li>';
if ($rights >= 7)
{
    echo '<li' . ($theme && $theme == 'moderated' ? ' class="active"' : '') .
        '><a href="' . $home .
        '/templates/index.php/theme/moderated">Moderasi (' . $count_new_template .
        ')</a><li>';
}
if ($user_id)
{
    echo '<li' . ($author && $author == $user_id ? ' class="active"' : '') .
        '><a href="' . $home . '/templates/index.php/author/' . $user_id .
        '">My Templates</a></li>' . '<li class="pull-right"><a href="' . $home .
        '/templates/upload.php">Upload</a><li>' . '';
}
echo '</ul><div class="tab-content">';
if ($total == 0)
{
    echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
}
else
{
    echo '<div class="row">';
    $treq = mysql_query("SELECT * FROM `templates` WHERE" . $sql_query .
        " `type`='" . $tipe . "' ORDER BY `time` DESC LIMIT $start, $kmess;");
    while ($tres = mysql_fetch_array($treq))
    {
        if (file_exists("../files/templates/screenshot/" . $tres['template'] .
            ".jpg"))
        {
            $thumbnail = $home . '/files/templates/screenshot/' . $tres['template'] .
                '.jpg';
        }
        else
        {
            $thumbnail = $home . '/files/templates/screenshot/no-preview.jpg';
        }
        echo '<div class="col-sm-4 col-md-3"><div class="box box-solid flat"><div class="box-body">';
        echo '<a class="thumbnail" style="height:180px;overflow:hidden;" href="' . $home . '/templates/detail.php/id/' .
            $tres['id'] . '"><img class="media-object" src="' . $thumbnail .
            '" alt=""/></a><h4 class="text-center" style="white-space: nowrap;overflow:hidden;"><a href="' .
            $home . '/templates/detail.php/id/' . $tres['id'] . '" title="' .
            htmlspecialchars($tres['name']) . '">' . htmlspecialchars($tres['name']) .
            '</a></h4><div class="text-center">Template: ' . ucfirst($tres['theme']) .
            '<br/>Diunggah: ' . functions::display_date($tres['time']) .
            '</div>';
        echo '</div></div></div>';
    }
    echo '</div>';
}
echo '</div></div>';

if ($total > $kmess)
    echo '<div class="topmenu">' . functions::display_pagination($home .
        '/templates/index.php/' . $link, $start, $total, $kmess) . '</div>';
require ('../incfiles/end.php');

?>
