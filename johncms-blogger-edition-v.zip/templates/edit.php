<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
$headmod = "templates";
require ('../incfiles/core.php');

if ($rights < 7)
{
    header('Location: ' . $home . '/templates/');
    exit();
}

$req = mysql_query("SELECT * FROM `templates` WHERE `id`='$id'");
if (mysql_num_rows($req) == 0)
{
    header('Location: ' . $home . '/templates/');
    exit();
}

$res = mysql_fetch_array($req);
$textl = "Edit";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Templates', 'url' => '/templates'),
    array('label' => htmlspecialchars($res['name']), 'url' =>
            '/templates/detail.php/id/' . $id),
    array('label' => $textl),
    ));

$text = isset($_POST['text']) ? $_POST['text'] : $res['text'];
$name = isset($_POST['name']) ? trim($_POST['name']) : $res['name'];
$tpl = isset($_POST['tpl']) ? $_POST['tpl'] : $res['template'];
if (isset($_POST['save']))
{
    $err = array();
    if (strlen($name) > 30 or strlen($name) < 4)
    {
        $err[] = "Nama file minimal 4 dan maksimal 30 karakter.";
    }
    elseif (mb_strlen($text) < 5 or mb_strlen($text) > 5000)
    {
        $err[] = "Keterangan minimal 5 dan maksimal 5000 karakter.";
    }
    if (empty($err))
    {
        @file_put_contents("../files/templates/description/" . $res['template'] .
            ".txt", $text);
        mysql_query("UPDATE `templates` SET `name`='" . mysql_real_escape_string
            ($name) . "', `theme`='" . mysql_real_escape_string($tpl) .
            "', `text`='" . mysql_real_escape_string($text) . "' WHERE `id` = '$id'");
        header('Location: ' . $home . '/templates/detail.php/id/' . $id);
        exit();
    }

}
require ('../incfiles/head.php');

echo '<form action="' . $home . '/templates/edit.php/id/' . $id .
    '" method="post">';
if (isset($err))
    echo functions::display_error($err);
echo '<div class="form-group"><label>Nama</label>' .
    '<input class="form-control" type="text" name="name" maxlength="30" value="' .
    htmlentities($name) . '"/>' .
    '<p class="help-block"><small>min 4, maks 30 karakter</small></p></div>' .
    '<div class="form-group"><label>Template</label><select class="form-control" name="tpl">' .
    '<option value="mobile"' . ($tpl == 'mobile' ? ' selected="selected"' : '') .
    '>Mobile</option>' . '<option value="desktop"' . ($tpl != 'mobile' ?
    ' selected="selected"' : '') . '>Desktop</option></select></div>' .
    '<div class="form-group"><label>Keterangan</label>' .
    '<textarea class="form-control" name="text" rows="5">' . htmlentities($text) .
    '</textarea>' . '<p class="help-block"><small>Minimal 5 dan maksimal 5000 karakter</small></p></div>' .
    '<p><button class="btn btn-primary" name="save" type="submit">' . $lng['save'] .
    '</button></p></form>';
require ('../incfiles/end.php');

?>
