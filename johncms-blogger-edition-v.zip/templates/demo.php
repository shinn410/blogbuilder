<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
if ($rights >= 7)
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) .
        "' AND (`type`='file' OR `type`='xfile')");
}
else
{
    $treq = mysql_query("SELECT * FROM `templates` WHERE `id`='" .
        mysql_real_escape_string($id) . "' AND `type`='file'");
}
$textl = "Templates";
if (mysql_num_rows($treq) == 0)
{
    header("Location: " . $home . "/templates/index.php");
    exit;
}
$bprev = mysql_fetch_array(mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '" .
    mysql_real_escape_string($set['blogpreview']) . "'"));
if (!$bprev)
{
    require ('../incfiles/head.php');
    echo functions::display_error("Blog untuk preview template tidak ada.");
    require ('../incfiles/end.php');
    exit;
}
$tres = mysql_fetch_array($treq);
$template = $tres['template'] . ".html";
if (copy("../files/templates/files/" . $template, "../sites/" . $bprev['url'] .
    "/templates/" . $tres['theme'] . ".html"))
{
    header("Location: http://" . $bprev['url'] . "/?t=" . $tres['theme']);
    exit;
}
else
{
    require ('../incfiles/head.php');
    echo '<div class="alert alert-danger">Kesalahan. Cobalah beberapa saat lagi.</div>';
    require ("../incfiles/end.php");
}

?>