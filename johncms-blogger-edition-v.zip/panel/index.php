<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

@ini_set("max_execution_time", "600");
define('_IN_JOHNCMS', 1);
define('_IN_JOHNADM', 1);

require ('../incfiles/core.php');

$lng = array_merge($lng, core::load_lng('admin'));
$lng = array_merge($lng, array('access_with_email_verification' =>
        'Dengan verifikasi E-Mail'));

if (core::$user_rights < 1)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}

$headmod = 'admin';
$textl = $lng['admin_panel'];
$main_header = 1;
$array = array(
    'forum',
    'news',
    'ads',
    'counters',
    'ip_whois',
    'languages',
    'settings',
    'sitemap',
    'smileys',
    'access',
    'antispy',
    'httpaf',
    'ipban',
    'antiflood',
    'ban_panel',
    'blog',
    'karma',
    'reg',
    'mail',
    'search_ip',
    'usr',
    'usr_adm',
    'usr_clean',
    'usr_del',
    );
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' .
    $array[$key] . '.php'))
{
    require ('../incfiles/head.php');
    require ('includes/' . $array[$key] . '.php');
}
else
{
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['admin_panel'])));
    require ('../incfiles/head.php');
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if ($rights >= 7)
        echo '<div class="row">';
    $regtotal = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `preg`='0'"),
        0);
    $bantotal = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `ban_time` > '" .
        time() . "'"), 0);
    $total_adm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` >= '1'"),
        0);
    if ($rights >= 7)
        echo '<div class="col-5 col-sm-5 col-lg-6">';
    echo '<div class="list-group">' .
        '<div class="list-group-item list-group-item-success"><i class="fa fa-users"></i> ' .
        $lng['users'] . '</div>' . ($regtotal && core::$user_rights >= 6 ?
        '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/reg"><i class="fa fa-angle-double-right"></i> ' . $lng['users_reg'] .
        ' <span class="badge">' . $regtotal . '</span></a>' : '') .
        '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/usr"><i class="fa fa-angle-double-right"></i> ' . $lng['users'] .
        ' <span class="badge">' . counters::users() . '</span></a>' .
        '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/usr_adm"><i class="fa fa-angle-double-right"></i> ' . $lng['users_administration'] .
        ' <span class="badge">' . $total_adm . '</span></a>' . ($rights >= 7 ?
        '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/usr_clean"><i class="fa fa-angle-double-right"></i> ' .
        $lng['users_clean'] . '</a>' : '') . '<a class="list-group-item" href="' .
        $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/ban_panel"><i class="fa fa-angle-double-right"></i> ' .
        $lng['ban_panel'] . ' <span class="badge">' . $bantotal . '</span></a>' . (core::
        $user_rights >= 7 ? '<a class="list-group-item" href="' . $set['homeurl'] .
        '/' . $set['admp'] .
        '/index.php/act/antiflood"><i class="fa fa-angle-double-right"></i> ' .
        $lng['antiflood'] . '</a>' : '') . (core::$user_rights >= 7 ?
        '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/karma"><i class="fa fa-angle-double-right"></i> ' . $lng['karma'] .
        '</a>' : '') . '<a class="list-group-item" href="' . $set['homeurl'] .
        '/users/search.php"><i class="fa fa-angle-double-right"></i> ' . $lng['search_nick'] .
        '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
        '/index.php/act/search_ip"><i class="fa fa-angle-double-right"></i> ' .
        $lng['ip_search'] . '</a>' . '</div>';
    if ($rights >= 7)
        echo '</div>';
    if ($rights >= 7)
    {
        $spam = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `spam`='1';"),
            0);
        echo '<div class="col-5 col-sm-5 col-lg-6">' .
            '<div class="list-group">';
        echo '<div class="list-group-item list-group-item-info"><i class="fa fa-bookmark"></i> ' .
            $lng['modules'] . '</div><a class="list-group-item" href="' . $set['homeurl'] .
            '/' . $set['admp'] .
            '/index.php/act/blog"><i class="fa fa-angle-double-right"></i> Blog</a>' .
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/forum"><i class="fa fa-angle-double-right"></i> ' .
            $lng['forum'] . '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] .
            '/' . $set['admp'] .
            '/index.php/act/news"><i class="fa fa-angle-double-right"></i> ' . $lng['news'] .
            '</a>' . '<a class="list-group-item" href="' . $set['homeurl'] . '/' .
            $set['admp'] .
            '/index.php/act/ads"><i class="fa fa-angle-double-right"></i> ' . $lng['advertisement'] .
            '</a>' . (core::$user_rights == 9 ?
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/sitemap"><i class="fa fa-angle-double-right"></i> ' .
            $lng['site_map'] . '</a>' : '') . (core::$user_rights == 9 ?
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/counters"><i class="fa fa-angle-double-right"></i> ' .
            $lng['counters'] . '</a>' : '') .
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/mail"><i class="fa fa-angle-double-right"></i> ' . $lng['mail'] .
            '</a>' . '</div>' . '</div>';
        echo '</div>' . '<div class="row">';
        echo '<div class="col-5 col-sm-5 col-lg-6">' .
            '<div class="list-group">' .
            '<div class="list-group-item list-group-item-warning"><i class="fa fa-cogs"></i> ' .
            $lng['system'] . '</div>' . (core::$user_rights == 9 ?
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/settings"><i class="fa fa-angle-double-right"></i> ' .
            $lng['site_settings'] . '</a>' : '') .
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/smileys"><i class="fa fa-angle-double-right"></i> ' .
            $lng['refresh_smileys'] . '</a>' . (core::$user_rights == 9 ?
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/languages"><i class="fa fa-angle-double-right"></i> ' .
            $lng['language_settings'] . '</a>' : '') .
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/access"><i class="fa fa-angle-double-right"></i> ' .
            $lng['access_rights'] . '</a>' . '</div>' . '</div>';
        echo '<div class="col-5 col-sm-5 col-lg-6">' .
            '<div class="list-group">' .
            '<div class="list-group-item list-group-item-danger">' .
            '<i class="fa fa-shield"></i> ' . $lng['security'] . '</div>' .
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/antispy"><i class="fa fa-angle-double-right"></i> ' .
            $lng['antispy'] . '</a>' . (core::$user_rights == 9 ?
            '<a class="list-group-item" href="' . $set['homeurl'] . '/' . $set['admp'] .
            '/index.php/act/ipban"><i class="fa fa-angle-double-right"></i> ' .
            $lng['ip_ban'] . '</a>' : '') . '</div>' . '</div>';
    }
    if ($rights >= 7)
    {
        echo '</div>';
    }
    echo '<div class="row">' . '<div class="col-5 col-sm-5 col-lg-6">' .
        '<div class="list-group">' .
        '<div class="list-group-item list-group-item-success">JohnCMS 5.2.1</div>' .
        '</div>' . '</div>';
    echo '<div class="col-5 col-sm-5 col-lg-6">' . '<div class="list-group">' .
        '<div class="list-group-item list-group-item-success">Bootstrap 3.2.0</div>' .
        '</div>' . '</div>' . '</div>';

}
require ('../incfiles/end.php');
