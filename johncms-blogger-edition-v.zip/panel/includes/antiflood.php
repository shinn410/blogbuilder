<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['antiflood_settings']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
$set_af = isset($set['antiflood']) ? unserialize($set['antiflood']) : array();
if (isset($_POST['submit']) || isset($_POST['save']))
{

    $set_af['mode'] = isset($_POST['mode']) && $_POST['mode'] > 0 && $_POST['mode'] <
        5 ? intval($_POST['mode']) : 1;
    $set_af['day'] = isset($_POST['day']) ? intval($_POST['day']) : 10;
    $set_af['night'] = isset($_POST['night']) ? intval($_POST['night']) : 30;
    $set_af['dayfrom'] = isset($_POST['dayfrom']) ? intval($_POST['dayfrom']) :
        10;
    $set_af['dayto'] = isset($_POST['dayto']) ? intval($_POST['dayto']) : 22;

    if ($set_af['day'] < 4)
        $set_af['day'] = 4;
    if ($set_af['day'] > 300)
        $set_af['day'] = 300;
    if ($set_af['night'] < 4)
        $set_af['night'] = 4;
    if ($set_af['night'] > 300)
        $set_af['night'] = 300;
    if ($set_af['dayfrom'] < 6)
        $set_af['dayfrom'] = 6;
    if ($set_af['dayfrom'] > 12)
        $set_af['dayfrom'] = 12;
    if ($set_af['dayto'] < 17)
        $set_af['dayto'] = 17;
    if ($set_af['dayto'] > 23)
        $set_af['dayto'] = 23;
    mysql_query("UPDATE `cms_settings` SET `val` = '" . serialize($set_af) .
        "' WHERE `key` = 'antiflood' LIMIT 1");
    echo '<div class="alert alert-success">' . $lng['settings_saved'] . '</div>';
}
elseif (empty($set_af) || isset($_GET['reset']))
{

    echo '<div class="alert alert-success">' . $lng['settings_default'] .
        '</div>';
    $set_af['mode'] = 2;
    $set_af['day'] = 10;
    $set_af['night'] = 30;
    $set_af['dayfrom'] = 10;
    $set_af['dayto'] = 22;
    @mysql_query("DELETE FROM `cms_settings` WHERE `key` = 'antiflood' LIMIT 1");
    mysql_query("INSERT INTO `cms_settings` SET `key` = 'antiflood', `val` = '" .
        serialize($set_af) . "'");
}

echo '<form role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/antiflood" method="post">' .
    '<div class="form-group">' . '<label class="control-label dis-block">' . $lng['operation_mode'] .
    '</label>' . '<div class="radio"><label><input type="radio" name="mode" value="3" ' . ($set_af['mode'] ==
    3 ? 'checked="checked"' : '') . '/> ' . $lng['day'] . '</label></div>' .
    '<div class="radio"><label><input type="radio" name="mode" value="4" ' . ($set_af['mode'] ==
    4 ? 'checked="checked"' : '') . '/> ' . $lng['night'] . '</label></div>' .
    '<div class="radio"><label><input data-toggle="tooltip" data-title="' . $lng['antiflood_dn_help'] .
    '" type="radio" name="mode" value="2" ' . ($set_af['mode'] == 2 ?
    'checked="checked"' : '') . '/> ' . $lng['day'] . ' / ' . $lng['night'] .
    '</label></div>' .
    '<div class="radio"><label><input data-toggle="tooltip" data-title="' . $lng['antiflood_ad_help'] .
    '" type="radio" name="mode" value="1" ' . ($set_af['mode'] == 1 ?
    'checked="checked"' : '') . '/> ' . $lng['adaptive'] . '</label></div>' .
    '</div>' . '<div class="form-group">' .
    '<label class="control-label dis-block">' . $lng['time_limit'] . '</label>' .
    '<p><input class="form-control form-table" name="day" size="3" value="' . $set_af['day'] .
    '" maxlength="3" /> ' . $lng['day'] . '</p>' .
    '<p><input class="form-control form-table" name="night" size="3" value="' .
    $set_af['night'] . '" maxlength="3" /> ' . $lng['night'] . '</p>' .
    '<p class="help-block">' . $lng['antiflood_tl_help'] . '</p>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label dis-block">' . $lng['day_mode'] .
    '</label>' . '<div class="row">' .
    '<div class="col-xs-4" style="padding-right:0px;">' .
    '<div class="input-group">' .
    '<input class="form-control" name="dayfrom" size="2" value="' . $set_af['dayfrom'] .
    '"/>' . '<span class="input-group-addon">:00</span>' . '</div>' . '</div>' .
    '<div class="col-xs-8">' . $lng['day_begin'] .
    ' <span class="gray">(6-12)</span></div>' . '</div><br/>' .
    '<div class="row">' . '<div class="col-xs-4" style="padding-right:0px;">' .
    '<div class="input-group">' .
    '<input class="form-control" name="dayto" size="2" value="' . $set_af['dayto'] .
    '"/>' . '<span class="input-group-addon">:00</span>' . '</div>
    </div>' . '<div class="col-xs-8">' . $lng['day_end'] .
    ' <span class="gray">(17-23)</span></div>' . '</div>' . '</div>' . '<p>' .
    '<button class="btn btn-primary" type="submit" name="submit">' . $lng['save'] .
    '</button>' . '&nbsp;<a class="btn btn-danger" href="' . $set['homeurl'] .
    '/panel/index.php/act/antiflood/reset">' . $lng['reset_settings'] . '</a>' .
    '</p>' . '</form>' . '<p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';

?>