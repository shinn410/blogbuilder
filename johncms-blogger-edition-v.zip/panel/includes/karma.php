<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['karma']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if ($rights == 9 && $do == 'clean')
{
    if (isset($_GET['yes']))
    {
        mysql_query("TRUNCATE TABLE `karma_users`");
        mysql_query("OPTIMIZE TABLE `karma_users`");
        mysql_query("UPDATE `users` SET `karma`='0', `plus_minus`='0|0'");
        mysql_query("OPTIMIZE TABLE `users`");
        echo '<div class="gmenu">' . $lng['karma_cleared'] . '</div>';
    }
    else
    {
        echo '<div class="alert alert-warning">' . $lng['karma_clear_confirmation'] .
            '</div>' . '<p><a class="btn btn-primary" href="' . $set['homeurl'] .
            '/panel/index.php/act/karma/do/clean/yes">' . $lng['delete'] .
            '</a> ' . '<a class="btn btn-default" href="' . $set['homeurl'] .
            '/panel/index.php/act/karma">' . $lng['cancel'] . '</a></p>';
    }
    require_once ("../incfiles/end.php");
    exit();
}
$settings = unserialize($set['karma']);
if (isset($_POST['submit']))
{
    $settings['karma_points'] = isset($_POST['karma_points']) ? abs(intval($_POST['karma_points'])) :
        0;
    $settings['karma_time'] = isset($_POST['karma_time']) ? abs(intval($_POST['karma_time'])) :
        0;
    $settings['forum'] = isset($_POST['forum']) ? abs(intval($_POST['forum'])) :
        0;
    $settings['time'] = isset($_POST['time']) ? abs(intval($_POST['time'])) : 0;
    $settings['on'] = isset($_POST['on']) ? 1 : 0;
    $settings['adm'] = isset($_POST['adm']) ? 1 : 0;
    $settings['karma_time'] = $settings['time'] ? $settings['karma_time'] * 3600 :
        $settings['karma_time'] * 86400;
    mysql_query("UPDATE `cms_settings` SET `val` = '" . mysql_real_escape_string
        (serialize($settings)) . "' WHERE `key` = 'karma'");
    echo '<div class="alert alert-success">' . $lng['settings_saved'] . '</div>';
}
$settings['karma_time'] = $settings['time'] ? $settings['karma_time'] / 3600 : $settings['karma_time'] /
    86400;
echo '<form role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/karma" method="post">' . '<div class="form-group">' .
    '<label class="control-label dis-block">' . $lng['karma_votes_per_day'] .
    '</label>' . '<input class="form-control form-table" type="text" name="karma_points" value="' .
    $settings['karma_points'] . '" size="4"/>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label dis-block">' . $lng['karma_restrictions'] .
    '</label>' . '<p><input class="form-control form-table" type="text" name="forum" value="' .
    $settings['forum'] . '" size="4"/> ' . $lng['forum_posts'] . '</p>' .
    '<p><input class="form-control form-table" type="text" name="karma_time" value="' .
    $settings['karma_time'] . '" size="4"/> ' . $lng['site_spent'] . '</p>' .
    '<div class="radio"><label><input name="time" type="radio" value="1"' . ($settings['time'] ?
    ' checked="checked"' : '') . '/>&#160;' . $lng['hours'] . '</label></div>' .
    '<div class="radio"><label><input name="time" type="radio" value="0"' . (!$settings['time'] ?
    ' checked="checked"' : '') . '/>&#160;' . $lng['days'] . '</label></div>' .
    '</div>' . '<div class="form-group">' .
    '<label class="control-label dis-block">' . $lng['general_settings'] .
    '</label>' . '<div class="checkbox"><label><input type="checkbox" name="on"' . ($settings['on'] ?
    ' checked="checked"' : '') . '/> ' . $lng['module_on'] . '</label></div>' .
    '<div class="checkbox"><label><input type="checkbox" name="adm"' . ($settings['adm'] ?
    ' checked="checked"' : '') . '/> ' . $lng['karma_admin_disable'] .
    '</label></div>' . '</div>' .
    '<p><button class="btn btn-primary" type="submit" name="submit">' . $lng['save'] .
    '</button>' . ($rights == 9 ? ' <a class="btn btn-danger" href="' . $set['homeurl'] .
    '/panel/index.php/act/karma/do/clean">' . $lng['karma_reset'] . '</a>' : '') .
    '</p>' . '</form>' . '<p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';

?>