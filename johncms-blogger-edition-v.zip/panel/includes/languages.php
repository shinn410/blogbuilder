<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$panel_lng = core::load_lng('panel_lng');

$lng_list = array();
$lng_desc = array();
foreach (glob('../incfiles/languages/*/_core.ini') as $val)
{
    $dir = explode('/', dirname($val));
    $iso = array_pop($dir);
    $desc = parse_ini_file($val);
    $lng_list[$iso] = isset($desc['name']) && !empty($desc['name']) ? $desc['name'] :
        $iso;
    $lng_desc[$iso] = $desc;
}

if (isset($_GET['refresh']))
{
    mysql_query("DELETE FROM `cms_settings` WHERE `key` = 'lng_list'");
    core::$lng_list = array();
    echo '<div class="alert alert-success"><p>' . $lng['refresh_descriptions_ok'] .
        '</p></div>';
}
$lng_add = array_diff(array_keys($lng_list), array_keys(core::$lng_list));
$lng_del = array_diff(array_keys(core::$lng_list), array_keys($lng_list));
if (!empty($lng_add) || !empty($lng_del))
{
    if (!empty($lng_del) && in_array($set['lng'], $lng_del))
    {

        mysql_query("UPDATE `cms_settings` SET `val` = '" . key($lng_list[]) .
            "' WHERE `key` = 'lng' LIMIT 1");
    }
    $req = mysql_query("SELECT * FROM `cms_settings` WHERE `key` = 'lng_list'");
    if (mysql_num_rows($req))
    {
        mysql_query("UPDATE `cms_settings` SET `val` = '" .
            mysql_real_escape_string(serialize($lng_list)) .
            "' WHERE `key` = 'lng_list' LIMIT 1");
    }
    else
    {
        mysql_query("INSERT INTO `cms_settings` SET `key` = 'lng_list', `val` = '" .
            mysql_real_escape_string(serialize($lng_list)) . "'");
    }
}

$language = isset($_GET['language']) ? trim($_GET['language']) : false;

class ini_file
{
    public static function key_filter($str)
    {
        $str = trim($str);
        $str = mb_substr($str, 0, 27);
        $str = preg_replace("/[^a-z0-9_]/", "", $str);
        return $str;
    }

    public static function value_filter($str)
    {
        $str = trim($str);
        $str = str_replace('"', '', $str);
        $str = str_replace("\r\n", "", $str);
        return $str;
    }

    public static function parser($language, $name_module)
    {
        if (!$language || !$name_module)
            return false;
        $ini_file = '../incfiles/languages/' . $language . '/' . $name_module .
            '.lng';
        if (file_exists($ini_file))
        {
            $out = parse_ini_file($ini_file);
            return $out;
        }
        return false;
    }

    public static function parser_edit($language)
    {
        if (!$language)
            return false;
        $ini_file = '../files/lng_edit/' . $language . '_iso.lng';
        if (file_exists($ini_file))
        {
            $out = parse_ini_file($ini_file, true);
            return $out;
        }
        return false;
    }

    public static function update_lng($name_module, $lng_edit, $lng_module)
    {
        if (isset($lng_edit[$name_module]))
        {
            $lng_module_standart = array_diff_key($lng_module, $lng_edit[$name_module]);
            $lng_module = $lng_module_standart + $lng_edit[$name_module];
        }
        ksort($lng_module);
        return $lng_module;
    }

    public static function save_file($language, $lng_module)
    {
        $ini_file = '../files/lng_edit/' . $language . '_iso.lng';
        if (!empty($lng_module))
        {
            $ini_text = array();
            foreach ($lng_module as $key => $val)
            {
                $ini_text[] = '[' . $key . ']';
                foreach ($val as $keyword => $phrase)
                {
                    $ini_text[] = $keyword . ' = "' . $phrase . '"';
                }
            }
            $ini_text = implode("\r\n", $ini_text);
            $open_ini_file = fopen($ini_file, w);
            fputs($open_ini_file, $ini_text);
            fclose($open_ini_file);
            @chmod($ini_file, 0666);
        }
        else
        {
            unlink($ini_file);
        }
    }
}

switch ($mod)
{
    case 'set':
        $iso = isset($_POST['iso']) ? trim($_POST['iso']) : false;
        if ($iso && array_key_exists($iso, $lng_list))
        {
            mysql_query("UPDATE `cms_settings` SET `val` = '" .
                mysql_real_escape_string($iso) . "' WHERE `key` = 'lng'");
        }
        header('Location: ' . core::$system_set['homeurl'] .
            '/panel/index.php/act/languages');
        break;

    case 'module':
        if (!$language || !array_key_exists($language, $lng_list))
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $array_module = glob('../incfiles/languages/' . $language . '/*.lng');
        $total = count($array_module);
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $panel_lng['languages'], 'url' =>
                    'panel/index.php/act/languages'),
            array('label' => $lng_list[$language]),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if ($do == 'error')
            echo '<div class="alert alert-danger"><b>' . $panel_lng['error'] .
                '!</b></div>';
        elseif ($do == 'reset')
            echo '<div class="alert alert-success"><b>' . $panel_lng['module_default'] .
                '!</b></div>';
        if ($total)
        {
            $count = $start + $kmess > $total ? $total : $start + $kmess;
            for ($i = $start; $i < $count; $i++)
            {
                echo is_integer($i / 2) ? '<div class="list1">' :
                    '<div class="list2">';
                $name_module = preg_replace('#^../incfiles/languages/' . $language .
                    '/(.*?).lng$#isU', '$1', $array_module[$i], 1);
                $lng_module_standart = ini_file::parser($language, $name_module);
                $lng_edit = ini_file::parser_edit($language);
                $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
                echo '<a data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal" href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/info_module/language/' .
                    $language . '/module/' . $name_module . '"><b>' . $name_module .
                    '</b></a>' . '<div class="sub">' . '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module . '">' . $panel_lng['phrases'] .
                    ' (' . count($lng_module) . ')</a>';
                if (!empty($lng_edit) && in_array($name_module, array_keys($lng_edit)))
                    echo ' | <a href="' . $set['homeurl'] .
                        '/panel/index.php/act/languages/mod/reset_module/language/' .
                        $language . '/module/' . $name_module . '/start/' . $start .
                        '">' . $panel_lng['reset'] . '</a>';
                echo '</div></div>';
            }
            echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': <b>' . $total . '</b></div>';
            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/panel/index.php/act/languages/mod/module/language/' . $language .
                    '/', $start, $total, $kmess) . '</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '!</p></div>';
        }
        echo '<p>' . functions::link_back($lng['back'],
            'panel/index.php/act/languages') . '</p>';
        break;

    case 'info_module':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $lng_module_standart = ini_file::parser($language, $name_module);
        $lng_edit = ini_file::parser_edit($language);
        if (!$lng_module_standart)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $panel_lng['languages'], 'url' =>
                    'panel/index.php/act/languages'),
            array('label' => $lng_list[$language], 'url' =>
                    'panel/index.php/act/languages/mod/module/language/' . $language),
            array('label' => $name_module . ': ' . $panel_lng['information'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<div class="alert alert-info">' . '<p><ul>' .
            '<li><span class="gray">' . $panel_lng['name'] . ':</span> ' . $name_module .
            '</li>' . '<li><span class="gray">' . $panel_lng['phras'] .
            ':</span> ' . count($lng_module) . '</li>';
        echo '</ul></p></div>';
        echo '<p>' . functions::link_back($lng['back'],
            'panel/index.php/act/languages/mod/module/language/' . $language .
            '/start/' . $start) . '</p>';
        break;

    case 'reset_module':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        if (!$name_module)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        if (isset($_GET['yes']))
        {
            $lng_edit = ini_file::parser_edit($language);
            if (isset($lng_edit[$name_module]))
            {
                unset($lng_edit[$name_module]);
                ini_file::save_file($language, $lng_edit);
            }
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/module/language/' . $language .
                '/start/' . $start . '/do/reset');
            exit;
        }
        else
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                        '/index.php'),
                array('label' => $panel_lng['languages'], 'url' =>
                        'panel/index.php/act/languages'),
                array('label' => $lng_list[$language], 'url' =>
                        'panel/index.php/act/languages/mod/module/language/' . $language),
                array('label' => $panel_lng['reset'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<div class="alert alert-warning"><p>' . $panel_lng['module_resets'] .
                '</p></div>' . '<form name="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/reset_module/language/' . $language .
                '/module/' . $name_module . '/start/' . $start .
                '/yes" method="POST">' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['continue'] .
                '</button>&#160;<a class="btn btn-default" href="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/module/language/' . $language .
                '/start/' . $start . '">' . $lng['cancel'] . '</a></p>' .
                '</form>' . '<p>' . functions::link_back($lng['back'],
                'panel/index.php/act/languages/mod/module/language/' . $language) .
                '</p>';
        }
        break;

    case 'phrases':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $symbol = isset($_GET['symbol']) ? trim(mb_substr($_GET['symbol'], 0, 1)) :
            0;
        $lng_module_standart = ini_file::parser($language, $name_module);
        $lng_edit = ini_file::parser_edit($language);
        if (!$lng_module_standart)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
        $total = 0;
        $array_symbol = array();
        $array_result = array();
        $array_menu = array();
        $array_menu[] = $symbol ? '<a href="' . $set['homeurl'] .
            '/panel/index.php/act/languages/mod/phrases/language/' . $language .
            '/module/' . $name_module . '">' . $lng['all'] . '</a>' : '<b>' . $lng['all'] .
            '</b>';
        foreach ($lng_module as $key => $val)
        {
            $symbol_1 = substr($key, 0, 1);
            if (!in_array($symbol_1, $array_symbol))
            {
                $array_symbol[] = $symbol_1;
                $array_menu[] = $symbol && $symbol_1 == $symbol ? '<b>' . $symbol_1 .
                    '</b>' : '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module . '/symbol/' . $symbol_1 . '">' .
                    $symbol_1 . '</a>';
            }
            if (!$symbol || $symbol_1 == $symbol)
            {
                ++$total;
                if ($total > $start && $total < $start + $kmess)
                    $array_result[$key] = $val;
            }
        }
        $array_menu[] = '&nbsp;&nbsp;<a href="' . $set['homeurl'] .
            '/panel/index.php/act/languages/mod/search/language/' . $language .
            '/module/' . $name_module . '"><i class="fa fa-search"></i> ' . $lng['search'] .
            '</a>';
        $lng_module = $array_result;
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $panel_lng['languages'], 'url' =>
                    'panel/index.php/act/languages'),
            array('label' => $lng_list[$language], 'url' =>
                    'panel/index.php/act/languages/mod/module/language/' . $language),
            array('label' => $name_module . ': ' . $panel_lng['phrases'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<div class="topmenu">' . functions::display_menu($array_menu) .
            '</div>';
        switch ($do)
        {

            case 'reset':
                echo '<div class="alert alert-success"><b>' . $panel_lng['phrase_default'] .
                    '!</b></div>';
                break;

            case 'edit':
                echo '<div class="alert alert-success"><b>' . $panel_lng['phrase_edit'] .
                    '!</b></div>';
                break;

            case 'error':
                echo '<div class="alert alert-danger"><b>' . $panel_lng['error'] .
                    '!</b></div>';
                break;

            default:
                echo '';
        }
        if ($total)
        {
            echo '<form role="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/massdel_phrase/language/' .
                $language . '/module/' . $name_module . '/symbol/' . $symbol .
                '/start/' . $start . '" method="post">';
            echo '<div class="table-responsive">' .
                '<table class="table table-striped">';
            echo '<thead><tr><th>#</th><th>Key</th><th>Value</th><th>Edit</th><th>Reset</th></tr></thead><tbody>';
            $i = 0;
            $reset = false;
            foreach ($lng_module as $key => $val)
            {

                echo '<tr><td>' . (isset($lng_edit[$name_module]) && in_array($key,
                    array_keys($lng_edit[$name_module])) ?
                    '<input type="checkbox" name="delch[]" value="' . $key .
                    '"/>' : ' ') . '</td><td>' . $key . '</td><td>' . $val .
                    '</td>';
                echo '<td><a data-toggle="tooltip" data-title="' . $lng['edit'] .
                    '" href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/edit_phrase/language/' .
                    $language . '/module/' . $name_module . '/key/' . $key .
                    '/symbol/' . $symbol . '/start/' . $start .
                    '"><span class="glyphicon glyphicon-edit"></span></a></td>';
                if (isset($lng_edit[$name_module]) && in_array($key, array_keys
                    ($lng_edit[$name_module])))
                {
                    $reset = true;
                    echo '<td><a data-toggle="tooltip" data-title="' . $panel_lng['default'] .
                        '" href="' . $set['homeurl'] .
                        '/panel/index.php/act/languages/mod/delete_phrase/language/' .
                        $language . '/module/' . $name_module . '/key/' . $key .
                        '/symbol/' . $symbol . '/start/' . $start .
                        '"><span class="glyphicon glyphicon-repeat"></span></a></td>';
                }
                else
                {
                    echo '<td> </td>';
                }
                echo '</tr>';
                ++$i;
            }
            echo '</tbody></table></div>';
            if ($reset)
                echo
                    '<div class="well well-sm"><input class="btn btn-danger" type="submit" value="' .
                    $panel_lng['default'] . '"/></div>';
            echo '</form><div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': <b>' . $total . '</b></div>';
            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module . '/symbol/' . $symbol . '/', $start,
                    $total, $kmess) . '</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '!</p></div>';
        }
        echo '<p>' . functions::link_back($lng['back'],
            'panel/index.php/act/languages/mod/module/language/' . $language) .
            '</p>';
        break;

    case 'search':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $symbol = isset($_GET['symbol']) ? trim(mb_substr($_GET['symbol'], 0, 1)) :
            0;
        $lng_module_standart = ini_file::parser($language, $name_module);
        if (!$lng_module_standart)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $lng_edit = ini_file::parser_edit($language);
        $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
        $search_post = isset($_POST['search']) ? trim($_POST['search']) : false;
        $search_get = isset($_GET['search']) ? rawurldecode(trim($_GET['search'])) : false;
        $search = $search_post ? $search_post : $search_get;
        $array_symbol = array();
        $array_result = array();
        $array_menu = array();
        $total = 0;
        $array_menu[] = '<a href="' . $set['homeurl'] .
            '/panel/index.php/act/languages/mod/phrases/language/' . $language .
            '/module/' . $name_module . '">' . $lng['all'] . '</a>';
        foreach ($lng_module as $key => $val)
        {
            $symbol_1 = substr($key, 0, 1);
            if (!in_array($symbol_1, $array_symbol))
            {
                $array_symbol[] = $symbol_1;
                $array_menu[] = $symbol && $symbol_1 == $symbol ? '<b>' . $symbol_1 .
                    '</b>' : '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module . '/symbol/' . $symbol_1 . '">' .
                    $symbol_1 . '</a>';
            }
            if (isset($search) && (stristr($key, $search) || stristr($val, $search)))
            {
                ++$total;
                if ($total > $start && $total < $start + $kmess)
                    $array_result[$key] = $val;
            }
        }
        $array_menu[] = '<b>' . $lng['search'] . '</b>';
        $lng_module = $array_result;
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $panel_lng['languages'], 'url' =>
                    'panel/index.php/act/languages'),
            array('label' => $lng_list[$language], 'url' =>
                    'panel/index.php/act/languages/mod/module/language/' . $language),
            array('label' => $name_module, 'url' =>
                    'panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module),
            array('label' => $lng['search'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<div class="topmenu">' . functions::display_menu($array_menu) .
            '</div>';
        echo '<div class="well well-sm"><form class="form-horizontal" role="form" action="' .
            $set['homeurl'] .
            '/panel/index.php/act/languages/mod/search/language/' . $language .
            '/module/' . $name_module . '" method="post">' .
            '<div class="input-group"><input class="form-control" type="text" value="' . ($search ?
            functions::checkout($search) : '') . '" name="search" />' .
            '<span class="input-group-btn"><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['search'] . '</button></span>' . '</div></form></div>';
        $i = 0;
        $reset = false;
        if ($total)
        {
            echo '<form role="form" class="form-horizontal" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/massdel_phrase/language/' .
                $language . '/module/' . $name_module . '/symbol/' . $symbol .
                '/start/' . $start . '" method="post">';
            echo '<div class="table-responsive">' .
                '<table class="table table-striped">';
            echo '<thead><tr><th>#</th><th>Key</th><th>Value</th><th>Edit</th><th>Reset</th></tr></thead><tbody>';
            foreach ($lng_module as $key => $val)
            {
                $search = str_replace('*', '', $search);
                $search_key = mb_strlen($search) < 3 ? $key : preg_replace('|(' .
                    preg_quote($search, '/') . ')|siu',
                    '<span style="background-color: #FFFF33">$1</span>', $key);
                $search_val = mb_strlen($search) < 3 ? $val : preg_replace('|(' .
                    preg_quote($search, '/') . ')|siu',
                    '<span style="background-color: #FFFF33">$1</span>', $val);
                echo '<tr><td>' . (isset($lng_edit[$name_module]) && in_array($key,
                    array_keys($lng_edit[$name_module])) ?
                    '<input type="checkbox" name="delch[]" value="' . $key .
                    '"/>' : ' ') . '</td><td>' . $search_key . '</td><td>' . $search_val .
                    '</td>';
                echo '<td><a data-toggle="tooltip" data-title="' . $lng['edit'] .
                    '" href="' . $set['homeurl'] .
                    '/panel/index.php/act/languages/mod/edit_phrase/language/' .
                    $language . '/module/' . $name_module . '/key/' . $key .
                    '/symbol/' . $symbol . '/start/' . $start .
                    '"><span class="glyphicon glyphicon-edit"></span></a></td>';

                if (isset($lng_edit[$name_module]) && in_array($key, array_keys
                    ($lng_edit[$name_module])))
                {
                    $reset = true;
                    echo '<td><a data-toggle="tooltip" data-title="' . $panel_lng['default'] .
                        '" href="' . $set['homeurl'] .
                        '/panel/index.php/act/languages/mod/delete_phrase/language/' .
                        $language . '/module/' . $name_module . '/key/' . $key .
                        '/symbol/' . $symbol . '/start/' . $start .
                        '"><span class="glyphicon glyphicon-repeat"></span></a></td>';
                }
                else
                {
                    echo '<td> </td>';
                }
                echo '</tr>';
                ++$i;
            }
            echo '</tbody></table></div>';
            if ($reset)
                echo
                    '<div class="well well-sm"><input class="btn btn-danger" type="submit" value="' .
                    $panel_lng['default'] . '"/></div>';
            echo '</form><div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                $lng['total'] . ': <b>' . $total . '</b></div>';
            if ($total > $kmess)
            {
                echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                    '/panel/index.php/act/languages/mod/search/language/' . $language .
                    '/module/' . $name_module . '/search/' . urlencode($search) .
                    '/', $start, $total, $kmess) . '</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-danger"><p>' . $lng['list_empty'] .
                '!</p></div>';
        }
        echo '<p>' . functions::link_back($lng['back'],
            'panel/index.php/act/languages/mod/phrases/language/' . $language .
            '/module/' . $name_module) . '</p>';
        break;

    case 'edit_phrase':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $symbol = isset($_GET['symbol']) ? trim(mb_substr($_GET['symbol'], 0, 1)) :
            0;
        $key = isset($_GET['key']) ? ini_file::key_filter($_GET['key']) : 0;
        $lng_module_standart = ini_file::parser($language, $name_module);
        $lng_edit = ini_file::parser_edit($language);
        if (!$lng_module_standart)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
        if (!in_array($key, array_keys($lng_module)))
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $module . '/symbol/' . $symbol . '/start/' . $start .
                '/do/error');
            exit;
        }
        if (isset($_POST['submit']) && isset($_POST['value']))
        {
            $value_edit = ini_file::value_filter($_POST['value']);
            if (!isset($value_edit))
            {
                header('Location: ' . core::$system_set['homeurl'] .
                    '/panel/index.php/act/languages/mod/edit_phrase/language/' .
                    $language . '/module/' . $name_module . '/symbol/' . $symbol .
                    '/key/' . $key . '/start/' . $start);
                exit;
            }
            if ($lng_module[$key] != $value_edit)
            {
                if (!$lng_module_standart[$key] || $lng_module_standart[$key] !=
                    $value_edit)
                {
                    $lng_edit[$name_module][$key] = $value_edit;
                }
                else
                {
                    if (count($lng_edit[$name_module]) > 1)
                        unset($lng_edit[$name_module][$key]);
                    elseif (count($lng_edit[$name_module]))
                        unset($lng_edit[$name_module]);
                }
                ini_file::save_file($language, $lng_edit);
            }
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start .
                '/do/edit');
            exit;
        }
        else
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                        '/index.php'),
                array('label' => $panel_lng['languages'], 'url' =>
                        'panel/index.php/act/languages'),
                array('label' => $lng_list[$language], 'url' =>
                        'panel/index.php/act/languages/mod/module/language/' . $language),
                array('label' => $name_module, 'url' =>
                        'panel/index.php/act/languages/mod/phrases/language/' .
                        $language . '/module/' . $name_module . '/symbol/' . $symbol),
                array('label' => $lng['edit'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<form name="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/edit_phrase/language/' . $language .
                '/module/' . $name_module . '/key/' . $key . '/symbol/' . $symbol .
                '/start/' . $start . '" method="POST">' .
                '<div class="form-group">' . '<label class="control-label">' . $panel_lng['value'] .
                '</label>' . '<textarea class="form-control" rows="' . $set_user['field_h'] .
                '" name="value">' . htmlentities($lng_module[$key], ENT_QUOTES,
                'UTF-8') . '</textarea>' . '</div>' .
                '<input class="btn btn-primary" type="submit" name="submit" value="' .
                $lng['save'] . '"/>' . '</form>';
            echo '<p>' . functions::link_back($lng['back'],
                'panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start) .
                '</p>';
        }
        break;

    case 'delete_phrase':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $symbol = isset($_GET['symbol']) ? trim(mb_substr($_GET['symbol'], 0, 1)) :
            0;
        $key = isset($_GET['key']) ? ini_file::key_filter($_GET['key']) : 0;
        $lng_module_standart = ini_file::parser($language, $name_module);
        $lng_edit = ini_file::parser_edit($language);
        if (!$lng_module_standart)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        $lng_module = ini_file::update_lng($name_module, $lng_edit, $lng_module_standart);
        if (!in_array($key, array_keys($lng_module)))
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $module . '/symbol/' . $symbol . '/start/' . $start .
                '/do/error');
            exit;
        }
        if (isset($_GET['yes']))
        {
            if (count($lng_edit[$name_module]) > 1)
                unset($lng_edit[$name_module][$key]);
            elseif (count($lng_edit[$name_module]))
                unset($lng_edit[$name_module]);
            ini_file::save_file($language, $lng_edit);
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start .
                '/do/reset');
            exit;
        }
        else
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                        '/index.php'),
                array('label' => $panel_lng['languages'], 'url' =>
                        'panel/index.php/act/languages'),
                array('label' => $lng_list[$language], 'url' =>
                        'panel/index.php/act/languages/mod/module/language/' . $language),
                array('label' => $name_module, 'url' =>
                        'panel/index.php/act/languages/mod/phrases/language/' .
                        $language . '/module/' . $name_module . '/symbol/' . $symbol),
                array('label' => $panel_lng['reset'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<div class="alert alert-danger">' . $panel_lng['phrase_resets'] .
                '</div>';
            echo '<form name="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/delete_phrase/language/' . $language .
                '/module/' . $name_module . '/key/' . $key . '/symbol/' . $symbol .
                '/start/' . $start . '/yes" method="POST">' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['continue'] .
                '</button>&#160;<a class="btn btn-default" href="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start .
                '">' . $lng['cancel'] . '</a></p>' . '</form>' . '<p>' .
                functions::link_back($lng['back'],
                'panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start) .
                '</p>';
        }
        break;


    case 'massdel_phrase':
        $name_module = isset($_GET['module']) ? ini_file::key_filter($_GET['module']) : false;
        $symbol = isset($_GET['symbol']) ? trim(mb_substr($_GET['symbol'], 0, 1)) :
            0;
        $lng_edit = ini_file::parser_edit($language);
        if (!$name_module)
        {
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/do/error');
            exit;
        }
        if (isset($_GET['yes']))
        {
            $mass_dell = $_SESSION['mass_dell'];
            foreach ($mass_dell as $key)
            {
                if (isset($lng_edit[$name_module][$key]))
                    unset($lng_edit[$name_module][$key]);
            }
            if (!count($lng_edit[$name_module]))
                unset($lng_edit[$name_module]);
            ini_file::save_file($language, $lng_edit);
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol . '/start/' . $start .
                '/do/massdel');
            exit;
        }
        else
        {
            if (!$_POST['delch'])
            {
                header('Location: ' . core::$system_set['homeurl'] .
                    '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                    '/module/' . $name_module . '/symbol/' . $symbol . '/start/' .
                    $start);
                exit;
            }
            foreach ($_POST['delch'] as $key)
            {
                $mass_dell[] = ini_file::key_filter($key);
            }
            $_SESSION['mass_dell'] = $mass_dell;
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                        '/index.php'),
                array('label' => $panel_lng['languages'], 'url' =>
                        'panel/index.php/act/languages'),
                array('label' => $lng_list[$language], 'url' =>
                        'panel/index.php/act/languages/mod/module/language/' . $language),
                array('label' => $name_module, 'url' =>
                        'panel/index.php/act/languages/mod/phrases/language/' .
                        $language . '/module/' . $name_module . '/symbol/' . $symbol),
                array('label' => $panel_lng['reset'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<div class="alert alert-warning"><p>' . $panel_lng['phrase_resets'] .
                '</p></div>' . '<form name="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/massdel_phrase/language/' .
                $language . '/module/' . $name_module . '/symbol/' . $symbol .
                '/start/' . $start . '/yes" method="POST">' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['continue'] .
                '</button>&#160;<a class="btn btn-default" href="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/start/' . $start . '">' . $lng['cancel'] .
                '</a></p>' . '</form>' . '<p>' . functions::link_back($lng['back'],
                'panel/index.php/act/languages/mod/phrases/language/' . $language .
                '/module/' . $name_module . '/symbol/' . $symbol) . '</p>';
        }
        break;

    default:
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['language_system']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if ($do == 'error')
            echo '<div class="alert alert-danger"><b>' . $panel_lng['error'] .
                '!</b></div>';
        echo '<form role="form" action="' . $set['homeurl'] .
            '/panel/index.php/act/languages/mod/set" method="post">';
        foreach ($lng_desc as $key => $val)
        {
            $lng_menu = array(
                (!empty($val['author']) ? '<span class="gray">' . $lng['author'] .
                    ':</span> ' . $val['author'] : ''),
                (!empty($val['author_email']) ?
                    '<span class="gray">E-mail:</span> ' . $val['author_email'] :
                    ''),
                (!empty($val['author_url']) ? '<span class="gray">URL:</span> ' .
                    $val['author_url'] : ''),
                (!empty($val['description']) ? '<span class="gray">' . $lng['description'] .
                    ':</span> ' . $val['description'] : ''));
            echo '<div>' . '<input type="radio" value="' . $key .
                '" name="iso" ' . ($key == $set['lng'] ? 'checked="checked"' :
                '') . '/>' . (file_exists('../images/flags/' . $key . '.gif') ?
                ' <img src="' . $set['homeurl'] . '/images/flags/' . $key .
                '.gif" alt=""/>&#160;' : '') . '<a href="' . $set['homeurl'] .
                '/panel/index.php/act/languages/mod/module/language/' . $key .
                '"><b>' . $val['name'] . '</b></a>&#160;<span class="green">[' .
                $key . ']</span>' . '<div class="sub">' . functions::display_menu($lng_menu,
                '<br />') . '</div></td>' . '</div>';
        }
        echo '<div class="well well-sm"><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['save'] . '</button> <a class="btn btn-info" href="' . $set['homeurl'] .
            '/panel/index.php/act/languages/refresh">' . $lng['refresh_descriptions'] .
            '</a></div>' . '</form>' .
            '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': <b>' . count($lng_desc) . '</b></div>';
        echo '<p>' . functions::link_back($lng['admin_panel'], 'panel/') .
            '</p>';
}

?>