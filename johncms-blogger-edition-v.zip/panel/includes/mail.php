<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$lng_mail = core::load_lng('mail');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['mail']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if (isset($_POST['submit']))
{
    $set_mail['cat_friends'] = isset($_POST['cat_friends']) && $_POST['cat_friends'] ==
        1 ? 1 : 0;
    $set_mail['message_include'] = isset($_POST['message_include']) && $_POST['message_include'] ==
        1 ? 1 : 0;
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string($_POST['them_message']) .
        "' WHERE `key` = 'them_message'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string($_POST['reg_message']) .
        "' WHERE `key` = 'reg_message'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . (isset($_POST['message_include']) &&
        $_POST['message_include'] == 1 ? 1 : 0) .
        "' WHERE `key` = 'setting_mail'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string(serialize
        ($set_mail)) . "' WHERE `key` = 'setting_mail'");
    $req = mysql_query("SELECT * FROM `cms_settings`");
    $set = array();
    while ($res = mysql_fetch_row($req))
        $set[$res[0]] = $res[1];
    echo '<div class="alert alert-success">' . $lng['settings_saved'] . '</div>';
}
$set_mail = unserialize($set['setting_mail']);
if (!isset($set_mail['cat_friends']))
    $set_mail['cat_friends'] = 0;
if (!isset($set_mail['message_include']))
    $set_mail['message_include'] = 0;
if (empty($set['them_message']))
    $set['them_message'] = $lng_mail['them_message'];
if (empty($set['reg_message']))
    $set['reg_message'] = $lng['hi'] . ", {LOGIN}\r\n" . $lng_mail['pleased_see_you'] .
        "\r\n" . $lng_mail['come_my_site'] . "\r\n" . $lng_mail['respectfully_yours'];

echo '<form role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/mail" method="post">';

echo '<div class="well well-sm">' . $lng_mail['system_message_reg'] . '</div>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng_mail['theme_system_message'] .
    '</label>' . '<input class="form-control" type="text" name="them_message" value="' . (!
    empty($set['them_message']) ? htmlentities($set['them_message'], ENT_QUOTES,
    'UTF-8') : '') . '"/>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng['message'] . '</label>' .
    '<textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="reg_message">' . (!empty($set['reg_message']) ? htmlentities($set['reg_message'],
    ENT_QUOTES, 'UTF-8') : '') . '</textarea>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng_mail['sending_the_message'] .
    '</label>' . '<div class="radio"><label><input type="radio" value="1" name="message_include" ' . ($set_mail['message_include'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['lng_on'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="message_include" ' . (empty
    ($set_mail['message_include']) ? 'checked="checked"' : '') . '/>&#160;' . $lng['lng_off'] .
    '</label></div>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng_mail['marks'] . '</label>
    <p class="help-block">{LOGIN} - ' . $lng_mail['login_contacts'] .
    '<br />{TIME} - ' . $lng_mail['current_time'] . '</p>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng_mail['cat_friends'] .
    '</label>' . '<div class="radio"><label><input type="radio" value="1" name="cat_friends" ' . ($set_mail['cat_friends'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['lng_on'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="cat_friends" ' . (empty
    ($set_mail['cat_friends']) ? 'checked="checked"' : '') . '/>&#160;' . $lng['lng_off'] .
    '</label></div>' . '</div>' .
    '<p><input class="btn btn-primary" type="submit" name="submit" value="' . $lng['save'] .
    '"/></p></form>' . '<p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';

?>