<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['administration']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
$sw = 0;
$adm = 0;
$smd = 0;
$mod = 0;
$req = mysql_query("SELECT * FROM `users` WHERE `rights` = '9' ORDER BY `name` ASC");
if (mysql_num_rows($req))
{
    echo '<div class="panel panel-info">' . '<div class="panel-heading">' .
        '<h3 class="panel-title">' . $lng['supervisors'] . '</h3>' . '</div>' .
        '<div class="panel-body">';
    while (($res = mysql_fetch_assoc($req)) !== false)
    {
        echo $sw % 2 ? '<div class="list2">' : '<div class="list1">';
        echo functions::display_user($res, array('header' => ('<b>ID:' . $res['id'] .
                '</b>')));
        echo '</div>';
        ++$sw;
    }
    echo '</div>' . '</div>';
}
$req = mysql_query("SELECT * FROM `users` WHERE `rights` = '7' ORDER BY `name` ASC");
if (mysql_num_rows($req))
{
    echo '<div class="panel panel-info">' . '<div class="panel-heading">' .
        '<h3 class="panel-title">' . $lng['administrators'] . '</h3>' . '</div>' .
        '<div class="panel-body">';
    while (($res = mysql_fetch_assoc($req)) !== false)
    {
        echo $adm % 2 ? '<div class="list2">' : '<div class="list1">';
        echo functions::display_user($res, array('header' => ('<b>ID:' . $res['id'] .
                '</b>')));
        echo '</div>';
        ++$adm;
    }
    echo '</div>' . '</div>';
}
$req = mysql_query("SELECT * FROM `users` WHERE `rights` = '6' ORDER BY `name` ASC");
if (mysql_num_rows($req))
{
    echo '<div class="panel panel-info">' . '<div class="panel-heading">' .
        '<h3 class="panel-title">' . $lng['supermoders'] . '</h3>' . '</div>' .
        '<div class="panel-body">';
    while (($res = mysql_fetch_assoc($req)) !== false)
    {
        echo $smd % 2 ? '<div class="list2">' : '<div class="list1">';
        echo functions::display_user($res, array('header' => ('<b>ID:' . $res['id'] .
                '</b>')));
        echo '</div>';
        ++$smd;
    }
    echo '</div>' . '</div>';
}
$req = mysql_query("SELECT * FROM `users` WHERE `rights` BETWEEN '1' AND '5' ORDER BY `name` ASC");
if (mysql_num_rows($req))
{
    echo '<div class="panel panel-info">' . '<div class="panel-heading">' .
        '<h3 class="panel-title">' . $lng['moders'] . '</h3>' . '</div>' .
        '<div class="panel-body">';
    while (($res = mysql_fetch_assoc($req)) !== false)
    {
        echo $mod % 2 ? '<div class="list2">' : '<div class="list1">';
        echo functions::display_user($res, array('header' => ('<b>ID:' . $res['id'] .
                '</b>')));
        echo '</div>';
        ++$mod;
    }
    echo '</div>' . '</div>';
}
echo '<h2><span class="label label-info">' . $lng['total'] . ': ' . ($sw + $adm +
    $smd + $mod) . '</span></h2>';

?>