<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['users_list']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
$sort = isset($_GET['sort']) ? trim($_GET['sort']) : '';

switch ($sort)
{
    case 'nick':
        $sort = 'nick';
        $lgs = $lng['nick'];
        $order = '`name` ASC';
        break;

    case 'ip':
        $sort = 'ip';
        $lgs = 'IP';
        $order = '`ip` ASC';
        break;
    default:
        $sort = 'id';
        $lgs = 'ID';
        $order = '`id` ASC';
}
echo '<div class="btn-group" style="margin-bottom: 10px;">' .
    '<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">' .
    $lng['sorting'] . ': ' . $lgs . ' <span class="caret"></span></button>' .
    '<ul class="dropdown-menu" role="menu">' . '<li><a href="' . $set['homeurl'] .
    '/panel/index.php/act/usr/sort/id">ID</a></li>' . '<li><a href="' . $set['homeurl'] .
    '/panel/index.php/act/usr/sort/nick">' . $lng['nick'] . '</a></li>' .
    '<li><a href="' . $set['homeurl'] .
    '/panel/index.php/act/usr/sort/ip">IP</a></li>' . '</ul>' . '</div>';
$req = mysql_query("SELECT COUNT(*) FROM `users`");
$total = mysql_result($req, 0);
$req = mysql_query("SELECT * FROM `users` WHERE `preg` = 1 ORDER BY $order LIMIT " .
    $start . ", " . $kmess);
$i = 0;
while (($res = mysql_fetch_assoc($req)) !== false)
{
    $link = '';
    if ($rights >= 7)
        $link .= '<a href="' . $set['homeurl'] .
            '/users/profile.php/act/edit/user/' . $res['id'] .
            '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
            '</a> | <a href="' . $set['homeurl'] .
            '/panel/index.php/act/usr_del/id/' . $res['id'] .
            '"><span class="glyphicon glyphicon-remove"></span> ' . $lng['delete'] .
            '</a> | ';
    $link .= '<a href="' . $set['homeurl'] .
        '/users/profile.php/act/ban/mod/do/user/' . $res['id'] .
        '"><span class="glyphicon glyphicon-ban-circle"></span> ' . $lng['ban_do'] .
        '</a>';
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    echo functions::display_user($res, array('header' => ('<b>ID:' . $res['id'] .
            '</b>'), 'sub' => $link));
    echo '</div>';
    ++$i;
}
echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
    $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
        '/panel/index.php/act/usr/sort/' . $sort . '?', $start, $total, $kmess) .
        '</div>';
}
