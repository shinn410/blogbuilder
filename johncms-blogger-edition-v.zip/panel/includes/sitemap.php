<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['site_map']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);

if (!isset($set['sitemap']) || isset($_GET['reset']))
{

    $settings = array(
        'forum' => 1,
        'lib' => 1,
        'users' => 0,
        'browsers' => 0);
    @mysql_query("DELETE FROM `cms_settings` WHERE `key` = 'sitemap'");
    mysql_query("INSERT INTO `cms_settings` SET
        `key` = 'sitemap',
        `val` = '" . mysql_real_escape_string(serialize($settings)) . "'
    ");
    echo '<div class="alert alert-success"><p>' . $lng['settings_default'] .
        '</p></div>';
}
elseif (isset($_POST['submit']))
{

    $settings['forum'] = isset($_POST['forum']);
    $settings['lib'] = isset($_POST['lib']);
    $settings['users'] = isset($_POST['users']) && $_POST['users'] == 1 ? 1 : 0;
    $settings['browsers'] = isset($_POST['browsers']) && $_POST['browsers'] == 1 ?
        1 : 0;
    mysql_query("UPDATE `cms_settings` SET
        `val` = '" . mysql_real_escape_string(serialize($settings)) . "'
        WHERE `key` = 'sitemap'
    ");
    echo '<div class="alert alert-success"><p>' . $lng['settings_saved'] .
        '</p></div>';
}
else
{

    $settings = unserialize($set['sitemap']);
}

echo '<form role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/sitemap" method="post">' . '<div class="form-group">' .
    '<label class="control-label">' . $lng['include_in_map'] . '</label>' .
    '<div class="checkbox"><label><input name="forum" type="checkbox" value="1" ' . ($settings['forum'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['forum'] . '</label></div>' .
    '<div class="checkbox"><label><input name="lib" type="checkbox" value="1" ' . ($settings['lib'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['library'] . '</label></div>' .
    '</div>' . '<div class="form-group">' . '<label class="control-label">' . $lng['browsers'] .
    '</label>' . '<div class="radio"><label><input type="radio" value="1" name="browsers" ' . ($settings['browsers'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['show_all'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="browsers" ' . (!
    $settings['browsers'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['show_only_computers'] .
    '</label></div>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng['users'] . '</label>' .
    '<div class="radio"><label><input type="radio" value="1" name="users" ' . ($settings['users'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['show_all'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="users" ' . (!
    $settings['users'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['show_only_guests'] .
    '</label></div>' . '</div>' .
    '<p><button class="btn btn-primary" type="submit" name="submit">' . $lng['save'] .
    '</button>' . ' <a class="btn btn-danger" href="' . $set['homeurl'] .
    '/panel/index.php/act/sitemap&amp;reset">' . $lng['reset_settings'] .
    '</a></p>' . '</form>' . '<p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';

?>