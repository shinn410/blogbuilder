<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['site_settings']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if (isset($_POST['submit']))
{
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['skindef']) .
        "' WHERE `key` = 'skindef'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string(htmlspecialchars
        ($_POST['madm'])) . "' WHERE `key` = 'email'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . intval($_POST['timeshift']) .
        "' WHERE `key` = 'timeshift'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['copyright']) .
        "' WHERE `key` = 'copyright'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check(preg_replace
        ("#/$#", '', trim($_POST['homeurl']))) . "' WHERE `key` = 'homeurl'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . intval($_POST['flsz']) .
        "' WHERE `key` = 'flsz'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . isset($_POST['gz']) .
        "' WHERE `key` = 'gzip'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_key']) .
        "' WHERE `key` = 'meta_key'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_desc']) .
        "' WHERE `key` = 'meta_desc'");
    $req = mysql_query("SELECT * FROM `cms_settings`");
    $set = array();
    while ($res = mysql_fetch_row($req))
        $set[$res[0]] = $res[1];
    $set['url'] = $set['homeurl'];
    echo '<div class="alert alert-success">' . $lng['settings_saved'] . '</div>';
}
echo '<form role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/settings" method="post">';

echo '<h3 class="page-header">' . $lng['common_settings'] . '</h3>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng['site_url'] .
    '</label>' . '<input class="form-control" type="text" name="homeurl" value="' .
    htmlentities($set['url']) . '"/>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng['site_copyright'] . '</label>' .
    '<input class="form-control" type="text" name="copyright" value="' .
    htmlentities($set['copyright'], ENT_QUOTES, 'UTF-8') . '"/>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng['site_email'] .
    '</label>' . '<input class="form-control" name="madm" maxlength="50" value="' .
    htmlentities($set['email']) . '"/>' . '</div>' . '<div class="form-group">' .
    '<label class="control-label">' . $lng['file_maxsize'] . ' (kb)</label>' .
    '<input class="form-control" type="text" name="flsz" value="' . intval($set['flsz']) .
    '"/>' . '</div>' .
    '<div class="checkbox"><label><input name="gz" type="checkbox" value="1" ' . ($set['gzip'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['gzip_compress'] .
    '</label></div>';

echo '<h3 class="page-header">' . $lng['clock_settings'] . '</h3>' .
    '<p><input class="form-control form-table" type="text" name="timeshift" size="2" maxlength="3" value="' .
    $set['timeshift'] . '"/> ' . $lng['time_shift'] . ' (+-12)</p>' .
    '<p><span style="font-weight:bold; background-color:#C0FFC0">' . date("H:i",
    time() + $set['timeshift'] * 3600) . '</span> ' . $lng['system_time'] .
    '</p>' . '<p><span style="font-weight:bold; background-color:#FFC0C0">' .
    date("H:i") . '</span> ' . $lng['server_time'] . '</p>';

echo '<h3 class="page-header">' . $lng['meta_tags'] . '</h3>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng['meta_keywords'] .
    '</label>' . '<textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="meta_key">' . $set['meta_key'] . '</textarea>' . '</div>' .
    '<div class="form-group">' . '<label class="control-label">' . $lng['meta_description'] .
    '</label>' . '<textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="meta_desc">' . $set['meta_desc'] . '</textarea>' . '</div>';

echo '<div class="form-group">' . '<label class="control-label">' . $lng['design_template'] .
    ' (Mobile)</label>' . '<select class="form-control" name="skindef">';
$dir = opendir('../theme/wap/');
while ($skindef = readdir($dir))
{
    if (($skindef != '.') && ($skindef != '..') && ($skindef != '.svn'))
    {
        $skindef = str_replace('.css', '', $skindef);
        echo '<option' . ($set['skindef'] == $skindef ? ' selected="selected">' :
            '>') . $skindef . '</option>';
    }
}
closedir($dir);
echo '</select>' . '</div>';

echo '<div class="form-group">' . '<label class="control-label">' . $lng['design_template'] .
    ' (Desktop)</label>' . '<select class="form-control" name="skindefweb">';
$dir = opendir('../theme/web/');
while ($skindef = readdir($dir))
{
    if (($skindef != '.') && ($skindef != '..') && ($skindef != '.svn'))
    {
        $skindef = str_replace('.css', '', $skindef);
        echo '<option' . ($set['skindefweb'] == $skindef ? ' selected="selected">' :
            '>') . $skindef . '</option>';
    }
}
closedir($dir);
echo '</select>' . '</div>';

echo '<p><button class="btn btn-primary" type="submit" name="submit">' . $lng['save'] .
    '</button></p></form>' . '<p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';

?>