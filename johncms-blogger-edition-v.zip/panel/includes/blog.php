<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7) {
    header('Location: ' . $home . '/index.php?err');
    exit;
}

if (!$do)
    $do = '';
else
    $do = htmlentities($do);

switch ($mod) {
    case 'accept':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => 'Lists', 'url' => $set['admp'] .
                    '/index.php/act/blog/mod/lists'),
            array('label' => 'Menyetujui'),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '$id'");
        if (mysql_num_rows($req)) {
            $blog = mysql_fetch_array($req);
            if (isset($_POST['submit'])) {
                mysql_query("UPDATE `blog_sites` SET `mod_reg` = 'no' WHERE `id` = '{$blog['id']}'") or
                    die(mysql_error());
                $n_text = 'Blog baru Kamu http://' . $blog['url'] .
                    ' telah disetujui oleh Administrator';
                mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '{$blog['user_id']}',
					`text` = '" . mysql_real_escape_string($n_text) . "',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = 'Blog baru telah disetujui'
                    ");
                echo
                    '<div class="alert alert-success">Pembuatan blog baru berhasil disetuji.<br/>' .
                    '<a class="alert-link" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists">&laquo; Kembali</a></div>';
            }
            else {
                echo '<form method="post" action="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/accept/id/' . $blog['id'] . '">' .
                    '<div class="alert alert-danger">Kamu yakin akan menyetujui pembuatan blog baru ini?</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">Ya</button>' .
                    ' <a class="btn btn-default" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists" data-dismiss="modal">Tidak</a></p></form>';
            }
        }
        else {
            echo functions::display_error('Blog tidak ada!');
        }
        break;

    case 'delete':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => 'Lists', 'url' => $set['admp'] .
                    '/index.php/act/blog/mod/lists'),
            array('label' => $lng['delete']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '$id'");
        if (mysql_num_rows($req)) {
            $blog = mysql_fetch_array($req);
            if (isset($_POST['submit'])) {
                functions::delete_blog($blog);
                $n_text = 'Blog Kamu http://' . $blog['url'] .
                    ' telah dihapus oleh Administrator';
                mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '{$blog['user_id']}',
					`text` = '" . mysql_real_escape_string($n_text) . "',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = 'Penghapusan Blog'
                    ");
                echo
                    '<div class="alert alert-success">Blog berhasil dihapus.<br/>' .
                    '<a class="alert-link" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists">&laquo; Kembali</a></div>';
            }
            else {
                echo '<form method="post" action="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/delete/id/' . $blog['id'] . '">' .
                    '<div class="alert alert-danger">Kamu yakin akan menghapus blog ini?</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">Ya</button>' .
                    ' <a class="btn btn-default" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists" data-dismiss="modal">Tidak</a></p></form>';
            }
        }
        else {
            echo functions::display_error('Blog tidak ada!');
        }
        break;

    case 'unblock':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => 'Lists', 'url' => $set['admp'] .
                    '/index.php/act/blog/mod/lists'),
            array('label' => 'Lepas pemblokiran'),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '$id'");
        if (mysql_num_rows($req)) {
            $blog = mysql_fetch_array($req);
            if (isset($_POST['submit'])) {
                mysql_query("UPDATE `blog_sites` SET `block` = 'no' WHERE `id` = '{$blog['id']}'") or
                    die(mysql_error());
                $n_text = 'Blog Kamu http://' . $blog['url'] .
                    ' sudah dilepas dari pemblokiran';
                mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '{$blog['user_id']}',
					`text` = '" . mysql_real_escape_string($n_text) . "',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = 'Lepas Pemblokiran Blog'
                    ");
                echo
                    '<div class="alert alert-success">Pemblokiran berhasil dilepas.<br/>' .
                    '<a class="alert-link" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists">&laquo; Kembali</a></div>';
            }
            else {
                echo '<form method="post" action="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/unblock/id/' . $blog['id'] . '">' .
                    '<div class="alert alert-danger">Kamu yakin akan melepas pemblokiran blog ini?</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">Ya</button>' .
                    ' <a class="btn btn-default" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists" data-dismiss="modal">Tidak</a></p></form>';
            }
        }
        else {
            echo functions::display_error('Blog tidak ada!');
        }
        break;

    case 'block':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => 'Lists', 'url' => $set['admp'] .
                    '/index.php/act/blog/mod/lists'),
            array('label' => 'Blokir'),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '$id'");
        if (mysql_num_rows($req)) {
            $blog = mysql_fetch_array($req);
            if (isset($_POST['submit'])) {
                mysql_query("UPDATE `blog_sites` SET `block` = 'yes' WHERE `id` = '{$blog['id']}'") or
                    die(mysql_error());
                $n_text = 'Blog Kamu http://' . $blog['url'] .
                    ' diblokir oleh Administratot';
                mysql_query("INSERT INTO `cms_mail` SET
					`user_id` = '$user_id', 
					`from_id` = '{$blog['user_id']}',
					`text` = '" . mysql_real_escape_string($n_text) . "',
					`time` = '" . time() . "',
					`sys` = '1',
					`them` = 'Pemblokiran Blog'
                    ");
                echo
                    '<div class="alert alert-success">Blog berhasil diblokir.<br/>' .
                    '<a class="alert-link" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists">&laquo; Kembali</a></div>';
            }
            else {
                echo '<form method="post" action="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/block/id/' . $blog['id'] . '">' .
                    '<div class="alert alert-danger">Kamu yakin akan memblokir blog ini?</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">Ya</button>' .
                    ' <a class="btn btn-default" href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/lists" data-dismiss="modal">Tidak</a></p></form>';
            }
        }
        else {
            echo functions::display_error('Blog tidak ada!');
        }
        break;

    case 'settings':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => $lng['settings']),
            ));

        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if (isset($_POST['submit'])) {
            $blogdomains = preg_split("/[\s,]+/", $_POST['blogdomains']);
            $blogsubdomaindisallow = preg_split("/[\s,]+/", $_POST['blogsubdomaindisallow']);
            $blogpreview = abs(intval($_POST['blogpreview']));
            $blogcategories = preg_split("/[,]+/", $_POST['blogcategories']);
            $blogmax = abs(intval($_POST['blogmax']));
            $blogtimediff = abs(intval($_POST['blogtimediff']));
            $blogediturl = $_POST['blogediturl'] == 'yes' ? 'yes' : 'no';
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string($blogpreview) .
                "' WHERE `key` = 'blogpreview'");
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string(serialize($blogdomains)) .
                "' WHERE `key` = 'blogdomains'");
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string(serialize($blogsubdomaindisallow)) .
                "' WHERE `key` = 'blogsubdomaindisallow'");
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string(serialize($blogcategories)) .
                "' WHERE `key` = 'blogcategories'");
            $in = array();
            for ($i = 0; $i < count($blogcategories); $i++) {
                $in[] = functions::permalink($blogcategories[$i]);
            }
            if (count($in)) {
                mysql_query("UPDATE `blog_sites` SET `category`='uncategorized' WHERE FIND_IN_SET(category,'" .
                    implode(",", $in) . "') = 0");
            }
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string($blogmax) . "' WHERE `key` = 'blogmax'");
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string($blogtimediff) .
                "' WHERE `key` = 'blogtimediff'");
            mysql_query("UPDATE `cms_settings` SET `val`='" .
                mysql_real_escape_string($blogediturl) .
                "' WHERE `key` = 'blogediturl'");
            $req = mysql_query("SELECT * FROM `cms_settings`");
            $set = array();
            while ($res = mysql_fetch_row($req))
                $set[$res[0]] = $res[1];
            $success = '<div class="alert alert-success">' . $lng['settings_saved'] .
                '</div>';

        }

        echo '<form role="form" action="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/settings" method="post">';
        if (isset($success))
            echo $success;
        echo '<div class="form-group"><label>Domain</label>' .
            '<input class="form-control" type="text" name="blogdomains" value="' .
            htmlentities(implode(',', unserialize($set['blogdomains']))) .
            '"/><p class="help-block">Jika domain lebih dari satu pisahkan dengan koma (,).' .
            ' Contoh: domain1.com,domain2.com</p></div>' .
            '<div class="form-group"><label>Subdomain yang dilarang</label>' .
            '<input class="form-control" type="text" name="blogsubdomaindisallow" value="' .
            htmlentities(implode(',', unserialize($set['blogsubdomaindisallow']))) .
            '"/><p class="help-block">Jika subdomain lebih dari satu pisahkan dengan koma (,).' .
            ' Contoh: mail,cpanel</p></div>' .
            '<div class="form-group"><label>Blog Preview</label>' .
            '<input class="form-control" type="text" name="blogpreview" value="' .
            $set['blogpreview'] .
            '"/><p class="help-block">ID Blog untuk preview template</p></div>' .
            '<div class="form-group"><label>Blog Kategori</label>' .
            '<input class="form-control" type="text" name="blogcategories" value="' .
            htmlentities(implode(',', unserialize($set['blogcategories']))) .
            '"/><p class="help-block">Pisahkan dengan koma (,). Contoh: Kesehatan,Hobi</p></div>' .
            '<div class="form-group"><label>Maksimal Jumlah Blog</label>' .
            '<input class="form-control" type="text" name="blogmax" value="' .
            htmlentities($set['blogmax']) .
            '" maxlength="2"/><p class="help-block">Maksimal jumlah blog per user</p></div>' .
            '<div class="form-group"><label>Selisih Waktu</label>' .
            '<div class="input-group"><input class="form-control" type="text" name="blogtimediff" value="' .
            htmlentities($set['blogtimediff']) .
            '" maxlength="2"/><span class="input-group-addon">Jam</span></div>' .
            '<p class="help-block">Selisih waktu pembuatan blog (dalam jam).</p></div>' .
            '<div class="form-group"><label>Mengubah URL Blog</label>' .
            '<div class="radio"><label>' .
            '<input type="radio" name="blogediturl" value="yes"' . ($set['blogediturl'] ==
            "yes" ? ' checked="checked"' : '') .
            '> Ijinkan</label></div><div class="radio"><label>' .
            '<input type="radio" name="blogediturl" value="no"' . ($set['blogediturl'] ==
            "no" ? ' checked="checked"' : '') .
            '> Jangan ijinkan</label></div></div>' .
            '<p><button class="btn btn-primary" type="submit" name="submit">' .
            $lng['save'] . '</button></p></form>';
        break;

    case 'lists':
        $sql = "(SELECT COUNT(*) FROM `blog_sites`)
                UNION ALL (SELECT COUNT(*) FROM `blog_sites` WHERE `mod_reg` = 'yes')
                UNION ALL (SELECT COUNT(*) FROM `blog_sites` WHERE `block` = 'yes')";
        $query = mysql_query($sql);
        $total = array();

        while ($res = mysql_fetch_array($query))
            $total[] = $res[0];

        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => $lng['list']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);

        echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs">' . '<li' . (!
            $do || !in_array($do, array('moderated', 'blocked')) ?
            ' class="active"' : '') . '><a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists"><i class="fa fa-rss-square"></i> Semua <span class="badge">' .
            $total[0] . '</span></a>' . '</li><li' . ($do == 'moderated' ?
            ' class="active"' : '') . '><a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists/do/moderated">' .
            '<i class="fa fa-ticket"></i> Moderasi <span class="badge">' . $total[1] .
            '</span></a></li>' . '<li' . ($do == 'blocked' ? ' class="active"' :
            '') . '><a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists/do/blocked">' .
            '<i class="fa fa-ban"></i> Pemblokiran <span class="badge">' . $total[2] .
            '</span></a></li>' . '</ul><div class="tab-content">';
        switch ($do) {
            case 'moderated':
                $sql = " WHERE `mod_reg` = 'yes'";
                $total = $total[1];
                break;

            case 'blocked':
                $sql = " WHERE `block` = 'yes'";
                $total = $total[2];
                break;

            default:
                $sql = "";
                $total = $total[0];
                break;
        }
        if ($total) {
            $req = mysql_query("SELECT * FROM `blog_sites`$sql ORDER BY `id` DESC LIMIT $start, $kmess");
            $i = 0;
            $author = array();
            while ($blog = mysql_fetch_array($req)) {
                if (!isset($author[$blog['id']])) {
                    $us = @mysql_fetch_array(mysql_query("SELECT `name`,`rights` FROM `users` 
                    WHERE `id` = {$blog['user_id']}"));
                    $author[$blog['user_id']] = $us ? $us : array('name' => '',
                            'rights' => 0);
                }
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '<h4 class="no-margin"><a href="//' . $blog['url'] .
                    '"><i class="fa fa-globe"></i> ' . htmlspecialchars($blog['title'],
                    ENT_QUOTES, 'UTF-8') . '</a></h4>';
                echo '<div class="sub"><p><a href="' . $home .
                    '/blogpanel/index.php/act/switch/id/' . $blog['id'] .
                    '/redir/' . base64_encode($set['homeurl'] .
                    '/blogpanel/index.php/act/dashboard') .
                    '"><i class="fa fa-sign-in"></i> Kelola</a>';
                if ($blog['mod_reg'] == 'yes')
                    echo ' | <a href="' . $home . '/' . $set['admp'] .
                        '/index.php/act/blog/mod/accept/id/' . $blog['id'] .
                        '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><i class="fa fa-check"></i> Setujui</a>';
                if ($blog['block'] == 'yes')
                    echo ' | <a href="' . $home . '/' . $set['admp'] .
                        '/index.php/act/blog/mod/unblock/id/' . $blog['id'] .
                        '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><i class="fa fa-ban"></i> Lepas pemblokiran</a>';
                else
                    echo ' | <a href="' . $home . '/' . $set['admp'] .
                        '/index.php/act/blog/mod/block/id/' . $blog['id'] .
                        '" data-toggle="' . functions::set_modal() .
                        '" data-target="#global-modal"><i class="fa fa-ban"></i> Blokir</a>';
                echo ' | <a href="' . $home . '/' . $set['admp'] .
                    '/index.php/act/blog/mod/delete/id/' . $blog['id'] .
                    '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a>' .
                    '</p><ul class="list-unstyled">' .
                    '<li><i class="fa fa-user"></i> Pengelola: <a href="' . $home .
                    '/users/profile.php/user/' . $blog['user_id'] . '">' . $author[$blog['user_id']]['name'] .
                    '</a></li>' . '<li><i class="fa fa-clock-o"></i> Dibuat: ' .
                    functions::display_date($blog['time']) . '</li>' .
                    '<li><i class="fa fa-ticket"></i> Moderasi: ' . ucfirst($blog['mod_reg']) .
                    '</li>' . '<li><i class="fa fa-ban"></i> Pemblokiran: ' .
                    ucfirst($blog['block']) . '</li>' . '</ul></div>';
                echo '</div>';
                $i++;
            }
        }
        echo '</div></div>';
        break;

    case 'posts':
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `time` < '" .
            time() . "'"), 0);
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog', 'url' => $set['admp'] .
                    '/index.php/act/blog'),
            array('label' => 'Posting'),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);

        if ($total) {
            $req = mysql_query("SELECT `blog_posts`.*, 
                    `users`.`name` AS `author_name`,
                    `blog_sites`.`url` AS `blog_url`, `blog_sites`.`title` AS `blog_title` 
                    FROM `blog_posts` LEFT JOIN `users` ON `blog_posts`.`user_id` = `users`.`id`
                    LEFT JOIN `blog_sites` ON `blog_posts`.`site_id` = `blog_sites`.`id` 
                    WHERE `blog_posts`.`time` < '" . time() . "' 
                    ORDER BY `blog_posts`.`time` DESC LIMIT $start, $kmess");
            $i = 0;
            while ($post = mysql_fetch_array($req)) {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '<a href="//' . $post['blog_url'] . '/' . $post['permalink'] .
                    '.html"><h4>' . htmlspecialchars($post['title']) .
                    '</h4></a><div class="sub"><ul class="list-unstyled">' .
                    '<li><i class="fa fa-rss"></i> Blog: <a href="//' . $post['blog_url'] .
                    '/">' . htmlspecialchars($post['blog_title']) . '</a></li>' .
                    '<li><i class="fa fa-user"></i> Penulis: <a href="' . $home .
                    '/users/profile.php/user/' . $post['user_id'] . '">' . $post['author_name'] .
                    '</a></li><li><i class="fa fa-clock-o"></i> Waktu: ' .
                    functions::display_date($post['time']) . '</li></ul>' . (($rights ==
                    7 || $rights == 9) ? '<div><a href="' . $home .
                    '/blogpanel/index.php/act/edit_post/post_id/' . $post['id'] .
                    '"><i class="fa fa-edit"></i> Edit</a>&nbsp;|&nbsp;<a href="' .
                    $home .
                    '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' . $post['id'] .
                    '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal"><i class="fa fa-times"></i> Hapus</a></div>' :
                    '') . '</div>';
                echo '</div>';
                ++$i;
            }
        }
        echo '</div></div>';
        break;

    case 'check_update':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('url' => $set['admp'] . '/index.php/act/blog', 'label' =>
                    'Modul Blog'),
            array('label' => 'Periksa pembaruan'),
            ));

        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if (($ver = file_get_contents('http://feed.heck.in/files/jcmsbe.txt')) != false) {
            if (version_compare(core::$version, $ver, '<'))
                echo
                    '<div class="alert alert-warning">Versi baru telah tersedia, yaitu <strong>JohnCMS Blogger Edition v' .
                    $ver . '</strong><p>Untuk info lebih lanjut hubungi ' .
                    '<a class="alert-link" href="http://facebook.com/achunks">Achunk JealousMan</a> (sms: 0818118061)</div>';
            else
                echo
                    '<div class="alert alert-success">Selamat, Kamu menggunakan JohnCMS Blogger Edition v.' .
                    core::$version . ', ini adalah versi terbaru.</div>';
        }
        else {
            echo '<div class="alert alert-danger">' .
                'Tidak dapat memeriksa pembaruan!</div>';
        }
        break;

    default:
        $sql = "(SELECT COUNT(*) FROM `blog_sites`)
                UNION ALL (SELECT COUNT(*) FROM `blog_sites` WHERE `mod_reg` = 'yes')
                UNION ALL (SELECT COUNT(*) FROM `blog_sites` WHERE `block` = 'yes')
                UNION ALL (SELECT COUNT(*) FROM `blog_posts`)";
        $query = mysql_query($sql);
        $total = array();

        while ($res = mysql_fetch_array($query))
            $total[] = $res[0];

        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => 'Modul Blog'),
            ));

        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<div class="row">';
        echo '<div class="col-sm-9">';
        echo '<p><a class="btn btn-app" href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/settings"><i class="fa fa-cogs"></i> ' . $lng['settings'] .
            '</a>&nbsp;<a class="btn btn-app" href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists"><span class="badge bg-aqua">' . $total[0] .
            '</span><i class="fa fa-rss-square"></i> Blog</a>' .
            '&nbsp;<a class="btn btn-app" href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/posts"><span class="badge bg-green">' . $total[3] .
            '</span><i class="fa fa-file-text"></i> Posting</a></p><hr />';
        echo '<div class="box box-solid"><div class="box-header"><h4 class="box-title">Halo ' .
            $login . '</h4></div><div class="box-body">';
        echo 'Selamat dan terima kasih sudah menggunakan JohnCMS Blogger Edition v' .
            core::$version . ', <a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/check_update">Periksa pembaruan &raquo;</a>.<br/>' .
            'JohnCMS Blogger Edition adalah pengembangan dari script JohnCMS yang ' .
            'dipublikasikan oleh situs <a href="http://johncms.com" target="_new">http://johncms.com</a>, tanpa mengurangi atau menghapus' .
            ' hak cipta dari situs tersebut Saya telah merubah nama script menjadi JohnCMS ' .
            'Blogger Edition semata-mata hanya untuk mencirikan script dari script JohnCMS ' .
            'yang telah dimodifikasi lainnya.<br/><br/>JohnCMS Blogger Edition dikembangkan oleh ' .
            'Achunk JealousMan yang pernah membuat script IndoWapBlog.<br/>' .
            'Untuk pertanyaan atau laporan tentang kesalahan script silakan hubungi melalui SMS/Telp ' .
            'ke +62818118061 atau kunjungi profile Facebook Achunk JealousMan ' .
            '<a href="http://fb.com/achunks" target="_new">http://fb.com/achunks</a>';
        echo '</div></div></div>';

        echo '<div class="col-sm-3"><h4 class="page-header margin text-center">Total Blog</h4>';
        echo '<div class="col-xs-6 col-sm-12"><div class="small-box bg-aqua">' .
            '<div class="inner"><h3>' . $total[0] . '</h3>' .
            '<p>Semua</p></div><div class="icon"><i class="fa fa-rss-square"></i></div>' .
            '<a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists" class="small-box-footer">Selengkapnya ' .
            '<i class="fa fa-arrow-circle-right"></i></a></div></div>';
        echo '<div class="col-xs-6 col-sm-12"><div class="small-box bg-yellow"><div class="inner"><h3>' .
            $total[1] . '</h3>' .
            '<p>Moderasi</p></div><div class="icon"><i class="fa fa-ticket"></i></div>' .
            '<a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists/do/moderated" class="small-box-footer">Selengkapnya ' .
            '<i class="fa fa-arrow-circle-right"></i></a></div></div>';
        echo '<div class="col-xs-6 col-sm-12"><div class="small-box bg-red"><div class="inner"><h3>' .
            $total[2] . '</h3>' .
            '<p>Pemblokiran</p></div><div class="icon"><i class="fa fa-ban"></i></div>' .
            '<a href="' . $home . '/' . $set['admp'] .
            '/index.php/act/blog/mod/lists/do/blocked" class="small-box-footer">Selengkapnya ' .
            '<i class="fa fa-arrow-circle-right"></i></a></div></div>';
        echo '</div>';
        echo '</div>';
        break;
}

?>