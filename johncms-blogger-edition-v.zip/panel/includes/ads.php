<?

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}

switch ($mod)
{
    case 'edit':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['advertisement'], 'url' =>
                    'panel/index.php/act/ads'),
            array('label' => ($id ? $lng['link_edit'] : $lng['link_add']))));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if ($id)
        {

            $req = mysql_query("SELECT * FROM `cms_ads` WHERE `id` = '$id'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
            }
            else
            {
                echo functions::display_error($lng['error_wrong_data'],
                    '<a href="' . $set['homeurl'] . '/panel/index.php/act/ads">' .
                    $lng['back'] . '</a>');
                require ('../incfiles/end.php');
                exit;
            }
        }
        else
        {
            $res = array('link' => 'http://');
        }
        if (isset($_POST['submit']))
        {
            $link = isset($_POST['link']) ? mysql_real_escape_string(trim($_POST['link'])) :
                '';
            $name = isset($_POST['name']) ? mysql_real_escape_string(trim($_POST['name'])) :
                '';
            $bold = isset($_POST['bold']);
            $italic = isset($_POST['italic']);
            $underline = isset($_POST['underline']);
            $show = isset($_POST['show']);

            $view = isset($_POST['view']) ? abs(intval($_POST['view'])) : 0;
            $day = isset($_POST['day']) ? abs(intval($_POST['day'])) : 0;
            $count = isset($_POST['count']) ? abs(intval($_POST['count'])) : 0;
            $day = isset($_POST['day']) ? abs(intval($_POST['day'])) : 0;
            $layout = isset($_POST['layout']) ? abs(intval($_POST['layout'])) :
                0;
            $type = isset($_POST['type']) ? intval($_POST['type']) : 0;
            $mesto = isset($_POST['mesto']) ? abs(intval($_POST['mesto'])) : 0;
            $color = isset($_POST['color']) ? mb_substr(trim($_POST['color']), 0,
                6) : '';
            $error = array();
            if (!$link || !$name)
                $error[] = $lng['error_empty_fields'];
            if ($type > 3 || $type < 0)
                $type = 0;
            if (!$mesto)
            {
                $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ads` WHERE `mesto` = '" .
                    $mesto . "' AND `type` = '" . $type . "'"), 0);
                if ($total != 0)
                    $error[] = $lng['links_place_occupied'];
            }
            if ($color)
            {
                if (preg_match("/[^\da-fA-F_]+/", $color))
                    $error[] = $lng['error_wrong_symbols'];
                if (strlen($color) < 6)
                    $error[] = $lng['error_color'];
            }
            if ($error)
            {
                echo functions::display_error($error,
                    '<a class="alert-link" href="' . $set['homeurl'] .
                    '/panel/index.php/act/ads/from/addlink">' . $lng['back'] .
                    '</a>');
                require ('../incfiles/end.php');
                exit;
            }
            if ($id)
            {

                mysql_query("UPDATE `cms_ads` SET
                    `type` = '$type',
                    `view` = '$view',
                    `link` = '$link',
                    `name` = '$name',
                    `color` = '$color',
                    `count_link` = '$count',
                    `day` = '$day',
                    `layout` = '$layout',
                    `bold` = '$bold',
                    `show` = '$show',
                    `italic` = '$italic',
                    `underline` = '$underline'
                    WHERE `id` = '$id'
                ");
            }
            else
            {

                $req = mysql_query("SELECT `mesto` FROM `cms_ads` ORDER BY `mesto` DESC LIMIT 1");
                if (mysql_num_rows($req) > 0)
                {
                    $res = mysql_fetch_array($req);
                    $mesto = $res['mesto'] + 1;
                }
                else
                {
                    $mesto = 1;
                }
                mysql_query("INSERT INTO `cms_ads` SET
                    `type` = '$type',
                    `view` = '$view',
                    `mesto` = '$mesto',
                    `link` = '$link',
                    `name` = '$name',
                    `color` = '$color',
                    `count_link` = '$count',
                    `day` = '$day',
                    `layout` = '$layout',
                    `to` = '0',
                    `show` = '$show',
                    `time` = '" . time() . "',
                    `bold` = '$bold',
                    `italic` = '$italic',
                    `underline` = '$underline'
                ") or die(mysql_error());
            }
            mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
                "' WHERE `id` = '$user_id'");
            echo '<div class="alert alert-success"><p>' . ($id ? $lng['link_edit_ok'] :
                $lng['link_add_ok']) . '<br />' . '<a class="alert-link" href="' .
                $set['homeurl'] . '/panel/index.php/act/ads/sort/' . $type .
                '">' . $lng['continue'] . '</a></p></div>';
        }
        else
        {

            echo '<form role="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/ads/mod/edit' . ($id ? '/id/' . $id : '') .
                '" method="post">' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['link'] . '</label>' .
                '<input class="form-control" type="text" name="link" value="' .
                htmlentities($res['link'], ENT_QUOTES, 'UTF-8') . '"/>' .
                '<div class="chechbox"><label><input type="checkbox" name="show" ' . (isset
                ($res['show']) && !empty($res['show']) ? 'checked="checked"' :
                '') . '/>&nbsp;' . $lng['link_direct'] . '</label></div>' .
                '<p class="help-block">' . $lng['link_direct_help'] . '</p>' .
                '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['title'] . '</label>' .
                '<input class="form-control" type="text" name="name" value="' . (isset
                ($res['name']) ? htmlentities($res['name'], ENT_QUOTES, 'UTF-8') :
                '') . '"/>' . '<p class="help-block">' . $lng['link_add_name_help'] .
                '</p>' . '</div>' . '<div class="form-group">' .
                '<label class="control-label dis-block">' . $lng['color'] .
                '</label>' .
                '<input class="form-control form-table" type="text" name="color" size="6" value="' . (isset
                ($res['color']) ? $res['color'] : '') . '"/>' .
                '<p class="help-block">' . $lng['link_add_color_help'] . '</p>' .
                '</div>' . '<div class="form-group">' .
                '<label class="control-label dis-block">' . $lng['transitions'] .
                '</label>' .
                '<input class="form-control form-table" type="text" name="count" size="6" value="' . (isset
                ($res['count_link']) ? $res['count_link'] : '') . '"/>' .
                '<p class="help-block">' . $lng['link_add_trans_help'] . '</p>' .
                '</div>' . '<div class="form-group">' .
                '<label class="control-label dis-block">' . $lng['days'] .
                '</label>' .
                '<input class="form-control form-table" type="text" name="day" size="6" value="' . (isset
                ($res['day']) ? $res['day'] : '') . '"/>' .
                '<p class="help-block">' . $lng['link_add_days_help'] . '</p>' .
                '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['to_show'] . '</label>' .
                '<div class="radio"><label><input type="radio" name="view" value="0" ' . (!
                isset($res['view']) || empty($res['view']) ? 'checked="checked"' :
                '') . '/>&nbsp;' . $lng['to_all'] . '</label></div>' .
                '<div class="radio"><label><input type="radio" name="view" value="1" ' . (isset
                ($res['view']) && ($res['view'] == 1) ? 'checked="checked"' : '') .
                '/>&nbsp;' . $lng['to_guest'] . '</label></div>' .
                '<div class="radio"><label><input type="radio" name="view" value="2" ' . (isset
                ($res['view']) && ($res['view'] == 2) ? 'checked="checked"' : '') .
                '/>&nbsp;' . $lng['to_users'] . '</label></div>' . '</div>' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['arrangement'] .
                '</label>' .
                '<div class="radio"><label><input type="radio" name="type" value="0" ' . (empty
                ($res['type']) ? 'checked="checked"' : '') . '/>&nbsp;' . $lng['links_armt_over_logo'] .
                ' (Konten bagian atas)</label></div>' .
                '<div class="radio"><label><input type="radio" name="type" value="1" ' . (isset
                ($res['type']) && ($res['type'] == 1) ? 'checked="checked"' : '') .
                '/>&nbsp;' . $lng['links_armt_under_usermenu'] .
                ' (Konten bagian bawah)</label></div>' .
                '<div class="radio"><label><input type="radio" name="type" value="2" ' . (isset
                ($res['type']) && ($res['type'] == 2) ? 'checked="checked"' : '') .
                '/>&nbsp;' . $lng['links_armt_over_counters'] .
                ' (Sidebar bagian atas)</label></div>' .
                '<div class="radio"><label><input type="radio" name="type" value="3" ' . (isset
                ($res['type']) && ($res['type'] == 3) ? 'checked="checked"' : '') .
                '/>&nbsp;' . $lng['links_armt_under_counters'] .
                ' (Sidebar bagian bawah)</label></div>' . '</div>' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['placing'] .
                '</label>' .
                '<div class="radio"><label><input type="radio" name="layout" value="0" ' . (empty
                ($res['layout']) ? 'checked="checked"' : '') . '/>&nbsp;' . $lng['link_add_placing_all'] .
                '</label></div>' .
                '<div class="radio"><label><input type="radio" name="layout" value="1" ' . (isset
                ($res['layout']) && ($res['layout'] == 1) ? 'checked="checked"' :
                '') . '/>&nbsp;' . $lng['link_add_placing_front'] .
                '</label></div>' .
                '<div class="radio"><label><input type="radio" name="layout" value="2" ' . (isset
                ($res['layout']) && ($res['layout'] == 2) ? 'checked="checked"' :
                '') . '/>&nbsp;' . $lng['link_add_placing_child'] .
                '</label></div>' . '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['links_allocation'] .
                '</label>' .
                '<div class="chechbox"><label><input type="checkbox" name="bold" ' . (!
                empty($res['bold']) ? 'checked="checked"' : '') . '/>&nbsp;<b>' .
                $lng['font_bold'] . '</b></label></div>' .
                '<div class="chechbox"><label><input type="checkbox" name="italic" ' . (!
                empty($res['italic']) ? 'checked="checked"' : '') .
                '/>&nbsp;<i>' . $lng['font_italic'] . '</i></label></div>' .
                '<div class="chechbox"><label><input type="checkbox" name="underline" ' . (!
                empty($res['underline']) ? 'checked="checked"' : '') .
                '/>&nbsp;<u>' . $lng['font_underline'] . '</u></label></div>' .
                '</div>' .
                '<input class="btn btn-primary" type="submit" name="submit" value="' . ($id ?
                $lng['edit'] : $lng['add']) . '" />' . '</form>' . '<p>' .
                functions::link_back($lng['advertisement'],
                'panel/index.php/act/ads') . '</p>';
        }
        break;

    case 'down':
        if ($id)
        {
            $req = mysql_query("SELECT `mesto`, `type` FROM `cms_ads` WHERE `id` = '$id'");
            if (mysql_num_rows($req) > 0)
            {
                $res = mysql_fetch_array($req);
                $mesto = $res['mesto'];
                $req = mysql_query("SELECT * FROM `cms_ads` WHERE `mesto` > '$mesto' AND `type` = '" .
                    $res['type'] . "' ORDER BY `mesto` ASC");
                if (mysql_num_rows($req) > 0)
                {
                    $res = mysql_fetch_array($req);
                    $id2 = $res['id'];
                    $mesto2 = $res['mesto'];
                    mysql_query("UPDATE `cms_ads` SET `mesto` = '$mesto2' WHERE `id` = '$id'");
                    mysql_query("UPDATE `cms_ads` SET `mesto` = '$mesto' WHERE `id` = '$id2'");
                }
            }
        }
        header('Location: ' . getenv("HTTP_REFERER"));
        break;

    case 'up':
        if ($id)
        {
            $req = mysql_query("SELECT `mesto`, `type` FROM `cms_ads` WHERE `id` = '$id'");
            if (mysql_num_rows($req) > 0)
            {
                $res = mysql_fetch_array($req);
                $mesto = $res['mesto'];
                $req = mysql_query("SELECT * FROM `cms_ads` WHERE `mesto` < '$mesto' AND `type` = '" .
                    $res['type'] . "' ORDER BY `mesto` DESC");
                if (mysql_num_rows($req) > 0)
                {
                    $res = mysql_fetch_array($req);
                    $id2 = $res['id'];
                    $mesto2 = $res['mesto'];
                    mysql_query("UPDATE `cms_ads` SET `mesto` = '$mesto2' WHERE `id` = '$id'");
                    mysql_query("UPDATE `cms_ads` SET `mesto` = '$mesto' WHERE `id` = '$id2'");
                }
            }
        }
        header('Location: ' . getenv("HTTP_REFERER") . '');
        break;

    case 'del':
        if ($id)
        {
            if (isset($_POST['submit']))
            {
                mysql_query("DELETE FROM `cms_ads` WHERE `id` = '$id'");
                header('Location: ' . $_POST['ref']);
            }
            else
            {
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                            '/index.php'),
                    array('label' => $lng['advertisement'], 'url' =>
                            'panel/index.php/act/ads'),
                    array('label' => $lng['delete'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);

                echo '<form role="form" action="' . $set['homeurl'] .
                    '/panel/index.php/act/ads/mod/del/id/' . $id .
                    '" method="post">' . '<div class="alert alert-danger">' . $lng['link_deletion_warning'] .
                    '</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['delete'] . '</button>' .
                    ' <a class="btn btn-default" href="' . htmlspecialchars($_SERVER['HTTP_REFERER']) .
                    '">' . $lng['cancel'] . '</a></p>' .
                    '<input type="hidden" name="ref" value="' . htmlspecialchars($_SERVER['HTTP_REFERER']) .
                    '" />' . '</form>';
            }
        }
        break;

    case 'clear':
        if (isset($_POST['submit']))
        {
            mysql_query("DELETE FROM `cms_ads` WHERE `to` = '1'");
            mysql_query("OPTIMIZE TABLE `cms_ads`");
            header('location: ' . $home . '/panel/index.php/act/ads');
        }
        else
        {
            $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                        '/index.php'),
                array('label' => $lng['advertisement'], 'url' =>
                        'panel/index.php/act/ads'),
                array('label' => $lng['links_delete_hidden'])));
            echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                $breadcrumb);
            echo '<form method="post" action="' . $set['homeurl'] .
                '/panel/index.php/act/ads/mod/clear">' .
                '<div class="alert alert-warning">' . $lng['link_clear_warning'] .
                '</div>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['delete'] . '</button>' .
                ' <a data-dismiss="modal" class="btn btn-default" href="' . $set['homeurl'] .
                '/panel/index.php/act/ads">' . $lng['cancel'] . '</a></p>' .
                '</form>';
        }
        break;

    case 'show':
        if ($id)
        {
            $req = mysql_query("SELECT * FROM `cms_ads` WHERE `id` = '$id'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                mysql_query("UPDATE `cms_ads` SET `to`='" . ($res['to'] ? 0 : 1) .
                    "' WHERE `id` = '$id'");
            }
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        break;

    default:
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['advertisement']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $array_type = array(
            $lng['links_armt_over_logo'],
            $lng['links_armt_under_usermenu'],
            $lng['links_armt_over_counters'],
            $lng['links_armt_under_counters']);
        $array_placing = array(
            $lng['link_add_placing_all'],
            $lng['link_add_placing_front'],
            $lng['link_add_placing_child']);
        $array_show = array(
            $lng['to_all'],
            $lng['to_guest'],
            $lng['to_users']);
        $type = isset($_GET['type']) ? intval($_GET['type']) : 0;
        $array_menu = array(
            (!$type ? '<li class="active"><a>' . $lng['links_armt_over_logo'] .
                '</a></li>' : '<li><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ads">' . $lng['links_armt_over_logo'] .
                '</a></li>'),
            ($type == 1 ? '<li class="active"><a>' . $lng['links_armt_under_usermenu'] .
                '</a></li>' : '<li><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ads/type/1">' . $lng['links_armt_under_usermenu'] .
                '</a></li>'),
            ($type == 2 ? '<li class="active"><a>' . $lng['links_armt_over_counters'] .
                '</a></li>' : '<li><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ads/type/2">' . $lng['links_armt_over_counters'] .
                '</a></li>'),
            ($type == 3 ? '<li class="active"><a>' . $lng['links_armt_under_counters'] .
                '</a></li>' : '<li><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ads/type/3">' . $lng['links_armt_under_counters'] .
                '</a></li>'));
        echo '<div class="nav nav-tabs">' . functions::display_menu($array_menu) .
            '</div>';
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ads` WHERE `type` = '$type'"),
            0);
        if ($total)
        {
            $req = mysql_query("SELECT * FROM `cms_ads` WHERE `type` = '$type' ORDER BY `mesto` ASC LIMIT $start,$kmess");
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                $name = str_replace('|', '; ', $res['name']);
                $name = htmlentities($name, ENT_QUOTES, 'UTF-8');

                if (!empty($res['color']))
                    $name = '<span style="color:#' . $res['color'] . '">' . $name .
                        '</span>';

                $font = $res['bold'] ? 'font-weight: bold;' : false;
                $font .= $res['italic'] ? ' font-style:italic;' : false;
                $font .= $res['underline'] ? ' text-decoration:underline;' : false;
                if ($font)
                    $name = '<span style="' . $font . '">' . $name . '</span>';


                echo '<p><img src="' . $set['homeurl'] . '/images/' . ($res['to'] ?
                    'red' : 'green') .
                    '.gif" width="16" height="16" class="left"/>&#160;' .
                    '<a href="' . htmlspecialchars($res['link']) . '">' .
                    htmlspecialchars($res['link']) .
                    '</a>&nbsp;<span class="badge">' . $res['count'] .
                    '</span><br />' . $name . '</p>';
                $menu = array(
                    '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/ads/mod/up/id/' . $res['id'] .
                        '"><span class="glyphicon glyphicon-chevron-up"></span> ' .
                        $lng['up'] . '</a>',
                    '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/ads/mod/down/id/' . $res['id'] .
                        '"><span class="glyphicon glyphicon-chevron-down"></span> ' .
                        $lng['down'] . '</a>',
                    '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/ads/mod/edit/id/' . $res['id'] .
                        '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
                        '</a>',
                    '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/ads/mod/del/id/' . $res['id'] .
                        '"><span class="glyphicon glyphicon-remove"></span> ' .
                        $lng['delete'] . '</a>',
                    '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/ads/mod/show/id/' . $res['id'] .
                        '">' . ($res['to'] ?
                        '<span class="glyphicon glyphicon-eye-open"></span> ' .
                        $lng['to_show'] :
                        '<span class="glyphicon glyphicon-eye-close"></span> ' .
                        $lng['hide']) . '</a>');
                echo '<div class="sub">' . '<div>' . functions::display_menu($menu,
                    ' | ') . '</div>' . '<p><span class="gray">' . $lng['installation_date'] .
                    ':</span> ' . functions::display_date($res['time']) .
                    '<br />' . '<span class="gray">' . $lng['placing'] .
                    ':</span>&nbsp;' . $array_placing[$res['layout']] . '<br />' .
                    '<span class="gray">' . $lng['to_show'] . ':</span>&nbsp;' .
                    $array_show[$res['view']];

                $agreement = array();
                $remains = array();
                if (!empty($res['count_link']))
                {
                    $agreement[] = $res['count_link'] . ' ' . $lng['transitions_n'];
                    $remains_count = $res['count_link'] - $res['count'];
                    if ($remains_count > 0)
                        $remains[] = $remains_count . ' ' . $lng['transitions_n'];
                }
                if (!empty($res['day']))
                {
                    $agreement[] = functions::timecount($res['day'] * 86400);
                    $remains_count = $res['day'] * 86400 - (time() - $res['time']);
                    if ($remains_count > 0)
                        $remains[] = functions::timecount($remains_count);
                }

                if ($agreement)
                {
                    echo '<br /><span class="gray">' . $lng['agreement'] .
                        ':</span>&nbsp;' . implode($agreement, ', ');
                    if ($remains)
                        echo '<br /><span class="gray">' . $lng['remains'] .
                            ':</span> ' . implode($remains, ', ');
                }
                echo ($res['show'] ? '<br /><span class="red"><b>' . $lng['link_direct'] .
                    '</b></span>' : '') . '</p></div></div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess)
        {
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/panel/index.php/act/ads/type/' . $type . '/', $start, $total,
                $kmess) . '</div>';
        }
        echo '<hr/><p><a class="btn btn-primary" href="' . $set['homeurl'] .
            '/panel/index.php/act/ads/mod/edit">' . $lng['link_add'] . '</a> ' .
            '<a class="btn btn-danger" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal" href="' . $set['homeurl'] .
            '/panel/index.php/act/ads/mod/clear">' . $lng['links_delete_hidden'] .
            '</a></p>' . '<p>' . functions::link_back($lng['admin_panel'],
            'panel/') . '</p>';
}

?>
