<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['users_clean']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);

switch ($mod)
{
    case 1:
        mysql_query("DELETE FROM `users`
            WHERE `datereg` < '" . (time() - 2592000 * 6) . "'
            AND `lastdate` < '" . (time() - 2592000 * 5) . "'
            AND `postforum` = '0'
            AND `postguest` < '10'
            AND `komm` < '10'
        ");
        mysql_query("OPTIMIZE TABLE `users`");
        echo '<div class="alert alert-success"><p>' . $lng['dead_profiles_deleted'] .
            '</p><p><a class="alert-link" href="' . $set['homeurl'] .
            '/panel/index.php">' . $lng['continue'] . '</a></p></div>';
        break;

    default:
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`
            WHERE `datereg` < '" . (time() - 2592000 * 6) . "'
            AND `lastdate` < '" . (time() - 2592000 * 5) . "'
            AND `postforum` = '0'
            AND `postguest` < '10'
            AND `komm` < '10'"), 0);
        echo '<form role="form" action="' . $set['homeurl'] .
            '/panel/index.php/act/usr_clean/mod/1" method="post">' .
            '<div class="alert alert-warning"><h3>' . $lng['dead_profiles'] .
            '</h3>' . $lng['dead_profiles_desc'] .
            '<br/><p class="label label-default">' . $lng['total'] . ': <b>' . $total .
            '</b></p></div>' .
            '<p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['delete'] . '"/></p></form>' . '<p>' . functions::link_back($lng['back'],
            'panel/index.php') . '</p>';
}

?>