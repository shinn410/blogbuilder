<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}

$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['access_rights']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if (isset($_POST['submit']))
{

    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['blog']) ?
        intval($_POST['blog']) : 0) . "', `key`='mod_blog'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['reg']) ?
        intval($_POST['reg']) : 0) . "', `key`='mod_reg'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['forum']) ?
        intval($_POST['forum']) : 0) . "', `key`='mod_forum'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['guest']) ?
        intval($_POST['guest']) : 0) . "', `key`='mod_guest'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['lib']) ?
        intval($_POST['lib']) : 0) . "', `key`='mod_lib'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['gal']) ?
        intval($_POST['gal']) : 0) . "', `key`='mod_gal'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['down']) ?
        intval($_POST['down']) : 0) . "', `key`='mod_down'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . isset($_POST['libcomm']) .
        "', `key`='mod_lib_comm'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . isset($_POST['galcomm']) .
        "', `key`='mod_gal_comm'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . isset($_POST['downcomm']) .
        "', `key`='mod_down_comm'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['active']) ?
        intval($_POST['active']) : 0) . "', `key`='active'");
    mysql_query("REPLACE `cms_settings` SET `val`='" . (isset($_POST['access']) ?
        intval($_POST['access']) : 0) . "', `key`='site_access'");
    $req = mysql_query("SELECT * FROM `cms_settings`");
    $set = array();
    while ($res = mysql_fetch_row($req))
        $set[$res[0]] = $res[1];
    mysql_free_result($req);
    echo '<div class="alert alert-success">' . $lng['settings_saved'] . '</div>';
}

$color = array(
    'red',
    'yelow',
    'green',
    'gray',
    );
echo '<form role="form" method="post" action="' . $set['homeurl'] .
    '/panel/index.php/act/access">';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_forum']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['forum'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="forum" ' . ($set['mod_forum'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="forum" ' . ($set['mod_forum'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_authorised'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="3" name="forum" ' . ($set['mod_forum'] ==
    3 ? 'checked="checked"' : '') . '/>&#160;' . $lng['read_only'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="forum" ' . (!
    $set['mod_forum'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_guest']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['guestbook'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="guest" ' . ($set['mod_guest'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled_for_guests'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="guest" ' . ($set['mod_guest'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="guest" ' . (!
    $set['mod_guest'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_lib']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['library'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="lib" ' . ($set['mod_lib'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="lib" ' . ($set['mod_lib'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_authorised'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="lib" ' . (!$set['mod_lib'] ?
    'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div>' .
    '<div class="checkbox"><label><input name="libcomm" type="checkbox" value="1" ' . ($set['mod_lib_comm'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['comments'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_gal']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['gallery'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="gal" ' . ($set['mod_gal'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="gal" ' . ($set['mod_gal'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_authorised'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="gal" ' . (!$set['mod_gal'] ?
    'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div>' .
    '<div class="checkbox"><label><input name="galcomm" type="checkbox" value="1" ' . ($set['mod_gal_comm'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['comments'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_down']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['downloads'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="down" ' . ($set['mod_down'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="down" ' . ($set['mod_down'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_authorised'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="down" ' . (!
    $set['mod_down'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div>' .
    '<div class="checkbox"><label><input name="downcomm" type="checkbox" value="1" ' . ($set['mod_down_comm'] ?
    'checked="checked"' : '') . ' />&#160;' . $lng['comments'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['active'] + 1] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['community'] .
    '</h3><div class="radio"><label><input type="radio" value="1" name="active" ' . ($set['active'] ?
    'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="active" ' . (!
    $set['active'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_authorised'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_reg']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['registration'] .
    '</label><div class="radio"><label><input type="radio" value="2" name="reg" ' . ($set['mod_reg'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="reg" ' . ($set['mod_reg'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_with_moderation'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="3" name="reg" ' . ($set['mod_reg'] ==
    3 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_with_email_verification'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="reg" ' . (!$set['mod_reg'] ?
    'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div></div>';

echo '<div class="form-group"><label class="control-label"><img src="' . $set['homeurl'] .
    '/images/' . $color[$set['mod_blog']] .
    '.gif" width="16" height="16" class="left"/>&#160;Blog' .
    '</label><div class="radio"><label><input type="radio" value="2" name="blog" ' . ($set['mod_blog'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="blog" ' . ($set['mod_blog'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_with_moderation'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="blog" ' . (!
    $set['mod_blog'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_disabled'] .
    '</label></div></div>';

echo '<div class="alert alert-danger"><div class="form-group">' .
    '<label class="control-label"><img src="' . $set['homeurl'] . '/images/' . $color[$set['site_access']] .
    '.gif" width="16" height="16" class="left"/>&#160;' . $lng['site_access'] .
    '</h3><div class="radio"><label><input type="radio" value="2" name="access" ' . ($set['site_access'] ==
    2 ? 'checked="checked"' : '') . '/>&#160;' . $lng['access_enabled'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="1" name="access" ' . ($set['site_access'] ==
    1 ? 'checked="checked"' : '') . '/>&#160;' . $lng['site_closed_except_adm'] .
    '</label></div>' .
    '<div class="radio"><label><input type="radio" value="0" name="access" ' . (!
    $set['site_access'] ? 'checked="checked"' : '') . '/>&#160;' . $lng['site_closed_except_sv'] .
    '</label></div></div></div>';

echo '<div class="help-block">' . $lng['access_help'] . '</div>' .
    '<p><button class="btn btn-primary" type="submit" name="submit" id="button">' .
    $lng['save'] . '</button></p></form><p>' . functions::link_back($lng['admin_panel'],
    'panel/') . '</p>';
