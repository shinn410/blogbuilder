<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}

switch ($mod)
{
    case 'new':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['ip_ban'], 'url' =>
                    'panel/index.php/act/ipban'),
            array('label' => $lng['ban_do'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if (isset($_POST['submit']))
        {
            $error = '';
            $get_ip = isset($_POST['ip']) ? trim($_POST['ip']) : '';
            $ban_term = isset($_POST['term']) ? intval($_POST['term']) : 1;
            $ban_url = isset($_POST['url']) ? htmlentities(trim($_POST['url']),
                ENT_QUOTES, 'UTF-8') : '';
            $reason = isset($_POST['reason']) ? htmlentities(trim($_POST['reason']),
                ENT_QUOTES, 'UTF-8') : '';
            if (empty($get_ip))
            {
                echo functions::display_error($lng['error_address'], '<a href="' .
                    $set['homeurl'] . '/panel/index.php/act/ipban/mod/new">' . $lng['back'] .
                    '</a>');
                require_once ('../incfiles/end.php');
                exit;
            }
            $ip1 = 0;
            $ip2 = 0;
            $ipt1 = array();
            $ipt2 = array();
            if (strstr($get_ip, '-'))
            {

                $mode = 1;
                $array = explode('-', $get_ip);
                $get_ip = trim($array[0]);
                if (!core::ip_valid($get_ip))
                    $error[] = $lng['error_firstip'];
                else
                    $ip1 = ip2long($get_ip);
                $get_ip = trim($array[1]);
                if (!core::ip_valid($get_ip))
                    $error[] = $lng['error_secondip'];
                else
                    $ip2 = ip2long($get_ip);
            }
            elseif (strstr($get_ip, '*'))
            {

                $mode = 2;
                $array = explode('.', $get_ip);
                for ($i = 0; $i < 4; $i++)
                {
                    if (!isset($array[$i]) || $array[$i] == '*')
                    {
                        $ipt1[$i] = '0';
                        $ipt2[$i] = '255';
                    }
                    elseif (is_numeric($array[$i]) && $array[$i] >= 0 && $array[$i] <=
                        255)
                    {
                        $ipt1[$i] = $array[$i];
                        $ipt2[$i] = $array[$i];
                    }
                    else
                    {
                        $error = $lng['error_address'];
                    }
                    $ip1 = ip2long($ipt1[0] . '.' . $ipt1[1] . '.' . $ipt1[2] .
                        '.' . $ipt1[3]);
                    $ip2 = ip2long($ipt2[0] . '.' . $ipt2[1] . '.' . $ipt2[2] .
                        '.' . $ipt2[3]);
                }
            }
            else
            {

                $mode = 3;
                if (!core::ip_valid($get_ip))
                {
                    $error = $lng['error_address'];
                }
                else
                {
                    $ip1 = ip2long($get_ip);
                    $ip2 = $ip1;
                }
            }
            if (!$error)
            {

                $req = mysql_query("SELECT * FROM `cms_ban_ip` WHERE ('$ip1' BETWEEN `ip1` AND `ip2`) OR ('$ip2' BETWEEN `ip1` AND `ip2`) OR (`ip1` >= '$ip1' AND `ip2` <= '$ip2')");
                $total = @mysql_num_rows($req);
                if ($total > 0)
                {
                    echo functions::display_error($lng['ip_ban_conflict_address']);
                    $i = 0;
                    while ($res = mysql_fetch_array($req))
                    {
                        echo $i % 2 ? '<div class="list2">' :
                            '<div class="list1">';
                        $get_ip = $res['ip1'] == $res['ip2'] ? long2ip($res['ip1']) :
                            long2ip($res['ip1']) . ' - ' . long2ip($res['ip2']);
                        echo '<a href="' . $set['homeurl'] .
                            '/panel/index.php/act/ipban/mod/detail/id/' . $res['id'] .
                            '">' . $get_ip . '</a> ';
                        switch ($res['ban_type'])
                        {
                            case 2:
                                echo $lng['redirect'];
                                break;

                            case 3:
                                echo $lng['registration'];
                                break;

                            default:
                                echo '<b>' . $lng['blocking'] . '</b>';
                        }
                        echo '</div>';
                        ++$i;
                    }
                    echo
                        '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
                        $lng['total'] . ': ' . $total . '</div>';
                    echo '<p><a class="link-back pull-left" href="' . $set['homeurl'] .
                        '/panel/index.php/act/ipban/mod/new">&larr; ' . $lng['back'] .
                        '</a> <a class="link-back pull-right" href="' . $set['homeurl'] .
                        '/panel/index.php/act/ipban/mod/new">' . $lng['admin_panel'] .
                        ' &rarr;</a></p><div class="clearfix"></div>';
                    require_once ('../incfiles/end.php');
                    exit;
                }
            }

            if ((core::$ip >= $ip1 && core::$ip <= $ip2) || (core::$ip_via_proxy >=
                $ip1 && core::$ip_via_proxy <= $ip2))
                $error = $lng['ip_ban_conflict_admin'];
            if (!$error)
            {

                echo '<form role="form" action="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban/mod/insert" method="post">';
                switch ($mode)
                {
                    case 1:
                        echo '<div class="menu"><p><h3>' . $lng['ip_ban_type1'] .
                            '</h3>&nbsp;' . long2ip($ip1) . ' - ' . long2ip($ip2) .
                            '</p>';
                        break;

                    case 2:
                        echo '<div class="menu"><p><h3>' . $lng['ip_ban_type2'] .
                            '</h3>' . long2ip($ip1) . ' - ' . long2ip($ip2) .
                            '</p>';
                        break;

                    default:
                        echo '<div class="menu"><p><h3>' . $lng['ip_ban_type3'] .
                            '</h3>&nbsp;' . long2ip($ip1) . '</p>';
                }
                echo '<p><h3>' . $lng['ban_type'] . ':</h3>&nbsp;';
                switch ($ban_term)
                {
                    case 2:
                        echo $lng['redirect'] . '</p><p><h3>' . $lng['redirect_url'] .
                            ':</h3>&nbsp;' . (empty($ban_url) ? $lng['default'] :
                            $ban_url);
                        break;

                    case 3:
                        echo $lng['registration'];
                        break;

                    default:
                        echo $lng['blocking'];
                }
                echo '</p><p><h3>' . $lng['reason'] . ':</h3>&nbsp;' . (empty($reason) ?
                    $lng['not_specified'] : $reason) . '</p>' .
                    '<input type="hidden" value="' . $ip1 . '" name="ip1" />' .
                    '<input type="hidden" value="' . $ip2 . '" name="ip2" />' .
                    '<input type="hidden" value="' . $ban_term .
                    '" name="term" />' . '<input type="hidden" value="' . $ban_url .
                    '" name="url" />' . '<input type="hidden" value="' . $reason .
                    '" name="reason" />' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['ban_do'] .
                    '</button> <a class="btn btn-default" href="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban">' . $lng['cancel'] . '</a></p>' .
                    '</div><div class="help-block"><small>' . $lng['check_confirmation'] .
                    '</small></div>' . '</form>' . '<p>' . functions::link_back($lng['admin_panel'],
                    'panel/') . '</p>';
            }
            else
            {
                echo functions::display_error($error, '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban/mod/new">' . $lng['back'] .
                    '</a>');
            }
        }
        else
        {

            echo '<form role="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/new" method="post">' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['ip_address'] .
                '</label>' .
                '<input class="form-control" type="text" name="ip"/>' . '</div>' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['ban_type'] .
                '</label>' .
                '<div class="radio"><label><input name="term" type="radio" value="1" checked="checked" />' .
                $lng['blocking'] . '</label></div>' .
                '<div class="radio"><label><input name="term" type="radio" value="3" />' .
                $lng['registration'] . '</label></div>' .
                '<div class="radio"><label><input name="term" type="radio" value="2" />' .
                $lng['redirect'] . '</label></div>' . '</div>' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['redirect_url'] .
                '</label>' .
                '<input class="form-control" type="text" name="url"/>' .
                '<p class="help-block"><small>&nbsp;' . $lng['not_mandatory_field'] .
                '<br />&nbsp;' . $lng['url_help'] . '</small></p>' . '</div>' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['reason'] .
                '</label>' . '<textarea class="form-control" rows="' . core::$user_set['field_h'] .
                '" name="reason"></textarea>' .
                '<p class="help-block"><small>&nbsp;' . $lng['not_mandatory_field'] .
                '</small></p>' . '</div>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['ban_do'] . '</button> <a class="btn btn-default" href="' .
                $set['homeurl'] . '/panel/index.php/act/ipban">' . $lng['cancel'] .
                '</a></p>' . '<div class="help-block"><small>' . $lng['ip_ban_help'] .
                '</small></div>' . '</form>' . '<p>' . functions::link_back($lng['admin_panel'],
                'panel/') . '</p>';
        }
        break;

    case 'insert':
        $ip1 = isset($_POST['ip1']) ? intval($_POST['ip1']) : '';
        $ip2 = isset($_POST['ip2']) ? intval($_POST['ip2']) : '';
        $ban_term = isset($_POST['term']) ? intval($_POST['term']) : 1;
        $ban_url = isset($_POST['url']) ? functions::check($_POST['url']) : '';
        $reason = isset($_POST['reason']) ? functions::check($_POST['reason']) :
            '';
        if (!$ip1 || !$ip2)
        {
            echo functions::display_error($lng['error_address'], '<a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/new">' . $lng['back'] . '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        mysql_query("INSERT INTO `cms_ban_ip` SET
        `ip1` = '$ip1',
        `ip2` = '$ip2',
        `ban_type` = '$ban_term',
        `link` = '$ban_url',
        `who` = '$login',
        `reason` = '$reason',
        `date` = '" . time() . "'");
        header('Location: ' . core::$system_set['homeurl'] .
            '/panel/index.php/act/ipban');
        break;

    case 'clear':
        if (isset($_GET['yes']))
        {
            mysql_query("TRUNCATE TABLE `cms_ban_ip`");
            header('Location: ' . core::$system_set['homeurl'] .
                '/panel/index.php/act/ipban');
        }
        else
        {
            echo '<div class="alert alert-danger"><p>' . $lng['ip_ban_clean_warning'] .
                '</p>' . '<p><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/clear/yes/yes">' . $lng['do'] .
                '</a> | ' . '<a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban">' . $lng['cancel'] .
                '</a></p></div>';
        }
        break;

    case 'detail':
        echo '<div class="page-header"><a href="' . $set['homeurl'] .
            '/panel/index.php/act/ipban"><b>' . $lng['ip_ban'] . '</b></a> | ' .
            $lng['ban_details'] . '</div>';
        if ($id)
        {

            $req = mysql_query("SELECT * FROM `cms_ban_ip` WHERE `id` = '$id'");
            $get_ip = '';
        }
        elseif (isset($_POST['ip']))
        {

            $get_ip = ip2long($_POST['ip']);
            if (!$get_ip)
            {
                echo functions::display_error($lng['error_address'], '<a href="' .
                    $set['homeurl'] . '/panel/index.php/act/ipban/mod/new">' . $lng['back'] .
                    '</a>');
                require_once ('../incfiles/end.php');
                exit;
            }
            $req = mysql_query("SELECT * FROM `cms_ban_ip` WHERE '$get_ip' BETWEEN `ip1` AND `ip2` LIMIT 1");
        }
        else
        {
            echo functions::display_error($lng['error_address'], '<a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/new">' . $lng['back'] . '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if (!mysql_num_rows($req))
        {
            echo '<div class="menu"><p>' . $lng['ip_search_notfound'] .
                '</p></div>';
            echo '<div class="page-header"><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban">' . $lng['back'] . '</a></div>';
            require_once ('../incfiles/end.php');
            exit;
        }
        else
        {
            $res = mysql_fetch_array($req);
            $get_ip = $res['ip1'] == $res['ip2'] ? '<b>' . long2ip($res['ip1']) .
                '</b>' : '[<b>' . long2ip($res['ip1']) . '</b>] - [<b>' .
                long2ip($res['ip2']) . '</b>]';
            echo '<div class="alert alert-danger"><p>' . $get_ip . '</p></div>';
            echo '<div class="menu"><p><h3>' . $lng['ban_type'] . '</h3>&nbsp;';
            switch ($res['ban_type'])
            {
                case 2:
                    echo $lng['redirect'];
                    break;

                case 3:
                    echo $lng['registration'];
                    break;

                default:
                    echo $lng['blocking'];
            }
            if ($res['ban_type'] == 2)
                echo '<br />&nbsp;' . $res['link'];
            echo '</p><p><h3>' . $lng['reason'] . '</h3>&nbsp;' . (empty($res['reason']) ?
                $lng['not_specified'] : $res['reason']) . '</p></div>';
            echo '<div class="menu">' . $lng['ban_who'] . ': <b>' . $res['who'] .
                '</b><br />';
            echo $lng['date'] . ': <b>' . date('d.m.Y', $res['date']) .
                '</b><br />';
            echo $lng['time'] . ': <b>' . date('H:i:s', $res['date']) .
                '</b></div>';
            echo '<div class="page-header"><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/del/id/' . $res['id'] . '">' . $lng['ip_ban_del'] .
                '</a></div>';
            echo '<p><a href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban">В список</a><br />' .
                functions::link_back($lng['admin_panel'], 'panel/') . '</p>';
        }
        break;

    case 'del':
        if ($id)
        {
            if (isset($_GET['yes']))
            {
                mysql_query("DELETE FROM `cms_ban_ip` WHERE `id`='$id'");
                mysql_query("OPTIMIZE TABLE `cms_ban_ip`");
                echo '<p>' . $lng['ban_del_confirmation'] . '</p>';
                echo '<p><a href="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban">' . $lng['continue'] .
                    '</a></p>';
            }
            else
            {
                echo '<p>' . $lng['ban_del_question'] . '</p>' . '<p><a href="' .
                    $set['homeurl'] . '/panel/index.php/act/ipban/mod/del/id/' .
                    $id . '/yes/yes">' . $lng['delete'] . '</a> | ' .
                    '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban/mod/detail/id/' . $id . '">' . $lng['cancel'] .
                    '</a></p>';
            }
        }
        break;

    case 'search':
        echo '<div class="page-header"><a href="' . $set['homeurl'] .
            '/panel/index.php/act/ipban"><b>' . $lng['ip_ban'] . '</b></a> | ' .
            $lng['search'] . '</div>' . '<form role="form" action="' . $set['homeurl'] .
            '/panel/index.php/act/ipban/mod/detail" method="post"><div class="menu"><p>' .
            '<h3>' . $lng['ip_address'] . ':</h3>' .
            '<input class="form-control" type="text" name="ip"/>' .
            '</p><p><input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['search'] . '"/>' .
            '</p></div><div class="page-header"><small>' . $lng['ip_ban_search_help'] .
            '</small></div>' . '</form>' . '<p><a href="' . $set['homeurl'] .
            '/panel/index.php/act/ipban">' . $lng['back'] . '</a><br />' .
            functions::link_back($lng['admin_panel'], 'panel/') . '</p>';
        break;

    default:
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['ip_ban']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT COUNT(*) FROM `cms_ban_ip`");
        $total = mysql_result($req, 0);
        if ($total > 0)
        {
            $start = isset($_GET['page']) ? $page * $kmess - $kmess : $start;
            $req = mysql_query("SELECT * FROM `cms_ban_ip` ORDER BY `id` ASC LIMIT $start,$kmess");
            $i = 0;
            while (($res = mysql_fetch_array($req)) !== false)
            {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                $get_ip = $res['ip1'] == $res['ip2'] ? long2ip($res['ip1']) :
                    long2ip($res['ip1']) . ' - ' . long2ip($res['ip2']);
                echo '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/ipban/mod/detail/id/' . $res['id'] .
                    '">' . $get_ip . '</a> ';
                switch ($res['ban_type'])
                {
                    case 2:
                        echo $lng['redirect'];
                        break;

                    case 3:
                        echo $lng['registration'];
                        break;

                    default:
                        echo '<b>' . $lng['blocking'] . '</b>';
                }
                echo '</div>';
                ++$i;
            }
        }
        else
        {
            echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
                '</p></div>';
        }
        echo '<hr/><p><a class="btn btn-primary" href="' . $set['homeurl'] .
            '/panel/index.php/act/ipban/mod/new">' . $lng['ip_ban_new'] .
            '</a></p>';
        echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
            $lng['total'] . ': ' . $total . '</div>';
        if ($total > $kmess)
        {
            echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                '/panel/index.php/act/ipban/', $start, $total, $kmess) .
                '</div>';
        }
        if ($total > 0)
            echo '<p><a class="btn btn-default btn-sm" href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/search">' . $lng['search'] .
                '</a> <a class="btn btn-default btn-sm" href="' . $set['homeurl'] .
                '/panel/index.php/act/ipban/mod/clear">' . $lng['ip_ban_clean'] .
                '</a></p>';
        echo '<p>' . functions::link_back($lng['admin_panel'], 'panel/') .
            '</p>';
}

?>