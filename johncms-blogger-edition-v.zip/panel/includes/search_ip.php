<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');
$error = array();
$search_post = isset($_POST['search']) ? trim($_POST['search']) : false;
$search_get = isset($_GET['search']) ? rawurldecode(trim($_GET['search'])) : false;
$search = $search_post ? $search_post : $search_get;
if (isset($_GET['ip']))
    $search = trim($_GET['ip']);
$menu = array((!$mod ? '<li class="active"><a>' . $lng['ip_actual'] .
        '</a></li>' : '<li><a href="' . $set['homeurl'] .
        '/panel/index.php/act/search_ip/search/' . rawurlencode($search) . '">' .
        $lng['ip_actual'] . '</a></li>'), ($mod == 'history' ?
        '<li class="active"><a>' . $lng['ip_history'] . '</a></li>' :
        '<li><a href="' . $set['homeurl'] .
        '/panel/index.php/act/search_ip/mod/history/search/' . rawurlencode($search) .
        '">' . $lng['ip_history'] . '</a></li>'));
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['admin_panel'], 'url' => 'panel/index.php'),
    array('label' => $lng['ip_search']),
    ));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
echo '<div class="nav nav-tabs">' . functions::display_menu($menu) . '</div>' .
    '<div class="well well-sm">' .
    '<form class="form-horizontal" role="form" action="' . $set['homeurl'] .
    '/panel/index.php/act/search_ip" method="post">' .
    '<div class="input-group">' .
    '<input class="form-control" type="text" name="search" value="' . functions::checkout($search) .
    '" />' . '<span class="input-group-btn">' .
    '<button class="btn btn-primary" type="submit" name="submit">' . $lng['search'] .
    '</button>' . '</span></div></form></div>';
if ($search)
{
    if (strstr($search, '-'))
    {
        $array = explode('-', $search);
        $ip = trim($array[0]);
        if (!core::ip_valid($ip))
            $error[] = $lng['error_firstip'];
        else
            $ip1 = ip2long($ip);
        $ip = trim($array[1]);
        if (!core::ip_valid($ip))
            $error[] = $lng['error_secondip'];
        else
            $ip2 = ip2long($ip);
    }
    elseif (strstr($search, '*'))
    {
        $array = explode('.', $search);
        for ($i = 0; $i < 4; $i++)
        {
            if (!isset($array[$i]) || $array[$i] == '*')
            {
                $ipt1[$i] = '0';
                $ipt2[$i] = '255';
            }
            elseif (is_numeric($array[$i]) && $array[$i] >= 0 && $array[$i] <=
                255)
            {
                $ipt1[$i] = $array[$i];
                $ipt2[$i] = $array[$i];
            }
            else
            {
                $error = $lng['error_address'];
            }
            $ip1 = ip2long($ipt1[0] . '.' . $ipt1[1] . '.' . $ipt1[2] . '.' . $ipt1[3]);
            $ip2 = ip2long($ipt2[0] . '.' . $ipt2[1] . '.' . $ipt2[2] . '.' . $ipt2[3]);
        }
    }
    else
    {
        if (!core::ip_valid($search))
        {
            $error = $lng['error_address'];
        }
        else
        {
            $ip1 = ip2long($search);
            $ip2 = $ip1;
        }
    }
}
if ($search && !$error)
{
    echo '<h2 class="page-header">' . $lng['search_results'] . '</h2>';
    if ($mod == 'history')
        $total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `cms_users_iphistory`.`user_id`) FROM `cms_users_iphistory` WHERE `ip` BETWEEN $ip1 AND $ip2 OR `ip_via_proxy` BETWEEN $ip1 AND $ip2"),
            0);
    else
        $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `ip` BETWEEN $ip1 AND $ip2 OR `ip_via_proxy` BETWEEN $ip1 AND $ip2"),
            0);
    if ($total > $kmess)
    {
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/panel/index.php/act/search_ip' . ($mod == 'history' ?
            '/mod/history' : '') . '/search/' . urlencode($search) . '/', $start,
            $total, $kmess) . '</div>';
    }
    if ($total)
    {
        if ($mod == 'history')
        {
            $req = mysql_query("SELECT `cms_users_iphistory`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`id`, `users`.`browser`
                FROM `cms_users_iphistory` LEFT JOIN `users` ON `cms_users_iphistory`.`user_id` = `users`.`id`
                WHERE `cms_users_iphistory`.`ip` BETWEEN $ip1 AND $ip2 OR `cms_users_iphistory`.`ip_via_proxy` BETWEEN $ip1 AND $ip2
                GROUP BY `users`.`id`
                ORDER BY `ip` ASC, `name` ASC LIMIT $start, $kmess
            ");
        }
        else
        {
            $req = mysql_query("SELECT * FROM `users`
            WHERE `ip` BETWEEN $ip1 AND $ip2 OR `ip_via_proxy` BETWEEN $ip1 AND $ip2
            ORDER BY `ip` ASC, `name` ASC LIMIT $start, $kmess");
        }
        $i = 0;
        while (($res = mysql_fetch_assoc($req)) !== false)
        {
            echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
            echo functions::display_user($res, array('iphist' => 1));
            echo '</div>';
            ++$i;
        }
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['not_found'] .
            '</p></div>';
    }
    echo '<div class="list-counter"><span class="glyphicon glyphicon-stats"></span> ' .
        $lng['total'] . ': ' . $total . '</div>';
    if ($total > $kmess)
    {

        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/panel/index.php/act/search_ip' . ($mod == 'history' ?
            '/mod/history' : '') . '/search/' . urlencode($search) . '/', $start,
            $total, $kmess) . '</div>';
    }
    echo '<p>' . functions::link_back($lng['admin_panel'], 'panel/') . '</p>';
}
else
{

    if ($error)
        echo functions::display_error($error);

    echo '<div class="alert alert-info">' . $lng['search_ip_help'] . '</div>';
    echo '<p>' . functions::link_back($lng['admin_panel'], 'panel/') . '</p>';
}

?>