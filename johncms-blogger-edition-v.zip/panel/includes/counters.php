<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9)
{
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}

switch ($mod)
{
    case 'view':
        if ($id)
        {
            $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
            if (mysql_num_rows($req))
            {
                if (isset($_GET['go']) && $_GET['go'] == 'on')
                {
                    mysql_query("UPDATE `cms_counters` SET `switch` = '1' WHERE `id` = '$id'");
                    $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
                }
                elseif (isset($_GET['go']) && $_GET['go'] == 'off')
                {
                    mysql_query("UPDATE `cms_counters` SET `switch` = '0' WHERE `id` = '$id'");
                    $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
                }
                $res = mysql_fetch_array($req);
                $breadcrumb = functions::breadcrumb($breadcrumbs = array(
                    array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                            '/index.php'),
                    array('label' => $lng['counters'], 'url' =>
                            'panel/index.php/act/counters'),
                    array('label' => $lng['viewing'])));
                echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
                    $breadcrumb);
                echo '<div class="menu">' . ($res['switch'] == 1 ?
                    '<span class="green">[ON]</span>' :
                    '<span class="red">[OFF]</span>') . '&#160;<b>' . $res['name'] .
                    '</b></div>';
                echo ($res['switch'] == 1 ? '<div class="gmenu">' :
                    '<div class="alert alert-danger">') .
                    '</div><div class="form-group"><label class="control-label">' .
                    $lng['counter_mod1'] . '</h3>' . $res['link1'] . '</p>';
                echo
                    '</div><div class="form-group"><label class="control-label">' .
                    $lng['counter_mod2'] . '</h3>' . $res['link2'] . '</p>';
                echo
                    '</div><div class="form-group"><label class="control-label">' .
                    $lng['display_mode'] . '</h3>';
                switch ($res['mode'])
                {
                    case 2:
                        echo $lng['counter_help1'];
                        break;

                    case 3:
                        echo $lng['counter_help2'];
                        break;

                    default:
                        echo $lng['counter_help12'];
                }
                echo '</p></div>';
                echo '<div class="page-header">' . ($res['switch'] == 1 ?
                    '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/view/go/off/id/' . $id .
                    '">' . $lng['lng_off'] . '</a>' : '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/view/go/on/id/' . $id .
                    '">' . $lng['lng_on'] . '</a>') . ' | <a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/edit/id/' . $id . '">' .
                    $lng['edit'] . '</a> | <a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/del/id/' . $id . '">' . $lng['delete'] .
                    '</a></div>';
            }
            else
            {
                echo functions::display_error($lng['error_wrong_data']);
            }
        }
        break;

    case 'up':
        if ($id)
        {
            $req = mysql_query("SELECT `sort` FROM `cms_counters` WHERE `id` = '$id'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                $sort = $res['sort'];
                $req = mysql_query("SELECT * FROM `cms_counters` WHERE `sort` < '$sort' ORDER BY `sort` DESC LIMIT 1");
                if (mysql_num_rows($req))
                {
                    $res = mysql_fetch_assoc($req);
                    $id2 = $res['id'];
                    $sort2 = $res['sort'];
                    mysql_query("UPDATE `cms_counters` SET `sort` = '$sort2' WHERE `id` = '$id'");
                    mysql_query("UPDATE `cms_counters` SET `sort` = '$sort' WHERE `id` = '$id2'");
                }
            }
        }
        header('Location: ' . core::$system_set['homeurl'] .
            '/panel/index.php/act/counters');
        break;

    case 'down':
        if ($id)
        {
            $req = mysql_query("SELECT `sort` FROM `cms_counters` WHERE `id` = '$id'");
            if (mysql_num_rows($req))
            {
                $res = mysql_fetch_assoc($req);
                $sort = $res['sort'];
                $req = mysql_query("SELECT * FROM `cms_counters` WHERE `sort` > '$sort' ORDER BY `sort` ASC LIMIT 1");
                if (mysql_num_rows($req))
                {
                    $res = mysql_fetch_assoc($req);
                    $id2 = $res['id'];
                    $sort2 = $res['sort'];
                    mysql_query("UPDATE `cms_counters` SET `sort` = '$sort2' WHERE `id` = '$id'");
                    mysql_query("UPDATE `cms_counters` SET `sort` = '$sort' WHERE `id` = '$id2'");
                }
            }
        }
        header('Location: ' . core::$system_set['homeurl'] .
            '/panel/index.php/act/counters');
        break;

    case 'del':
        if (!$id)
        {
            echo functions::display_error($lng['error_wrong_data'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/panel/index.php/act/counters">' . $lng['back'] . '</a>');
            require ('../incfiles/end.php');
            exit;
        }
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['counters'], 'url' =>
                    'panel/index.php/act/counters'),
            array('label' => $lng['delete'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
        if (mysql_num_rows($req))
        {
            if (isset($_POST['submit']))
            {
                mysql_query("DELETE FROM `cms_counters` WHERE `id` = '$id'");
                echo '<div class="alert alert-success">' . $lng['counter_deleted'] .
                    '<br/><a class="alert-link" href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters">' . $lng['continue'] .
                    '</a></div>';
                require ('../incfiles/end.php');
                exit;
            }
            else
            {
                echo '<form role="form" action="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/del/id/' . $id .
                    '" method="post">';
                $res = mysql_fetch_array($req);
                echo '<div class="alert alert-warning">' . $res['name'] .
                    '</h3>' . $lng['delete_confirmation'] . '</div>' .
                    '<p><button class="btn btn-primary" type="submit" name="submit">' .
                    $lng['delete'] .
                    '</button> <a class="btn btn-default" href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters">' . $lng['cancel'] .
                    '</a></p>';
                echo '</form>';
            }
        }
        else
        {
            echo functions::display_error($lng['error_wrong_data'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/panel/index.php/act/counters">' . $lng['back'] . '</a>');
            require ('../incfiles/end.php');
            exit;
        }
        break;

    case 'edit':
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['counters'], 'url' =>
                    'panel/index.php/act/counters'),
            array('label' => (isset($_POST['submit']) ? $lng['preview'] : ($id ?
                    $lng['edit'] : $lng['add'])))));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        if (isset($_POST['submit']))
        {

            $name = isset($_POST['name']) ? mb_substr(trim($_POST['name']), 0,
                25) : '';
            $link1 = isset($_POST['link1']) ? trim($_POST['link1']) : '';
            $link2 = isset($_POST['link2']) ? trim($_POST['link2']) : '';
            $mode = isset($_POST['mode']) ? intval($_POST['mode']) : 1;
            if (empty($name) || empty($link1))
            {
                echo functions::display_error($lng['error_empty_fields'],
                    '<a class="alert-link" href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/edit' . ($id ? '/id/' . $id :
                    '') . '">' . $lng['back'] . '</a>');
                require ('../incfiles/end.php');
                exit;
            }
            echo '<p><h3>' . $lng['title'] . '</h3><b>' . functions::check($name) .
                '</b></p>' . '<p><h3>' . $lng['counter_mod1'] . '</h3>' . $link1 .
                '</p>' . '<p><h3>' . $lng['counter_mod2'] . '</h3>' . $link2 .
                '</p>' . '<div class="alert alert-danger">' . $lng['counter_preview_help'] .
                '</div>' . '<form role="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/counters/mod/add" method="post">' .
                '<input type="hidden" value="' . $name . '" name="name" />' .
                '<input type="hidden" value="' . htmlspecialchars($link1) .
                '" name="link1" />' . '<input type="hidden" value="' .
                htmlspecialchars($link2) . '" name="link2" />' .
                '<input type="hidden" value="' . $mode . '" name="mode" />';
            if ($id)
                echo '<input type="hidden" value="' . $id . '" name="id" />';
            echo '<p><button class="btn btn-primary" type="submit" name="submit">' .
                $lng['save'] . '</button> <a class="btn btn-default" href="' . $set['homeurl'] .
                '/panel/index.php/act/counters/mod/edit' . ($id ? '/id/' . $id :
                '') . '">' . $lng['cancel'] . '</a></p>';
            echo '</form>';
        }
        else
        {
            $name = '';
            $link1 = '';
            $link2 = '';
            $mode = 0;
            if ($id)
            {

                $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
                if (mysql_num_rows($req) > 0)
                {
                    $res = mysql_fetch_array($req);
                    $name = $res['name'];
                    $link1 = htmlspecialchars($res['link1']);
                    $link2 = htmlspecialchars($res['link2']);
                    $mode = $res['mode'];
                    $switch = 1;
                }
                else
                {
                    echo functions::display_error($lng['error_wrong_data'],
                        '<a href="' . $set['homeurl'] .
                        '/panel/index.php/act/counters">' . $lng['back'] .
                        '</a>');
                    require ('../incfiles/end.php');
                    exit;
                }
            }
            echo '<form role="form" action="' . $set['homeurl'] .
                '/panel/index.php/act/counters/mod/edit" method="post">' .
                '<div class="form-group">' . '<label class="control-label">' . $lng['title'] .
                '</label>' .
                '<input class="form-control" type="text" name="name" value="' .
                $name . '" />' . '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['counter_mod1'] .
                '</label>' .
                '<textarea class="form-control" rows="3" name="link1">' . $link1 .
                '</textarea>' . '<p class="help-block"><small>' . $lng['counter_mod1_description'] .
                '</small></p>' . '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['counter_mod2'] .
                '</label>' .
                '<textarea class="form-control" rows="3" name="link2">' . $link2 .
                '</textarea>' . '<p class="help-block"><small>' . $lng['counter_mod2_description'] .
                '</small></p>' . '</div>' . '<div class="form-group">' .
                '<label class="control-label">' . $lng['view_mode'] . '</label>' .
                '<div class="radio"><label><input type="radio" value="1" ' . ($mode ==
                0 || $mode == 1 ? 'checked="checked" ' : '') .
                'name="mode" />&#160;' . $lng['default'] . '</label></div>' .
                '<p class="help-block"><small>' . $lng['counter_mod_default_help'] .
                '</small></p>' .
                '<div class="radio"><label><input type="radio" value="2" ' . ($mode ==
                2 ? 'checked="checked" ' : '') . 'name="mode" />&#160;' . $lng['counter_mod1'] .
                '</label></div>' .
                '<div class="radio"><label><input type="radio" value="3" ' . ($mode ==
                3 ? 'checked="checked" ' : '') . 'name="mode" />&#160;' . $lng['counter_mod2'] .
                '</label></div>' . '</div>' .
                '<div class="alert alert-warning"><small>' . $lng['counter_add_help'] .
                '</small></div>';
            if ($id)
                echo '<input type="hidden" value="' . $id . '" name="id" />';
            echo '<div class="bmenu"><input class="btn btn-primary" type="submit" value="' .
                $lng['preview'] . '" name="submit" /></div>';
            echo '</form>';
        }
        break;

    case 'add':
        $name = isset($_POST['name']) ? mb_substr($_POST['name'], 0, 25) : '';
        $link1 = isset($_POST['link1']) ? $_POST['link1'] : '';
        $link2 = isset($_POST['link2']) ? $_POST['link2'] : '';
        $mode = isset($_POST['mode']) ? intval($_POST['mode']) : 1;
        if (empty($name) || empty($link1))
        {
            echo functions::display_error($lng['error_empty_fields'],
                '<a href="' . $set['homeurl'] .
                '/panel/index.php/act/counters/mod/edit' . ($id ? '/id/' . $id :
                '') . '">' . $lng['back'] . '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if ($id)
        {

            $req = mysql_query("SELECT * FROM `cms_counters` WHERE `id` = '$id'");
            if (mysql_num_rows($req) != 1)
            {
                echo functions::display_error($lng['error_wrong_data']);
                require_once ('../incfiles/end.php');
                exit;
            }
            mysql_query("UPDATE `cms_counters` SET
            `name` = '" . functions::check($name) . "',
            `link1` = '" . mysql_real_escape_string($link1) . "',
            `link2` = '" . mysql_real_escape_string($link2) . "',
            `mode` = '$mode'
            WHERE `id` = '$id'");
        }
        else
        {

            $req = mysql_query("SELECT `sort` FROM `cms_counters` ORDER BY `sort` DESC LIMIT 1");
            if (mysql_num_rows($req) > 0)
            {
                $res = mysql_fetch_array($req);
                $sort = $res['sort'] + 1;
            }
            else
            {
                $sort = 1;
            }

            mysql_query("INSERT INTO `cms_counters` SET
            `name` = '" . functions::check($name) . "',
            `sort` = '$sort',
            `link1` = '" . mysql_real_escape_string($link1) . "',
            `link2` = '" . mysql_real_escape_string($link2) . "',
            `mode` = '$mode'");
        }
        echo '<div class="alert alert-success"><p>' . ($id ? $lng['counter_edit_conf'] :
            $lng['counter_add_conf']) . '</p></div>';
        break;

    default:
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['admin_panel'], 'url' => $set['admp'] .
                    '/index.php'),
            array('label' => $lng['counters']),
            ));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
        echo '<p><a class="btn btn-primary" href="' . $set['homeurl'] .
            '/panel/index.php/act/counters/mod/edit">' . $lng['add'] .
            '</a></p>';
        $req = mysql_query("SELECT * FROM `cms_counters` ORDER BY `sort` ASC");
        if (mysql_num_rows($req))
        {
            $i = 0;
            while ($res = mysql_fetch_assoc($req))
            {
                echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
                echo '<img src="' . $set['homeurl'] . '/images/' . ($res['switch'] ==
                    1 ? 'green' : 'red') .
                    '.gif" width="16" height="16" class="left"/>&#160;';
                echo '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/view/id/' . $res['id'] .
                    '"><b>' . $res['name'] . '</b></a><br />';
                echo '<div class="sub"><a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/up/id/' . $res['id'] .
                    '"><span class="glyphicon glyphicon-chevron-up"></span> ' .
                    $lng['up'] . '</a> | ';
                echo '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/down/id/' . $res['id'] .
                    '"><span class="glyphicon glyphicon-chevron-down"></span> ' .
                    $lng['down'] . '</a> | ';
                echo '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/edit/id/' . $res['id'] .
                    '"><span class="glyphicon glyphicon-edit"></span> ' . $lng['edit'] .
                    '</a> | ';
                echo '<a href="' . $set['homeurl'] .
                    '/panel/index.php/act/counters/mod/del/id/' . $res['id'] .
                    '"><span class="glyphicon glyphicon-remove"></span> ' . $lng['delete'] .
                    '</a></div></div>';
                ++$i;
            }
        }
}
echo '<p>' . ($mod ? functions::link_back($lng['counters'],
    'panel/index.php/act/counters') : functions::link_back($lng['admin_panel'],
    'panel/')) . '</p>';

?>