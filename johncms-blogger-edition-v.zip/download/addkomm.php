<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($user_id && !isset($ban['1']) && !isset($ban['10']) && ($set['mod_down_comm'] ||
    $rights < 7))
{
    if ($_GET['id'] == "")
    {
        require_once ("../incfiles/head.php");
        echo functions::display_error($lng['not_found']);
        require_once ('../incfiles/end.php');
        exit;
    }
    if (isset($_POST['submit']))
    {

        $flood = functions::antiflood();
        if ($flood)
        {
            require_once ('../incfiles/head.php');
            echo functions::display_error('<strong>Flood!</strong><br />Silakan tunggu ' .
                $flood . ' detik lagi.', '<a href="' . $set['homeurl'] .
                '/download/index.php/act/komm/id/' . $id .
                '" class="alert-link">' . $lng['back'] . '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if ($_POST['msg'] == "")
        {
            require_once ("../incfiles/head.php");
            echo functions::display_error("Silakan masukan komentar!<br/><a href='" .
                $home . "/download/index.php/act/komm/id/" . $id .
                "' class='alert-link'>" . $lng['back'] . "</a><br/>");
            require_once ('../incfiles/end.php');
            exit;
        }
        $msg = functions::check($_POST['msg']);
        if ($_POST[msgtrans] == 1)
        {
            $msg = functions::trans($msg);
        }
        $msg = mb_substr($msg, 0, 500);
        $agn = strtok($agn, ' ');
        mysql_query("insert into `download` values(0,'$id','','" . time() .
            "','','komm','$login','" . long2ip($ip) . "','" . $agn . "','" . $msg .
            "','');");
        $fpst = $datauser['komm'] + 1;
        mysql_query("UPDATE `users` SET
		`komm`='" . $fpst . "',
		`lastpost` = '" . time() . "'
		WHERE `id`='" . $user_id . "'");
        header("Location: " . $home . "/download/index.php/act/komm/id/$id");
        exit();
    }
    else
    {
        require_once ("../incfiles/head.php");
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(
            array('label' => $lng['downloads'], 'url' =>
                    'download/index.php/act/view/file/' . $id),
            array('label' => $lng['comments'], 'url' =>
                    'download/index.php/act/komm/id/' . $id),
            array('label' => $lng['comments'])));
        echo functions::main_header($lng['write'], $breadcrumb);
        echo "<form action='" . $home . "/download/index.php/act/addkomm/id/" .
            $id . "' method='post'>" .
            "<div class='form-group'><label>Komentar (max. 500)</label>" .
            "<textarea class='form-control' rows='6' name='msg' ></textarea>" .
            "</div>" .
            "<div class='checkbox'><label><input type='checkbox' name='msgtrans' value='1' title='Translit' /> Translit</label></div>" .
            "<input class='btn btn-primary' type='submit' name='submit' value='Send' />" .
            "</form>";
        echo '<p>' . functions::display_translit() . '</p>';
    }
}
else
{
    require_once ("../incfiles/head.php");
    echo functions::display_error("Akses ditolak!");
}
echo '<p>' . functions::link_back($lng['back'], 'download/act/komm/id/' . $id) .
    '</p>';

?>