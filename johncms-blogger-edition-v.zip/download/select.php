<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ("../incfiles/head.php");
if (!empty($_GET['cat']))
{
    $cat = $_GET['cat'];
    if (provcat($cat) == false)
    {
        echo functions::display_error('Folder tidak ada!');
        require_once ('../incfiles/end.php');
        exit;
    }
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
                'url' => 'download/index.php/cat/' . $cat), array('label' => $lng_dl['upload_file'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if ($rights == 4 || $rights >= 6)
    {
        echo "<form action='" . $home .
            "/download/index.php/act/upl' method='post' enctype='multipart/form-data'>
         <div class='form-group'>
         <label class='control-label block'>" . $lng['select'] .
            " <span class='label-help'>(max " . $set['flsz'] .
            " kb.)</span></label>
         <input type='file' name='fail'/></p>
         </div>
         <div class='form-group'>
         <label class='control-label block'>" . $lng_dl['screenshot'] .
            "</label>
         <input type='file' name='screens'/></p>
         </div>
         <div class='form-group'>
         <label class='control-label block'>" . $lng['description'] . "</label>
         <textarea class='form-control' name='opis'></textarea></p>
         </div>
         <div class='form-group'>
         <label class='control-label block'>" . $lng_dl['save_as'] . "</label>
         <input class='form-control' type='text' name='newname'/></p>
         </div>
         <input type='hidden' name='cat' value='" . $cat . "'/>
         <p><input class='btn btn-primary' type='submit' value='" . $lng_dl['upload'] .
            "'/></p>
         </form>";
    }
    else
    {
        echo functions::display_error($lng['error_wrong_data']);
    }
    echo '<p>' . functions::link_back($lng['back'], 'download/index.php/cat/' .
        $cat) . '</p>';
}
else
{
    echo functions::display_error($lng['error_wrong_data']);
}

?>