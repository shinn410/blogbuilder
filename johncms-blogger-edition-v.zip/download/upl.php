<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
$formfot = isset($formfot) ? $formfot : '';
$ch1 = isset($ch1) ? $ch1 : '';
if ($rights == 4 || $rights >= 6)
{
    if (empty($_POST['cat']))
    {
        $loaddir = $loadroot;
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                    $lng['downloads'], 'url' =>
                    'download/index.php/act/view/file/' . $file), array('label' =>
                    $lng_dl['upload'])));
    }
    else
    {
        $cat = intval(trim($_POST['cat']));
        if (provcat($cat) == false)
        {
            echo functions::display_error('Folder tidak ada!');
            require_once ('../incfiles/end.php');
            exit;
        }
        $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" .
            $cat . "';");
        if (mysql_num_rows($cat1) == 0)
        {
            echo functions::display_error('Direktori tidak ada!',
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/download/index.php/">' . $lng['back'] . '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                    $lng['downloads'], 'url' => 'download/index.php/cat/' . $cat),
                array('label' => $lng_dl['upload'])));
        $adrdir = mysql_fetch_array($cat1);
        $loaddir = "$adrdir[adres]/$adrdir[name]";
    }
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    $opis = functions::check($_POST['opis']);
    $fname = isset($_FILES['fail']['name']) ? $_FILES['fail']['name'] : '';
    $fname = strtolower($fname);
    $fsize = $_FILES['fail']['size'];
    $scrname = $_FILES['screens']['name'];
    $scrsize = $_FILES['screens']['size'];
    $scsize = @GetImageSize($_FILES['screens']['tmp_name']);
    $scwidth = $scsize[0];
    $scheight = $scsize[1];
    $ftip = functions::format($fname);
    $ffot = strtolower($scrname);
    $dopras = array(
        "gif",
        "jpg",
        "png");
    if ($fname == "")
    {
        echo functions::display_error('Silakan masukan file');
    }
    else
    {
        if (empty($_POST['newname']))
        {
            $newname = str_replace(".$ftip", "", $fname);
        }
        else
        {
            $newname = functions::check($_POST['newname']);
        }
        if ($scrname != "")
        {
            $formfot = functions::format($ffot);
            if (!in_array($formfot, $dopras))
            {
                echo functions::display_error($lng_dl['screenshot_name_error'],
                    '<a class="alert-link" href="' . $set['homeurl'] .
                    '/download/index.php/act/select/cat/' . $cat . '">' . $lng['back'] .
                    '</a>');
                require_once ('../incfiles/end.php');
                exit;
            }
        }
        if ($scwidth > 320 || $scheight > 320)
        {
            echo functions::display_error($lng_dl['screenshot_size_error'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/download/index.php/act/select/cat/' . $cat . '">' . $lng['back'] .
                '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if (preg_match("/[^\da-z_\-.]+/", $scrname))
        {
            echo functions::display_error($lng_dl['screenshot_name_error'],
                '<a class="alert-link" href="' . $set['homeurl'] .
                '/download/index.php/act/select/cat/' . $cat . '">' . $lng['back'] .
                '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if ($fsize >= 1024 * $set['flsz'])
        {
            echo functions::display_error('Ukuran file melebihi batas ' . $set['flsz'] .
                ' kb.<br/><a class="alert-link" href="' . $set['homeurl'] .
                '/download/index.php/act/select/cat/' . $cat . '">' . $lng['back'] .
                '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }
        if (preg_match("/[^\da-z_\-.]+/", $fname))
        {
            echo "<div class='alert alert-danger'>File name <b>$fname</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation (. () + _-)<br /><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if (preg_match("/[^\da-z_\-.]+/", $newname))
        {
            echo "<div class='alert alert-danger'>The new file name <b>$newname</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation ( .()+_- )<br /><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if ((preg_match("/.php/i", $fname)) or (preg_match("/.pl/i", $fname)) or
            ($fname == ".htaccess") or (preg_match("/php/i", $newname)) or (preg_match
            ("/.pl/i", $newname)) or ($newname == ".htaccess"))
        {
            echo "<div class='alert alert-danger'>Trying to send a file type banned.<br/><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if ((move_uploaded_file($_FILES["screens"]["tmp_name"], "$screenroot/$newname.$ftip.$formfot")) == true)
        {
            $ch1 = "$newname.$ftip.$formfot";
            @chmod("$ch1", 0777);
            @chmod("$screenroot/$ch1", 0777);
            echo "<div class=\"alert alert-success\">Screenshot loaded!</div>";
        }
        $newname = "$newname.$ftip";
        if ((move_uploaded_file($_FILES["fail"]["tmp_name"], "$loaddir/$newname")) == true)
        {
            $ch = $newname;
            @chmod("$ch", 0777);
            @chmod("$loaddir/$ch", 0777);
            echo "<div class=\"alert alert-success\">file is loaded!</div>";
            mysql_query("insert into `download` values(0,'" . $cat . "','" . $loaddir .
                "','" . time() . "','" . $ch . "','file','','','','" . $opis .
                "','" . $ch1 . "');");
        }
        else
        {
            echo "<div class='alert alert-danger'>Error loading file</div>";
        }
    }
    if (!empty($_POST['fail1']))
    {
        $uploadedfile = $_POST['fail1'];
        if (strlen($uploadedfile) > 0)
        {
            $array = explode('file=', $uploadedfile);
            $tmp_name = $array[0];
            $filebase64 = $array[1];
        }
        $ftip = functions::format($tmp_name);
        if (empty($_POST['newname']))
        {
            $newname = str_replace(".$ftip", "", $tmp_name);
        }
        else
        {
            $newname = functions::check($_POST['newname']);
        }
        if (!empty($_POST['screens1']))
        {
            $uploaddir1 = "$screenroot";
            $uploadedfile1 = $_POST['screens1'];
            if (strlen($uploadedfile1) > 0)
            {
                $array1 = explode('file=', $uploadedfile1);
                $tmp_name1 = $array1[0];
                $filebas64 = $array1[1];
            }
            if (eregi("[^a-z0-9.()+_-]", $tmp_name1))
            {
                echo "<div class='alert alert-danger'>File name <b>$tmp_name1</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation ( .()+_- )<br /><a href='" .
                    $home . "/download/index.php/act/select/cat/" . $cat .
                    "'>Back</a></div>";
                require_once ('../incfiles/end.php');
                exit;
            }
            $ffot = strtolower($tmp_name1);
            $dopras = array(
                "gif",
                "jpg",
                "png");

            $formfot = functions::format($ffot);
            if (!in_array($formfot, $dopras))
            {
                echo
                    "<div class='alert alert-danger'>Error loading screenshot.<br/><a class='alert-link' href='" .
                    $home . "/download/index.php/act/select/cat/" . $cat . "'>" .
                    $lng['back'] . "</a></div>";
                require_once ('../incfiles/end.php');
                exit;
            }
            if (strlen($filebas64) > 0)
            {
                $FileName1 = "$uploaddir/$newname.$ftip.$formfot";
                $filedata1 = base64_decode($filebas64);
                $fid1 = @fopen($FileName1, "wb");
                if ($fid1)
                {
                    if (flock($fid1, LOCK_EX))
                    {
                        fwrite($fid1, $filedata1);
                        flock($fid1, LOCK_UN);
                    }
                    fclose($fid1);
                }
                if (file_exists($FileName1) && filesize($FileName1) == strlen($filedata1))
                {
                    $sizsf = GetImageSize("$FileName1");
                    $widthf = $sizsf[0];
                    $heightf = $sizsf[1];
                    if ($widthf > 320 || $heightf > 320)
                    {
                        echo
                            "<div class='alert alert-danger'>Image size must not exceed the resolution 320*320 px<br/><a class='alert-link' href='" .
                            $home . "/download/index.php/act/select/cat/" . $cat .
                            "'>" . $lng['back'] . "</a></div>";
                        unlink("$FileName1");
                        require_once ('../incfiles/end.php');
                        exit;
                    }
                    echo
                        '<div class="alert alert-success">Screenshot loaded!</div>';

                    $ch1 = "$newname.$ftip.$formfot";

                }
                else
                {
                    echo
                        "<div class='alert alert-danger'>Error loading screenshot</div>";
                }
            }
        }
        $uploaddir = "$loaddir";
        if (eregi("[^a-z0-9.()+_-]", $tmp_name))
        {
            echo "<div class='alert alert-danger'>File name <b>$tmp_name</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation (. () + _-)<br /><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if (eregi("[^a-z0-9.()+_-]", $newname))
        {
            echo "<div class='alert alert-danger'>The new file name <b>$newname</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation (. () + _-)<br /><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if ((preg_match("/php/i", $tmp_name)) or (preg_match("/.pl/i", $tmp_name)) or
            ($fname == ".htaccess") or (preg_match("/php/i", $newname)) or (preg_match
            ("/.pl/i", $newname)) or ($newname == ".htaccess"))
        {
            echo "<div class='alert alert-danger'>Trying to send a file type banned.<br/><a class='alert-link' href='" .
                $home . "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                "</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        if (strlen($filebase64) > 0)
        {
            $FileName = "$uploaddir/$newname.$ftip";
            $filedata = base64_decode($filebase64);
            $fid = @fopen($FileName, "wb");
            if ($fid)
            {
                if (flock($fid, LOCK_EX))
                {
                    fwrite($fid, $filedata);
                    flock($fid, LOCK_UN);
                }
                fclose($fid);
            }
            if (file_exists($FileName) && filesize($FileName) == strlen($filedata))
            {
                $siz = filesize("$FileName");
                $siz = round($siz / 1024, 2);
                if ($siz >= 1024 * $set['flsz'])
                {
                    echo "<div class='alert alert-danger'>Weight file exceeds " .
                        $set['flsz'] . " кб<br/>" .
                        "<a class='alert-link' href='" . $home .
                        "/download/index.php/act/select/cat/" . $cat . "'>" . $lng['back'] .
                        "</a></div>";
                    unlink("$FileName");
                    require_once ('../incfiles/end.php');
                    exit;
                }
                echo '<div class="alert alert-success">File is loaded</div>';

                $ch = "$newname.$ftip";
                mysql_query("insert into `download` values(0,'" . $cat . "','" .
                    $loaddir . "','" . time() . "','" . $ch .
                    "','file','','','','" . $opis . "','" . $ch1 . "');");
            }
            else
            {
                echo
                    '<div class="alert alert-danger">Error Uploading file</div>';
            }
        }
    }
}
else
{
    echo functions::display_error('Akses dilarang!');
}
echo '<p>' . functions::link_back($lng['back'], 'download/index.php/cat/' . $cat) .
    '</p>';

?>