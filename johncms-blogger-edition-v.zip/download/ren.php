<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ("../incfiles/head.php");
if ($rights == 4 || $rights >= 6)
{
    $cat = isset($_GET['cat']) ? intval(trim($_GET['cat'])) : '';
    if (provcat($cat) == false)
    {
        echo functions::display_error('Folder tidak ada!');
        require_once ('../incfiles/end.php');
        exit;
    }
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
                'url' => 'download/index.php/cat/' . $cat), array('label' => $lng_dl['rename_folder'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" .
        $cat . "';");
    $adrdir = mysql_fetch_array($cat1);
    $namedir = "$adrdir[adres]/$adrdir[name]";
    if (isset($_POST['submit']))
    {
        if (!empty($_POST['newrus']))
        {
            $newrus = functions::check($_POST['newrus']);
        }
        else
        {
            $newrus = "$adrdir[text]";
        }
        if (mysql_query("update `download` set text='" . $newrus .
            "' where id='" . $cat . "';"))
        {
            echo '<div class="alert alert-success">' . $lng_dl['name_changed'] .
                '</div>';
        }
    }
    else
    {
        echo "<form action='" . $home . "/download/index.php/act/ren/cat/" . $cat .
            "' method='post'>";
        echo "<div class='form-group'>" . "<label class='control-label block'>" .
            $lng_dl['folder_name_for_list'] . "</label>" .
            "<input class='form-control' type='text' name='newrus' value='" . $adrdir['text'] .
            "'/>" . "</div>";
        echo "<p><input class='btn btn-primary' type='submit' name='submit' value='" .
            $lng_dl['change'] . "'/></p></form>";
    }
}
echo '<p>' . functions::link_back($lng['back'], 'download/index.php/cat/' . $cat) .
    '</p>';

?>