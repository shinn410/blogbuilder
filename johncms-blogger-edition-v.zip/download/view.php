<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");

$im = array();
$delimag = opendir("$filesroot/graftemp");
while ($imd = readdir($delimag))
{
    if ($imd != "." && $imd != ".." && $imd != "index.php")
    {
        $im[] = $imd;
    }
}
closedir($delimag);
$totalim = count($im);
for ($imi = 0; $imi < $totalim; $imi++)
{
    $filtime[$imi] = filemtime("$filesroot/graftemp/$im[$imi]");
    $tim = time();
    $ftime1 = $tim - 10;
    if ($filtime[$imi] < $ftime1)
    {
        @unlink("$filesroot/graftemp/$im[$imi]");
    }
}
if ($_GET['file'] == '')
{
    echo functions::display_error($lng_dl['file_not_selected'], '<a href="' . $set['homeurl'] .
        '/download/index.php">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}
$file = intval(trim($_GET['file']));
$file1 = mysql_query("select * from `download` where type = 'file' and id = '" .
    $file . "';");
$file2 = mysql_num_rows($file1);
$adrfile = mysql_fetch_array($file1);
if (($file1 == 0) || (!is_file("$adrfile[adres]/$adrfile[name]")))
{
    echo functions::display_error($lng_dl['file_select_error'], '<a href="' . $set['homeurl'] .
        '/download/index.php">' . $lng['back'] . '</a>');
    require_once ('../incfiles/end.php');
    exit;
}
$_SESSION['downl'] = rand(1000, 9999);
$siz = filesize("$adrfile[adres]/$adrfile[name]");
$siz = round($siz / 1024, 2);
$filtime = filemtime("$adrfile[adres]/$adrfile[name]");
$filtime = date("d.m.Y", $filtime);

$dnam = mysql_query("select * from `download` where type = 'cat' and id = '" . $adrfile['refid'] .
    "';");
$dnam1 = mysql_fetch_array($dnam);
$dirname = "$dnam1[text]";
$dirid = "$dnam1[id]";
$nadir = $adrfile['refid'];
$breadcrumbs = array();

$breadcrumbs[] = '<li class="active">' . $adrfile['name'] . '</li>';
while ($nadir != "" && $nadir != "0")
{
    $breadcrumbs[] = '<li><a href="' . $set['homeurl'] .
        '/download/index.php/cat/' . $nadir . '">' . $dirname . '</a></li>';
    $dnamm = mysql_query("select * from `download` where type = 'cat' and id = '" .
        $nadir . "';");
    $dnamm1 = mysql_fetch_array($dnamm);
    $dnamm2 = mysql_query("select * from `download` where type = 'cat' and id = '" .
        $dnamm1['refid'] . "';");
    $dnamm3 = mysql_fetch_array($dnamm2);
    $nadir = $dnamm1['refid'];
    $dirname = $dnamm3['text'];
}
$breadcrumbs[] = '<li><a href="' . $set['homeurl'] . '/download/index.php">' . $lng['downloads'] .
    '</a></li>';
$brcm = '<ol class="breadcrumb">';
$i = count($breadcrumbs);
while ($i--)
    $brcm .= $breadcrumbs[$i];
$brcm .= '</ol>';
echo functions::main_header($adrfile['name'], functions::breadcrumb(array(
    array('label' => $lng['download'], 'url' => '/download'),
    array('label' => $adrfile['name']),
    )));
echo $brcm;
echo '<div class="box box-solid"><div class="box-body"><div class="row"><div class="col-sm-6">';
echo '<p><b>' . $lng_dl['file'] . ': <span class="red">' . $adrfile['name'] .
    '</span></b><br/>' . '<b>' . $lng_dl['uploaded'] . ':</b> ' . $filtime .
    '</p>';
$graf = array(
    "gif",
    "jpg",
    "png");
$prg = strtolower(functions::format($adrfile['name']));
if (in_array($prg, $graf))
{
    $sizsf = GetImageSize("$adrfile[adres]/$adrfile[name]");
    $widthf = $sizsf[0];
    $heightf = $sizsf[1];

    $namefile = $adrfile['name'];
    $infile = "$adrfile[adres]/$namefile";
    if (!empty($_SESSION['razm']))
    {
        $razm = $_SESSION['razm'];
    }
    else
    {
        $razm = 110;
    }
    $sizs = GetImageSize($infile);
    $width = $sizs[0];
    $height = $sizs[1];
    $quality = 100;
    $x_ratio = $razm / $width;
    $y_ratio = $razm / $height;
    if (($width <= $razm) && ($height <= $razm))
    {
        $tn_width = $width;
        $tn_height = $height;
    }
    else
        if (($x_ratio * $height) < $razm)
        {
            $tn_height = ceil($x_ratio * $height);
            $tn_width = $razm;
        }
        else
        {
            $tn_width = ceil($y_ratio * $width);
            $tn_height = $razm;
        }
        switch ($prg)
        {
            case "gif":
                $im = ImageCreateFromGIF($infile);
                break;

            case "jpg":
                $im = ImageCreateFromJPEG($infile);
                break;

            case "jpeg":
                $im = ImageCreateFromJPEG($infile);
                break;

            case "png":
                $im = ImageCreateFromPNG($infile);
                break;
        }
    $im1 = ImageCreateTrueColor($tn_width, $tn_height);
    imagecopyresized($im1, $im, 0, 0, 0, 0, $tn_width, $tn_height, $width, $height);
    $path = "$filesroot/graftemp";
    $imagnam = "$path/$namefile.temp.png";
    imageJpeg($im1, $imagnam, $quality);
    echo '<p><img class="thumbnail" src="' . $home . '/' . substr($imagnam, 3) .
        '" alt=""/></p>';
    imagedestroy($im);
    imagedestroy($im1);
    @chmod("$imagnam", 0644);
    echo '<p>' . $widthf . ' x ' . $heightf . 'px</p>';
}

if ($prg == "mp3")
{
    $id3 = new MP3_Id();
    $result = $id3->read("$adrfile[adres]/$adrfile[name]");
    $result = $id3->study();
    echo '<p>';
    if (!empty($id3->artists))
        echo '<div><b>' . $lng_dl['artist'] . ':</b> ' . $id3->artists .
            '</div>';
    if (!empty($id3->album))
        echo '<div><b>' . $lng_dl['album'] . ':</b> ' . $id3->album . '</div>';
    if (!empty($id3->year))
        echo '<div><b>' . $lng_dl['released'] . ':</b> ' . $id3->year . '</div>';
    if (!empty($id3->name))
        echo '<div><b>' . $lng['title'] . ':</b> ' . $id3->name . '</div>';
    echo '</p>';
    if ($id3->getTag('bitrate'))
    {
        echo '<b>' . $lng_dl['bitrate'] . ':</b> ' . $id3->getTag('bitrate') .
            ' kBit/sec<br/>' . '<b>' . $lng_dl['duration'] . ':</b> ' . $id3->getTag('length') .
            '<br/>';
    }
}
if (!empty($adrfile['text']))
{
    echo "<p>Description:<br/>$adrfile[text]</p>";
}

if ((!in_array($prg, $graf)) && ($prg != "mp3"))
{
    if (!empty($adrfile['screen']))
    {
        $infile = "$screenroot/$adrfile[screen]";
        if (!empty($_SESSION['razm']))
        {
            $razm = $_SESSION['razm'];
        }
        else
        {
            $razm = 110;
        }
        $sizs = GetImageSize($infile);
        $width = $sizs[0];
        $height = $sizs[1];
        $quality = 100;
        $angle = 0;
        $fontsiz = 20;
        $tekst = $set['copyright'];
        $x_ratio = $razm / $width;
        $y_ratio = $razm / $height;
        if (($width <= $razm) && ($height <= $razm))
        {
            $tn_width = $width;
            $tn_height = $height;
        }
        else
            if (($x_ratio * $height) < $razm)
            {
                $tn_height = ceil($x_ratio * $height);
                $tn_width = $razm;
            }
            else
            {
                $tn_width = ceil($y_ratio * $width);
                $tn_height = $razm;
            }
            $format = functions::format($infile);
        switch ($format)
        {
            case "gif":
                $im = ImageCreateFromGIF($infile);
                break;

            case "jpg":
                $im = ImageCreateFromJPEG($infile);
                break;

            case "jpeg":
                $im = ImageCreateFromJPEG($infile);
                break;

            case "png":
                $im = ImageCreateFromPNG($infile);
                break;
        }
        $color = imagecolorallocate($im, 55, 255, 255);
        $fontdir = opendir("$filesroot/fonts");
        while ($ttf = readdir($fontdir))
        {
            if ($ttf != "." && $ttf != ".." && $ttf != "index.php")
            {
                $arr[] = $ttf;
            }
        }
        $it = count($arr);
        $ii = rand(0, $it - 1);
        $fontus = "$filesroot/fonts/$arr[$ii]";
        $font_size = ceil(($width + $height) / 15);
        @imagettftext($im, $font_size, $angle, '10', $height - 10, $color, $fontus,
            $tekst);
        $im1 = imagecreatetruecolor($tn_width, $tn_height);
        $namefile = "$adrfile[name]";
        imagecopyresized($im1, $im, 0, 0, 0, 0, $tn_width, $tn_height, $width, $height);
        $path = "$filesroot/graftemp";
        switch ($format)
        {
            case "gif":
                $imagnam = "$path/$namefile.temp.gif";
                ImageGif($im1, $imagnam, $quality);
                echo "<p><img src='" . substr($imagnam, 3) . "' alt=''/></p>";
                break;

            case "jpg":
                $imagnam = "$path/$namefile.temp.jpg";
                imageJpeg($im1, $imagnam, $quality);
                echo "<p><img src='" . $home . "/" . substr($imagnam, 3) .
                    "' alt=''/></p>";
                break;

            case "jpeg":
                $imagnam = "$path/$namefile.temp.jpg";
                imageJpeg($im1, $imagnam, $quality);
                echo "<p><img src='" . $home . "/" . substr($imagnam, 3) .
                    "' alt=''/></p>";

                break;

            case "png":
                $imagnam = "$path/$namefile.temp.png";
                imagePng($im1, $imagnam, $quality);
                echo "<p><img src='" . $home . "/" . substr($imagnam, 3) .
                    "' alt=''/></p>";
                break;
        }
        imagedestroy($im);
        imagedestroy($im1);
    }
}

$dl_count = !empty($adrfile['ip']) ? intval($adrfile['ip']) : 0;
echo '<p><a class="btn btn-danger" href="' . $set['homeurl'] .
    '/download/index.php/act/down/id/' . $file .
    '"><span class="glyphicon glyphicon-floppy-save"></span> ' . $lng['download'] .
    '</a></p></div><div class="col-sm-4"><p><i class="fa fa-square"></i> ' . $lng_dl['size'] .
    ': <small><b>' . $siz . '</b> kB</small></p>';
if ($prg == "zip")
{
    echo "<p><a href='" . $home . "/download/index.php/act/zip/file/" . $file .
        "'><i class=\"fa fa-archive\"></i> Open Archive</a></p>";
}
echo '<p><span class="glyphicon glyphicon-floppy-saved"></span> ' . $lng_dl['downloads'] .
    ': <small><span class="badge">' . $dl_count . '</span></small></p>';
if ($set['mod_down_comm'] || $rights >= 7)
{
    $totalkomm = mysql_result(mysql_query("SELECT COUNT(*) FROM `download` WHERE `type` = 'komm' AND `refid` = '$file'"),
        0);
    echo '<p><a href="' . $set['homeurl'] . '/download/index.php/act/komm/id/' .
        $file . '"><span class="glyphicon glyphicon-comment"></span> ' . $lng['comments'] .
        '</a> <small><span class="badge">' . $totalkomm . '</span></small></p>';
}
if (!empty($adrfile['soft']))
{
    $rating = explode(",", $adrfile['soft']);
    $rat = $rating[0] / $rating[1];
    $rat = round($rat, 2);
    echo '<p><span class="glyphicon glyphicon-star"></span> ' . $lng_dl['average_rating'] .
        ': <small><span class="badge">' . $rat . '</span></small></p>' .
        '<p><span class="glyphicon glyphicon-stats"></span> ' . $lng_dl['vote_count'] .
        ': <small><span class="badge">' . $rating[1] . '</span></small></p>';
}

echo '<p><form class="form-horizontal" role="form" action="' . $set['homeurl'] .
    '/download/index.php/act/rat/id/' . $file . '" method="post">' .
    '<div class="input-group col-xs-2 col-md-3">' .
    '<select class="form-control" name="rat">';
for ($i = 10; $i >= 1; --$i)
{
    echo "<option>$i</option>";
}
echo '</select>' . '<span class="input-group-btn"><input class="btn btn-primary" type="submit" value="' .
    $lng_dl['rate'] . '"/></span></div></form></p>';

echo '</div></div></div></div>';
if (($rights == 4 || $rights >= 6) && (!empty($_GET['file'])))
{
    echo '<ul class="nav nav-pills">';
    if ((!in_array($prg, $graf)) && ($prg != "mp3"))
    {
        echo '<li><a href="' . $set['homeurl'] .
            '/download/index.php/act/screen/file/' . $file .
            '"><i class="fa fa-edit"></i> ' . $lng_dl['change_screenshot'] .
            '</a></li>';
    }
    echo '<li><a href="' . $set['homeurl'] .
        '/download/index.php/act/opis/file/' . $file .
        '"><i class="fa fa-edit"></i> ' . $lng_dl['change_description'] .
        '</a></li>';
    echo '<li><a href="' . $set['homeurl'] .
        '/download/index.php/act/dfile/file/' . $file .
        '"><i class="fa fa-times"></i> ' . $lng_dl['delete_file'] . '</a></li>';
    echo '</ul>';
}
