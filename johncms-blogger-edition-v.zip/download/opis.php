<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
if ($rights == 4 || $rights >= 6)
{
    if ($_GET['file'] == "")
    {
        echo functions::display_error($lng_dl['file_not_selected'] .
            '<br/><a class="alert-link" href="' . $set['homeurl'] .
            '/download/">' . $lng['back'] . '</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    $file = intval($_GET['file']);
    $file1 = mysql_query("SELECT * FROM `download` WHERE `type` = 'file' AND `id` = '" .
        $file . "';");
    $file2 = mysql_num_rows($file1);
    $adrfile = mysql_fetch_array($file1);
    if (($file1 == 0) || (!is_file("$adrfile[adres]/$adrfile[name]")))
    {
        echo functions::display_error($lng_dl['file_not_selected'] .
            '<br/><a class="alert-link" href="' . $set['homeurl'] .
            '/download/">' . $lng['back'] . '</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    $stt = "$adrfile[text]";
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['downloads'],
                'url' => 'download/index.php/act/view/file/' . $file), array('label' =>
                $lng_dl['change_description'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if (isset($_POST['submit']))
    {
        $newt = functions::check($_POST['newt']);
        mysql_query("update `download` set `text`='" . $newt . "' where `id`='" .
            $file . "';");
        echo '<div class="alert alert-success">' . $lng_dl['description_changed'] .
            '</div>';
    }
    else
    {
        $str = str_replace("<br/>", "\r\n", $adrfile['text']);
        echo "<form action='" . $home . "/download/index.php/act/opis/file/" . $file .
            "' method='post'>";
        echo '<div class="form-group">' .
            '<label class="control-label dis-block">' . $lng['description'] .
            '</label>' . '<textarea class="form-control" rows="4" name="newt">' .
            $str . '</textarea>' . '</div>';
        echo "<input class='btn btn-primary' type='submit' name='submit' value='" .
            $lng['save'] . "'/>" . "</form>";
    }
}
else
{
    echo functions::display_error('Akses dilarang!');
}
echo '<p>' . functions::link_back($lng['back'],
    'download/index.php/act/view/file/' . $file) . '</p>';
