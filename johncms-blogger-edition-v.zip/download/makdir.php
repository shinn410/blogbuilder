<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
            'url' => '/download/'), array('label' => $lng_dl['make_folder'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
$cat = isset($_GET['cat']) ? intval($_GET['cat']) : false;
if ($rights == 4 || $rights >= 6)
{
    if (isset($_POST['submit']))
    {
        if (empty($cat))
        {
            $droot = $loadroot;
        }
        else
        {
            $cat = intval(trim($cat));
            if (provcat($cat) == false)
            {
                echo functions::display_error('Folder tidak ada!');
                require_once ('../incfiles/end.php');
                exit;
            }
            $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" .
                $cat . "';");
            $adrdir = mysql_fetch_array($cat1);
            $droot = "$adrdir[adres]/$adrdir[name]";
        }
        $drn = functions::check($_POST['drn']);
        $rusn = functions::check($_POST['rusn']);
        $mk = @mkdir("$droot/$drn", 0777);
        if ($mk == true)
        {
            chmod("$droot/$drn", 0777);
            echo '<div class="alert alert-success"><p>Folder created</p></div>';
            mysql_query("insert into `download` values(0,'" . $cat . "','" . $droot .
                "','" . time() . "','" . $drn . "','cat','','','','" . $rusn .
                "','');");
            $categ = mysql_query("select * from `download` where type = 'cat' and name='$drn' and refid = '" .
                $cat . "';");
            $newcat = mysql_fetch_array($categ);
            echo '<p>' . functions::link_back('To Folder &rarr;',
                'download/index.php/cat/' . $newcat['id'], false) . '</p>';
        }
        else
        {
            echo '<div class="alert alert-danger">ERROR</div>';
        }
    }
    else
    {
        echo "<form role='form' ction='download/index.php/act/makdir/cat/" . $cat .
            "' method='post'>
         <div class='form-group'>
         <label class='control-label block'>" . $lng_dl['folder_name'] .
            "</label>
         <input class='form-control' type='text' name='drn'/>
         </div>
         <div class='form-group'>
         <label class='control-label block'>" . $lng_dl['folder_name_for_list'] .
            "</label>
         <input class='form-control' type='text' name='rusn'/>
         </div>
         <p><input class='btn btn-primary' type='submit' name='submit' value='" .
            $lng_dl['make_folder'] . "'/></p>
         </form>";
    }
}
echo '<p>' . functions::link_back($lng['back'], 'download/index.php') . '</p>';

?>