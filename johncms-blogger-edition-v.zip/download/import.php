<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
if ($rights >= 6)
{
    if (empty($_GET['cat']))
    {
        $loaddir = $loadroot;
    }
    else
    {
        $cat = intval($_GET['cat']);
        if (provcat($cat) == false)
        {
            echo functions::display_error('Folder tidak ada!');
            require_once ('../incfiles/end.php');
            exit;
        }
        $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" .
            $cat . "';");
        $adrdir = mysql_fetch_array($cat1);
        $loaddir = "$adrdir[adres]/$adrdir[name]";
    }
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
                'url' => 'download/index.php/cat/' . $cat), array('label' => $lng_dl['import_file'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if (isset($_POST['submit']))
    {
        $url = trim($_POST['url']);
        $opis = functions::check($_POST['opis']);
        $newn = functions::check($_POST['newn']);
        $tipf = functions::format($url);
        if (eregi("[^a-z0-9.()+_-]", $newn))
        {
            echo "<div class='alert alert-danger'>The new file name <b>$newn</b> contains invalid characters <br/> allowed only alphanumeric characters and some punctuation (. () + _-)<br /><a class='alert-link' href='" .
                $home . "/download/index.php/act/import/cat/" . $cat .
                "'>Back</a></div>";
            require_once ('../incfiles/end.php');
            exit;
        }
        $import = "$loaddir/$newn.$tipf";
        $files = file_exists("$import");
        if (!$files)
        {
            if (copy($url, $import))
            {
                $ch = "$newn.$tipf";
                echo
                    "<div class='alert alert-success'>File successfully downloaded</div>";
                mysql_query("insert into `download` values(0,'$cat','" .
                    mysql_real_escape_string($loaddir) . "','" . time() . "','" .
                    mysql_real_escape_string($ch) . "','file','','','','" . $opis .
                    "','');");
            }
            else
            {
                echo
                    "<div class='alert alert-danger'>File download failed!</div>";
            }
        }
        else
        {
            echo "<div class='alert alert-danger'>Error, file with the same name already exists in the directory</div>";
        }
    }
    else
    {
        echo "<form action='" . $home . "/download/index.php/act/import/cat/" .
            $cat . "' method='post'>";
        echo "<div class='form-group'>
            <label class='control-label'>Enter the URL</label>
            <input class='form-control' type='text' name='url' value='http://'/>
            </div>
            <div class='form-group'>
            <label class='control-label'>Description</label>
            <textarea class='form-control' name='opis'></textarea>
            </div>
            <div class='form-group'>
            <label class='control-label'>Save as <span class='label-help'>(without extension)</span></label>
            <input class='form-control' type='text' name='newn'/>
            </div>";
        echo "<p><input class='btn btn-primary' type='submit' name='submit' value='Import'/></p>
            </form>";
    }
}
else
{
    echo functions::display_error('Akses dilarang!');
}
echo '<p>' . functions::link_back($lng['back'], 'download/index.php/cat/' . $cat) .
    '</p>';
