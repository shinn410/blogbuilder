<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ("../incfiles/head.php");
if ($rights == 4 || $rights >= 6)
{
    if ($_GET['file'] == "")
    {
        echo functions::display_error($lng_dl['file_not_selected'] .
            '<br/><a class="alert-link" href="' . $set['homeurl'] .
            '/download/">' . $lng['back'] . '</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    $file = intval(trim($_GET['file']));
    $file1 = mysql_query("select * from `download` where type = 'file' and id = '" .
        $file . "';");
    $file2 = mysql_num_rows($file1);
    $adrfile = mysql_fetch_array($file1);
    if (($file1 == 0) || (!is_file("$adrfile[adres]/$adrfile[name]")))
    {
        echo functions::display_error($lng_dl['file_not_selected'] .
            '<br/><a class="alert-link" href="' . $set['homeurl'] .
            '/download/">' . $lng['back'] . '</a>');
        require_once ('../incfiles/end.php');
        exit;
    }
    $refd = mysql_query("select * from `download` where type = 'cat' and id = '" .
        $adrfile['refid'] . "'");
    $refd1 = mysql_fetch_array($refd);
    $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['downloads'],
                'url' => 'download/index.php/act/view/file/' . $file), array('label' =>
                $lng_dl['delete_file'])));
    echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
        $breadcrumb);
    if (isset($_POST['submit']))
    {
        unlink($adrfile['adres'] . '/' . $adrfile['name']);
        mysql_query("delete from `download` where id='" . $adrfile['id'] .
            "' LIMIT 1;");
        echo '<div class="alert alert-success">' . $lng_dl['file_deleted'] .
            '.<br/><a class="alert-link" href="' . $set['homeurl'] .
            '/download/index.php/cat/' . $refd1['id'] . '">' . $lng['continue'] .
            ' &rarr;</a></div>';
    }
    else
    {
        echo '<form role="form" action="' . $set['homeurl'] .
            '/download/index.php/act/dfile/file/' . $file . '" method="post">' .
            '<div class="alert alert-warning">' . $lng['delete_confirmation'] .
            '</div>' . '<p>' .
            '<input class="btn btn-primary" type="submit" name="submit" value="' .
            $lng['delete'] . '" />' . ' <a class="btn btn-default" href="' . $set['homeurl'] .
            '/download/index.php/act/view/file/' . $file . '">' . $lng['cancel'] .
            '</a>' . '</p>' . '</form>';
        echo '<p>' . functions::link_back($lng['back'],
            'download/index.php/act/view/file/' . $file) . '</p>';
    }
}
