<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
$headmod = 'load';
require_once ('../incfiles/core.php');
$lng_dl = core::load_lng('downloads');
require_once ('../incfiles/lib/mp3.php');
require_once ('../incfiles/lib/pclzip.lib.php');
$textl = $lng['downloads'];
$filesroot = '../download';
$screenroot = "$filesroot/screen";
$loadroot = "$filesroot/files";

$error = '';
if (!$set['mod_down'] && $rights < 7)
    $error = $lng_dl['downloads_closed'];
elseif ($set['mod_down'] == 1 && !$user_id)
    $error = $lng['access_guest_forbidden'];
if ($error)
{
    require_once ('../incfiles/head.php');
    echo '<div class="alert alert-danger"><p>' . $error . '</p></div>';
    require_once ("../incfiles/end.php");
    exit;
}

function provcat($catalog)
{
    $cat1 = mysql_query("select * from `download` where type = 'cat' and id = '" .
        abs(intval($catalog)) . "';");
    $cat2 = mysql_num_rows($cat1);
    if ($cat2 == 0)
        return false;
    $adrdir = mysql_fetch_array($cat1);
    if (!is_dir($adrdir['adres'] . '/' . $adrdir['name']))
        return false;
    return $adrdir;
}
$main_header = 1;
$array = array(
    'scan_dir',
    'rat',
    'delmes',
    'search',
    'addkomm',
    'komm',
    'new',
    'zip',
    'arc',
    'down',
    'dfile',
    'opis',
    'screen',
    'ren',
    'import',
    'refresh',
    'upl',
    'view',
    'makdir',
    'select',
    'preview',
    'delcat',
    'mp3',
    );
if (in_array($act, $array))
{
    require_once ($act . '.php');
}
else
{
    require_once ('../incfiles/head.php');
    if (!$set['mod_down'])
        echo '<div class="alert alert-warning">' . $lng_dl['downloads_closed'] .
            '</div>';

    $new_file_btn = '<li><a href="' . $set['homeurl'] .
        '/download/index.php/act/new"><i class="fa fa-flash"></i> ' . $lng['new_files'] .
        ' <span class="badge">' . mysql_result(mysql_query("SELECT COUNT(*) FROM `download` WHERE `time` > '" .
        (time() - 259200) . "' AND `type` = 'file'"), 0) . '</span></a></li>';
    $cat = isset($_GET['cat']) ? intval($_GET['cat']) : '';
    if (empty($_GET['cat']))
    {

        $breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' =>
                    $lng['download'])));
        echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'],
            $breadcrumb);
    }
    else
    {

        $req = mysql_query("SELECT * FROM `download` WHERE `type` = 'cat' AND `id` = '" .
            $cat . "' LIMIT 1");
        $res = mysql_fetch_array($req);
        if (mysql_num_rows($req) == 0 || !is_dir($res['adres'] . '/' . $res['name']))
        {

            echo functions::display_error($lng_dl['folder_does_not_exist'],
                '<a href="' . $set['homeurl'] . '/download/index.php">' . $lng['back'] .
                '</a>');
            require_once ('../incfiles/end.php');
            exit;
        }


        $tree = array();
        $dirid = $cat;
        while ($dirid != '0' && $dirid != "")
        {
            $req = mysql_query("SELECT * FROM `download` WHERE `type` = 'cat' and `id` = '" .
                $dirid . "' LIMIT 1");
            $res = mysql_fetch_array($req);
            $tree[] = '<li><a href="' . $set['homeurl'] .
                '/download/index.php/cat/' . $dirid . '">' . $res['text'] .
                '</a></li>';
            $dirid = $res['refid'];
        }
        krsort($tree);
        $cdir = array_pop($tree);
        $breadcrumb = '<ol class="breadcrumb"><li><a href="' . $set['homeurl'] .
            '/download/index.php">' . $lng['downloads'] . '</b></a></li>';
        foreach ($tree as $value)
        {
            $breadcrumb .= $value;
        }
        $breadcrumb .= '<li class="active">' . strip_tags($cdir) . '</li>' .
            '</ol>';
        echo functions::main_header(strip_tags($cdir), functions::breadcrumb($breadcrumbs =
            array(array('label' => $lng['download']))));
        echo $breadcrumb;
    }

    if (empty($cat))
    {
        echo '<div class="row"><div class="col-sm-6 pull-right margin">' .
            '<form role="form" action="' . $set['homeurl'] .
            '/download/index.php/act/search" method="post">' .
            '<div class="input-group">' .
            '<input class="form-control" type="text" name="srh" size="20" maxlength="20" value=""/>' .
            '<span class="input-group-btn">' .
            '<button class="btn btn-primary" type="submit">' . $lng['search'] .
            '</button>' . '</span>' . '</div>' . '</form>' . '</div></div>';
    }
    $req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `refid` = '$cat' AND `type` = 'cat'");
    $totalcat = mysql_result($req, 0);

    $req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `refid` = '$cat' AND `type` = 'file'");
    $totalfile = mysql_result($req, 0);
    $total = $totalcat + $totalfile;
    if ($total > 0)
    {
        $zap = mysql_query("SELECT * FROM `download` WHERE `refid` = '$cat' ORDER BY `type` ASC, `text` ASC, `name` ASC LIMIT " .
            $start . "," . $kmess);
        echo '<div class="list-group">';
        while ($zap2 = mysql_fetch_array($zap))
        {
            if ($totalcat > 0 && $zap2['type'] == 'cat')
            {

                $g1 = 0;

                $req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `type` = 'file' AND `adres` LIKE '" .
                    ($zap2['adres'] . '/' . $zap2['name']) . "%'");
                $g = mysql_result($req, 0);

                $req = mysql_query("SELECT COUNT(*) FROM `download` WHERE `type` = 'file' AND `adres` LIKE '" .
                    ($zap2['adres'] . '/' . $zap2['name']) . "%' AND `time` > '" .
                    (time() - 259200) . "'");
                $g1 = mysql_result($req, 0);
                echo '<a class="list-group-item" href="' . $set['homeurl'] .
                    '/download/index.php/cat/' . $zap2['id'] .
                    '"><span class="glyphicon glyphicon-folder-open"></span>&nbsp;&nbsp;' .
                    $zap2['text'] . ' <span class="badge">' . $g . ($g1 != 0 ?
                    '/<span class="red">+' . $g1 . '</span>' : '') .
                    '</span></a>';
            }
            elseif ($totalfile > 0 && $zap2['type'] == 'file')
            {

                $ft = functions::format($zap2['name']);
                switch ($ft)
                {
                    case "mp3":
                        $imt = "mp3.png";
                        break;

                    case "zip":
                        $imt = "rar.png";
                        break;

                    case "jar":
                        $imt = "jar.png";
                        break;

                    case "gif":
                        $imt = "gif.png";
                        break;

                    case "jpg":
                        $imt = "jpg.png";
                        break;

                    case "png":
                        $imt = "png.png";
                        break;
                    default:
                        $imt = "file.gif";
                        break;
                }
                if ($zap2['text'] != "")
                {

                    $tx = $zap2['text'];
                    if (mb_strlen($tx) > 100)
                    {
                        $tx = mb_substr(strip_tags($tx), 0, 90);
                        $tx .= '...';
                    }

                }
                echo '<a class="list-group-item' . (isset($tx) ?
                    '" data-toggle="popover" title="' . htmlentities($zap2['name'],
                    ENT_QUOTES, 'UTF-8') . '" data-content="' . functions::checkout
                    ($tx) . '' : '') . '" href="' . $set['homeurl'] .
                    '/download/index.php/act/view/file/' . $zap2['id'] .
                    '"><img src="' . $set['homeurl'] . '/download/img/' . $imt .
                    '" alt=""/>&nbsp;&nbsp;' . htmlentities($zap2['name'],
                    ENT_QUOTES, 'UTF-8') . '</a>';

            }
        }
        echo '</div>';
    }
    else
    {
        echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
            '</p></div>';
    }

    if ($total > $kmess)
    {
        echo '<p>' . functions::display_pagination($set['homeurl'] .
            '/download/index.php/cat/' . $cat . '/', $start, $total, $kmess) .
            '</p>';
    }
    echo '<hr/><ul class="nav nav-pills">';
    if (isset($new_file_btn))
        echo $new_file_btn;
    if ($rights == 4 || $rights >= 6)
    {


        echo '<li><a href="' . $set['homeurl'] .
            '/download/index.php/act/makdir/cat/' . $cat .
            '"><i class="fa fa-plus"></i> ' . $lng_dl['make_folder'] .
            '</a></li>';
        if (!empty($_GET['cat']))
        {
            $delcat = mysql_query("select * from `download` where type = 'cat' and refid = '" .
                $cat . "';");
            $delcat1 = mysql_num_rows($delcat);
            if ($delcat1 == 0)
            {
                echo '<li><a href="' . $set['homeurl'] .
                    '/download/index.php/act/delcat/cat/' . $cat .
                    '"><i class="fa fa-times"></i> ' . $lng_dl['delete_folder'] .
                    '</a></li>';
            }
            echo '<li><a href="' . $set['homeurl'] .
                '/download/index.php/act/ren/cat/' . $cat .
                '"><i class="fa fa-pencil"></i> ' . $lng_dl['rename_folder'] .
                '</a></li>';
            echo '<li><a href="' . $set['homeurl'] .
                '/download/index.php/act/select/cat/' . $cat .
                '"><i class="fa fa-upload"></i> ' . $lng_dl['upload_file'] .
                '</a></li>';
            if ($rights >= 6)
                echo '<li><a href="' . $set['homeurl'] .
                    '/download/index.php/act/import/cat/' . $cat .
                    '"><i class="fa fa-exchange"></i> ' . $lng_dl['import_file'] .
                    '</a></li>';
        }
        echo '<li><a href="' . $set['homeurl'] .
            '/download/index.php/act/refresh"><i class="fa fa-refresh"></i> ' .
            $lng_dl['refresh_downloads'] . '</a></li>';
    }
    echo '<li><a href="' . $set['homeurl'] .
        '/download/index.php/act/preview"><i class="fa fa-crop"></i> ' . $lng_dl['images_size'] .
        '</a></li>';
    echo '</ul>';
}

require_once ('../incfiles/end.php');

?>