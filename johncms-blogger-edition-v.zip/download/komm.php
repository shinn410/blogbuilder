<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
if ($_GET['id'] == "")
{
    echo functions::display_error('ERROR<br/><a class="alert-link" href="' . $set['homeurl'] .
        '/download">Back</a>');
    require_once ('../incfiles/end.php');
    exit;
}
if (!$set['mod_down_comm'] && $rights < 7)
{
    echo functions::display_error('ERROR<br/><a class="alert-link" href="' . $set['homeurl'] .
        '/download">Back</a>');
    require_once ('../incfiles/end.php');
    exit;
}
$i = !isset($i) ? 0 : $i;
$mess = mysql_query("select * from `download` where type='komm' and refid='" . $id .
    "' order by time DESC LIMIT " . $start . "," . $kmess);
$total = mysql_num_rows($mess);
$fayl = mysql_query("select * from `download` where type='file' and id='" . $id .
    "';");
$fayl1 = mysql_fetch_array($fayl);
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['downloads'],
            'url' => 'download/index.php/act/view/file/' . $id), array('label' =>
            $lng['comments'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
echo '<ul class="nav nav-tabs"><li><a href="' . $set['homeurl'] .
    '/download/index.php/act/view/file/' . $id . '">' . $fayl1['name'] .
    '</a></li><li class="active"><a>' . $lng['comments'] . '</a></li></ul>';
if ($user_id && !isset($ban['1']) && !isset($ban['10']))
{
    echo "<p class='margin'><a class='btn btn-default btn-sm' data-toggle='modal' data-target='#global-modal' href='" .
        $home . "/download/index.php/act/addkomm/id/" . $id . "'><span class=\"glyphicon glyphicon-pencil\"></span> Add Comment</a></p>";
}

while ($mass = mysql_fetch_array($mess))
{
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    $uz = @mysql_query("select * from `users` where name='" . functions::check($mass['avtor']) .
        "';");
    $mass1 = @mysql_fetch_array($uz);
    $text = functions::checkout($mass['text'], 1, 1);
    if ($set_user['smileys'])
        $text = functions::smileys($text, $res['rights'] ? 1 : 0);
    if ($rights == 4 || $rights >= 6)
    {
        $subtext = "<a href='" . $home . "/download/index.php/act/delmes/id/" .
            $mass['id'] . "'><span class=\"glyphicon glyphicon-remove\"></span> " .
            $lng['delete'] . "</a><br/>";
    }
    else
        $subtext = '';
    $arg = array(
        'header' => '(' . functions::display_date($mass['time']) . ')',
        'body' => $text,
        'sub' => $subtext);
    echo functions::display_user($mass1, $arg);
    echo '</div>';
    ++$i;
}
if ($total > $kmess)
{
    echo '<p>' . functions::display_pagination($set['homeurl'] .
        '/download/index.php/act/komm/id/' . $id . '/', $start, $total, $kmess) .
        '</p>';
}
echo '<p>' . functions::link_back($lng['back'],
    'download/index.php/act/view/file/' . $id) . '</p>';

?>