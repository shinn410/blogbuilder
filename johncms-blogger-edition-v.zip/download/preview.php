<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
            'url' => 'download/index.php/'), array('label' => $lng_dl['images_size'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if (isset($_POST['submit']))
{
    if (!empty($_POST['razmer']))
    {
        $razmer = intval($_POST['razmer']);
    }
    $_SESSION['razm'] = $razmer;
    echo '<div class="alert alert-success">' . $lng_dl['preview_size_set'] . ' ' .
        $razmer * $razmer . ' px</div>';
}
else
{
    echo "<form role=\"form\" action='" . $home .
        "/download/index.php/act/preview' method='post'>
	<div class='form-group'>
	<label class='control-label block'>" . $lng_dl['select_preview_size'] .
        "</label>
	<div class=\"input-group\">
	<select class='form-control' name='razmer'>";
    if (!empty($_SESSION['razm']))
    {
        $realr = $_SESSION['razm'];
        echo "<option value='" . $realr . "'>" . $realr . "*" . $realr .
            "</option>";
    }
    echo "<option value='32'>32*32</option>
<option value='50'>50*50</option>
<option value='64'>64*64</option>
<option value='80'>80*80</option>
<option value='100'>100*100</option>
<option value='120'>120*120</option>
<option value='160'>160*160</option>
<option value='200'>200*200</option>
</select><span class=\"input-group-btn\"><button class='btn btn-primary' type='submit' name='submit'>Ok</button></span></div></div></form>";
}
echo '<p>' . functions::link_back($lng['back'], 'download/index.php/') . '</p>';
