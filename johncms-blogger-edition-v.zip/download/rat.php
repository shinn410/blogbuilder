<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require_once ("../incfiles/head.php");
$breadcrumb = functions::breadcrumb($breadcrumbs = array(array('label' => $lng['download'],
            'url' => 'download/index.php/'), array('label' => $lng_dl['images_size'])));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
if ($_GET['id'] == "")
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$id = intval(trim($_GET['id']));
$typ = mysql_query("select * from `download` where id='" . $id . "';");
if (mysql_num_rows($typ) == 0)
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$ms = mysql_fetch_array($typ);
if ($ms['type'] != "file")
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
if (isset($_SESSION['rat']) == $id)
{
    echo '<div class="alert alert-danger">' . $lng_dl['already_rated'] .
        '<br/><a class="alert-link" href="' . $set['homeurl'] .
        '/download/index.php/act/view/file/' . $id . '">' . $lng['back'] .
        '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$rat = intval(functions::check($_POST['rat']));
if (!empty($ms['soft']))
{
    $rt = explode(",", $ms[soft]);
    $rt1 = $rt[0] + $rat;
    $rt2 = $rt[1] + 1;
    $rat1 = "$rt1,$rt2";
}
else
{
    $rat1 = "$rat,1";
}
$_SESSION['rat'] = $id;
mysql_query("update `download` set soft = '" . $rat1 . "' where id = '" . $id .
    "';");
echo '<div class="alert alert-success">' . $lng_dl['vote_adopted'] .
    '<br/><a class="alert-link" href="' . $set['homeurl'] .
    '/download/index.php/act/view/file/' . $id . '">' . $lng['back'] .
    '</a></div>';

?>