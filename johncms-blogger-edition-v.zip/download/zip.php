<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

require_once ("../incfiles/head.php");

$delarc = opendir("$filesroot/arctemp");
$mp = array();
while ($zp = readdir($delarc))
{
    if ($zp != "." && $zp != ".." && $zp != "index.php")
    {
        $mp[] = $zp;
    }
}
closedir($delarc);
$totalmp = count($mp);
for ($imp = 0; $imp < $totalmp; $imp++)
{
    $filtime[$imp] = filemtime("$filesroot/arctemp/$mp[$imp]");
    $tim = time();
    $ftime1 = $tim - 300;
    if ($filtime[$imp] < $ftime1)
    {
        @unlink("$filesroot/arctemp/$mp[$imp]");
    }
}
if ($_GET['file'] == "")
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$file = intval(trim($_GET['file']));
$file1 = mysql_query("select * from `download` where type = 'file' and id = '" .
    $file . "';");
$file2 = mysql_num_rows($file1);
if ($file1 == 0)
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$adrfile = mysql_fetch_array($file1);
if (!is_file($adrfile['adres'] . '/' . $adrfile['name']))
{
    echo '<div class="alert alert-danger">ERROR<br/><a class="alert-link" href="' .
        $set['homeurl'] . '/download/index.php">' . $lng['back'] . '</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$breadcrumb = functions::breadcrumb($breadcrumbs = array(
    array('label' => $lng['download'], 'url' => 'download/index.php/'),
    array('label' => htmlentities($adrfile['name'], ENT_QUOTES, 'UTF-8'), 'url' =>
            'download/index.php/act/view/file/' . $file),
    array('label' => 'Open Archive')));
echo functions::main_header($breadcrumbs[count($breadcrumbs) - 1]['label'], $breadcrumb);
$zip = new PclZip("$adrfile[adres]/$adrfile[name]");

if (($list = $zip->listContent()) == 0)
{
    die("Error: " . $zip->errorInfo(true));
}
$sizelist = false;
$savelist = false;
for ($i = 0; $i < sizeof($list); $i++)
{
    for (reset($list[$i]); $key = key($list[$i]); next($list[$i]))
    {
        $listcontent = "[$i]--$key:" . $list[$i][$key] . "";
        $zfilesize = strstr($listcontent, "--size");
        $zfilesize = ereg_replace("--size:", "", $zfilesize);
        $zfilesize = @ereg_replace("$zfilesize", "$zfilesize|", $zfilesize);
        $sizelist .= $zfilesize;

        $zfile = strstr($listcontent, "--filename");
        $zfile = ereg_replace("--filename:", "", $zfile);
        $zfile = @ereg_replace("$zfile", "$zfile|", $zfile);
        $savelist .= "$zfile";
    }
}
$sizefiles2 = explode("|", $sizelist);
$sizelist2 = array_sum($sizefiles2);
$obkb = round($sizelist2 / 1024, 2);

$preview = "$savelist";
$preview = explode("|", $preview);

$count = count($preview) - 1;
echo "<div class='alert alert-info'>" . (isset($arch) ? '<strong>' . $arch .
    '</strong><br/>' : '') . "Total Files: $count <br/> Berat membongkar arsip: $obkb kb<br/>Anda dapat mendownload file individual dari arsip</div>";

if ($count < $start + 10)
{
    $end = $count;
}
else
{
    $end = $start + 10;
}
$no = 0;
for ($i = $start; $i < $end; $i++)
{
    echo $no % 2 ? '<div class="list2">' : '<div class="list1">';
    $sizefiles = explode("|", $sizelist);
    $selectfile = explode("|", $savelist);
    $path = $selectfile[$i];
    $fname = ereg_replace(".*[\\/]", "", $path);
    $zdir = ereg_replace("[\\/]?[^\\/]*$", "", $path);
    $tfl = strtolower(functions::format($fname));
    $df = array(
        "asp",
        "aspx",
        "shtml",
        "htd",
        "php",
        "php3",
        "php4",
        "php5",
        "phtml",
        "htt",
        "cfm",
        "tpl",
        "dtd",
        "hta",
        "pl",
        "js",
        "jsp");
    if (in_array($tfl, $df))
    {
        echo "$zdir/$fname";
    }
    else
    {
        echo $zdir . '/<a href="' . $set['homeurl'] .
            '/download/index.php/act/arc/file/' . $file . '/f/' . $i . '/start/' .
            $start . '">' . $fname . '</a>';
    }
    if ($sizefiles[$i] != "0")
    {
        $sizekb = round($sizefiles[$i] / 1024, 2);
        echo " ($sizekb кб)";
    }

    echo '</div>';
    ++$no;
}
if ($count > $kmess)
{
    echo '<p>' . functions::display_pagination($set['homeurl'] .
        '/download/index.php/act/zip/file/' . $file . '/', $start, $count, $kmess) .
        '</p>';
}
echo '<p>' . functions::link_back($lng['back'],
    'download/index.php/act/view/file/' . $file) . '</p>';
