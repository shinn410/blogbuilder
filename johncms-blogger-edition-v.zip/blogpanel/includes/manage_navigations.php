<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$show_html = '';
$c = 0;
$textl = "Kelola Navigasi";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
if (file_exists(ROOTPATH . 'sites/' . $blog['url'] . '/navigations.dat'))
    $navigations = file_get_contents(ROOTPATH . 'sites/' . $blog['url'] .
        '/navigations.dat');
else
    $navigations = '';
if (empty($navigations))
{
    $show_html .= '<div class="alert alert-danger">' . $lng['list_empty'] .
        '</div>';
}
else
{
    if (!isset($_SESSION['key']))
        $_SESSION['key'] = md5(time());
    $key = $_SESSION['key'];

    if (strpos($navigations, "^") === false)
    {
        if (isset($_GET['delete']) and isset($_GET['key']) and $_GET['key'] == $key and
            $_GET['delete'] == "ALL")
        {
            unset($_SESSION['key']);
            if (file_exists(ROOTPATH . 'sites/' . $blog['url'] .
                '/navigations.dat'))
                unlink(ROOTPATH . 'sites/' . $blog['url'] . '/navigations.dat');
            header('location: ' . $home .
                '/blogpanel/index.php/act/manage_navigations');
            exit;
        }
        elseif (isset($_GET['edit']) and $_GET['edit'] == "ALL")
        {
            if (isset($_POST[$key]))
            {
                unset($_SESSION['key']);
                $code = $_POST['code'];
                if ((mb_strlen($code) < 2) || (mb_strlen($code) > 5000))
                {
                    $key = $_SESSION['key'] = md5(time());
                    $show_html .=
                        '<div class="alert alert-danger"><p>Kode minimal 2 dan maksimal 5000 karakter.</p></div>';
                }
                else
                {
                    $newcode = str_replace("^", "", $code);
                    @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                        '/navigations.dat', $newcode);
                    header('location: ' . $home .
                        '/blogpanel/index.php/act/manage_navigations');
                    exit;
                }
            }
            $show_html .=
                '<div class="box box-default"><div class="box-body"><form method="post" action="' .
                $set['homeurl'] .
                '/blogpanel/index.php/act/manage_navigations/edit/ALL">' .
                '<div class="form-group"><label>Kode</label>' .
                '<textarea class="form-control" rows="' . $set_user['field_h'] .
                '" name="code">' . htmlentities($navigations) .
                '</textarea></div><p><input class="btn btn-primary" type="submit" name="' .
                $key . '" value="Simpan"/> <a class="btn btn-default" href="' .
                $set['homeurl'] .
                '/blogpanel/index.php/act/manage_navigations">Batal</a></p></form></div></div>';
        }
        else
        {
            $show_html .= $c % 2 ? '<div class="list2">' : '<div class="list1">';
            $show_html .= functions::smileys($navigations) .
                '<div class="sub"><a href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/manage_navigations/edit/ALL">' .
                '<i class="fa fa-edit"></i> Edit</a> | <a href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/manage_navigations/delete/ALL/key/' .
                $key . '" onclick="return confirm(\'Kamu yakin akan menghapus navigasi ini?\')"><i class="fa fa-times"></i> Hapus</a></div></div>';
            $c++;
        }
    }
    else
    {
        $nav = explode("^", $navigations);
        $nav_totals = count($nav);
        for ($i = 0; $i < $nav_totals; $i++)
        {
            if (isset($_GET['down']) and isset($_GET['key']) and $_GET['key'] ==
                $key and ctype_digit($_GET['down']) and $_GET['down'] == $i and
                $i >= 0 and $i < $nav_totals)
            {
                unset($_SESSION['key']);
                $u = $i + 1;
                $nav2 = explode("^", $navigations);
                for ($n = 0; $n < count($nav2); $n++)
                {

                    if ($n == $u)
                    {
                        $navigs[] = $nav[$i];
                    }
                    else
                    {
                        if ($n == $i)
                        {
                            $navigs[] = $nav[$u];
                        }
                        else
                        {
                            $navigs[] = $nav2[$n];
                        }
                    }

                }
                $newcode = implode("^", $navigs);
                @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                    '/navigations.dat', $newcode);

                header('location: ' . $home .
                    '/blogpanel/index.php/act/manage_navigations');
                exit;
            }
            elseif (isset($_GET['up']) and isset($_GET['key']) and $_GET['key'] ==
                $key and ctype_digit($_GET['up']) and $_GET['up'] == $i and $i >
                0 and $i <= $nav_totals)
            {
                unset($_SESSION['key']);
                $u = $i - 1;
                $nav2 = explode("^", $navigations);
                for ($n = 0; $n < count($nav2); $n++)
                {

                    if ($n == $u)
                    {
                        $navigs[] = $nav[$i];
                    }
                    else
                    {
                        if ($n == $i)
                        {
                            $navigs[] = $nav[$u];
                        }
                        else
                        {
                            $navigs[] = $nav2[$n];
                        }
                    }

                }
                $newcode = implode("^", $navigs);
                @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                    '/navigations.dat', $newcode);
                header('location: ' . $home .
                    '/blogpanel/index.php/act/manage_navigations');
                exit;
            }
            elseif (isset($_GET['delete']) and isset($_GET['key']) and $_GET['key'] ==
                $key and ctype_digit($_GET['delete']) and $_GET['delete'] == $i)
            {
                $nav2 = explode("^", $navigations);
                for ($n = 0; $n < count($nav2); $n++)
                {
                    if ($n == $i)
                        continue;
                    $newcodes[] = $nav2[$n];
                }
                if (is_array($newcodes))
                    $newcode = implode("^", $newcodes);
                else
                    $newcode = $newcode;
                @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                    '/navigations.dat', $newcode);

                header('location: ' . $home .
                    '/blogpanel/index.php/act/manage_navigations');
                exit();
            }
            elseif (isset($_GET['edit']) and ctype_digit($_GET['edit']) and $_GET['edit'] ==
                $i)
            {
                if (isset($_POST[$key]))
                {
                    unset($_SESSION['key']);
                    $code = $_POST['code'];
                    if (mb_strlen($code) < 2 or mb_strlen($code) > 5000)
                    {
                        $key = $_SESSION['key'] = md5(time());
                        $show_html .=
                            '<div class="alert alert-danger"><p>Kode minimal 2 dan maksimal 5000 karakter.</p></div>';
                    }
                    else
                    {
                        $nav2 = explode("^", $navigations);
                        for ($n = 0; $n < count($nav2); $n++)
                        {
                            if ($n == $i)
                            {
                                $newcodes[] = str_replace("^", "", $code);
                            }
                            else
                            {
                                $newcodes[] = $nav2[$n];
                            }
                        }
                        $newcode = implode("^", $newcodes);
                        @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                            '/navigations.dat', $newcode);

                        header('location: ' . $home .
                            '/blogpanel/index.php/act/manage_navigations');
                        exit;
                    }
                }
                $show_html .=
                    '<div class="box box-default"><div class="box-body">' .
                    '<form method="post" action="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations/edit/' . $i .
                    '"><div class="form-group"><label>Kode</label><textarea class="form-control" rows="' .
                    $set_user['field_h'] . '" name="code">' . htmlentities($nav[$i]) .
                    '</textarea></div><p><input class="btn btn-primary" type="submit" name="' .
                    $key .
                    '" value="Simpan"/> <a class="btn btn-default" href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations">Batal</a></p></form></div></div>';
            }
            else
            {
                $show_html .= $c % 2 ? '<div class="list2">' :
                    '<div class="list1">';
                $show_html .= functions::smileys($nav[$i]) . '<div class="sub">' . ($i >
                    0 ? '<a href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations/up/' . $i .
                    '/key/' . $key .
                    '"><i class="fa fa-arrow-up"></i> Naik</a> | ' : '') . ($i <
                    ($nav_totals - 1) ? '<a href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations/down/' . $i .
                    '/key/' . $key .
                    '"><i class="fa fa-arrow-down"></i> Turun</a> | ' : '') .
                    '<a href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations/edit/' . $i .
                    '/key/' . $key .
                    '"><i class="fa fa-edit"></i> Edit</a> | <a href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/manage_navigations/delete/' . $i .
                    '/key/' . $key . '" onclick="return confirm(\'Kamu yakin akan menghapus navigasi ini?\')"><i class="fa fa-times"></i> Hapus</a></div></div>';
                $c++;
            }
        }
    }
}
require (dirname(__file__) . '/../../incfiles/head.php');
if (isset($_SESSION['notice']))
{
    echo '<div class="alert alert-info">' . htmlentities($_SESSION['notice']) .
        '</div>';
    unset($_SESSION['notice']);
}
if (!$is_ajax && !$is_modal)
{
    echo '<p><a class="func" data-toggle="' . functions::set_modal() .
        '" data-target="#create_navigation" href="' . $home .
        '/blogpanel/index.php/act/create_navigation"><i class="fa fa-plus"></i> Membuat Navigasi</a></p>';
}
echo $show_html;
echo functions::modal('', array('id' => 'create_navigation', 'title' =>
        'Membuat Navigasi'));
require (dirname(__file__) . '/../../incfiles/end.php');
