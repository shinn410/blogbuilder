<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$category = isset($_GET['category']) ? trim($_GET['category']) : false;
$tag = isset($_GET['tag']) ? trim($_GET['tag']) : false;
$textl = "Kelola Posting";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<p><a class="func" href="' . $home .
    '/blogpanel/index.php/act/write_post"><i class="fa fa-pencil"></i> Tulis posting</a>&nbsp;' .
    '<a class="func" href="' . $home .
    '/blogpanel/index.php/act/upload_post"><i class="fa fa-upload"></i> Upload posting</a></p>';
if (isset($_SESSION['notice']))
{
    echo '<div class="alert alert-info">' . htmlentities($_SESSION['notice']) .
        '</div>';
    unset($_SESSION['notice']);
}

if ($category)
{
    $req = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `permalink`='" .
        mysql_real_escape_string($category) . "'");
    if (mysql_num_rows($req) != 1)
    {
        echo '<div class="alert alert-danger">Kategori tidak ada!<br /><a class="alert-link" href="' .
            $home . '/blogpanel/index.php/act/manage_posts">Kembali</a></div>';
    }
    else
    {
        $cat = mysql_fetch_array($req);
        echo '<div class="alert alert-info">Menampilkan posting pada kategori <i><b>' .
            htmlspecialchars($cat['name']) .
            '</b></i><br /><a class="alert-link" href="' . $home .
            '/blogpanel/index.php/act/manage_posts">Kembali</a></div>';
    }
}
if ($category)
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
        "' AND `category`='" . mysql_real_escape_string($category) . "'"), 0);
}
elseif ($tag)
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
        "' AND `tags` LIKE '%" . mysql_real_escape_string(functions::search_db($tag)) .
        "%'"), 0);

    echo '<div class="alert alert-info">Menampilkan posting dengan tag <i><b>' .
        htmlspecialchars(str_replace('-', ' ', $tag)) .
        '</b></i><br /><a class="alert-link" href="' . $home .
        '/blogpanel/index.php/act/manage_posts">Kembali</a></div>';
}
else
{
    $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
        "'"), 0);
}
if ($total == 0)
{
    echo '<div class="alert alert-warning"><p>Tidak ada posting.</p></div>';
}
else
{
    if ($category)
    {
        $blg = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
            "' AND `category`='" . mysql_real_escape_string($category) .
            "' ORDER BY `time` DESC LIMIT $start,$kmess");
        $link = 'category/' . htmlentities($category);
    }
    elseif ($tag)
    {
        $blg = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
            "' AND `tags` LIKE '%" . mysql_real_escape_string(functions::search_db
            ($tag)) . "%' ORDER BY `time` DESC LIMIT $start,$kmess");
        $link = 'tag/' . htmlentities($tag);
    }
    else
    {
        $blg = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
            "' ORDER BY `time` DESC LIMIT $start,$kmess");
        $link = '';
    }
    while ($post = mysql_fetch_array($blg))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        echo '<h4>' . ($post['time'] > time() ? htmlspecialchars($post['title']) :
            '<a href="' . $home . '/login.php?redirect=' . urlencode('http://' . $blog['url'] .
            '/' . $post['permalink'] . '.html') . '">' . htmlspecialchars($post['title']) .
            '</a>') . '</h4><div class="sub"><div>' . ($post['time'] > time() ?
            '<a class="func" href="' . $home . '/login.php?redirect=' . urlencode('http://' .
            $blog['url'] . '/' . $post['permalink'] . '.html') .
            '"><i class="fa fa-eye"></i> Preview</a>&nbsp;' : '') .
            '<a class="func" href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/edit_post/post_id/' . $post['id'] .
            '"><i class="fa fa-edit"></i> Edit</a>&nbsp;<a class="func" data-toggle="' .
            functions::set_modal() . '" data-target="#delete_post" href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' . $post['id'] .
            '"><i class="fa fa-times"></i> Hapus</a></div>';
        $ktp = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `blog_categories` WHERE `site_id`='" .
            $post['site_id'] . "' AND `user_id`='" . $blog['user_id'] .
            "' AND `permalink`='" . mysql_real_escape_string($post['category']) .
            "'"));
        echo '<ul><li>Kategori  : <a href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/manage_posts/category/' . $post['category'] .
            '">' . htmlspecialchars($ktp['name']) . '</a></li>' . '<li>Tags  : ' .
            functions::get_tags($post['tags'], '<a href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/manage_posts/tag/{TAG_LINK}">{TAG_NAME}</a>') .
            '</a></li>';
        echo '<li>' . ($post['time'] > time() ? 'Konsep' : 'Diterbitkan') .
            '  : ' . functions::display_date($post['time']) . '</li>';
        $ts = ($set['timeshift'] * 3600) + time();
        if ($post['hits_today_date'] != date("d-m-Y", $ts))
            $hitoday = 0;
        else
            $hitoday = $post['hits_today'];
        echo '<li>Komentar  : ' . $post['comments'] .
            '</li><li>Hits hari ini  : ' . $hitoday . '</li><li>Hits total  : ' .
            $post['hits_total'];
        echo '</li></ul></div></div>';
        ++$i;
    }
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($home .
            '/blogpanel/index.php/act/manage_posts/' . $link, $start, $total, $kmess) .
            '</div>';
    echo functions::modal('', array('id' => 'delete_post', 'title' =>
            'Hapus Posting'));
}
require (dirname(__file__) . '/../../incfiles/end.php');
