<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
$domains = unserialize($set['blogdomains']);
if (($set['mod_blog'] == 1) && $rights < 7)
    $mod_reg = 'yes';
else
    $mod_reg = 'no';

if (count($domains) == 0) {
    $textl = "Buat Blog";
    require (dirname(__file__) . '/../../incfiles/head.php');
    echo functions::display_error("Saat ini belum tersedia.");
    require (dirname(__file__) . '/../../incfiles/end.php');
    exit();
}

$bc = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `user_id`='$user_id'"),
    0);
if ($bc >= $set['blogmax']) {
    $textl = "Membuat Blog";
    require (dirname(__file__) . '/../../incfiles/head.php');
    echo functions::display_error("Anda sudah tidak bisa lagi membuat blog baru. " .
        "Maksimal blog per user adalah " . $set['blogmax'] . " blog.");
    require (dirname(__file__) . '/../../incfiles/end.php');
    exit;
}
$selisih = 3600 * $set['blogtimediff'];
$dur = time() - $selisih;
$d_req = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='$user_id' 
        AND (`mod_reg` = 'yes' OR `time` > '$dur') ORDER BY `time` DESC LIMIT 1;");
if (mysql_num_rows($d_req)) {
    $b_req = mysql_fetch_array($d_req);
    $textl = "Membuat Blog";
    require (dirname(__file__) . '/../../incfiles/head.php');
    if ($_req['mod_reg'] == 'yes')
        echo functions::display_error('Blog Kamu yang sebelumnya masih menunggu moderasi Administrator');
    else
        echo functions::display_error('Kamu dapat membuat blog baru dalam 1x' .
            $set['blogtimediff'] . ' jam.');
    require (dirname(__file__) . '/../../incfiles/end.php');
    exit;
}
$subdomain = isset($_POST['subdomain']) ? strtolower($_POST['subdomain']) : '';
$subdomain = functions::permalink($subdomain);
$domain = isset($_POST['domain']) ? strtolower($_POST['domain']) : '';
$ttl = isset($_POST['title']) ? $_POST['title'] : '';
if (isset($_GET['domain'])) {
    $expl = explode('.', strtolower($_GET['domain']), 2);
    if ((isset($expl[0]) && isset($expl[1])) && in_array($expl[1], $domains)) {
        $subdomain = functions::permalink($expl[0]);
        $domain = $expl[1];
    }
}
if (isset($_POST['create'])) {
    $error = array();
    if (substr($subdomain, 0, 1) == "-" or substr($subdomain, -1) == "-")
        $error[] = "Subdomain harus diawali dan diakhiri huruf atau angka.";
    $dof = unserialize($set['blogsubdomaindisallow']);
    if (in_array($subdomain, $dof) || is_dir("../" . $subdomain))
        $error[] = "Subdomain tidak diijinkan.";
    if (!in_array($domain, $domains))
        $error[] = "Domain tidak benar.";
    $url = $subdomain . '.' . $domain;
    $url2 = $subdomain . '.' . $domain;
    $tb = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `url`='" .
        mysql_real_escape_string($url) . "' OR `url`='" .
        mysql_real_escape_string($url2) . "' OR `url2`='" .
        mysql_real_escape_string($url) . "' OR `url2`='" .
        mysql_real_escape_string($url2) . "'"), 0);
    if ($tb != 0)
        $error[] = 'Alamat blog ' . $url . ' sudah terdaftar. (<a href="' . $set['homeurl'] .
            '/pages/blog.php/act/whois/domain/' . $subdomain . '.' . $domain .
            '">WHOIS</a>)';
    if (mb_strlen($subdomain) < 4 or mb_strlen($subdomain) > 16)
        $error[] = "Subdomain minimal 4 dan maksimal 16 karakter.";
    if (mb_strlen($ttl) < 2 or mb_strlen($ttl) > 30)
        $error[] = "Judul minimal 2 dan maksimal 30 karakter.";
    if (empty($error)) {
        @mkdir(ROOTPATH . 'sites/' . $url, 0777);
        @mkdir(ROOTPATH . 'sites/' . $url . '/contents', 0777);
        @mkdir(ROOTPATH . 'sites/' . $url . '/site', 0777);
        @mkdir(ROOTPATH . 'sites/' . $url . '/templates', 0777);
        mysql_query("
            INSERT INTO `blog_sites` SET 
            `user_id`='$user_id',
            `title` = '" . mysql_real_escape_string($ttl) . "',
            `url`='" . mysql_real_escape_string($url) . "',
            `url2`='" . mysql_real_escape_string($url2) . "',
            `mod_reg`='" . $mod_reg . "',
            `time`='" . time() . "'
            ");
        $bid = mysql_insert_id();
        mysql_query("INSERT INTO `blog_categories` SET `site_id`='" . $bid .
            "', `user_id`='" . $blog['user_id'] .
            "', `name`='Uncategorized', `permalink`='uncategorized', `counts`='0'");
        mysql_query("UPDATE `users` SET `www`='" . mysql_real_escape_string('http://' .
            $url) . "' WHERE `id`='" . $blog['user_id'] . "'");
        if ($mod_reg == 'yes')
            $_SESSION['notice'] =
                'Blog berhasil dibuat, dan sedang menunggu moderasi Administrator.';
        else
            $_SESSION['notice'] = 'Blog berhasil dibuat';

        header("location: " . $home . "/blogpanel/");
        exit();
    }
    else {
        $result = functions::display_error($error);
    }
}
$textl = "Buat Blog";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel/'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

echo '<form role="form" method="post" action="' . $home .
    '/blogpanel/index.php/act/create_blog">';
if (@$result)
    echo $result;
echo '<div class="form-group"><label>Subdomain</label>' .
    '<input class="form-control" type="text" name="subdomain" value="' .
    htmlspecialchars($subdomain) . '" maxlength="16"/>' .
    '<p class="help-block">Subdomain yang dilarang: <i>' . implode(', ',
    unserialize($set['blogsubdomaindisallow'])) . '</i></p></div>';
echo '<div class="form-group"><label>Domain</label>' .
    '<select class="form-control" name="domain">';
foreach ($domains as $domainsite) {
    echo '<option value="' . $domainsite . '"' . ($domain == $domainsite ?
        ' selected="selected"' : '') . '>' . $domainsite . '</option>';
}
echo '</select></div>';
echo '<div class="form-group"><label>Judul</label>' .
    '<input class="form-control" type="text" name="title" value="' .
    htmlspecialchars($ttl) . '"/></div>';
echo '<p><button class="btn btn-primary" type="submit" name="create">Buat Blog</button></p></form>';
require (dirname(__file__) . '/../../incfiles/end.php');
