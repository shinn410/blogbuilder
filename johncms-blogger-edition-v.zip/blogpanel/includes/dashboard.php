<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$textl = htmlspecialchars($blog['url']);
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url']),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

if (isset($_SESSION['notice']))
{
    echo '<div class="alert alert-info">' . htmlentities($_SESSION['notice']) .
        '</div>';
    unset($_SESSION['notice']);
}
if ($user_id != $blog['user_id'])
{
    $author = functions::get_user($blog['user_id']);
    echo '<div class="callout callout-info">' . functions::display_user($author) .
        '</div>';
}
$query = "(SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `time`<'" . time() .
    "') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `time`>'" . time() .
    "') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`!='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`!='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`!='0' AND `status`='spam') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' AND `post_id`='0' AND `status`='spam')";
$sql = mysql_query($query);
$total = array();
while ($res = mysql_fetch_array($sql))
{
    $total[] = $res[0];
}
$blogset = unserialize($blog['settings']);
echo '<p class="visible-xs text-center"><a class="func" href="http://' . $blog['url'] .
    '">' . htmlspecialchars($blog['title']) . '</a></p>';
echo '<div class="list-group visible-xs">';
echo '<!--<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/write_post"><i class="fa fa-pencil"></i> Menulis Posting</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/upload_post"><i class="fa fa-upload"></i> Upload Posting</a>-->';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/manage_posts"><span class="badge bg-green">' . ($total[1] +
    $total[2]) . '</span><i class="fa fa-file-text"></i> Posting</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/manage_categories"><span class="badge bg-green">' .
    $total[0] . '</span><i class="fa fa-flag"></i> Kategori</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/manage_comments"><span class="badge bg-aqua">' . ($total[3] +
    $total[4] + $total[5]) .
    '</span><i class="fa fa-comments"></i> Komentar</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/manage_navigations"><i class="fa fa-code"></i> Navigasi</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/template"><i class="fa fa-desktop"></i> Template</a>';
echo '<a class="list-group-item" href="' . $set['homeurl'] .
    '/blogpanel/index.php/act/files"><i class="fa fa-file"></i> Files</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/site_explorer"><i class="fa fa-folder-open"></i> Site Explorer</a>';
echo '<a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/settings"><i class="fa fa-cog"></i> Settings</a>';
echo '</div>';

echo '<div class="row hidden-xs">';
echo '<div class="col-sm-6"><div class="row">';
echo '<!--<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block" href="' .
    $home . '/blogpanel/index.php/act/write_post"><i class="fa fa-pencil"></i> Menulis Posting</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block" href="' .
    $home . '/blogpanel/index.php/act/upload_post"><i class="fa fa-upload"></i> Upload Posting</a></div>-->';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block" href="' .
    $home . '/blogpanel/index.php/act/manage_posts"><span class="badge bg-green">' . ($total[1] +
    $total[2]) . '</span><i class="fa fa-file-text"></i> Posting</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block;" href="' .
    $home . '/blogpanel/index.php/act/manage_categories"><span class="badge bg-green">' .
    $total[0] . '</span><i class="fa fa-flag"></i> Kategori</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block;" href="' .
    $home . '/blogpanel/index.php/act/manage_comments"><span class="badge bg-aqua">' . ($total[3] +
    $total[4] + $total[5]) .
    '</span><i class="fa fa-comments"></i> Komentar</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block;" href="' .
    $home . '/blogpanel/index.php/act/manage_navigations"><i class="fa fa-code"></i> Navigasi</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block;" href="' .
    $home . '/blogpanel/index.php/act/template"><i class="fa fa-desktop"></i> Template</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block;" href="' .
    $set['homeurl'] .
    '/blogpanel/index.php/act/files"><i class="fa fa-file"></i> Files</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block" href="' .
    $home . '/blogpanel/index.php/act/site_explorer"><i class="fa fa-folder-open"></i> Site Explorer</a></div>';
echo '<div class="col-xs-6 col-sm-4"><a class="btn btn-app" style="display:block" href="' .
    $home . '/blogpanel/index.php/act/settings"><i class="fa fa-cog"></i> Settings</a></div>';
echo '</div></div>';

echo '<div class="col-sm-6"><div class="box box-solid flat"><div class="box-header">' .
    '<h3 class="box-title"><i class="fa fa-rss-square"></i>&#160;' . $blog['url'] .
    '</h3></div><!-- /.box-header --><div class="box-body"><dl class="dl-horizontal">';

echo '<dt>Nama/Judul</dt><dd>' . htmlspecialchars($blog['title']) . '</dd>';
echo '<dt>URL</dt><dd><a href="http://' . $blog['url'] .
    '/" target="_new">http://' . $blog['url'] . '</a></dd>';
echo '<dt>Deskripsi</dt><dd>' . htmlspecialchars($blogset['description']) .
    '</dd>';
echo '<dt>Keywords</dt><dd>' . htmlspecialchars($blogset['keywords']) . '</dd>';
echo '<dt>Menunggu moderasi</dt><dd>' . ucfirst($blog['mod_reg']) .
    '</dd><dt>Pemblokiran</dt><dd>' . ucfirst($blog['block']) . '</dd>';
echo '<hr />';

echo '<dt>Posting</dt><dd><a href="' . $home .
    '/blogpanel/index.php/act/manage_posts">' . ($total[1] + $total[2]) .
    '</a> (' . $total[1] . ' diterbitkan, ' . $total[2] .
    ' konsep)</dd><dt>Kategori</dt><dd><a href="' . $home .
    '/blogpanel/index.php/act/manage_categories">' . $total[0] .
    '</a></dd><dt>Komentar</dt><dd><a href="' . $home .
    '/blogpanel/index.php/act/manage_comments">' . ($total[3] + $total[4] + $total[5]) .
    '</a> (<a href="' . $home .
    '/blogpanel/index.php/act/manage_comments/mod/accepted">' . $total[3] .
    '</a> disetujui, <a href="' . $home .
    '/blogpanel/index.php/act/manage_comments/mod/moderated">' . $total[4] .
    '</a> menunggu moderasi, <a href="' . $home .
    '/blogpanel/index.php/act/manage_comments/mod/spam">' . $total[5] .
    '</a> spam)</dd><dt>Hits hari ini</dt><dd>' . ($blog['hits_today_date'] ==
    date('d-m-Y', (time() + $set['timeshift'])) ? $blog['hits_today'] : '0') .
    '</dd><dt>Total hits</dt><dd> ' . $blog['hits_total'] . '</dd>';
if (($total[1] + $total[2]) > 0)
{
    $last_post = mysql_fetch_array(mysql_query("SELECT `draft`,`time` FROM `blog_posts` WHERE `site_id`='" .
        $blog['id'] . "' ORDER BY `time` DESC LIMIT 1"));
    echo '<dt>Posting terakhir</dt><dd>' . functions::display_date($last_post['time']) . ($last_post['draft'] ==
        "yes" ? ' (Konsep)' : '') . '</dd>';
    if (($total[3] + $total[4] + $total[5]) > 0)
    {
        $last_comment = mysql_fetch_array(mysql_query("SELECT `time` FROM `blog_comments` WHERE `site_id`='" .
            $blog['id'] . "' ORDER BY `time` DESC LIMIT 1"));
        echo '<dt>Komentar terakhir</dt><dd>' . functions::display_date($last_comment['time']) .
            '</dd>';
    }
}
echo '</div></div></div>';

echo '</div><!-- /.row -->';

require (dirname(__file__) . '/../../incfiles/end.php');
