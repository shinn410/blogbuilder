<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}

if (!$id)
{
    header('Location: ' . $home . '/blogpanel/index.php/act/manage_categories/');
    exit();
}
$cat_que = mysql_query("SELECT * FROM `blog_categories` WHERE `id`='" . $id .
    "' AND `site_id` = '" . $blog['id'] . "'");
if (mysql_num_rows($cat_que) == 0)
{
    header('Location: ' . $home . '/blogpanel/index.php/act/manage_categories/');
    exit();
}
$category = mysql_fetch_array($cat_que);

switch ($mod)
{
    case 'delete':
        if ($category['permalink'] == "uncategorized")
        {
            $textl = "Edit Kategori";
            $breadcrumb = functions::breadcrumb(array(
                array('label' => 'Blog Panel', 'url' => '/blogpanel'),
                array('label' => $blog['url'], 'url' =>
                        '/blogpanel/index.php/act/dashboard'),
                array('label' => $textl),
                ));
            require (dirname(__file__) . '/../../incfiles/head.php');
            echo functions::display_error('Kategori ini tidak bisa dihapus.',
                '<a class="alert-lnik" href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/manage_categories/">' . $lng['back'] .
                '</a>');
            require (dirname(__file__) . '/../../incfiles/end.php');
            exit();
        }
        if (!isset($_SESSION['key']))
            $_SESSION['key'] = md5(time());
        $submit = $_SESSION['key'];
        if (isset($_POST[$submit]))
        {
            mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + " .
                $category['counts'] . " WHERE `site_id`='" . $blog['id'] .
                "' AND `permalink`='uncategorized'");
            mysql_query("UPDATE `blog_posts` SET `category` = 'uncategorized' WHERE `site_id`='" .
                $blog['id'] . "' AND `category` = '" . mysql_real_escape_string
                ($category['permalink']) . "'");
            mysql_query("DELETE FROM `blog_categories` WHERE `id`='" . $category['id'] .
                "'");
            unset($_SESSION['key']);
            header("Location: " . $home .
                "/blogpanel/index.php/act/manage_categories");
            exit();
        }
        $textl = "Hapus Kategori";
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'Blog Panel', 'url' => '/blogpanel'),
            array('label' => $blog['url'], 'url' =>
                    '/blogpanel/index.php/act/dashboard'),
            array('label' => $textl),
            ));
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form method="post" action="' . $set['homeurl'] .
            '/blogpanel/index.php/act/edit_category/mod/delete/id/' . $category['id'] .
            '"><div class="alert alert-warning">Anda yakin akan menghapus Kategori ini?</div>' .
            '<p><button class="btn btn-danger" type="submit" name="' . $submit .
            '">Ya</button>&nbsp;<a data-dismiss="modal" class="btn btn-default" href="' .
            $home . '/blogpanel/index.php/act/manage_categories/">Batal</a></p></form>';
        require (dirname(__file__) . '/../../incfiles/end.php');
        break;

    default:
        $name = isset($_POST['name']) ? $_POST['name'] : $category['name'];
        if (isset($_POST['name']))
        {
            $permalink = functions::permalink($name);
            if (mb_strlen($name) < 2 or mb_strlen($name) > 30)
                $error = "Nama kategori harus 2 s/d 30 karakter.";

            if ($category['permalink'] == "uncategorized")
            {
                $cc = mysql_query("SELECT * FROM `blog_categories` WHERE WHERE `id` != '" .
                    $category['id'] . "' AND `site_id`='" .
                    mysql_real_escape_string($category['site_id']) .
                    "' AND `user_id`='" . mysql_real_escape_string($blog['user_id']) .
                    "' AND `name`='" . mysql_real_escape_string($name) .
                    "' AND `permalink`!='uncategorized'");
                if (mysql_num_rows($cc) != 0)
                    $error = "Nama kategori sudah ada.";
            }
            else
            {
                $cc = mysql_query("SELECT * FROM `blog_categories` WHERE `id` != '" .
                    $category['id'] . "' AND (`site_id`='" .
                    mysql_real_escape_string($category['site_id']) .
                    "' AND `user_id`='" . mysql_real_escape_string($blog['user_id']) .
                    "') AND (`name`='" . mysql_real_escape_string($name) .
                    "' OR `permalink`='" . mysql_real_escape_string($permalink) .
                    "')");
                if (mysql_num_rows($cc) != 0)
                    $error = "Nama kategori sudah ada.";
            }
            if (empty($error))
            {
                if ($category['permalink'] == "uncategorized")
                {
                    $new_permalink = $category['permalink'];
                }
                else
                {
                    $new_permalink = $permalink;
                }
                mysql_query("UPDATE `blog_categories` SET `name`='" .
                    mysql_real_escape_string($name) . "', `permalink`='" .
                    mysql_real_escape_string($new_permalink) . "' WHERE `id`='" .
                    mysql_real_escape_string($category['id']) .
                    "' AND `user_id`='" . mysql_real_escape_string($blog['user_id']) .
                    "'");
                header("location: " . $home .
                    "/blogpanel/index.php/act/manage_categories");
                exit();
            }
            else
            {
                $error = '<div class="alert alert-danger">' . $error . '</div>';
            }
        }
        $textl = "Edit Kategori";
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'Blog Panel', 'url' => '/blogpanel'),
            array('label' => $blog['url'], 'url' =>
                    '/blogpanel/index.php/act/dashboard'),
            array('label' => $textl),
            ));
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form method="post" action="' . $set['homeurl'] .
            '/blogpanel/index.php/act/edit_category/id/' . $id . '">';
        if (isset($error))
            echo $error;
        echo '<div class="form-group"><label>Nama Kategori</label>' .
            '<input class="form-control" type="text" name="name" value="' .
            htmlspecialchars($name) . '"/>' .
            '</div><p><button class="btn btn-primary" type="submit" name="submit">Simpan</button>' .
            '&nbsp;<a data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/manage_categories/" class="btn btn-default">Batal</a></p></form>';
        require (dirname(__file__) . '/../../incfiles/end.php');
}
