<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$site_root = str_replace('\\', '/', dirname(__file__)) . '/../../sites/' . $blog['url'] .
    '/site';
function get_dir($exp_limit, $str = false)
{
    if (!$str)
    {
        $str = strtr(strip_tags(trim($_SERVER['PATH_INFO'])), array('\\' => '/',
                '//' => '/'));
    }
    $path = explode('/', $str, $exp_limit);
    $indexes = explode('/', str_replace('\\', '/', @$path[$exp_limit - 1]));
    $dirs = array();
    foreach ($indexes as $idx)
    {
        $idx = trim($idx);
        if ($idx != '' || $idx != '.' || $idx != '..' || mb_substr($idx, 0, 1) !=
            '.' || mb_substr($idx, -1) != '.')
            $dirs[] = $idx;
    }
    return implode('/', $dirs);
}

$textl = 'Site Explorer';
$breadcrumbs = array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => 'Site Explorer', 'url' =>
            '/blogpanel/index.php/act/site_explorer'),
    );
$ext_text = array(
    'html',
    'txt',
    'css',
    'js',
    );
switch ($mod)
{
    case 'move':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        parse_str($_SERVER['QUERY_STRING'], $r2);

        if (!is_dir($site_root . '/' . $dir) || !isset($r2['move']) || (@$r2['move'] ==
            ''))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $move = get_dir(4, '/AChuNk/JealousMan/' . strip_tags(trim($r2['move'])));
        if (!is_dir($site_root . '/' . $move) && !is_file($site_root . '/' . $move))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer/page/1/' . $dir);
            exit();
        }
        $name = basename($move);
        if (isset($_POST['submit']))
        {
            if (rename($site_root . '/' . $move, $site_root . '/' . $dir . '/' .
                $name))
            {
                header("Location: " . $home .
                    "/blogpanel/index.php/act/site_explorer/page/1/" . $dir .
                    "/" . $name);
                exit();
            }
            else
            {
                $error = functions::display_error("Gagal memindahkan file/folder");
            }
        }

        $textl = 'Pindah: ' . $name;
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
        $breadcrumbs[3] = array('label' => $name);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/move/' . $dir . '?move=' .
            $move . '" method="post">' . (isset($error) ? $error : '') .
            '<div class="alert alert-warning">Apa kamu yakin akan memindahkan <strong class="text-red">' .
            htmlentities($name) .
            '</strong> ke folder <strong class="text-red">/' . htmlentities($dir) .
            '</strong> ?</div><p><button class="btn btn-primary" type="submit" name="submit">Ya pindahkan</button>' .
            '&nbsp;<a class="btn btn-default" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . $dir .
            '" data-dismiss="modal">Batal</a></p></form>';
        break;

    case 'edit_file':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_file($site_root . '/' . $dir) || ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $ext = functions::get_file_ext($dir);
        if (!in_array($ext, $ext_text))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
            exit();
        }
        $name = basename($dir);
        $code = isset($_POST['code']) ? $_POST['code'] : file_get_contents($site_root .
            '/' . $dir);
        if (isset($_POST['code']))
        {
            if (file_put_contents($site_root . '/' . $dir, $code))
                $result =
                    '<div class="alert alert-success">File berhasil disimpan.</div>';
            else
                $result = functions::display_error('File gagal disimpan!');
        }
        $textl = 'Edit: ' . $name;
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
        $breadcrumbs[3] = array('label' => $name);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');

        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/edit_file/' . $dir .
            '" method="post">';
        if (isset($result))
            echo $result;
        echo '<div class="form-group"><label class="pull-right"><a class="func" href="//' .
            $blog['url'] . '/site/' . $dir .
            '" target="_new"><i class="fa fa-eye"></i> Preview</a></label><label>Kode</label>' .
            '<textarea class="form-control" name="code" rows="20">' .
            htmlentities($code) . '</textarea>' . '</div>';
        echo '<p><button class="btn btn-primary" type="submit">Simpan</button></p>';
        echo '</form>';
        break;

    case 'upload':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if (!is_dir($site_root . '/' . $dir))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $errors = array();
        if (!isset($_SESSION['key']))
            $_SESSION['key'] = md5(time());
        $key = $_SESSION['key'];
        if (isset($_POST[$key]) && isset($_FILES['berkas']))
        {
            unset($_SESSION['key']);
            $key = $_SESSION['key'] = md5(time());
            $ffile = $_FILES['berkas']['tmp_name'];
            $fname = strtolower($_FILES['berkas']['name']);
            $fsize = $_FILES['berkas']['size'];
            if ($fsize >= 1024 * $set['flsz'])
                $errors[] = "Ukuran File tidak boleh lebih dari " . $set['flsz'] .
                    " Kb.";
            $ext = functions::get_file_ext($fname);
            $fname = functions::permalink(substr($fname, 0, "-" . (strlen($ext) +
                1)));
            $fname = mb_strlen($fname) > 30 ? mb_substr($fname, 0, 30) : $fname;
            $filename = $fname . '.' . $ext;
            if (strlen($ext) > 4 || strlen($ext) < 2)
                $errors[] = "Ekstensi file tidak benar";
            if (empty($fname))
                $errors[] = "Silakan pilih File.";
            if (!$errors)
            {
                if (move_uploaded_file($ffile, $site_root . '/' . $dir . '/' . $filename))
                {
                    header('Location: ' . $home .
                        '/blogpanel/index.php/act/site_explorer/mod/file_info/' .
                        $dir . '/' . $filename);
                    exit();
                }
                else
                    $errors[] = 'File gagal diupload';
            }
        }

        $textl = 'Upload';
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . $dir);
        $breadcrumbs[3] = array('label' => $textl);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/upload/' . $dir .
            '" method="post" enctype="multipart/form-data">';
        if ($errors)
            echo functions::display_error($errors);
        echo '<div class="form-group"><label>File</label>' .
            '<input type="file" name="berkas"/>' .
            '<p class="help-block">Maksimal ukuran ' . $set['flsz'] .
            ' kb</p></div>';
        echo '<p><button class="btn btn-primary" type="submit" name="' . $key .
            '">Upload</button>' .
            '&nbsp;<a class="btn btn-default" data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . $dir .
            '">Batal</a></p>';
        echo '</form>';
        break;

    case 'download':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_file($site_root . '/' . $dir) || ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $name = basename($dir);
        $mime_types = include_once (dirname(__file__) .
            '/../../incfiles/mime_types.php');
        $ex = strtolower(substr(strrchr($name, "."), 1));
        if (in_array($ex, array_keys($mime_types)))
            $type = $mime_types[$ex];
        else
            $type = "application/octet-stream";
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $type);
        header('Content-Disposition: attachment; filename=' . $name);
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($site_root . '/' . $dir));
        readfile($site_root . '/' . $dir);
        exit();
        break;

    case 'file_info':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_file($site_root . '/' . $dir) || ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $name = basename($dir);
        $textl = 'File: ' . $name;
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
        $breadcrumbs[3] = array('label' => $name);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        $types = include_once (dirname(__file__) .
            '/../../incfiles/mime_types.php');
        $ext = functions::get_file_ext($name);
        if (in_array($ext, array_keys($types)))
            $type = $types[$ext];
        else
            $type = "application/octet-stream";
        echo '<div class="row"><div class="col-sm-6"><div class="box box-solid"><div class="box-body">' .
            '<dl class="dl-horizontal">' . '<dt>Nama</dt><dd>' . $name . '</dd>' .
            '<dt>Tipe</dt><dd>' . $type . '</dd>' . '<dt>Ukuran</dt><dd>' .
            round(filesize($site_root . '/' . $dir) / 1024, 2) . ' kb</dd>' .
            '<dt>Diupload</dt>' . '<dd>' . functions::display_date(filemtime($site_root .
            '/' . $dir)) . '</dd>' . '<dt>URL</dt><dd><a href="http://' . $blog['url'] .
            '/site/' . $dir . '">http://' . $blog['url'] . '/site/' . $dir .
            '</a></dd></dl></div></div></div>';
        echo '<div class="col-sm-6"><div class="list-group">';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/rename/' . $dir .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-pencil"></i> Ubah nama</a>';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/?move=' . $dir . '">' .
            '<i class="fa fa-exchange"></i> Pindah</a>';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/delete/' . $dir .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-times"></i> Hapus</a>';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/download/' . $dir . '">' .
            '<i class="fa fa-download"></i> Download</a>';
        if (in_array($ext, $ext_text))
            echo '<a class="list-group-item" href="' . $home .
                '/blogpanel/index.php/act/site_explorer/mod/edit_file/' . $dir .
                '">' . '<i class="fa fa-edit"></i> Edit</a>';
        echo '</div></div>';
        echo '</div>';
        break;

    case 'delete':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_dir($site_root . '/' . $dir) && !is_file($site_root . '/' . $dir) ||
            ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $name = basename($dir);
        $textl = 'Hapus';
        if (is_dir($site_root . '/' . $dir))
        {
            $typ = 'Folder';
            $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                    '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
            $breadcrumbs[3] = array('label' => $name);
        }
        else
        {
            $typ = 'File';
            if (dirname($dir) == '')
            {
                $breadcrumbs[3] = array('label' => $name);
            }
            else
            {
                $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                        '/blogpanel/index.php/act/site_explorer/page/1/' .
                        dirname($dir));
                $breadcrumbs[3] = array('label' => $name);
            }
        }
        if (isset($_POST['submit']))
        {
            if ($typ == 'File')
            {
                @unlink($site_root . '/' . $dir);
            }
            else
            {
                @functions::delete_dir($site_root . '/' . $dir);
            }
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
            exit();
        }
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/delete/' . $dir .
            '" method="post">';
        echo '<div class="alert alert-warning">Apakah Kamu yakin akan menghapus ' .
            $typ . ' ini ?</div>';
        echo '<p><button class="btn btn-danger" type="submit" name="submit">Hapus</button>' .
            '&nbsp;<a class="btn btn-default" data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir) .
            '">Batal</a></p>';
        echo '</form>';
        break;

    case 'rename':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_dir($site_root . '/' . $dir) && !is_file($site_root . '/' . $dir) ||
            ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $name = basename($dir);
        $value = isset($_POST['value']) ? functions::permalink($_POST['value']) :
            $name;
        $textl = 'Ubah nama';
        $prev_dir = dirname($dir);
        if (is_dir($site_root . '/' . $dir))
        {
            $tipe = 'dir';
        }
        else
        {
            $tipe = 'file';
            $exp_str = explode('.', $name);
            $value = isset($_POST['value']) ? functions::permalink($_POST['value']) :
                $exp_str[0];
        }

        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
        $breadcrumbs[3] = array('label' => $name);
        $breadcrumb = functions::breadcrumb($breadcrumbs);

        if (isset($_POST['value']))
        {
            if ($tipe == 'file')
            {
                $value = $value . '.' . $exp_str[1];
                if (file_exists($site_root . '/' . $prev_dir . '/' . $value))
                {
                    $error = 'File sudah ada';
                }
                elseif (rename($site_root . '/' . $dir, $site_root . '/' . $prev_dir .
                    '/' . $value))
                {
                    header('Location: ' . $home .
                        '/blogpanel/index.php/act/site_explorer/page/1/' . $prev_dir);
                    exit();
                }
                else
                {
                    $error = 'Gagal merubah nama';
                }
            }
            else
            {
                if (is_dir($site_root . '/' . $prev_dir . '/' . $value))
                {
                    $error = 'Folder sudah ada';
                }
                elseif (rename($site_root . '/' . $dir, $site_root . '/' . $prev_dir .
                    '/' . $value))
                {
                    header('Location: ' . $home .
                        '/blogpanel/index.php/act/site_explorer/page/1/' . $prev_dir);
                    exit();
                }
                else
                {
                    $error = 'Gagal merubah nama';
                }
            }
        }
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/rename/' . $dir .
            '" method="post">';
        if (isset($error))
            echo functions::display_error($error);
        if ($tipe == 'file')
        {
            echo '<div class="form-group"><label>Nama file</label>';
            echo '<div class="input-group">' .
                '<input class="form-control" type="text" name="value" value="' .
                htmlentities($value) . '"/><span class="input-group-addon">.' .
                $exp_str[1] . '</span></div>';
            echo '</div>';
        }
        else
        {
            echo '<div class="form-group"><label>Nama Folder</label>' .
                '<input class="form-control" type="text" name="value" value="' .
                htmlentities($value) . '"/></div>';
        }
        echo '<p><button class="btn btn-primary" type="submit">Simpan</button>' .
            '&nbsp;<a class="btn btn-default" data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . $prev_dir .
            '">Batal</a></p>';
        echo '</form>';
        break;

    case 'actions':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if ((!is_dir($site_root . '/' . $dir) && !is_file($site_root . '/' . $dir) ||
            ($dir == '')))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $name = basename($dir);
        if (is_dir($site_root . '/' . $dir))
        {
            $typ = 'folder';
            $textl = 'Folder: ' . $name;
            $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                    '/blogpanel/index.php/act/site_explorer/page/1/' . dirname($dir));
            $breadcrumbs[3] = array('label' => $name);
        }
        else
        {
            $typ = 'file';
            $textl = 'File: ' . $name;
            if (dirname($dir) == '')
            {
                $breadcrumbs[3] = array('label' => $name);
            }
            else
            {
                $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                        '/blogpanel/index.php/act/site_explorer/page/1/' .
                        dirname($dir));
                $breadcrumbs[3] = array('label' => $name);
            }
        }
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<div class="list-group">';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/rename/' . $dir .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-pencil"></i> Ubah nama</a>';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/?move=' . $dir . '">' .
            '<i class="fa fa-exchange"></i> Pindah</a>';
        echo '<a class="list-group-item" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/delete/' . $dir .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-times"></i> Hapus</a>';
        if ($typ == 'file')
        {
            echo '<a class="list-group-item" href="' . $home .
                '/blogpanel/index.php/act/site_explorer/mod/download/' . $dir .
                '">' . '<i class="fa fa-download"></i> Download</a>';
            $ext = functions::get_file_ext($dir);
            if (in_array($ext, $ext_text))
                echo '<a class="list-group-item" href="' . $home .
                    '/blogpanel/index.php/act/site_explorer/mod/edit_file/' . $dir .
                    '">' . '<i class="fa fa-edit"></i> Edit</a>';
        }
        echo '</div>';
        break;

    case 'create_file':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if (!is_dir($site_root . '/' . $dir))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $errors = array();
        $value = isset($_POST['value']) ? functions::permalink($_POST['value']) :
            '';
        $type = isset($_POST['type']) ? $_POST['type'] : $ext_text[0];
        if ($value != '')
        {
            if (mb_strlen($value) < 2 || mb_strlen($value) > 30)
                $errors[] = 'Panjang minimal 2 dan maksimal 30 karakter';
            if (file_exists($site_root . '/' . $dir . '/' . $value . '.' . $type))
                $errors[] = 'File sudah ada';
            if (!in_array($type, $ext_text))
                $errors[] = 'Jenis file tidak benar';
            if (!$errors)
            {
                if (file_put_contents($site_root . '/' . $dir . '/' . $value .
                    '.' . $type, "\n") != false)
                {
                    header('Location: ' . $home .
                        '/blogpanel/index.php/act/site_explorer/page/1/' . $dir);
                    exit();
                }
                else
                {
                    $errors[] = 'Gagal membuat file';
                }
            }
        }
        $textl = 'Buat File';
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . $dir);
        $breadcrumbs[3] = array('label' => $textl);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/create_file/' . $dir .
            '" method="post">';
        if ($errors)
            echo functions::display_error($errors);
        echo '<div class="form-group"><label>Nama File</label>' .
            '<input class="form-control" type="text" name="value" value="' .
            htmlentities($value) . '"/>' .
            '<p class="help-block">Karakter yang diijinkan a-z, 0-9 dan simbol _</p></div>';
        echo '<div class="form-group"><label>Jenis</label>';
        foreach ($ext_text as $ext)
        {
            echo '<div class="radio"><label>' .
                '<input type="radio" name="type" value="' . $ext . '"' . ($type ==
                $ext ? ' checked' : '') . '/> ' . strtoupper($ext) .
                '</label></div>';
        }
        echo '</div>';
        echo '<p><button class="btn btn-primary" type="submit">Buat</button>' .
            '&nbsp;<a class="btn btn-default" data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . $dir .
            '">Batal</a></p>';
        echo '</form>';
        break;

    case 'create_dir':
        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        if (!is_dir($site_root . '/' . $dir))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer');
            exit();
        }
        $errors = array();
        $value = isset($_POST['value']) ? functions::permalink($_POST['value']) :
            '';
        if ($value != '')
        {
            if (mb_strlen($value) < 2 || mb_strlen($value) > 30)
                $errors[] = 'Panjang minimal 2 dan maksimal 30 karakter';
            if (is_dir($site_root . '/' . $dir . '/' . $value))
                $errors[] = 'Folder sudah ada';
            if (!$errors)
            {
                if (mkdir($site_root . '/' . $dir . '/' . $value, 0777))
                {
                    header('Location: ' . $home .
                        '/blogpanel/index.php/act/site_explorer/page/1/' . $dir .
                        '/' . $value);
                    exit();
                }
                else
                {
                    $errors[] = 'Gagal membuat folder';
                }
            }
        }
        $textl = 'Buat Folder';
        $breadcrumbs[2] = array('label' => 'Site Explorer', 'url' =>
                '/blogpanel/index.php/act/site_explorer/page/1/' . $dir);
        $breadcrumbs[3] = array('label' => $textl);
        $breadcrumb = functions::breadcrumb($breadcrumbs);
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo '<form role="form" action="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/create_dir/' . $dir .
            '" method="post">';
        if ($errors)
            echo functions::display_error($errors);
        echo '<div class="form-group"><label>Nama Folder</label>' .
            '<input class="form-control" type="text" name="value" value="' .
            htmlentities($value) . '"/>' .
            '<p class="help-block">Karakter yang diijinkan a-z, 0-9 dan simbol _</p></div>';
        echo '<p><button class="btn btn-primary" type="submit">Buat</button>' .
            '&nbsp;<a class="btn btn-default" data-dismiss="modal" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/page/1/' . $dir .
            '">Batal</a></p>';
        echo '</form>';
        break;

    default:
        if ($mod || !isset($_GET['page']))
        {
            header('Location: ' . $home .
                '/blogpanel/index.php/act/site_explorer/page/1');
            exit();
        }
        parse_str($_SERVER['QUERY_STRING'], $r2);
        if (isset($r2['move']))
            $move = '?move=' . htmlentities($r2['move']);
        else
            $move = '';

        $dir = get_dir(6);
        $dir = mb_substr($dir, -1) == '/' ? mb_substr($dir, 0, -1) : $dir;
        $dir = mb_substr($dir, 0, 1) == '/' ? mb_substr($dir, 1) : $dir;
        $breadcrumb = functions::breadcrumb(array(
            array('label' => 'Blog Panel', 'url' => '/blogpanel'),
            array('label' => $blog['url'], 'url' =>
                    '/blogpanel/index.php/act/dashboard'),
            array('label' => $textl),
            ));
        require (dirname(__file__) . '/../../incfiles/head.php');
        $site_dir = $site_root . ($dir == '' ? '' : '/' . $dir);
        echo '<p><a class="func" href="' . $home .
            '/blogpanel/index.php/act/site_explorer/mod/create_dir/' . $dir .
            '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-folder"></i> Buat Folder</a>&nbsp;<a class="func" href="' .
            $home . '/blogpanel/index.php/act/site_explorer/mod/create_file/' .
            $dir . '" data-toggle="' . functions::set_modal() .
            '" data-target="#global-modal">' .
            '<i class="fa fa-file"></i> Buat File</a>&nbsp;<a class="func" href="' .
            $home . '/blogpanel/index.php/act/site_explorer/mod/upload/' . $dir .
            '">' . '<i class="fa fa-upload"></i> Upload</a></p>';
        if (is_dir($site_dir))
        {
            if ($dir != '')
            {
                $xdir = '';
                $dirs = preg_split("/\/+/", $dir);
                $total_drx = count($dirs);
                echo '<ol class="breadcrumb">';
                echo '<li><a href="' . $home .
                    '/blogpanel/index.php/act/site_explorer/page/1/' . $move .
                    '">' .
                    '<i class="fa fa-folder-open"></i> Site Explorer</a></li>';
                for ($x = 0; $x < $total_drx; $x++)
                {
                    if ($x == ($total_drx - 1))
                    {
                        echo '<li class="active">' . $dirs[$total_drx - 1] .
                            '</li>';
                    }
                    else
                    {
                        echo '<li><a href="' . $home .
                            '/blogpanel/index.php/act/site_explorer/page/1/' . $xdir .
                            $dirs[$x] . $move . '">' . $dirs[$x] . '</a></li>';
                    }
                    $xdir .= $dirs[$x] . '/';
                }
                echo '</ol>';

            }
            if ($move != '')
            {
                echo
                    '<div class="alert alert-info"><a class="alert-link" href="' .
                    $set['homeurl'] .
                    '/blogpanel/index.php/act/site_explorer/mod/move/' . $dir .
                    $move . '" data-toggle="' . functions::set_modal() .
                    '" data-target="#global-modal">Pindahkan <span class="text-red">' .
                    htmlentities(basename($r2['move'])) .
                    '</span> ke sini</a>, atau <a class="alert-link" href="' . $set['homeurl'] .
                    '/blogpanel/index.php/act/site_explorer/page/' . $page . '/' .
                    $dir . '">batalkan</a> tindakan ini!</div>';
            }
            $files = functions::read_dir($site_dir);
            $total = count($files);
            if ($total)
            {
                if (!in_array('index.html', $files) && $move == '')
                {
                    echo '<div class="alert alert-warning">' .
                        'Buatlah file dengan nama <strong>index.html</strong> ' .
                        'agar folder bisa dijelajahi secara otomatis</div>';
                }
                $end = $start + $kmess;
                if ($end > $total)
                    $end = $total;
                echo '<ul class="list-group">';
                for ($e = $start; $e < $end; $e++)
                {
                    echo '<li class="list-group-item">';
                    if (is_file($site_dir . '/' . $files[$e]))
                    {
                        echo '<a href="' . $home .
                            '/blogpanel/index.php/act/site_explorer/mod/file_info/' . ($dir ==
                            '' ? '' : $dir . '/') . $files[$e] . $move .
                            '"><i class="fa fa-file"></i> ' . $files[$e] .
                            '</a>';
                    }
                    else
                    {
                        echo '<a href="' . $home .
                            '/blogpanel/index.php/act/site_explorer/page/' . $page .
                            '/' . ($dir == '' ? '' : $dir . '/') . $files[$e] .
                            $move . '"><i class="fa fa-folder"></i> ' . $files[$e] .
                            '</a>';
                    }
                    echo '<a class="pull-right" href="' . $home .
                        '/blogpanel/index.php/act/site_explorer/mod/actions/' . ($dir ==
                        '' ? '' : $dir . '/') . $files[$e] . '" data-toggle="' .
                        functions::set_modal() .
                        '" data-target="#global-modal"> <i class="fa fa-cog"></i> </a>';
                    echo '</li>';
                }
                echo '</ul>';
                if ($total > $kmess)
                    echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
                        '/blogpanel/index.php/act/site_explorer/', $start, $total,
                        $kmess, 'page/%d/' . strtr($dir, array('%' => '%%')) . $move) .
                        '</div>';
            }
            else
            {
                echo '<div class="alert alert-info">Folder kosong</div>';
            }
        }
        else
        {
            echo '<div class="alert alert-danger">Tidak ada File/Folder!</div>';
        }
        break;
}
require (dirname(__file__) . '/../../incfiles/end.php');
