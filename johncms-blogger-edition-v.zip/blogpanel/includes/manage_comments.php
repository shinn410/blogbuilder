<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}

if (isset($_GET['comment_id']))
{
    $cid = abs(intval(trim($_GET['comment_id'])));
    $co_que = mysql_query("SELECT * FROM `blog_comments` WHERE `id`='" . $cid .
        "' AND `site_id`='" . $blog['id'] . "'");
    if (mysql_num_rows($co_que) != 0)
    {
        $co = mysql_fetch_array($co_que);
        if ($co['status'] != "spam" and $mod == "spam")
        {
            mysql_query("UPDATE `blog_comments` SET `status`='spam' WHERE `id` = '" .
                $co['id'] . "'");
            if ($co['post_id'] != 0 and $co['status'] == "accepted")
            {
                mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='" .
                    $co['post_id'] . "'");
            }
            $return = "Komentar berhasil dipindahkan.";
        }
        elseif ($co['status'] != "accepted" and $mod == "accepted")
        {
            mysql_query("UPDATE `blog_comments` SET `status`='accepted' WHERE `id` = '" .
                $co['id'] . "'");
            if ($co['post_id'] != 0)
            {
                mysql_query("UPDATE `blog_posts` SET `comments` = `comments` + 1 WHERE `id`='" .
                    $co['post_id'] . "'");
            }
            $return = "Komentar berhasil dipindahkan.";
        }
        elseif ($mod == "delete")
        {
            mysql_query("DELETE FROM `blog_comments` WHERE `id` = '" . $co['id'] .
                "'");
            if ($co['post_id'] != 0 and $co['status'] == "accepted")
            {
                mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='" .
                    $co['post_id'] . "'");
            }
            $return = "Komentar berhasil dihapus.";
        }

    }
    else
    {
        $return = "Komentar yang dipilih tidak benar.";
    }
}

$in = isset($_GET['in']) ? $_GET['in'] : 'post';
if ($in == "guestbook")
{
    $qu = "`post_id`='0'";
    $in = "guestbook";
    $ttl = "Komentar Buku tamu";
}
else
{
    $qu = "`post_id`!='0'";
    $in = "post";
    $ttl = "Komentar Posting";
}

$query = mysql_query("

        (SELECT COUNT(*) 
        FROM `blog_comments` 
        WHERE `site_id`='" . $blog['id'] . "' 
        AND $qu 
        AND `status` = 'accepted') 
        
        UNION ALL 
        (SELECT COUNT(*) 
        FROM `blog_comments` 
        WHERE `site_id`='" . $blog['id'] . "' 
        AND $qu 
        AND `status` = 'moderated') 
        
        UNION ALL 
        (SELECT COUNT(*) 
        FROM `blog_comments` 
        WHERE `site_id`='" . $blog['id'] . "' 
        AND $qu 
        AND `status` = 'spam')
        
        UNION ALL 
        (SELECT COUNT(*) 
        FROM `blog_comments` 
        WHERE `site_id`='" . $blog['id'] . "' 
        AND $qu 
        AND `adminread` = '0')
        
        ");
$taotal = array();
while ($taotl = mysql_fetch_array($query))
{
    $taotal[] = $taotl[0];
}
$total_accepted = $taotal[0];
$total_moderated = $taotal[1];
$total_spam = $taotal[2];
$total_unread = $taotal[3];

switch ($mod)
{
    case 'accepted':
        $status = "accepted";
        $qu2 = "`status` = 'accepted'";
        break;
    case 'moderated':
        $status = "moderated";
        $qu2 = "`status` = 'moderated'";
        break;
    case 'spam':
        $status = "spam";
        $qu2 = "`status` = 'spam'";
        break;
    case 'unread':
        $status = "unread";
        $qu2 = "`adminread` = '0'";
        break;
    default:
        header('Location: ' . $set['homeurl'] .
            '/blogpanel/index.php/act/manage_comments/in/' . $in . '/mod/' . ($total_unread ?
            'unread' : 'accepted'));
        exit;

        break;
}

$textl = $ttl;
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
if (isset($return))
    echo '<div class="alert alert-info">' . $return . '</div>';
if ($in == 'guestbook')
    echo '<p class="visible-xs"><a class="func" href="' . $set['homeurl'] .
        '/login.php?redirect=' . urlencode('http://' . $blog['url'] . '/about.html') .
        '">Ke Buku tamu &raquo;</a></p>';
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li' . ((!$mod or $mod ==
    "accepted") ? ' class="active"' : '') . '><a href="' . $set['homeurl'] .
    '/blogpanel/index.php/act/manage_comments/in/' . $in .
    '/mod/accepted">Disetujui <span class="badge">' . $total_accepted .
    '</span></a></li><li' . ($mod == "moderated" ? ' class="active"' : '') .
    '><a href="' . $set['homeurl'] .
    '/blogpanel/index.php/act/manage_comments/in/' . $in .
    '/mod/moderated">Dimoderasi <span class="badge">' . $total_moderated .
    '</span></a></li><li' . ($mod == "spam" ? ' class="active"' : '') .
    '><a href="' . $set['homeurl'] .
    '/blogpanel/index.php/act/manage_comments/in/' . $in .
    '/mod/spam">Spam <span class="badge">' . $total_spam . '</span></a></li><li' . ($mod ==
    "unread" ? ' class="active"' : '') . '><a href="' . $set['homeurl'] .
    '/blogpanel/index.php/act/manage_comments/in/' . $in .
    '/mod/unread">Unread <span class="badge">' . $total_unread .
    '</span></a></li>' . ($in == 'guestbook' ?
    '<li class="pull-right hidden-xs"><a href="' . $set['homeurl'] .
    '/login.php?redirect=' . urlencode('http://' . $blog['url'] . '/about.html') .
    '">Ke Buku tamu &raquo;</a></li>' : '') .
    '</ul><div class="tab-content"><div class="tab-pane active">';
if ($mod == "moderated")
    $total = $total_moderated;
elseif ($mod == "spam")
    $total = $total_spam;
elseif ($mod == "accepted")
    $total = $total_accepted;
elseif ($mod == "unread")
    $total = $total_unread;
else
    $total = $total_unread;
if ($total == 0)
{
    echo '<div class="alert alert-warning"><p>' . $lng['list_empty'] .
        '</p></div>';
}
else
{
    $comments = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id`='" .
        $blog['id'] . "' AND $qu AND $qu2 ORDER BY `time` DESC LIMIT $start,$kmess");

    $posts = array();
    $mass_read = array();
    $reply = array();
    while ($comment = mysql_fetch_array($comments))
    {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        if ($comment['author_id'] != 0)
            echo '<a href="' . $home . '/users/profile.php/user/' . $comment['author_id'] .
                '"><img src="' . $home . '/users/avatar.php/user/' . $comment['author_id'] .
                '" alt=""/></a> ';
        else
            echo '<img src="' . $home . '/users/avatar.php/user/' . $comment['author_id'] .
                '" alt=""/>';
        echo '<a href="' . htmlentities($comment['author_homepage']) . '">' .
            htmlspecialchars($comment['author_name']) . '</a> ';
        if ($comment['adminread'] == 0)
        {
            $mass_read[] = $comment['id'];
            echo '(<span class="red">' . functions::display_date($comment['time']) .
                '</span>)';
        }
        else
        {
            echo '(' . functions::display_date($comment['time']) . ')';
        }
        if (empty($comment['quote']))
        {
            echo '<br />' . nl2br($comment['text']) . '<br />';
        }
        else
        {
            if (!isset($reply[$comment['quote']]))
            {
                $reply[$comment['quote']] = mysql_fetch_array(mysql_query("SELECT * FROM `blog_comments` WHERE `id` = '" .
                    mysql_real_escape_string($comment['quote']) . "'"));
            }
            echo '<div class="callout callout-info" style="margin-top:10px;"><h4>' .
                $reply[$comment['quote']]['author_name'] . '</h4><p>' . $reply[$comment['quote']]['text'] .
                '</p></div>' . nl2br($comment['text']);
        }
        if ($comment['post_id'] != 0)
        {
            if (!isset($posts[$comment['post_id']]))
            {
                $posts[$comment['post_id']] = @mysql_fetch_array(mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `id`='" .
                    $comment['post_id'] . "'"));
            }
            echo '<br />Pada postingan <a href="' . $set['homeurl'] .
                '/login.php?redirect=' . urlencode('http://' . $blog['url'] . '/' . $posts[$comment['post_id']]['permalink'] .
                '.html') . '">' . htmlspecialchars($posts[$comment['post_id']]['title']) .
                '</a>';
        }
        echo '<div class="sub">';
        if ($comment['status'] == 'accepted')
        {
            if ($comment['post_id'] != 0)
                echo '<a href="' . $set['homeurl'] . '/login.php?redirect=' . urlencode('http://' .
                    $blog['url'] . '/' . $posts[$comment['post_id']]['permalink'] .
                    '.html?comment_reply=' . $comment['id']) . '#comment-' . $comment['id'] .
                    '"><i class="fa fa-reply"></i> Balas</a>';
            else
                echo '<a href="' . $set['homeurl'] . '/login.php?redirect=' . urlencode('http://' .
                    $blog['url'] . '/about.html?comment_reply=' . $comment['id']) .
                    '#comment-' . $comment['id'] .
                    '"><i class="fa fa-reply"></i> Balas</a>';
            echo ' | <a href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/manage_comments/in/' . htmlentities($in) .
                '/mod/spam/comment_id/' . $comment['id'] .
                '"><i class="fa fa-exclamation-triangle"></i> Spam</a>';
        }
        else
        {
            echo '<a href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/manage_comments/in/' . htmlentities($in) .
                '/mod/accepted/comment_id/' . $comment['id'] .
                '"><i class="fa fa-check"></i> Menyetujui</a>';
        }
        echo ' | ' . '<a href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/manage_comments/in/' . htmlentities($in) .
            '/mod/delete/comment_id/' . $comment['id'] .
            '" onclick="return confirm(\'Anda yakin ingin menghapus komentar ini?\')">' .
            '<span class="red"><i class="fa fa-times"></i> Hapus</span></a></div></div>';
        ++$i;
    }
    if ($mass_read)
    {
        $postid = implode(',', $mass_read);
        mysql_query("UPDATE `blog_comments` SET `adminread`='1' WHERE `id` IN (" .
            $postid . ")");
    }
    if ($total > $kmess)
    {
        if ($mod == 'unread')
            echo '<p class="text-center margin"><a class="btn btn-default" href="' .
                $home . '/blogpanel/index.php/act/manage_comments/in/' .
                htmlentities($in) . '/mod/unread/refresh/' . time() .
                '"><i class="fa fa-refresh"></i> Refresh</a></p>';
        else
            echo '<div class="topmenu">' . functions::display_pagination($home .
                '/blogpanel/index.php/act/manage_comments/in/' . htmlentities($in) .
                '/mod/' . $status . '/', $start, $total, $kmess) . '</div>';
    }
}
echo '</div></div></div>';
require (dirname(__file__) . '/../../incfiles/end.php');
