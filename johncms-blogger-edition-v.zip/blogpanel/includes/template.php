<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$theme = isset($_GET['theme']) ? ($_GET['theme'] == 'mobile' ? 'mobile' :
    'desktop') : 'mobile';
$mod = in_array($mod, array(
    'preview',
    'upload',
    'edit',
    'download',
    'reset',
    )) ? $mod : 'preview';
if ($mod == 'download')
{
    $file_location = file_exists(ROOTPATH . 'sites/' . $blog['url'] .
        '/templates/' . $theme . '.html') ? ROOTPATH . 'sites/' . $blog['url'] .
        '/templates/' . $theme . '.html' : ROOTPATH . 'incfiles/blog/' . $theme .
        '.html';
    $name = basename($file_location);
    header('Content-Description: File Transfer');
    header('Content-Type: text/html');
    header('Content-Disposition: attachment; filename=' . $name);
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_location));
    readfile($file_location);
    exit();
}
$textl = "Template";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<div class="nav-tabs-custom"><ul class="nav nav-tabs"><li' . ($theme ==
    'mobile' ? ' class="active"' : '') . '><a href="' . $home .
    '/blogpanel/index.php/act/template/mod/' . $mod . '/theme/mobile">' .
    '<i class="fa fa-mobile"></i> Mobile</a></li><li' . ($theme == 'desktop' ?
    ' class="active"' : '') . '><a href="' . $home .
    '/blogpanel/index.php/act/template/mod/' . $mod . '/theme/desktop">' .
    '<i class="fa fa-desktop"></i> Desktop</a></li><li class="pull-right"><a href="//' .
    $blog['url'] . '/?t=' . $theme . '">' .
    '<i class="fa fa-eye"></i> Live preview</a></li></ul>' .
    '<div class="tab-content"><div class="row">';
echo '<div class="col-sm-3"><div class="list-group">' .
    '<a class="list-group-item' . ($mod == 'preview' ? ' active' : '') .
    '" href="' . $home . '/blogpanel/index.php/act/template/mod/preview/theme/' .
    $theme . '"><i class="fa fa-eye"></i> Preview</a>' .
    '<a class="list-group-item' . ($mod == 'upload' ? ' active' : '') .
    '" href="' . $home . '/blogpanel/index.php/act/template/mod/upload/theme/' .
    $theme . '"><i class="fa fa-upload"></i> Upload</a>' .
    '<a class="list-group-item' . ($mod == 'edit' ? ' active' : '') . '" href="' .
    $home . '/blogpanel/index.php/act/template/mod/edit/theme/' . $theme . '">' .
    '<i class="fa fa-edit"></i> edit</a><a class="list-group-item" href="' . $home .
    '/blogpanel/index.php/act/template/mod/download/theme/' . $theme . '">' .
    '<i class="fa fa-download"></i> Download</a><a class="list-group-item" href="' .
    $home . '/templates/index.php/theme/' . $theme . '">' .
    '<i class="fa fa-list"></i> Template lists</a><a class="list-group-item' . ($mod ==
    'reset' ? ' active' : '') . '" href="' . $home .
    '/blogpanel/index.php/act/template/mod/reset/theme/' . $theme . '">' .
    '<i class="fa fa-retweet"></i> Reset to default</a></div></div>';
echo '<div class="col-sm-9">';
switch ($mod)
{
    case 'reset':
        if (isset($_POST['submit']))
        {
            if (file_exists(ROOTPATH . 'sites/' . $blog['url'] . '/templates/' .
                $theme . '.html'))
                @unlink(ROOTPATH . 'sites/' . $blog['url'] . '/templates/' . $theme .
                    '.html');
            echo '<div class="alert alert-success">' .
                'Template berhasil direset ke default sistem.<br /><a class="alert-link" href="' .
                $home . '/blogpanel/index.php/act/template/theme/' . $theme .
                '">' . $lng['back'] . '</a></div>';
        }
        else
        {
            echo '<form method="post" action="' . $home .
                '/blogpanel/index.php/act/template/mod/reset/theme/' . $theme .
                '"><div class="alert alert-warning">Kamu yakin akan mereset template ke default sistem?</div>' .
                '<p><button class="btn btn-primary" type="submit" name="submit">Ya</button>' .
                '&nbsp;<a class="btn btn-default" href="' . $home .
                '/blogpanel/index.php/act/template/theme/' . $theme .
                '">Tidak</a></p></form>';
        }
        break;

    case 'upload':
        $types = array(
            "application/xml",
            "text/xml",
            "text/html",
            "text/xhtml",
            );
        $err = array();
        if (isset($_FILES['fail']))
        {
            $tpl = $_FILES['fail'];
            if (empty($tpl['name']))
                $err[] = 'Silakan pilih file';
            elseif (mb_substr($tpl['name'], -5) != ".html" && mb_substr($tpl['name'],
                -4) != ".xml")
                $err[] = "Ekstensi file tidak benar.";
            elseif (!in_array($tpl['type'], $types))
                $err[] = "Jenis file tidak benar";
            elseif ($tpl['size'] > 501024)
                $err[] = "Ukuran file melebihi 50 kb.";
            if ($err)
                $result = functions::display_error($err);
            else
            {
                if (move_uploaded_file($tpl['tmp_name'], ROOTPATH . 'sites/' . $blog['url'] .
                    '/templates/' . $theme . '.html'))
                {
                    include_once ROOTPATH . 'incfiles/lib/TemplateGenerator.php';
                    $updateContent = new TemplateGenerator(file_get_contents(ROOTPATH .
                        'sites/' . $blog['url'] . '/templates/' . $theme .
                        '.html'));
                    @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                        '/templates/' . $theme . '.html', $updateContent);
                    $result = '<div class="alert alert-success">' .
                        'Template berhasil diupload</div>';
                }
                else
                    $result = functions::display_error('Template gagal diupload');
            }
        }
        echo '<form role="form" method="post" action="' . $home .
            '/blogpanel/index.php/act/template/mod/upload/theme/' . $theme .
            '" enctype="multipart/form-data">' . (isset($result) ? $result : '') .
            '<div class="form-group"><label>File</label>' .
            '<input name="MAX_FILE_SIZE" value="522880" type="hidden"/>' .
            '<input type="file" name="fail"/><p class="help-block">' .
            '<small>Ekstensi file harus .html dan ukuran maksimal 50 kb.</small></p></div>' .
            '<p><button class="btn btn-primary" type="submit">Upload</button></p></form>';
        break;

    case 'edit':
        $file = file_exists(ROOTPATH . 'sites/' . $blog['url'] . '/templates/' .
            $theme . '.html') ? ROOTPATH . 'sites/' . $blog['url'] .
            '/templates/' . $theme . '.html' : ROOTPATH . 'incfiles/blog/' . $theme .
            '.html';
        $code = isset($_POST['code']) ? $_POST['code'] : file_get_contents($file);
        if (isset($_POST['code']))
        {
            if (file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
                '/templates/' . $theme . '.html', $code))
            {
                $result =
                    '<div class="alert alert-success" style="max-width: none !important;">' .
                    'Template berhasil disimpan</div>';
            }
            else
                $result =
                    '<div class="alert alert-danger" style="max-width: none !important;">' .
                    'Template gagal disimpan</div>';
        }
        echo '<form role="form" method="post" action="' . $home .
            '/blogpanel/index.php/act/template/mod/edit/theme/' . $theme . '">' . (isset
            ($result) ? $result : '') .
            '<div class="form-group" style="max-width: none !important;"><textarea class="form-control no-max-width" style="max-width: none !important;" name="code" rows="20">' .
            htmlentities($code) . '</textarea></div>' .
            '<p><button class="btn btn-primary" type="submit">' . $lng['save'] .
            '</button></p></form>';
        break;

    case 'preview':
        echo '<div class="embed-responsive embed-responsive-4by3">' .
            '<iframe src="http://' . $blog['url'] . '/?t=' . $theme .
            '" id="blog_iframe"></iframe></div>';
        break;

    default:
        break;
}
echo '</div>';
echo '</div></div></div>';
require (dirname(__file__) . '/../../incfiles/end.php');
