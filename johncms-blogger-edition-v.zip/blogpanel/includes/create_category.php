<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$title = isset($_POST['title']) ? $_POST['title'] : '';
if (isset($_POST['title']))
{
    $permalink = functions::permalink($title);
    if (mb_strlen($title) < 2 or mb_strlen($title) > 30)
        $error = "Nama kategori harus 2 s/d 30 karakter.";
    $ck = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `user_id`='" .
        mysql_real_escape_string($blog['user_id']) . "'"), 0);
    if ($ck >= 20)
        $error = "Kategori pada blog ini sudah mencapai 20 kategori.";
    $cc = mysql_query("SELECT * FROM `blog_categories` WHERE (`site_id`='" .
        mysql_real_escape_string($blog['id']) . "' AND `user_id`='" .
        mysql_real_escape_string($blog['user_id']) . "') AND (`name`='" .
        mysql_real_escape_string($title) . "' OR `permalink`='" .
        mysql_real_escape_string($permalink) . "')");
    if (mysql_num_rows($cc) != 0)
        $error = "Nama kategori sudah ada.";
    if (empty($error))
    {
        mysql_query("INSERT INTO `blog_categories` SET `site_id`='" .
            mysql_real_escape_string($blog['id']) . "', `user_id`='" .
            mysql_real_escape_string($blog['user_id']) . "', `name`='" .
            mysql_real_escape_string($title) . "', `permalink`='" .
            mysql_real_escape_string($permalink) . "', `counts`='0'");
        mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
            "' WHERE `id` = '" . $blog['user_id'] . "'");
        $_SESSION['notice'] = 'Kategori berhasildibuat.';
        header("location: " . $home .
            "/blogpanel/index.php/act/manage_categories");
        exit();
    }
    else
    {
        $error = '<div class="alert alert-danger">' . $error . '</div>';
    }
}
$textl = "Membuat Kategori";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');

echo '<form method="post" action="' . $set['homeurl'] .
    '/blogpanel/index.php/act/create_category">';
if (isset($error))
    echo $error;
echo '<div class="form-group"><label>Nama kategori</label>' .
    '<input class="form-control" type="text" name="title" value="' .
    htmlspecialchars($title) .
    '"/></div><p><button class="btn btn-primary" type="submit">' .
    'Buat kategori</button></p></form>';
require (dirname(__file__) . '/../../incfiles/end.php');
