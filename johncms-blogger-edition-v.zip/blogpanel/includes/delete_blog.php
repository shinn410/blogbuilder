<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if ($rights >= 7)
{
    $check = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='" .
        mysql_real_escape_string($id) . "'");
}
else
{
    $check = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='" .
        mysql_real_escape_string($id) . "' AND `user_id`='" . $user_id . "'");
}
if (mysql_num_rows($check) == 0)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$blog = mysql_fetch_array($check);

if (!isset($_SESSION['key']))
    $_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit]))
{
    functions::delete_blog($blog);

    unset($_SESSION['key']);
    if ($blog['user_id'] == $user_id)
        header("Location: " . $home . "/blogpanel/");
    else
        header("Location: " . $home . "/users/profile.php/user/" . $blog['user_id']);
    exit;
}
$textl = "Hapus Blog";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form role="form" method="post" action="' . $home .
    '/blogpanel/index.php/act/delete_blog/id/' . $blog['id'] .
    '"><div class="alert alert-warning">Anda yakin akan menghapus Blog ini?</div>' .
    '<p><button class="btn btn-danger" type="submit" name="' . $submit .
    '">Hapus</button> <a class="btn btn-default" data-dismiss="modal" ' .
    'href="javascript:window.history.back()">Batal</a></p></form>';
require (dirname(__file__) . '/../../incfiles/end.php');

?>