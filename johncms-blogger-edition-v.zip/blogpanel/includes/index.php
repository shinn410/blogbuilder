<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

$textl = "Blog Panel";
$breadcrumb = functions::breadcrumb(array(array('label' => $textl)));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<p><a class="func" data-toggle="' . functions::set_modal() .
    '" data-target="#global-modal" href="' . $home .
    '/blogpanel/index.php/act/create_blog"><i class="fa fa-plus"></i> Buat Blog baru</a></p>';
if (isset($_SESSION['notice']))
{
    echo '<div class="alert alert-info">' . htmlentities($_SESSION['notice']) .
        '</div>';
    unset($_SESSION['notice']);
}
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='" . $user_id .
    "' ORDER BY `time` DESC");
$nums = mysql_num_rows($myb);
if ($nums == 0)
{
    echo '<div class="alert alert-info"><p>Anda belum memiliki blog.</p></div>';
}
else
{
    echo '<div class="row">';
    $i = 0;
    while ($blog = mysql_fetch_array($myb))
    {
        echo '<div class="col-sm-6"><div class="panel box ' . ($i % 2 ?
            'box-danger' : ($i % 3 ? 'box-success' : 'box-info')) .
            '"><div class="box-header"><h4 class="box-title pull-right">' .
            '<a href="' . $set['homeurl'] . '/login.php?redirect=' . urlencode('http://' .
            $blog['url']) .
            '" target="_blank"><i class="fa fa-external-link"></i></a></h4><h4 class="box-title">' .
            $blog['url'] . '</h4></div><div class="box-body" style="border-top:' .
            ' 1px dashed #eee;"><dl class="dl-horizontal"><dt>Judul</dt><dd>' .
            htmlspecialchars($blog['title']) . '</dd><dt>URL</dt><dd>http://' .
            $blog['url'] . '</dd><dt>Kategori</dt><dd>' . htmlspecialchars($blog['category']) .
            '</dd><dt>Dibuat</dt><dd>' . functions::display_date($blog['time']) .
            '</dd><dt>Menunggu moderasi</dt><dd>' . ucfirst($blog['mod_reg']) .
            '</dd><dt>Pemblokiran</dt><dd>' . ucfirst($blog['block']) .
            '</dd></dl><p><a class="btn pull-right"' . ' data-toggle="' .
            functions::set_modal() . '" data-target="#deleteblog" href="' . $home .
            '/blogpanel/index.php/act/delete_blog/id/' . $blog['id'] .
            '"><i class="fa fa-times"></i> Delete</a><a class="btn"' . ' href="' .
            $home . '/blogpanel/index.php/act/switch/id/' . $blog['id'] .
            '"><i class="fa fa-sign-in"></i> Switch</a></p></div></div></div>';
        ++$i;
    }
    echo '</div>';
}
echo functions::modal('', array('id' => 'deleteblog', 'title' => 'Delete Blog'));
require (dirname(__file__) . '/../../incfiles/end.php');
