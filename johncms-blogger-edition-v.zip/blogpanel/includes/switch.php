<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if ($id)
{
    if ($rights == 7 || $rights == 9)
    {
        $check = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `id`='" .
            $id . "'"), 0);
    }
    else
    {
        $check = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `id`='" .
            $id . "' AND `user_id`='" . $user_id . "'"), 0);
    }
    if ($check == 1)
    {
        $_SESSION['blog_id'] = $id;
        if (isset($_GET['redir']))
        {
            echo '<html><head><meta http-equiv="Refresh" content="0;URL=' .
                htmlentities(base64_decode($_GET['redir'])) .
                '" /></head><body><p>Mohon tunggu sebentar atau <a href="' .
                htmlentities(base64_decode($_GET['redir'])) .
                '">klik di sini</a> untuk melanjutkan.</p></body></html>';
        }
        else
            header("Location: " . $set['url'] .
                "/blogpanel/index.php/act/dashboard");
        exit();
    }
}
header("Location: " . $set['url'] . "/blogpanel/");
exit();
