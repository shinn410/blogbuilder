<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
function FileName($var)
{
    $var = functions::permalink($var);
    return strlen($var) > 30 ? substr($var, 0, 30) : $var;
}
$file_extensions = array(
    'rar',
    'zip',
    'pdf',
    'tar',
    'gz',
    'ico',
    'jpg',
    'jpeg',
    'gif',
    'png',
    'bmp',
    '3gp',
    'mp3',
    'amr',
    'mp4',
    'avi',
    'mpg',
    'sis',
    'thm',
    'jar',
    'jad',
    'apk',
    'cab',
    'sisx',
    'exe',
    'msi',
    'nth',
    'thm',
    'css',
    'txt',
    'xml',
    );
if (isset($_GET['delete']))
{
    $delete = trim($_GET['delete']);
    $head = '<meta http-equiv="Refresh" content="1;URL=' . $home .
        '/blogpanel/index.php/act/files/page/' . $page . '" />';
}
if (!isset($_SESSION['key']))
    $_SESSION['key'] = md5(time());
$key = $_SESSION['key'];
if (isset($_POST[$key]))
{
    unset($_SESSION['key']);
    $key = $_SESSION['key'] = md5(time());
    $ffile = $_FILES['berkas']['tmp_name'];
    $fname = strtolower($_FILES['berkas']['name']);
    $fsize = $_FILES['berkas']['size'];
    if ($fsize >= 1024 * $set['flsz'])
        $error = "Ukuran File tidak boleh lebih dari " . $set['flsz'] . " Kb.";
    $ext = functions::get_file_ext($fname);
    $fname = functions::permalink(substr($fname, 0, "-" . (strlen($ext) + 1)));
    $fname = mb_strlen($fname) > 30 ? mb_substr($fname, 0, 30) : $fname;
    $filename = $fname . '.' . $ext;
    if (!in_array($ext, $file_extensions))
        $error = "Ekstensi File tidak diijinkan";
    if (empty($fname))
        $error = "Silakan pilih File.";
    if (!isset($error))
    {
        if (move_uploaded_file($ffile, dirname(__file__) . '/../../sites/' . $blog['url'] .
            '/contents/' . $filename))
            $result = '<div class="alert alert-success">File <a href="//' . $blog['url'] .
                '/content/' . $filename . '">' . $filename .
                '</a> berhasil diupload.</div>';
        else
            $result =
                '<div class="alert alert-danger">File gagal diupload</div>';
    }
    else
    {
        $result = '<div class="alert alert-danger">' . $error . '</div>';
    }
}
$textl = 'Files';
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<div class="gmenu"><form role="form" action="' . $home .
    '/blogpanel/index.php/act/files" method="post" enctype="multipart/form-data">' . (isset
    ($result) ? $result : '') .
    '<div class="form-group"><label>Upload file</label>' .
    '<input type="file" name="berkas"/><p class="help-block">Maksimal ukuran ' .
    $set['flsz'] . ' kb</p></div>' .
    '<p><button class="btn btn-primary" type="submit" name="' . $key .
    '">Upload</button></p></form></div>';

$files = glob(dirname(__file__) . '/../../sites/' . $blog['url'] . '/contents/*');
if ($files != false)
{
    foreach ($files as $rfile)
    {
        $fail[] = array(
            filemtime($rfile),
            basename($rfile),
            filesize($rfile));
    }
    if ($fail)
        rsort($fail);
}

if ($files == false)
    $total = 0;
else
    $total = (int)count($files);
if ($total)
{
    $end = $start + $kmess;
    if ($end > $total)
        $end = $total;
    for ($e = $start; $e < $end; $e++)
    {
        $ft = functions::display_date($fail[$e][0]);
        $fs = round($fail[$e][2] / 1024, 2);
        $name = $fail[$e][1];
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
        if (isset($delete) && $delete == $name)
        {
            unlink(dirname(__file__) . '/../../sites/' . $blog['url'] .
                '/contents/' . $name);
            echo '<div class="alert alert-success">File <strong>' . $name .
                '</strong> berhasil dihapus, harap tunggu atau <a class="alert alert-link" href="' .
                $home . '/blogpanel/index.php/act/files/page/' . $page .
                '">klik di sini</a> untuk melanjutkan</div>';
        }
        else
        {
            echo '<a href="//' . $blog['url'] . '/content/' . $name . '">' . $name .
                '</a><div class="sub"><div><a href="' . $set['homeurl'] .
                '/blogpanel/index.php/act/files/page/' . $page . '/delete/' . $name .
                '" ' . 'onclick="return confirm(\'Kamu yakin akan menghapus file ini?\')">' .
                '<span class="red"><i class="fa fa-times"></i> Hapus</span></a></div>';
            echo '<div class="gray">Uploaded: ' . $ft . '<br/>Size: ' . $fs .
                ' kb</div></div>';
        }
        echo '</div>';
        ++$i;
    }
    if ($total > $kmess)
        echo '<div class="topmenu">' . functions::display_pagination($set['homeurl'] .
            '/blogpanel/index.php/act/files/', $start, $total, $kmess) .
            '</div>';
}
else
{
    echo '<div class="alert alert-warning">' . $lng['list_empty'] . '</div>';
}
require (dirname(__file__) . '/../../incfiles/end.php');
