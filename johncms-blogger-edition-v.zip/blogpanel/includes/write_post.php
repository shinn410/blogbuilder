<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
$foot = '';
if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}

$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;
$mode = isset($_REQUEST['mode']) ? (in_array($_REQUEST['mode'], array('bbcode',
        'html')) ? $_REQUEST['mode'] : 'html') : 'html';
function permalink($var)
{
    global $blog;
    $var = functions::permalink($var);
    $cek = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE `user_id`='" .
        $blog['user_id'] . "' AND `permalink`='" . mysql_real_escape_string($var) .
        "'"), 0);
    if ($cek == 0)
    {
        $var = $var;
    }
    else
    {
        $num = $cek + 1;
        $var = $var . "-" . $num;
    }
    return $var;
}

$ttl = isset($_POST['title']) ? trim($_POST['title']) : '';
$dcs = isset($_POST['description']) ? trim($_POST['description']) : '';
$nlbr = isset($_POST['nlbr']) ? $_POST['nlbr'] : 0;
if ($nlbr == 1 && $mode == 'html')
{
    $dcs = str_replace("\n", "<br />", str_replace("\r", "<br />", str_replace("\r\n",
        "<br />", $dcs)));
}

$cat = isset($_POST['category']) ? trim($_POST['category']) : '';
$new_cat = $cat == 'NEW' ? true : false;
$category_name = isset($_POST['NEW_CATEGORY']) ? trim($_POST['NEW_CATEGORY']) :
    '';
$tags = isset($_POST['tags']) ? trim(strtolower($_POST['tags'])) : '';
$privacy = isset($_POST['privacy']) ? ($_POST['privacy'] == 'publics' ?
    'publics' : 'friends') : 'publics';
if (isset($_POST['pilih_berkas']))
{
    $images = array(
        'jpg',
        'png',
        'gif',
        );
    $berkas = htmlentities(trim($_POST['berkas']));
    if ($berkas != '')
    {
        if ($mode == 'html')
        {
            if (in_array(functions::get_file_ext($berkas), $images))
                $dcs = $dcs . "\n<img src=\"http://{$blog['url']}/content/$berkas\" alt=\"$berkas\"/>";
            else
                $dcs = $dcs . "\n<a href=\"http://{$blog['url']}/content/$berkas\">$berkas</a>";
        }
        else
        {
            if (in_array(functions::get_file_ext($berkas), $images))
                $dcs = $dcs . "\n[img]http://{$blog['url']}/content/{$berkas}[/img]";
            else
                $dcs = $dcs . "\n[url=http://{$blog['url']}/content/{$berkas}]{$berkas}[/url]";
        }
    }
}
if (isset($_POST['publish']) || isset($_POST['preview']))
{
    $error = array();
    $tags = SaveTags($tags);
    $key = isset($_POST['key']) ? strtolower($_POST['key']) : false;
    $time_published = strtotime(str_replace('/', '-', @$_POST['time_published']) .
        ':00');
    $default_time = strtotime(str_replace('/', '-', $_POST['default_time']) .
        ':00');
    if ($time_published < (time() + $shift))
    {
        $waktu = time();
        $draft = "no";
    }
    elseif ($time_published < $default_time)
    {
        $waktu = time();
        $draft = "no";
    }
    else
    {
        $waktu = $time_published - $shift;
        $draft = "yes";
    }

    if (empty($_SESSION['key']) or $_SESSION['key'] != $key)
        $error[] = "Session tidak benar.";
    if ($cat == 'NEW')
    {
        $cat_permalink = functions::permalink($category_name);
        if (mb_strlen($category_name) < 2 or mb_strlen($category_name) > 30)
            $error[] = "Nama kategori baru harus 2 s/d 30 karakter.";
        $ck = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "'"), 0);
        if ($ck >= 20)
            $error[] = "Kategori sudah mencapai 20.";
        $cc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "' AND `permalink`='" .
            mysql_real_escape_string($cat_permalink) . "'");
        if (mysql_num_rows($cc) != 0)
            $error[] = "Nama kategori sudah ada.";
        if (empty($error))
        {
            $cat = $cat_permalink;
        }
    }
    else
    {
        $bc = mysql_result(mysql_query("SELECT COUNT(`permalink`) FROM `blog_categories` WHERE `site_id`='" .
            mysql_real_escape_string($blog['id']) . "' AND `permalink`='" .
            mysql_real_escape_string($cat) . "'"), 0);
        if ($bc == 0)
            $error[] = "Blog atau kategori yang dipilih tidak benar.";
    }
    if (mb_strlen($ttl) < 2 or mb_strlen($ttl) > 100)
        $error[] = "Judul harus 2 s/d 100 karakter.";
    if (mb_strlen($dcs) < 10)
        $error[] = "Deskripsi minimal 10 karakter";
    if (empty($error))
    {
        mysql_query("INSERT INTO `blog_posts` SET `site_id` = '" .
            mysql_real_escape_string($blog['id']) . "', `user_id`='" . $blog['user_id'] .
            "', `title` = '" . mysql_real_escape_string($ttl) .
            "', `description` = '" . mysql_real_escape_string($dcs) .
            "', `category` = '" . mysql_real_escape_string($cat) .
            "', `tags` = '" . mysql_real_escape_string($tags) .
            "', `permalink` = '" . mysql_real_escape_string(permalink($ttl)) .
            "', `privacy` = '" . mysql_real_escape_string($privacy) .
            "', `draft` = '" . mysql_real_escape_string($draft) .
            "', `mode` = '" . mysql_real_escape_string($mode) . "', `time` = '" .
            mysql_real_escape_string($waktu) . "'");
        if ($_POST['category'] == 'NEW')
        {
            mysql_query("INSERT INTO `blog_categories` SET `site_id`='" .
                mysql_real_escape_string($blog['id']) . "', `user_id`='" .
                mysql_real_escape_string($blog['user_id']) . "', `name`='" .
                mysql_real_escape_string($category_name) . "', `permalink`='" .
                mysql_real_escape_string($cat_permalink) . "', `counts`='1'");
        }
        else
        {
            mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='" .
                mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
                "' AND `permalink`='" . mysql_real_escape_string($cat) . "'");
        }
        mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
            "' WHERE `id` = '" . $blog['user_id'] . "'");
        $_SESSION['notice'] = 'Posting berhasil disimpan';
        header("location: " . $home . "/blogpanel/index.php/act/manage_posts");
        exit();
    }
    else
    {
        $error = '<div class="alert alert-danger">' . implode('<br />', $error) .
            '</div>';
    }
}
$textl = "Menulis Posting";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form method="post" action="' . $set['homeurl'] .
    '/blogpanel/index.php/act/write_post" id="post-form" name="form1">';
if (@$error)
    echo $error;
echo '<div class="form-group"><label>Judul</label>' .
    '<input class="form-control" type="text" name="title" value="' .
    htmlentities($ttl) . '" required/></div>';
echo '<div class="form-group"><label>Deskripsi</label>' . ($mode == 'bbcode' ?
    '<p>' . bbcode::auto_bb('form1', 'description', 1) . '</p>' : '') .
    '<textarea class="form-control" rows="8" name="description" required>' .
    htmlspecialchars($dcs) . '</textarea>' .
    '<p class="help-block"><i class="fa fa-exchange"></i> ' . ($mode == 'html' ?
    'Beralih ke mode <a id="mode" onclick="return confirm(\'' .
    'Pastikan sebelum beralih mode penulisan Anda sudah menyalin teks!\')"href="' .
    $home . '/blogpanel/index.php/act/write_post/mode/bbcode">BBCode</a></p>' :
    'Beralih ke mode <a id="mode" onclick="return confirm(\'' .
    'Pastikan sebelum beralih mode penulisan Anda sudah menyalin teks!\')" href="' .
    $home . '/blogpanel/index.php/act/write_post/mode/html">HTML</a>') . '</p>';
if ($mode == 'html')
    echo '<div class="checkbox"><label><input type="checkbox" name="nlbr" value="1"' . ($nlbr ==
        1 ? ' checked="checked"' : '') .
        '> Replace new line to &lt;br /&gt;</label></div>';
echo '</div>';
$files = glob(dirname(__file__) . '/../../sites/' . $blog['url'] . '/contents/*');
if ($files != false)
{
    foreach ($files as $rfile)
    {
        $fail[] = basename($rfile);
    }
    if ($fail)
        rsort($fail);
}

if ($files == false)
    $tfile = 0;
else
    $tfile = (int)count($files);
if ($tfile > 0)
{
    echo '<div class="form-group"><label>Masukan berkas</label>' .
        '<div class="input-group"><select class="form-control" name="berkas">' .
        '<option value="" selected="selected">   </option>';
    for ($i = 0; $i < $tfile; $i++)
    {
        echo '<option value="' . $fail[$i] . '">' . $fail[$i] . '</option>';
    }
    echo '</select><span class="input-group-btn"><button class="btn btn-default" type="submit" ' .
        'name="pilih_berkas">Pilih</button></span></div>';
    $jquery .= '$(\'[name="berkas"]\').change(function(){var berkas=$(this).val();if(berkas=="")' .
        'return;var mode = "' . $mode .
        '";var ext=berkas.substr(-4);if(ext==".jpg"||ext==".png"||ext==".gif"||ext==".png")' .
        '{if(mode == "html"){var data=\'<img src="http://' . $blog['url'] .
        '/content/\'+berkas+\'" alt="\'+berkas+\'"/>\';}' . 'else{var data=\'[img]http://' .
        $blog['url'] . '/content/\'+berkas+\'[/img]\';}}' .
        'else{if(mode == "html"){var data=\'<a href="http://' . $blog['url'] .
        '/content/\'+berkas+\'">\'+berkas+\'</a>\';}' . 'else{var data=\'[url=http://' .
        $blog['url'] . '/content/\'+berkas+\']\'+berkas+\'[/url]\';}}' .
        'var desc=$(\'[name="description"]\').val();$(\'[name="description"]\').val(desc+\'\n\'+data);});';
}

echo '<div class="form-group test"><label>Kategori</label>';
$bcats = mysql_query("SELECT `name`,`permalink` FROM `blog_categories` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "'");
$c = 1;
if (mysql_num_rows($bcats) > 0)
{
    while ($bcat = mysql_fetch_array($bcats))
    {
        echo '<div class="radio"><label><input type="radio" name="category" value="' .
            $bcat['permalink'] . '"' . ($cat == $bcat['permalink'] ?
            ' checked="checked"' : '') . '/> ' . htmlspecialchars($bcat['name']) .
            '</label></div>';
        $c++;
    }
}
if ($c < 20)
{
    echo '<div class="input-group"><span class="input-group-addon">' .
        '<input type="radio" name="category" value="NEW"' . ($new_cat ?
        ' checked="checked"' : '') . '/></span>' .
        '<input type="text" class="form-control" name="NEW_CATEGORY" value="' . ($new_cat ?
        htmlspecialchars($category_name) : '') .
        '" placeholder="Create new category"/>' . '</div>';
}
echo '</div><div class="form-group"><label>Tags</label>' .
    '<input class="form-control" type="text" name="tags" value="' .
    htmlspecialchars($tags) .
    '"/><p class="help-block">Pisahkan dengan koma (,)</p></div>' .
    '<div class="radio"><label><input type="radio" name="privacy" value="publics"' . ($privacy ==
    "publics" ? ' checked="checked"' : '') .
    '> Semua orang boleh melihat postingan ini</label></div>' .
    '<div class="radio"><label><input type="radio" name="privacy" value="friends"' . ($privacy ==
    "friends" ? ' checked="checked"' : '') .
    '> Hanya teman yang boleh melihat postingan ini</label></div>';
$taim = time();
echo '<div class="form-group"><label>Waktu penerbitan</label>' .
    '<div class="input-group" id="datemask"><div class="input-group-addon">' .
    '<i class="fa fa-calendar"></i></div>' .
    '<input type="text" class="form-control" name="time_published" data-inputmask="\'alias\': \'datetime\'" value="' .
    date("d/m/Y H:i", ($taim + $shift)) .
    '" data-mask="1" disabled="disabled" maxlength="16"/>' .
    '</div><!-- /.input group --></div><!-- /.form group -->';
$_SESSION['key'] = md5(time());
echo '<input type="hidden" name="default_time" value="' . date("d/m/Y H:i", ($taim +
    $shift)) . '"><input type="hidden" name="key" value="' . $_SESSION['key'] .
    '">' . '<input type="hidden" name="mode" value="' . $mode .
    '"></p><p><button class="btn btn-primary" type="submit" name="publish">Terbitkan</button>' .
    ' <button class="btn btn-primary" type="submit" name="preview">Preview</button></p></form>';
$foot .= '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>' .
    '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>' .
    '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>';
$jquery .= '$("[data-mask]").inputmask();$("#datemask").click(function(event){event.preventDefault();' .
    '$("#datemask input").prop("disabled",false);});';
require (dirname(__file__) . '/../../incfiles/end.php');
