<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
if (($rights >= 7) && $id)
    $bID = $id;
else
    $bID = false;
if (($blog = get_blog($bID)) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$blogdomains = unserialize($set['blogdomains']);
if ($set['blogediturl'] == "yes")
{
    $edit = explode(".", $blog['url2'], 2);
    $subdomain = isset($_POST['subdomain']) ? strtolower($_POST['subdomain']) :
        $edit[0];
    $subdomain = functions::permalink($subdomain);
    $domain = isset($_POST['domain']) ? strtolower($_POST['domain']) : $edit[1];
}
$bset = unserialize($blog['settings']);
$cset = array();
$ttl = isset($_POST['title']) ? $_POST['title'] : trim($blog['title']);
$cset['description'] = isset($_POST['description']) ? trim($_POST['description']) :
    $bset['description'];
$cset['keywords'] = isset($_POST['keywords']) ? strtolower(trim($_POST['keywords'])) :
    $bset['keywords'];
$category = isset($_POST['category']) ? $_POST['category'] : $blog['category'];
$cset['metagoogle'] = isset($_POST['metagoogle']) ? trim($_POST['metagoogle']) :
    $bset['metagoogle'];
$cset['moderatecomment'] = isset($_POST['modcomment']) ? 'yes' : 'no';
$cset['captchacomment'] = isset($_POST['comcaptcha']) ? 'yes' : 'no';
$cset['emailcomment'] = isset($_POST['comemail']) ? 'yes' : 'no';
$cset['postperpage'] = isset($_POST['perpage']) ? abs(intval($_POST['perpage'])) :
    $bset['postperpage'];
$blog_categories = unserialize($set['blogcategories']);
if (isset($_POST['save']))
{
    $error = array();
    if ($set['blogediturl'] == "yes")
    {
        $url = $subdomain . '.' . $domain;
        $url2 = $subdomain . '.' . $domain;
        if ($url2 == $blog['url2'])
        {
            $url = $blog['url'];
            $url2 = $blog['url2'];
        }
        else
        {
            if (substr($subdomain, 0, 1) == "-" or substr($subdomain, -1) == "-")
                $error[] =
                    "Subdomain harus diawali dan diakhiri huruf atau angka.";
            $dof = explode(",", $set['blogsubdomaindisallow'] . ",www1,www2");
            if (in_array($subdomain, $dof) || is_dir("../" . $subdomain))
                $error[] = "Subdomain tidak diijinkan.";
            if (!in_array($domain, $blogdomains))
                $error[] = "Domain tidak benar.";
            $tb = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `url`='" .
                mysql_real_escape_string($url) . "' OR `url`='" .
                mysql_real_escape_string($url2) . "' OR `url2`='" .
                mysql_real_escape_string($url) . "' OR `url2`='" .
                mysql_real_escape_string($url2) . "'"), 0);
            if ($tb != 0)
                $error[] = 'Alamat blog ' . $url .
                    ' sudah terdaftar. (<a href="' . $set['homeurl'] .
                    '/pages/whois.php?domain=' . $subdomain . '.' . $domain .
                    '">WHOIS</a>)';
            if (mb_strlen($subdomain) < 4 or mb_strlen($subdomain) > 30)
                $error[] = "Subdomain minimal 4 dan maksimal 30 karakter.";
        }
    }
    else
    {
        $url = $blog['url'];
        $url2 = $blog['url2'];
    }
    if (mb_strlen($ttl) < 2 or mb_strlen($ttl) > 30)
        $error[] = "Judul minimal 2 dan maksimal 30 karakter.";
    if (mb_strlen($cset['description']) > 200)
        $error[] = "Deskripsi minimal 2 dan maksimal 100 karakter";
    if (mb_strlen($cset['keywords']) > 200)
        $error[] = "Keywords maksimal 200 karakter";
    if (mb_strlen($cset['metagoogle']) > 100)
        $error[] = "Meta tag Google maksimal 100 karakter";
    if (!in_array($category, $blog_categories))
        $error[] = 'Kategori tidak benar';

    if (empty($error))
    {
        $settings = serialize(array_merge($bset, $cset));
        $moduls = $rights >= 7 ? serialize(preg_split("/[\s,]+/", $_POST['moduls'])) :
            $blog['moduls'];
        mysql_query("UPDATE `blog_sites` SET `title` = '" .
            mysql_real_escape_string(functions::checkin($ttl)) . "', `url`='" .
            mysql_real_escape_string($url) . "', `url2`='" .
            mysql_real_escape_string($url2) . "', `settings` = '" .
            mysql_real_escape_string($settings) . "', `category` = '" .
            mysql_real_escape_string($category) . "', `moduls` = '" .
            mysql_real_escape_string($moduls) . "' WHERE `id`='" . $blog['id'] .
            "'");
        mysql_query("UPDATE `users` SET `www`='" . mysql_real_escape_string('http://' .
            $url) . "' WHERE `id`='" . $blog['user_id'] . "'");
        if ($blog['user_id'] == $user_id)
        {
            $_SESSION['notice'] = 'Blog berhasil diperbarui.';
            header("location: " . $set['url'] .
                "/blogpanel/index.php/act/dashboard");
            exit();
        }
        else
            $result =
                '<div class="alert alert-success">Perubahan berhasil disimpan.</div>';
    }
    else
    {
        $result = functions::display_error($error);
    }
}
$textl = 'Pengaturan';
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form role="form" method="post" action="' . $home .
    '/blogpanel/index.php/act/settings/' . (($rights == 7 || $rights == 9) && $id ?
    'id/' . $id : '') . '">';
if (isset($result))
    echo $result;
if ($set['blogediturl'] == "yes")
{
    echo '<div class="form-group"><label>Subdomain</label>' .
        '<input class="form-control" type="text" name="subdomain" value="' .
        htmlspecialchars($subdomain) . '"/></div>';
    echo '<div class="form-group"><label>Domain</label>' .
        '<select class="form-control" name="domain">';
    foreach ($blogdomains as $domainsite)
    {
        echo '<option value="' . $domainsite . '"' . ($edit[1] == $domainsite ?
            ' selected="selected"' : '') . '>' . $domainsite . '</option>';
    }
    echo '</select></div>';
}
echo '<div class="form-group"><label>Judul</label>' .
    '<input class="form-control" type="text" name="title" value="' .
    htmlspecialchars($ttl) . '"/></div>';
echo '<div class="form-group"><label>Keywords</label>' .
    '<input class="form-control" type="text" name="keywords" value="' .
    htmlspecialchars($cset['keywords']) . '"/></div>';
echo '<div class="form-group"><label>Deskripsi</label>' .
    '<textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="description">' . htmlspecialchars($cset['description']) .
    '</textarea></div>';
echo '<div class="form-group"><label>Kategori</label>' .
    '<select class="form-control" name="category">';
foreach ($blog_categories as $cat)
{
    echo '<option value="' . $cat . '"' . ($category == $cat ?
        ' selected="selected"' : '') . '>' . htmlspecialchars($cat) .
        '</option>';
}
echo '</select></div>';
echo '<div class="form-group"><label>Meta tag Google</label>' .
    '<input class="form-control" type="text" name="metagoogle" value="' .
    htmlspecialchars($cset['metagoogle']) . '"/></div>';
if ($rights >= 7)
{
    echo '<div class="form-group"><label>Modules</label>' .
        '<input class="form-control" type="text" name="moduls" value="' .
        implode(',', unserialize($blog['moduls'])) . '"/></div>';
}
echo '<div class="form-group"><label>Jumlah posting pada halaman awal</label>' .
    '<select class="form-control" name="perpage">';
for ($i = 1; $i <= 20; $i++)
{
    echo '<option value="' . $i . '"' . ($cset['postperpage'] == $i ?
        ' selected="selected"' : '') . '>' . $i . ' posting</option>';
}
echo '</select></div>';

echo '<div class="checkbox"><label>' .
    '<input type="checkbox" name="modcomment" value="yes"' . ($bset['moderatecomment'] ==
    "yes" ? ' checked="checked"' : '') . '> Moderasi komentar</label></div>';
echo '<div class="checkbox"><label>' .
    '<input type="checkbox" name="comcaptcha" value="yes"' . ($bset['captchacomment'] ==
    "yes" ? ' checked="checked"' : '') . '> Captcha pada komentar</label></div>';
echo '<div class="checkbox"><label>' .
    '<input type="checkbox" name="comemail" value="yes"' . ($bset['emailcomment'] ==
    "yes" ? ' checked="checked"' : '') . '> Email pada komentar</label></div>';

echo '<p><button class="btn btn-primary" type="submit" name="save">Simpan</button></p>';
echo '</form>';
require (dirname(__file__) . '/../../incfiles/end.php');
