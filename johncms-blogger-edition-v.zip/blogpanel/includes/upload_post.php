<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;

function permalink($var)
{
    global $bl;
    $var = functions::permalink($var);
    $cek = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE `user_id`='" .
        $bl['user_id'] . "' AND `permalink`='" . mysql_real_escape_string($var) .
        "'"), 0);
    if ($cek == 0)
    {
        $var = $var;
    }
    else
    {
        $num = $cek + 1;
        $var = $var . "-" . $num;
    }
    return $var;
}
if (($bl = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$ttl = isset($_POST['title']) ? $_POST['title'] : '';

$cat = isset($_POST['category']) ? $_POST['category'] : '';
$tags = isset($_POST['tags']) ? strtolower($_POST['tags']) : '';
$privacy = isset($_POST['privacy']) ? ($_POST['privacy'] == 'publics' ?
    'publics' : 'friends') : 'publics';
if (isset($_POST['publish']))
{
    $error = array();
    $desc = $_FILES['description']['tmp_name'];
    $nlbr = isset($_POST['nlbr']) ? $_POST['nlbr'] : 0;
    if ($nlbr == 1)
    {
        $dcs = str_replace("\n", "<br />", str_replace("\r", "<br />",
            str_replace("\r\n", "<br />", $dcs)));
    }
    $tags = SaveTags($tags);
    $key = $_POST['key'];
    $time_published = strtotime(str_replace('/', '-', @$_POST['time_published']) .
        ':00');
    $default_time = strtotime(str_replace('/', '-', $_POST['default_time']) .
        ':00');
    if ($time_published < $default_time)
    {
        $waktu = time();
        $draft = "no";
    }
    else
    {
        $waktu = $time_published - $shift;
        $draft = "yes";
    }
    if (mb_strlen($ttl) < 2 or mb_strlen($ttl) > 100)
        $error[] = "Judul harus 2 s/d 100 karakter.";
    if (empty($_FILES['description']['name']))
        $error[] = "Silakan pilih file";
    elseif ($_FILES['description']['type'] != "text/plain")
        $error[] = "File harus berekstensi TXT";
    elseif ($_FILES['description']['size'] > 501024)
        $error[] = "File maksimal berukuran 50kb";
    elseif ($desc != '')
    {
        $hand = fopen($desc, "r");
        $dcs = fread($hand, $_FILES['description']['size']);
        fclose($hand);
    }
    elseif (mb_strlen($dcs) < 10)
        $error[] = "Deskripsi minimal 10 karakter";
    if (empty($_SESSION['key']) or $_SESSION['key'] != $key)
        $error[] = "Session tidak benar.";
    $bc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
        mysql_real_escape_string($bl['id']) . "' AND `user_id`='" . $bl['user_id'] .
        "' AND `permalink`='" . mysql_real_escape_string($cat) . "'");
    if (mysql_num_rows($bc) == 0)
        $error[] = "Blog atau kategori yang dipilih tidak benar.";
    if (empty($error))
    {
        mysql_query("INSERT INTO `blog_posts` SET `site_id` = '" .
            mysql_real_escape_string($bl['id']) . "', `user_id`='" . $bl['user_id'] .
            "', `title` = '" . mysql_real_escape_string($ttl) .
            "', `description` = '" . mysql_real_escape_string($dcs) .
            "', `category` = '" . mysql_real_escape_string($cat) .
            "', `tags` = '" . mysql_real_escape_string($tags) .
            "', `permalink` = '" . mysql_real_escape_string(permalink($ttl)) .
            "', `privacy` = '" . mysql_real_escape_string($privacy) .
            "', `draft` = '" . mysql_real_escape_string($draft) .
            "', `time` = '" . mysql_real_escape_string($waktu) . "'");

        mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='" .
            mysql_real_escape_string($bl['id']) . "' AND `user_id`='" . $bl['user_id'] .
            "' AND `permalink`='" . mysql_real_escape_string($cat) . "'");
        mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
            "' WHERE `id` = '" . $bl['user_id'] . "'");
        $_SESSION['notice'] = 'Posting berhasil disimpan';
        header("location: " . $home . "/blogpanel/index.php/act/manage_posts");
        exit;
    }
    else
    {
        $error = '<div class="alert alert-danger">' . implode('<br />', $error) .
            '</div>';
    }
}
$textl = "Upload Posting";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $bl['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form method="post" action="' . $set['homeurl'] .
    '/blogpanel/index.php/act/upload_post" enctype="multipart/form-data">';
if (@$error)
    echo $error;
echo '<div class="form-group"><label>Judul</label>' .
    '<input class="form-control" type="text" name="title" value="' .
    htmlspecialchars($ttl) . '"/></div>' .
    '<div class="form-group"><label>Deskripsi</label>' .
    '<input type="file" name="description"/>' .
    '<p class="help-block">Harus file TXT</span><p/></div>' .
    '<div class="checkbox"><label><input type="checkbox" name="nlbr" value="1">' .
    ' Replace new line to &lt;br /&gt;</label></div>' .
    '<div class="form-group"><label>Kategori</label>' .
    '<select class="form-control" name="category">';
$bcats = mysql_query("SELECT `name`,`permalink` FROM `blog_categories` WHERE `site_id`='" .
    mysql_real_escape_string($bl['id']) . "' AND `user_id`='" . $bl['user_id'] .
    "'");
if (mysql_num_rows($bcats) == 0)
{
}
else
{
    while ($bcat = mysql_fetch_array($bcats))
    {
        echo '<option value="' . $bcat['permalink'] . '"' . ($cat == $bcat['permalink'] ?
            ' selected="selected"' : '') . '>' . htmlspecialchars($bcat['name']) .
            '</option>';
    }
}
echo '</select></div><div class="form-group"><label>Tags</label>' .
    '<input class="form-control" type="text" name="tags" value="' .
    htmlspecialchars($tags) .
    '"/><p class="help-block">Pisahkan dengan koma (,)</p></div>' .
    '<div class="radio"><label><input type="radio" name="privacy" value="publics"' . ($privacy ==
    "publics" ? ' checked="checked"' : '') .
    '> Semua orang boleh melihat postingan ini</label></div>' .
    '<div class="radio"><label><input type="radio" name="privacy" value="friends"' . ($privacy ==
    "friends" ? ' checked="checked"' : '') .
    '> Hanya teman yang boleh melihat postingan ini</label></div>';
$taim = time();
echo '<div class="form-group"><label>Waktu penerbitan</label>' .
    '<div class="input-group" id="datemask"><div class="input-group-addon">' .
    '<i class="fa fa-calendar"></i></div>' .
    '<input type="text" class="form-control" name="time_published" data-inputmask="\'alias\': \'datetime\'" value="' .
    date("d/m/Y H:i", ($taim + $shift)) .
    '" data-mask="1" disabled="disabled" maxlength="16"/>' .
    '</div><!-- /.input group --></div><!-- /.form group -->';
echo '<input type="hidden" name="default_time" value="' . date("d/m/Y H:i", ($taim +
    $shift)) . '">';
$_SESSION['key'] = md5(time());
echo '<input type="hidden" name="key" value="' . $_SESSION['key'] .
    '"></p><p><input class="btn btn-primary" type="submit" name="publish" value="Terbitkan"/></p></form>';
$foot = '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>' .
    '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>' .
    '<script src="' . $home .
    '/theme/default/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>';
$jquery .= '$("[data-mask]").inputmask();$("#datemask").click(function(event){event.preventDefault();' .
    '$("#datemask input").prop("disabled",false);});';
require (dirname(__file__) . '/../../incfiles/end.php');
