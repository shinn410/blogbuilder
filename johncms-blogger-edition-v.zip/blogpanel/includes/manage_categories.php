<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
$textl = "Kelola Kategori";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
if (isset($_SESSION['notice']))
{
    echo '<div class="alert alert-info">' . htmlentities($_SESSION['notice']) .
        '</div>';
    unset($_SESSION['notice']);
}
echo '<p><a class="func" data-toggle="' . functions::set_modal() .
    '" data-target="#global-modal" href="' . $home .
    '/blogpanel/index.php/act/create_category"><i class="fa fa-plus"></i> Membuat Kategori</a></p>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "'"), 0);
$ctg = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
    mysql_real_escape_string($blog['id']) . "' AND `user_id`='" . $blog['user_id'] .
    "' ORDER BY `name` ASC LIMIT $start,$kmess");
if ($total > $kmess)
    echo '<div class="topmenu">' . functions::display_pagination($home .
        '/blogpanel/index.php/act/manage_categories/', $start, $total, $kmess) .
        '</div>';
while ($cat = mysql_fetch_array($ctg))
{
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    $total_posts = $cat['counts'];
    echo '<div><a class="badge pull-right" href="' . $set['homeurl'] .
        '/blogpanel/index.php/act/manage_posts/category/' . $cat['permalink'] .
        '">' . $total_posts . '</a><strong>' . htmlspecialchars($cat['name']) .
        '</strong></div>';
    echo '<div class="sub"><a data-toggle="' . functions::set_modal() .
        '" data-target="#global-modal" href="' . $set['homeurl'] .
        '/blogpanel/index.php/act/edit_category/id/' . $cat['id'] .
        '"><i class="fa fa-edit"></i> Edit</a>' . ($cat['permalink'] !=
        'uncategorized' ? ' | <a data-toggle="' . functions::set_modal() .
        '" data-target="#global-modal" href="' . $set['homeurl'] .
        '/blogpanel/index.php/act/edit_category/mod/delete/id/' . $cat['id'] .
        '"><i class="fa fa-times"></i> Hapus</a>' : '') . '</div>';
    echo '</div>';
    ++$i;
}
if ($total > $kmess)
{
    echo '<div class="topmenu">' . functions::display_pagination($home .
        '/blogpanel/index.php/act/manage_categories/', $start, $total, $kmess) .
        '</div>';
}

require (dirname(__file__) . '/../../incfiles/end.php');
