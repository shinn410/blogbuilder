<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');

if (($blog = get_blog()) == false)
{
    header("Location: " . $set['url'] . "/blogpanel");
    exit();
}
if (file_exists(ROOTPATH . 'sites/' . $blog['url'] . '/navigations.dat'))
    $navigations = file_get_contents(ROOTPATH . 'sites/' . $blog['url'] .
        '/navigations.dat');
else
    $navigations = '';
$code = isset($_POST['code']) ? $_POST['code'] : '';
if (isset($_POST['submit']))
{
    if (mb_strlen($code) < 2 or mb_strlen($code) > 5000)
        $error = "Kode minimal 2 dan maksimal 5000 karakter";
    if (empty($error))
    {
        $code = str_replace("^", "", $code);
        if (empty($navigations))
        {
            $navcode = $code;
        }
        else
        {
            $navcode = $code . "^" . $navigations;
        }
        @file_put_contents(ROOTPATH . 'sites/' . $blog['url'] .
            '/navigations.dat', $navcode);
        mysql_query("UPDATE `users` SET `lastpost` = '" . time() .
            "' WHERE `id` = '" . $blog['user_id'] . "'");
        $_SESSION['notice'] = 'Navigasi berhasil dibuat';
        header("location: " . $home .
            "/blogpanel/index.php/act/manage_navigations");
        exit();
    }
    else
    {
        $error = '<div class="alert alert-danger">' . $error . '</div>';
    }
}
$textl = "Membuat Navigasi";
$breadcrumb = functions::breadcrumb(array(
    array('label' => 'Blog Panel', 'url' => '/blogpanel'),
    array('label' => $blog['url'], 'url' => '/blogpanel/index.php/act/dashboard'),
    array('label' => $textl),
    ));
require (dirname(__file__) . '/../../incfiles/head.php');
echo '<form role="form" method="post" action="' . $set['homeurl'] .
    '/blogpanel/index.php/act/create_navigation">';
if (@$error)
    echo $error;
echo '<div class="form-group"><label>Kode</label>' .
    '<textarea class="form-control" rows="' . $set_user['field_h'] .
    '" name="code">' . htmlentities($code) . '</textarea></div>' .
    '<p><button class="btn btn-primary" type="submit" name="submit">Simpan</button></p></form>';
require (dirname(__file__) . '/../../incfiles/end.php');
