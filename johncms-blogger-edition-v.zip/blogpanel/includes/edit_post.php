<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

defined('_IN_JOHNCMS') or die('Error');
$foot = '';

$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;

if (isset($_GET['post_id']))
{
    $post_id = mysql_real_escape_string(trim($_GET['post_id']));

    if ($rights >= 7)
    {
        $cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='" . $post_id .
            "'");
    }
    else
    {
        $cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='" . $post_id .
            "' AND `user_id`='$user_id'");
    }
    if (mysql_num_rows($cpost) == 0)
    {
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo functions::display_error('Postingan yang dipilih tidak benar',
            '<a class="alert-link" href="' . $set['homeurl'] .
            '/blogpanel/index.php/act/manage_posts">' . $lng['back'] . '</a>');
        require (dirname(__file__) . '/../../incfiles/end.php');
        exit;
    }
    $post = mysql_fetch_assoc($cpost);
    $puser = mysql_fetch_array(mysql_query("SELECT `name`,`rights` FROM `users` WHERE `id`='" .
        $post['user_id'] . "'"));
    if ($post['user_id'] != $user_id && $rights <= $puser['rights'])
    {
        require (dirname(__file__) . '/../../incfiles/head.php');
        echo functions::display_error('Kamu tidak dapat memoderasi Postingan ini.');
        require (dirname(__file__) . '/../../incfiles/end.php');
        exit;
    }
    $blog = mysql_fetch_array(mysql_query("SELECT `id`,`url` FROM `blog_sites` WHERE `id`='" .
        $post['site_id'] . "'"));
    switch ($mod)
    {
        case 'delete':
            if (!isset($_SESSION['key']))
                $_SESSION['key'] = md5(time());
            $submit = $_SESSION['key'];
            if (isset($_POST[$submit]))
            {
                mysql_query("DELETE FROM `blog_posts` WHERE `id`='" . $post['id'] .
                    "'");
                mysql_query("DELETE FROM `blog_comments` WHERE `post_id`='" . $post['id'] .
                    "'");
                mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='" .
                    $post['site_id'] . "' AND `permalink`='" .
                    mysql_real_escape_string($post['category']) . "'");
                unset($_SESSION['key']);
                $_SESSION['notice'] = 'Posting berhasil dihapus';
                header("Location: " . $home .
                    "/blogpanel/index.php/act/manage_posts");
                exit;
            }
            $textl = "Hapus Posting";
            require (dirname(__file__) . '/../../incfiles/head.php');
            echo '<form method="post" action="' . $set['homeurl'] .
                '/blogpanel/index.php/act/edit_post/mod/delete/post_id/' . $post_id .
                '"><div class="alert alert-warning">Anda yakin akan menghapus Postingan ini?</div>' .
                '<p><button class="btn btn-danger" class="btn btn-primary" type="submit" name="' .
                $submit .
                '">Ya</button> <a class="btn btn-default" data-dismiss="modal" ' .
                'href="javascript:window.history.back()">Tidak</a></p></form>';
            require (dirname(__file__) . '/../../incfiles/end.php');
            break;

        default:
            $title = isset($_POST['title']) ? $_POST['title'] : trim($post['title'], true);
            $description = isset($_POST['description']) ? $_POST['description'] :
                $post['description'];
            $cat = isset($_POST['category']) ? $_POST['category'] : $post['category'];
            $tags = isset($_POST['tags']) ? strtolower($_POST['tags']) : $post['tags'];
            $privacy = isset($_POST['privacy']) ? ($_POST['privacy'] ==
                'publics' ? 'publics' : 'friends') : $post['privacy'];

            if (isset($_POST['publish']))
            {
                $tags = SaveTags($tags);
                $key = $_POST['key'];
                $time_published = strtotime(str_replace('/', '-', $_POST['time_published']) .
                    ':00');
                $default_time = strtotime(str_replace('/', '-', $_POST['default_time']) .
                    ':00');
                if ($time_published > time())
                {
                    $waktu = time();
                    $draft = "no";
                }
                elseif ($time_published < $default_time)
                {
                    $waktu = $post['time'];
                    $draft = $post['draf'];
                }
                else
                {
                    $waktu = $time_published - $shift;
                    $draft = "yes";
                }
                $edit = intval($post['edit']);
                if ($time_published != $default_time && $edit >= 5)
                {
                    $waktu = $post['time'];
                    $draft = $post['draft'];
                }
                else
                    $edit = $edit + 1;

                if (empty($_SESSION['key']) or $_SESSION['key'] != $key)
                    $error = "Session tidak benar.";
                $bc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='" .
                    mysql_real_escape_string($post['site_id']) .
                    "' AND `user_id`='" . $post['user_id'] .
                    "' AND `permalink`='" . mysql_real_escape_string($cat) . "'");
                if (mysql_num_rows($bc) == 0)
                    $error = "Kategori yang dipilih tidak benar.";
                if (mb_strlen($title) < 2 or mb_strlen($title) > 100)
                    $error = "Judul harus 2 s/d 100 karakter.";
                if (mb_strlen($description) < 10)
                    $error = "Deskripsi minimal 10 karakter";
                if (empty($error))
                {

                    mysql_query("UPDATE `blog_posts` SET `title` = '" .
                        mysql_real_escape_string($title) .
                        "', `description` = '" . mysql_real_escape_string($description) .
                        "', `category` = '" . mysql_real_escape_string($cat) .
                        "', `tags` = '" . mysql_real_escape_string($tags) .
                        "', `privacy` = '" . mysql_real_escape_string($privacy) .
                        "', `draft` = '" . mysql_real_escape_string($draft) .
                        "', `edit` = '" . mysql_real_escape_string($edit) .
                        "', `time` = '" . mysql_real_escape_string($waktu) .
                        "' WHERE `id`='" . $post['id'] . "' AND `user_id`='" . $post['user_id'] .
                        "'");
                    if ($cat != $post['category'])
                    {
                        mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='" .
                            mysql_real_escape_string($post['site_id']) .
                            "' AND `user_id`='" . $post['user_id'] .
                            "' AND `permalink`='" . mysql_real_escape_string($post['category']) .
                            "'");

                        mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='" .
                            mysql_real_escape_string($post['site_id']) .
                            "' AND `user_id`='" . $post['user_id'] .
                            "' AND `permalink`='" . mysql_real_escape_string($cat) .
                            "'");
                    }
                    if ($post['user_id'] == $user_id)
                    {
                        $_SESSION['notice'] = 'Posting berhasil dipublikasikan';
                        header("location: " . $home .
                            "/blogpanel/index.php/act/manage_posts");
                        exit();
                    }
                    else
                        $result =
                            '<div class="alert alert-success">Posting berhasil diperbarui.<br />' .
                            '<a class="alert-link" href="//' . $blog['url'] .
                            '/' . $post['permalink'] .
                            '.html">Lihat posting</a> atau kunjungi profile <a class="alert-link" href="' .
                            $home . '/users/profile.php/user/' . $post['user_id'] .
                            '">' . $puser['name'] . '</a></div>';
                }
                else
                {
                    $result = '<div class="alert alert-danger">' . $error .
                        '</div>';
                }
            }
            $textl = "Edit Posting";
            $breadcrumb = functions::breadcrumb(array(
                array('label' => 'Blog Panel', 'url' => '/blogpanel'),
                array('label' => $blog['url'], 'url' =>
                        '/blogpanel/index.php/act/dashboard'),
                array('label' => 'Kelola Posting', 'url' =>
                        '/blogpanel/index.php/act/manage_posts'),
                array('label' => $textl),
                ));
            require (dirname(__file__) . '/../../incfiles/head.php');
            echo '<form method="post" action="' . $set['homeurl'] .
                '/blogpanel/index.php/act/edit_post/post_id/' . $post_id .
                '" name="form1">';
            if (isset($result))
                echo $result;
            echo '<div class="form-group"><label>Judul</label>' .
                '<input class="form-control" type="text" name="title" value="' .
                htmlspecialchars($title) . '"/></div>';
            echo '<div class="form-group"><label>Deskripsi</label>' . ($post['mode'] ==
                'bbcode' ? '<p>' . bbcode::auto_bb('form1', 'description', 1) .
                '</p>' : '') .
                '<textarea class="form-control" rows="8" name="description">' .
                htmlspecialchars($description) . '</textarea></div>';

            echo '<div class="form-group"><label>Kategori</label>' .
                '<select class="form-control" name="category">';
            $bcats = mysql_query("SELECT `name`,`permalink` FROM `blog_categories` WHERE `site_id`='" .
                $blog['id'] . "'");
            while ($bcat = mysql_fetch_array($bcats))
            {
                echo '<option value="' . $bcat['permalink'] . '"' . ($cat == $bcat['permalink'] ?
                    ' selected="selected"' : '') . '>' . htmlspecialchars($bcat['name']) .
                    '</option>';
            }
            echo '</select></div><div class="form-group"><label>Tags</label>' .
                '<input class="form-control" type="text" name="tags" value="' .
                htmlspecialchars($tags) .
                '"/><p class="help-block">Pisahkan dengan koma (,)</p></div>' .
                '<div class="radio"><label><input type="radio" name="privacy" value="publics"' . ($privacy ==
                "publics" ? ' checked="checked"' : '') .
                '> Semua orang boleh melihat postingan ini</label></div>' .
                '<div class="radio"><label><input type="radio" name="privacy" value="friends"' . ($privacy ==
                "friends" ? ' checked="checked"' : '') .
                '> Hanya teman yang boleh melihat postingan ini</label></div>';
            $taim = time();
            $tm = explode("-", date("d-F-Y-H-i-s", ($taim + $shift)));
            echo '<div class="form-group"><label>Waktu penerbitan</label>' .
                '<div class="input-group" id="datemask"><div class="input-group-addon">' .
                '<i class="fa fa-calendar"></i></div>' .
                '<input type="text" class="form-control" name="time_published" ' .
                'data-inputmask="\'alias\': \'datetime\'" value="' . date("d/m/Y H:i",
                ($post['time'] + $shift)) .
                '" data-mask="1" disabled="disabled" maxlength="16"/>' .
                '</div><!-- /.input group --></div><!-- /.form group -->';
            echo '<input type="hidden" name="default_time" value="' . date("d/m/Y H:i",
                ($post['time'] + $shift)) . '">';
            $_SESSION['key'] = md5(time());
            echo '<input type="hidden" name="key" value="' . $_SESSION['key'] .
                '"></p><p><input class="btn btn-primary" type="submit" name="publish" value="Simpan"/>' .
                '</p></form>';
            $foot .= '<script src="' . $home .
                '/theme/default/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>' .
                '<script src="' . $home .
                '/theme/default/js/plugins/input-mask/jquery.inputmask.date.extensions.js" ' .
                'type="text/javascript"></script>' . '<script src="' . $home .
                '/theme/default/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript">' .
                '</script>';
            $jquery .=
                '$("[data-mask]").inputmask();$("#datemask").click(function(event){event.preventDefault();' .
                '$("#datemask input").prop("disabled",false);});';
            require (dirname(__file__) . '/../../incfiles/end.php');
    }
}
else
{
    header("location: " . $home . "/blogpanel/index.php/act/manage_posts");
}
