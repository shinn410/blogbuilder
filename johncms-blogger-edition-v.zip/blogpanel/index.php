<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * 
 * About Modifier
 * @package     JohnCMS Blogger Edition
 * @version     VERSION.txt (see attached file)
 * @author      Achunk JealousMan
 * @link        http://fb.com/achunks
 * @phone       +62818118061
 */

define('_IN_JOHNCMS', 1);
$headmod = "blogpanel";

require ('../incfiles/core.php');

if (!$user_id)
{
    header('Location: ' . $set['url'] . '/');
    exit;
}
if (!$set['mod_blog'] && $rights < 7)
{
    include_once ('../incfiles/head.php');
    echo functions::display_error('Akses blog panel ditutup!');
    include_once ('../incfiles/end.php');
    exit;
}
elseif (isset($ban['101']))
{
    include_once ('../incfiles/head.php');
    echo functions::display_error('Kamu tidak diijinkan untuk mengelola Blog!');
    include_once ('../incfiles/end.php');
    exit;
}

function get_blog($id = false)
{
    global $datauser;

    if ($id == false)
        $id = isset($_SESSION['blog_id']) ? abs(intval($_SESSION['blog_id'])) : false;
    else
        $id = abs(intval($id));
    if ($id == false)
        return false;
    if ($datauser['rights'] == 7 || $datauser['rights'] == 9)
    {
        $check = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='" .
            mysql_real_escape_string($id) . "'");
    }
    else
    {
        $check = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='" .
            mysql_real_escape_string($id) . "' AND `user_id`='" . $datauser['id'] .
            "' AND `mod_reg`='no' AND `block`='no'");
    }
    if (mysql_num_rows($check) == 1)
    {
        $blog = mysql_fetch_array($check);
        if ($blog['user_id'] != $datauser['id'])
        {
            $user = mysql_fetch_array(mysql_query("SELECT `rights` FROM `users` WHERE `id`='" .
                $blog['user_id'] . "'"));
            if ($datauser['rights'] <= $user['rights'])
                return false;
        }
        return $blog;
    }
    else
    {
        return false;
    }
}

function SaveTags($var)
{
    $var = strtolower($var);
    $vars = preg_split("/[\s,]+/", $var);
    $tags = array();
    foreach ($vars as $tag)
    {
        $tags[] = str_replace('-', ' ', functions::permalink($tag));
    }
    return implode(',', $tags);
}

$array = array(
    'create_category',
    'create_navigation',
    'create_blog',
    'dashboard',
    'delete_blog',
    'edit_category',
    'edit_navigation',
    'edit_post',
    'files',
    'manage_categories',
    'manage_comments',
    'manage_navigations',
    'manage_posts',
    'settings',
    'site_explorer',
    'switch',
    'template',
    'upload_post',
    'write_post',
    );
$i = 0;
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' .
    $array[$key] . '.php'))
{
    require ('includes/' . $array[$key] . '.php');
}
else
{
    require ('includes/index.php');
}
